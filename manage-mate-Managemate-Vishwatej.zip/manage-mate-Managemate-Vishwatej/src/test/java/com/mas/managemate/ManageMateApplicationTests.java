package com.mas.managemate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManageMateApplicationTests {

	@Test
	void contextLoads() {
	}

}
