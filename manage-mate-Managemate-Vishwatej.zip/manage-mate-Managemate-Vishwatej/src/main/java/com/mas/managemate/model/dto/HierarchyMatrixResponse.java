package com.mas.managemate.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class HierarchyMatrixResponse {

    private String message;
    private boolean response;
    private List<Hierarchy> data;


    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class Hierarchy {
        @JsonProperty("HOD_No")
        private String hodNo;

        @JsonProperty("Level")
        private String level;

        @JsonProperty("lv")
        private String lv;

        @JsonProperty("ImagePath")
        private String imagePath;

        @JsonProperty("EmployeeNo")
        private String employeeNo;

        @JsonProperty("EmployeeName")
        private String employeeName;
    }
}
