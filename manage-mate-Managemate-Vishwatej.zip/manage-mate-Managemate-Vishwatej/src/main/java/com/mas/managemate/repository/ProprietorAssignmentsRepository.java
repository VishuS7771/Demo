package com.mas.managemate.repository;

import com.mas.managemate.model.entity.ProprietorAssignments;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProprietorAssignmentsRepository extends JpaRepository<ProprietorAssignments, Long> {

//    List<ProprietorAssignments> findByTray_TrayId(long trayId);

    List<ProprietorAssignments> findByStatus_statusIdAndSubStatus_subStatusId(long statusId, long subStatusId);

    List<ProprietorAssignments> findByProprietor_ProprietorId(long proprietorId);

}
