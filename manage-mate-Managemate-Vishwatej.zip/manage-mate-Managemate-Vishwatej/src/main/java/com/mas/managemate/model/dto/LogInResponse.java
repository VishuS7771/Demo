package com.mas.managemate.model.dto;

import com.mas.managemate.model.entity.MenuPermission;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class LogInResponse {

    private String employeeNo;

    private boolean isLogin;

    private String message;

    private String jwt;

    private EmployeeProfileResponse.EmployeeData employeeData;

    private MenuPermission menuPermission;

    private boolean isMenuPermissionAccess;
}
