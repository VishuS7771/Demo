package com.mas.managemate.model.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.mas.managemate.model.entity.ProprietorMaster;
import com.mas.managemate.model.entity.StatusDefinitions;
import com.mas.managemate.model.entity.SubStatusDefinitions;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProprietorAssignmentsDto {

    private long proprietorMappingId;

    private StatusDefinitionsDto statusDefinitionsDto;

    private SubStatusDefinitionsDto subStatusDefinitionsDto;

    private ProprietorMasterDto proprietorMasterDto;

    private TrayMasterDto trayMasterDto;

    private int isActive;

    private long createdBy;

    @JsonFormat(pattern = "yyyy-dd-MM HH:mm:ss", timezone = "Asia/Kolkata")
    private Date createdOn;
}
