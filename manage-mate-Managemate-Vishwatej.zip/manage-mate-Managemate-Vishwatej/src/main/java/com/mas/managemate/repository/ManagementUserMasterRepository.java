package com.mas.managemate.repository;

import com.mas.managemate.model.entity.ManagementUserMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ManagementUserMasterRepository extends JpaRepository<ManagementUserMaster,Long>
{
    boolean existsByManagementUserId(long managementUserId);
}
