package com.mas.managemate.service;

import com.mas.managemate.model.dto.GeneralMeetingReportDTO;

public interface GeneralMeetingRepostService {

    public void generateReport(GeneralMeetingReportDTO generalMeetingReportDTO,String path) throws Exception;
}
