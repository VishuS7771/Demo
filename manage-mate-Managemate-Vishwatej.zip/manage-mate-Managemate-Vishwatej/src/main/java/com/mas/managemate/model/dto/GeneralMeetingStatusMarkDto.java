package com.mas.managemate.model.dto;

import com.mas.managemate.model.entity.GeneralMeeting;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class GeneralMeetingStatusMarkDto
{
    private long generalMeetingStatusId;

    private String status;

    private Date markedOn;

    private String markedBy;

    private GeneralMeeting generalMeeting;
}
