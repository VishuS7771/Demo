package com.mas.managemate.repository;

import com.mas.managemate.model.entity.GeneralMeeting;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface GeneralMeetingRepository extends JpaRepository<GeneralMeeting,Long> {
}
