package com.mas.managemate.repository;

import com.mas.managemate.model.entity.TaskTimelines;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TaskTimeLinesRepository extends JpaRepository<TaskTimelines,Long> {

//    @Query("SELECT tt FROM TaskTimelines tt WHERE tt.tasks.id where :taskId")
//    List<TaskTimelines> findByTaskId(@Param("taskId") Long taskId);

    @Query("SELECT tt FROM TaskTimelines tt WHERE tt.tasks.id IN :taskIds")
    List<TaskTimelines> findByTaskIds(@Param("taskIds") List<Long> taskIds);

    TaskTimelines findByTasks_Id(Long taskId);

}
