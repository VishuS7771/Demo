package com.mas.managemate.model.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "general_meeting_task_timeline",schema = "managemate")
public class GeneralMeetingTaskTimeline {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long generalMeetingTaskTimeline;
    private String activity;
    private Date completionDate;
    private Date markDate;
    private String markedBy;
    private String remarks;
    @ManyToOne
    @JoinColumn(name = "general_meeting_task_id")
    private GeneralMeetingTasks generalMeetingTasks;

}
