package com.mas.managemate.service;

import com.mas.managemate.model.dto.*;
import com.mas.managemate.model.entity.GeneralMeetingStatusMark;
import com.mas.managemate.model.entity.GeneralMeetingTasks;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

public interface GeneralMeetingService {

    void markStatus(MeetingStatusMarkDto meetingStatusMarkDto, MultipartFile file) throws Exception;

    GeneralMeetingDto createGeneralMeeting(GeneralMeetingDto generalMeetingDto);

    List<GeneralMeetingDto> getAllGeneralMeetings(Long employeeNo) throws Exception;

    GeneralMeetingDto updateMeeting(Long generalMeetingId, GeneralMeetingDto generalMeetingDto);

    void rescheduleMeeting(Long generalMeetingId, GeneralMeetingDto generalMeetingDto);

    List<GeneralMeetingTaskDto> getMeetingTask(long meetingId) throws Exception;

    void taskRespond(TaskRespondDto taskRespondDto,MultipartFile file) throws Exception;

    void taskMarking(TaskRespondDto taskRespondDto) throws Exception;

    void saveMeetingTask(List<GeneralMeetingTaskDto> generalMeetingTaskDto);

    void editTask(long taskId, GeneralMeetingTaskDto generalMeetingTaskDto);

    List<TaskRespondDto> getRespondAndMarking(long meetingTaskId);

    GeneralMeetingDto getMeetingById(Long generalMeetingId);

    void sendMeetingLink(long meetingId);

    GeneralMeetingTimelineDto getGeneralMeetingTimeline(long id);

    List<GeneralMeetingTaskDto> getGeneralMeetingTaskByEmp(Long id, Boolean flag) throws Exception;

}
