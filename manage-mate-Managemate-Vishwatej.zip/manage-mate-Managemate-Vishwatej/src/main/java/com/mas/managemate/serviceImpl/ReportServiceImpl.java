package com.mas.managemate.serviceImpl;

import com.alibaba.excel.EasyExcel;
import com.mas.managemate.model.dto.*;
import com.mas.managemate.model.entity.Tasks;
import com.mas.managemate.repository.TasksRepository;
import com.mas.managemate.service.ReportService;
import com.mas.managemate.util.ApiClient;
import com.mas.managemate.util.CustomCellStyleHandler;
import com.mas.managemate.util.DateConverter;

import org.apache.poi.openxml4j.util.ZipSecureFile;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

import java.io.File;
import java.io.FileOutputStream;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.*;

@Service
public class ReportServiceImpl implements ReportService {

    @Autowired
    private TaskServiceImpl taskServiceImpl;

    @Autowired
    private TasksRepository tasksRepository;

    @Autowired
    private ApiClient apiClient;

    @Override
    public ByteArrayResource generateExcel(ReportDto reportDto,String filePath) throws Exception {
        List<Tasks> filteredTasks=new ArrayList<>();

        if (reportDto.getFromDate() != null && reportDto.getToDate() != null) {
           Date fromDate = reportDto.getFromDate();
            LocalDateTime fromLocalDate = fromDate.toInstant()
                    .atZone(ZoneId.systemDefault())
                    .toLocalDateTime();
            Date toDate = reportDto.getToDate();
            LocalDateTime toLocalDate = toDate.toInstant()
                    .atZone(ZoneId.systemDefault())
                    .toLocalDateTime();
            filteredTasks= tasksRepository.findAll().stream()
                    .filter(task -> !toLocalDate.isBefore(fromLocalDate) &&
                            !fromLocalDate.isAfter(toLocalDate))
                    .toList();
            filteredTasks =filteredTasks.stream().filter(a->a.getParentTask()==null).toList();
        }else{
            Tasks tasks = tasksRepository.findByTaskId(reportDto.getTaskId());
            filteredTasks.add(tasks);
        }


        if (filteredTasks.isEmpty()) {
            throw new RuntimeException("Task not found with Task ID");
        }

        List<TasksDto> tasksDtos = taskServiceImpl.mapData(filteredTasks);

        // Prepare the data to be written into Excel
        List<List<String>> data = new ArrayList<>();

        List<String> headers = Arrays.asList(
                "Sr No", "Task ID", "Task Name", "Module", "Requirement Type", "Requirement Subject",
                "Platform", "Priority", "Stakeholder Name", "BA Name", "Developer Name", "Stage Proprietor", "Status",
                "Sub-Status", "Enroll Date", "Status Date", "BA(Pre-development)-Start Date", "BA(Pre-development)-End-date",
                "Development - Start Date", "Development-End Date", "BA(Testing)-Start Date", "BA(Testing)-End Date",
                "Completed Date", "BA(Pre-development)-Days", "Development Days", "BA(Testing)-Days"
        );

        // Add header row
        data.add(headers);

        // Populate data rows
        for (int i = 0; i < tasksDtos.size(); i++) {
            TasksDto dto = tasksDtos.get(i);
            List<String> row = new ArrayList<>();
            row.add(String.valueOf(i + 1)); // Sr No
            row.add(dto.getTaskId()); // Task ID
            row.add(dto.getTaskName()); // Task Name
            row.add(dto.getModuleName()); // Module
            row.add(dto.getRequirementType()); // Requirement Type
            row.add(dto.getRequirementSubject()); // Requirement Subject
            row.add(dto.getPlatform()); // Platform
            row.add(dto.getTaskPriority()); // Priority

            // Fetch stakeholder name
            String stakeholderName = apiClient.getEmployeeProfile(String.valueOf(dto.getRaisedBy()))
                    .getData().get(0).getEmployeeFullName();
            row.add(stakeholderName); // Stakeholder Name

            // Fetch task assignments (BA & Dev names)
            List<TaskAssignmentDto> taskAssignmentDtos = dto.getTaskAssignmentHistoryDto();
            List<String> baList = new ArrayList<>();
            List<String> devList = new ArrayList<>();

            for (TaskAssignmentDto a : taskAssignmentDtos) {
                try {
                    EmployeeProfileResponse.EmployeeData employeeData =
                            apiClient.getEmployeeProfile(String.valueOf(a.getEmployeeId()))
                                    .getData().get(0);
                    if (employeeData.getDepartment().contains("Project Management")) {
                       if(!baList.contains(employeeData.getEmployeeFullName())){
                           baList.add(employeeData.getEmployeeFullName());
                        }

                    } else if (employeeData.getDepartment().contains("Software Development")) {
                        if(!devList.contains(employeeData.getEmployeeFullName())){
                            devList.add(employeeData.getEmployeeFullName());
                        }

                    }
                } catch (Exception e) {
                    System.err.println("Error fetching employee data for ID: " + a.getEmployeeId());
                    e.printStackTrace();
                }
            }

            row.add(String.join(", ", baList)); // BA Name
            row.add(String.join(", ", devList)); // Developer Name


            // Fetch status data from timeline
            List<TaskTimelineDto> timelineDtos = dto.getTaskTimelineDto();

            if (timelineDtos == null || timelineDtos.isEmpty()) {
                // Set all values to "N/A" when the list is null or empty
                row.add("N/A"); // Stage Proprietor
                row.add("N/A"); // Status
                row.add("N/A"); // Sub-Status
                row.add(dto.getDateAndTime() != null ? dto.getDateAndTime().toString() : "N/A"); // Enroll Date
                row.add("N/A"); // Status Date
            } else {
                Optional<TaskTimelineDto> latestTimeline = timelineDtos.stream()
                        .max(Comparator.comparing(TaskTimelineDto::getDateAndTime));

                if (latestTimeline.isPresent()) {
                    row.add(latestTimeline.get().getProprietorAssignmentsDto() != null &&
                            latestTimeline.get().getProprietorAssignmentsDto().getProprietorMasterDto() != null
                            ? latestTimeline.get().getProprietorAssignmentsDto().getProprietorMasterDto().getProprietorName()
                            : "N/A"); // Stage Proprietor

                    row.add(latestTimeline.get().getStatusDefinitionsDto() != null
                            ? latestTimeline.get().getStatusDefinitionsDto().getStatus()
                            : "N/A"); // Status

                    row.add(latestTimeline.get().getSubStatusDefinitionsDto() != null
                            ? latestTimeline.get().getSubStatusDefinitionsDto().getSubStatus()
                            : "N/A"); // Sub-Status

                    row.add(dto.getDateAndTime() != null ? dto.getDateAndTime().toString() : "N/A"); // Enroll Date
                    row.add(latestTimeline.get().getDateAndTime() != null
                            ? DateConverter.convertDateTime(latestTimeline.get().getDateAndTime())
                            : "N/A"); // Status Date
                } else {
                    // If no valid latest timeline is found, set all to "N/A"
                    row.add("N/A"); // Stage Proprietor
                    row.add("N/A"); // Status
                    row.add("N/A"); // Sub-Status
                    row.add(dto.getDateAndTime() != null ? dto.getDateAndTime().toString() : "N/A"); // Enroll Date
                    row.add("N/A"); // Status Date
                }
            }
            // Fetch various timeline dates
            TaskTimelineDto baStartTimeline = findTimelineByStatusAndSubStatus(timelineDtos, "In-Process", "Requirement Understanding");
            TaskTimelineDto baEndTimeline = findTimelineByStatusAndSubStatus(timelineDtos, "In-Process", "SRS-Submitted");
            TaskTimelineDto devEndTimeline = findTimelineByStatusAndSubStatus(timelineDtos, "In-Process", "Development-Completed");
            TaskTimelineDto testingEndTimeline = findTimelineByStatusAndSubStatus(timelineDtos, "In-Process", "Testing-SRS-Submitted");
            TaskTimelineDto completedTimeLine = findTimelineByStatusAndSubStatus(timelineDtos, "Completed", "Implemented");

            row.add(baStartTimeline!=null?DateConverter.convertDate(baStartTimeline.getDateAndTime()).toString():"N/A");//BA(Pre-development)-Start Date
            row.add(baEndTimeline!=null?DateConverter.convertDate(baEndTimeline.getDateAndTime()).toString():"N/A");//BA(Pre-development)-End-date
            row.add(devEndTimeline!=null?DateConverter.convertDate(devEndTimeline.getDateAndTime()).toString():"N/A"); // Dev Start Date
            row.add(devEndTimeline!=null?DateConverter.convertDate(devEndTimeline.getDateAndTime()).toString():"N/A"); // Dev End Date
            row.add(testingEndTimeline!=null?DateConverter.convertDate(testingEndTimeline.getDateAndTime()).toString():"N/A"); // BA Testing Start
            row.add(testingEndTimeline!=null?DateConverter.convertDate(testingEndTimeline.getDateAndTime()).toString():"N/A"); // BA Testing End
            row.add(completedTimeLine!=null?DateConverter.convertDate(completedTimeLine.getDateAndTime()).toString():"N/A"); // Completed Date

            // Calculate duration in days
            row.add(String.valueOf(getDaysBetween(baStartTimeline, baEndTimeline)));
            row.add(String.valueOf(getDaysBetween(baEndTimeline, devEndTimeline)));
            row.add(String.valueOf(getDaysBetween(devEndTimeline, testingEndTimeline)));

            // Add row to data
            data.add(row);
        }

        // Write to ByteArrayOutputStream
        ByteArrayOutputStream outStream = new ByteArrayOutputStream();
       // exportData(outStream,data);
        EasyExcel.write(outStream)
                .registerWriteHandler(new CustomCellStyleHandler())
                .sheet("Project Tracker")
                .doWrite(data);

        ByteArrayResource resource;
        ZipSecureFile.setMinInflateRatio(0.001);
        try (ByteArrayOutputStream finalStream = new ByteArrayOutputStream()) {
            XSSFWorkbook workbook = new XSSFWorkbook(new ByteArrayInputStream(outStream.toByteArray()));
            XSSFSheet sheet = workbook.getSheetAt(0);

            // Auto-adjust all column widths
            for (int colIndex = 0; colIndex < headers.size(); colIndex++) {
                sheet.autoSizeColumn(colIndex);
            }
            workbook.write(finalStream);
            workbook.close();

            // Save to file
            File directory = new File(filePath);
            if (!directory.exists()) {
                directory.mkdirs();
            }
            File file = new File(filePath + "\\Project_Tracker.xlsx");
            try (FileOutputStream fileOut = new FileOutputStream(file)) {
                finalStream.writeTo(fileOut);
            }
            resource = new ByteArrayResource(java.nio.file.Files.readAllBytes(file.toPath()));
        }

        return resource;
    }

    private TaskTimelineDto findTimelineByStatusAndSubStatus(List<TaskTimelineDto> timelines, String status, String subStatus) {
        if(timelines==null){
            return null;
        }
        return timelines.stream()
                .filter(a -> status.equalsIgnoreCase(a.getStatusDefinitionsDto().getStatus()) &&
                        subStatus.equalsIgnoreCase(a.getSubStatusDefinitionsDto().getSubStatus()))
                .findFirst()
                .orElse(null);
    }

    private long getDaysBetween(TaskTimelineDto start, TaskTimelineDto end) {
        if (start == null || start.getDateAndTime() == null || end == null || end.getDateAndTime() == null) {
            return 0; // or throw an exception if necessary
        }
        return ChronoUnit.DAYS.between(convertToLocalDate(start.getDateAndTime()),convertToLocalDate(end.getDateAndTime()) ) + 1;
    }

    public static LocalDate convertToLocalDate(Date date) {
        return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    }


}
