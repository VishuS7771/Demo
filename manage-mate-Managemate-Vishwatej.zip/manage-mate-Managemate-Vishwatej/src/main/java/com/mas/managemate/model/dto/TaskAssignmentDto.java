package com.mas.managemate.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TaskAssignmentDto {

    private long assignTaskId;

    private TasksDto task;

    private long employeeId;

    private String employeeNameAndId;

    private Date assignDate;

    private String remarks;

    private long assignedBy;

    private String assignedByNameAndId;

    private int isAssigned;

    private String attachmentPath;
}
