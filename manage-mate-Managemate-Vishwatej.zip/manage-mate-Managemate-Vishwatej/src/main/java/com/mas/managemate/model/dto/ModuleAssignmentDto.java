package com.mas.managemate.model.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ModuleAssignmentDto {
    private long moduleMappingId;
    private String module;
    private long moduleId;
    private long employeeId;
    private int isActive;
    private long createdBy;
    @JsonFormat(pattern = "yyyy-dd-MM HH:mm:ss", timezone = "Asia/Kolkata")
    private Date createdOn;
    private String mappedEmployee;
}
