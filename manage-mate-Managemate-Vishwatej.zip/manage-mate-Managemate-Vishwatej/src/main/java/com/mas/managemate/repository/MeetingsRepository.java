package com.mas.managemate.repository;

import com.mas.managemate.model.entity.Meetings;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface MeetingsRepository extends JpaRepository<Meetings,Long> {
    Optional<Meetings> findByMeetingId(String meetingId);

    List<Meetings> findByTasks_TaskId(String taskId);

    List<Meetings> findByTasks_Id(long taskId);

    @Query("SELECT tt FROM Meetings tt WHERE tt.tasks.id IN :taskIds")
    List<Meetings> findByTasks_TaskIds(@Param("taskIds") List<Long> taskIds);
}
