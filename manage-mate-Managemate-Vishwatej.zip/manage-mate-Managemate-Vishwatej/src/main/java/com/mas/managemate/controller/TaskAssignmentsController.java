package com.mas.managemate.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mas.managemate.model.dto.ApiResponse;
import com.mas.managemate.model.dto.TaskAssignmentDto;
import com.mas.managemate.model.dto.TasksDto;
import com.mas.managemate.service.TaskAssignmentsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/task-assignments")
@Slf4j
public class TaskAssignmentsController {

    @Autowired
    private TaskAssignmentsService taskAssignmentsService;

    @PostMapping("/assign")
    public ApiResponse<?> assignTask(@RequestParam("taskAssignmentHistoryDto") String taskAssignmentJson, @RequestParam(value = "file", required = false) MultipartFile file) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            TaskAssignmentDto taskAssignmentDto = objectMapper.readValue(taskAssignmentJson, TaskAssignmentDto.class);
            TaskAssignmentDto taskAssignments = taskAssignmentsService.assignTask(taskAssignmentDto,file);
            return new ApiResponse<>(taskAssignments, String.format("Task assigned to employee ID %d", taskAssignmentDto.getEmployeeId()), HttpStatus.CREATED);
        } catch (Exception e) {
            log.error("Error while assigning task to employee ID  {}" ,e.getMessage(), e);
            return new ApiResponse<>(null, "Failed to assign task: " + e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }


    @GetMapping("/get-by-taskId/{taskId}")
    public ApiResponse<?> getByTaskId(@PathVariable long taskId){
        try {
            List<TaskAssignmentDto> taskAssignmentDtos =taskAssignmentsService.getByTaskId(taskId);
            return new ApiResponse<>(taskAssignmentDtos,"fetch Task Assignments by Task Id Successful",HttpStatus.OK);
        }catch (Exception e){
            log.error("Failed to get task assignment by Task Id {}:{}",taskId,e.getMessage());
            return new ApiResponse<>(e.getMessage(),"Failed to get task assignment by Task Id "+e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/get-task-assignment/{empId}")
    public ApiResponse<?> getTaskListForMeeting(@PathVariable long empId){
        try{
            List<TasksDto> tasksDtos =taskAssignmentsService.getTaskListForMeeting(empId);
            return new ApiResponse<>(tasksDtos,"Fetch task for meeting by assigned employee successful",HttpStatus.OK);
        }catch (Exception e){
            log.error("Failed to get task list for Meeting {}",e.getMessage());
            return new ApiResponse<>(e.getMessage(),"Failed to get task list for Meeting "+e.getMessage(), HttpStatus.BAD_REQUEST);

        }
    }

}
