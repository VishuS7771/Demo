package com.mas.managemate.model.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Entity
@Table(name = "EmailNotificationsHistory", schema = "managemate")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class EmailNotificationsHistory {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "objectId")
    private long objectId;

    @Column(name = "object")
    private String object;

    @Column(name = "emailTo")
    private String emailTo;

    @Column(name = "emailFrom")
    private String emailFrom;

    @Column(name = "emailCc")
    private String emailCc;

    @Column(name = "emailSubject")
    private String emailSubject;

    @Column(name = "emailContent")
    private String emailContent;

    @Column(name = "sentDateTime")
    private Date sentDateTime;
}
