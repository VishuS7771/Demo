package com.mas.managemate.model.mapper;

import com.mas.managemate.model.dto.ProprietorAssignmentsDto;
import com.mas.managemate.model.dto.ProprietorMasterDto;
import com.mas.managemate.model.entity.ProprietorAssignments;
import com.mas.managemate.model.entity.ProprietorMaster;
import lombok.extern.slf4j.Slf4j;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Slf4j
@Mapper(componentModel = "spring")
public abstract class ProprietorMapper {

    /* This is below method using Proprietor Assignments API */
    @Mapping(source = "statusDefinitionsDto", target = "status")
    @Mapping(source = "subStatusDefinitionsDto", target = "subStatus")
    @Mapping(source = "proprietorMasterDto", target = "proprietor")
    @Mapping(source = "trayMasterDto", target = "tray")
    public abstract ProprietorAssignments mapToProprietorAssignment(ProprietorAssignmentsDto proprietorAssignmentsDto);

    @Mapping(source = "status", target = "statusDefinitionsDto")
    @Mapping(source = "subStatus", target = "subStatusDefinitionsDto")
    @Mapping(source = "proprietor", target = "proprietorMasterDto")
    @Mapping(source = "tray", target = "trayMasterDto")
    public abstract ProprietorAssignmentsDto mapToProprietorAssignmentsDto(ProprietorAssignments proprietorAssignments);

    public  abstract List<ProprietorMasterDto> mapToProprietorMaster(List<ProprietorMaster> proprietorMaster);

}
