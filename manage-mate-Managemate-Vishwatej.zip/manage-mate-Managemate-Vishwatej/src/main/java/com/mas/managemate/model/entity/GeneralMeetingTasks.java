package com.mas.managemate.model.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "general_meeting_tasks",schema = "managemate")
public class GeneralMeetingTasks implements Comparable<GeneralMeetingTasks> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long generalMeetingTaskId;

    private String taskName;

    private String remark;

    private Date targetDate;

    private Date createdOn;

    private String status;

    private String createdBy;

    @ManyToOne
    @JoinColumn(name = "general_meeting_id",referencedColumnName = "id")
    private GeneralMeeting generalMeeting;

    @Override
    public int compareTo(GeneralMeetingTasks meetingTasks) {
        if (this.generalMeetingTaskId == null && meetingTasks.generalMeetingTaskId == null) {
            return 0;
        } else if (this.generalMeetingTaskId == null) {
            return -1; // this comes before
        } else if (meetingTasks.generalMeetingTaskId == null) {
            return 1; // this comes after
        }
        return this.generalMeetingTaskId.compareTo(meetingTasks.generalMeetingTaskId);
    }
}
