package com.mas.managemate.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MeetingStatusMarkResponseDto {
    private String meetingName;
    private String status;
    private Date markedOn;
    private String markedBy;
}
