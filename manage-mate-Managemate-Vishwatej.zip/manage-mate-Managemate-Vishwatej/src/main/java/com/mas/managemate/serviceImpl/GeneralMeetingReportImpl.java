package com.mas.managemate.serviceImpl;

import com.mas.managemate.model.dto.*;
import com.mas.managemate.model.entity.GeneralMeeting;
import com.mas.managemate.model.entity.GeneralMeetingTaskTimeline;
import com.mas.managemate.model.entity.GeneralMeetingTasks;
import com.mas.managemate.model.entity.MeetingTaskAssignee;
import com.mas.managemate.model.entity.MeetingTaskStatus;
import com.mas.managemate.model.entity.TaskRespond;
import com.mas.managemate.model.mapper.GeneralMeetingMapper;
import com.mas.managemate.repository.*;
import com.mas.managemate.service.GeneralMeetingRepostService;
import com.mas.managemate.util.ApiClient;
import com.mas.managemate.util.DateConverter;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class GeneralMeetingReportImpl implements GeneralMeetingRepostService {

    @Autowired
    private GeneralMeetingRepository generalMeetingRepository;

    @Autowired
    private GeneralMeetingMapper generalMeetingMapper;

    @Autowired
    GeneralMeetingServiceImpl generalMeetingServiceImpl;

    @Autowired
    private GeneralMeetingTaskRepository generalMeetingTaskRepository;

    @Autowired
    private GeneralMeetingTaskTimelineRepository generalMeetingTaskTimelineRepository;

    @Autowired
    private MeetingTaskAssigneeRepository meetingTaskAssigneeRepository;

    @Autowired
    private MeetingParticipantsRepository meetingParticipantsRepository;

    @Autowired
    private MeetingTaskStatusRepository meetingTaskStatusRepository;

    @Autowired
    private TaskRespondRepository taskRespondRepository;

    @Autowired
    private ApiClient apiClient;

    // Helper method to create a cell style with borders
    private CellStyle createBorderedStyle(Workbook workbook, boolean isHeader) {
        CellStyle style = workbook.createCellStyle();
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);

        if (isHeader) {
            Font font = workbook.createFont();
            font.setBold(true);
            style.setFont(font);
            style.setAlignment(HorizontalAlignment.CENTER);
            style.setVerticalAlignment(VerticalAlignment.CENTER);
        } else {
            style.setAlignment(HorizontalAlignment.LEFT);
            style.setVerticalAlignment(VerticalAlignment.CENTER);
            style.setWrapText(true);
        }

        return style;
    }

    // Helper method to auto-adjust column widths based on content
    private void adjustColumnWidths(Sheet sheet, int numberOfColumns, List<String[]> dataRows, String[] headers) {
        for (int col = 0; col < numberOfColumns; col++) {
            int maxLength = headers[col].length();
            for (String[] rowData : dataRows) {
                String cellValue = col < rowData.length && rowData[col] != null ? rowData[col] : "";
                maxLength = Math.max(maxLength, cellValue.length());
            }
            int width = Math.min(maxLength * 256, 50 * 256);
            sheet.setColumnWidth(col, width);
        }
    }

    @Override
    public void generateReport(GeneralMeetingReportDTO generalMeetingReportDTO, String path) throws Exception {
        try {
            List<GeneralMeeting> generalMeetings = generalMeetingRepository.findAll();
            log.info("Fetched {} GeneralMeeting entities from the database", generalMeetings.size());

            List<Integer> empIds = Arrays.asList(19954, 32721, 538, 32860);

            if (!empIds.contains(generalMeetingReportDTO.getEmpId())) {
                long employeeNo = generalMeetingReportDTO.getEmpId();
                generalMeetings = generalMeetings.stream()
                        .filter(generalMeeting ->
                                generalMeeting.getScheduledBy().equalsIgnoreCase(String.valueOf(employeeNo)) ||
                                        generalMeeting.getCreatedBy() == employeeNo ||
                                        meetingParticipantsRepository.findByGeneralMeeting_Id(generalMeeting.getId())
                                                .stream()
                                                .anyMatch(participant -> participant.getEmployeeId() == employeeNo) ||
                                        generalMeetingTaskRepository.findByGeneralMeeting_Id(generalMeeting.getId())
                                                .stream()
                                                .anyMatch(task -> meetingTaskAssigneeRepository
                                                        .findByGeneralMeetingTasks_GeneralMeetingTaskId(task.getGeneralMeetingTaskId())
                                                        .stream()
                                                        .anyMatch(a -> a.getEmpId() == employeeNo))
                        )
                        .toList();
            }
            List<GeneralMeetingDto> generalMeetingDtos = generalMeetingMapper.mapToGeneralMeetingDtoList(generalMeetings);
            log.info("Mapped {} GeneralMeeting entities to GeneralMeetingDto objects", generalMeetingDtos.size());

            generalMeetingDtos = generalMeetingServiceImpl.setFullData(generalMeetingDtos);
            log.info("After setFullData, number of GeneralMeetingDto objects: {}", generalMeetingDtos.size());

            for (GeneralMeetingDto dto : generalMeetingDtos) {
                log.debug("GeneralMeetingDto ID: {}, Meeting ID: {}, Meeting Name: {}, Segments: {}, Departments: {}",
                        dto.getId(),
                        dto.getMeetingId() != null ? dto.getMeetingId() : "null",
                        dto.getMeetingName() != null ? dto.getMeetingName() : "null",
                        dto.getSegmentDtos() != null ?
                                dto.getSegmentDtos().stream().map(DepartmentDto::getName).collect(Collectors.toList()) : "null",
                        dto.getDepartmentDtos() != null ? dto.getDepartmentDtos().stream().map(DepartmentDto::getName).collect(Collectors.toList()) : "null");
            }

            if (generalMeetingReportDTO.getReportType() == null) {
                throw new IllegalArgumentException("Report type cannot be null");
            }

            switch (generalMeetingReportDTO.getReportType().toLowerCase()) {
                case "generalmeetingreport":
                    generateGeneralMeetingReport(generalMeetingReportDTO, generalMeetingDtos, path);
                    break;
                case "meetingmomreport":
                    generateMeetingMOMReport(generalMeetingReportDTO, generalMeetingDtos, path);
                    break;
                case "taskreport":
                    generateTaskReport(generalMeetingReportDTO, path);
                    break;
                default:
                    throw new IllegalArgumentException("Invalid report type: " + generalMeetingReportDTO.getReportType());
            }
        } catch (IOException e) {
            log.error("IOException occurred while generating report: {}", e.getMessage(), e);
            throw new Exception("Failed to generate report due to I/O error: " + e.getMessage(), e);
        } catch (Exception e) {
            log.error("Unexpected error occurred while generating report: {}", e.getMessage(), e);
            throw new Exception("Failed to generate report: " + e.getMessage(), e);
        }
    }

    public void generateGeneralMeetingReport(GeneralMeetingReportDTO reportDTO, List<GeneralMeetingDto> generalMeetingDtos, String path) throws Exception {
        Workbook workbook = new XSSFWorkbook();
        try {
            generalMeetingDtos = filterMeetings(generalMeetingDtos, reportDTO);
            log.info("After filtering, number of GeneralMeetingDto objects for General Meeting report: {}", generalMeetingDtos.size());

            Sheet sheet = workbook.createSheet("General Meeting Report");

            // Create styles for header and data cells
            CellStyle headerStyle = createBorderedStyle(workbook, true);
            CellStyle dataStyle = createBorderedStyle(workbook, false);

            // Create Header Row
            Row header = sheet.createRow(0);
            String[] headers = {
                    "SR. NO.", "MEETING ID", "MEETING NAME", "MEETING DATE", "HOST ID", "HOST NAME",
                    "SEGMENT", "DEPARTMENTS", "ATTENDEES", "MEETING STATUS", "TASK ASSIGNED BY",
                    "TASK NAME", "TASK DETAILS", "EMPLOYEE NAME", "ASSIGNED DATE",
                    "TARGET DATE", "USER EXPECTED DATE", "COMPLETION DATE", "TASK - STATUS",
                    "OVERDUE", "PENDING DAYS"
            };

            for (int i = 0; i < headers.length; i++) {
                Cell cell = header.createCell(i);
                cell.setCellValue(headers[i]);
                cell.setCellStyle(headerStyle);
            }

            // Prepare data for auto-sizing columns
            List<String[]> dataRows = new ArrayList<>();

            int rowCount = 1;
            int serialNo = 1;

            for (GeneralMeetingDto meeting : generalMeetingDtos) {
                List<GeneralMeetingTaskDto> tasks = meeting.getGeneralMeetingTaskDtos();

                if (tasks != null) {
                    for (GeneralMeetingTaskDto task : tasks) {
                        List<GeneralMeetingTaskTimeline> timelines = generalMeetingTaskTimelineRepository.findByGeneralMeetingTasks_GeneralMeetingTaskId(task.getGeneralMeetingTaskId());
                        timelines.stream()
                                .filter(t -> t.getMarkDate() != null)
                                .max(java.util.Comparator.comparing(GeneralMeetingTaskTimeline::getMarkDate))
                                .ifPresent(timeline -> task.setCompletionDate(timeline.getCompletionDate()));

                        List<MeetingTaskAssignee> assignees = meetingTaskAssigneeRepository.findByGeneralMeetingTasks_GeneralMeetingTaskId(task.getGeneralMeetingTaskId());
                        List<MeetingTaskAssigneeDto> assigneeDtos = generalMeetingMapper.fromMeetingTaskAssignee(assignees);
                        for (MeetingTaskAssigneeDto assigneeDto : assigneeDtos) {
                            try {
                                EmployeeProfileResponse profile = apiClient.getEmployeeProfile(String.valueOf(assigneeDto.getEmpId()));
                                if (profile != null && profile.getData() != null && !profile.getData().isEmpty()) {
                                    assigneeDto.setEmployeeName(profile.getData().get(0).getEmployeeFullName());
                                } else {
                                    assigneeDto.setEmployeeName("Unknown");
                                    log.warn("No employee profile found for empId: {}", assigneeDto.getEmpId());
                                }
                            } catch (Exception e) {
                                log.error("Error fetching employee profile for empId: {}: {}", assigneeDto.getEmpId(), e.getMessage());
                                assigneeDto.setEmployeeName("Unknown");
                            }
                        }
                        task.setMeetingTaskAssigneeDtos(assigneeDtos);

                        // Fetch the latest task status from MeetingTaskStatus
                        List<MeetingTaskStatus> statuses = meetingTaskStatusRepository.findByGeneralMeetingTaskId(Collections.singletonList(task.getGeneralMeetingTaskId()));
                        statuses.stream()
                                .filter(status -> status.getMarkedOn() != null)
                                .max(Comparator.comparing(MeetingTaskStatus::getMarkedOn))
                                .ifPresent(latest -> task.setStatus(latest.getTaskStatus()));

                        // Fetch the latest completion date from TaskRespondDto
                        List<TaskRespond> taskResponds = taskRespondRepository.findByGeneralMeetingTasks_GeneralMeetingTaskId(task.getGeneralMeetingTaskId());
                        taskResponds.stream()
                                .filter(TaskRespond::isMarking)
                                .max(Comparator.comparing(TaskRespond::getRespondedOn))
                                .ifPresent(latestRespond -> task.setCompletionDate(latestRespond.getRespondedOn()));
                    }
                }

                if (tasks == null || tasks.isEmpty()) {
                    String[] rowData = new String[headers.length];
                    fillMeetingColumnsArray(rowData, serialNo, meeting, null);
                    dataRows.add(rowData);
                    Row row = sheet.createRow(rowCount++);
                    fillMeetingColumns(row, serialNo++, meeting, null, dataStyle);
                    continue;
                }

                for (GeneralMeetingTaskDto task : tasks) {
                    String[] rowData = new String[headers.length];
                    fillMeetingColumnsArray(rowData, serialNo, meeting, task);
                    dataRows.add(rowData);
                    Row row = sheet.createRow(rowCount++);
                    fillMeetingColumns(row, serialNo++, meeting, task, dataStyle);
                }
            }

            // Auto-adjust column widths based on content
            adjustColumnWidths(sheet, headers.length, dataRows, headers);

            try (FileOutputStream fos = new FileOutputStream(path)) {
                workbook.write(fos);
                log.info("Successfully wrote General Meeting Report to: {}", path);
            }
        } finally {
            workbook.close();
        }
    }

    // Helper method to fill data array for column width calculation
    private void fillMeetingColumnsArray(String[] rowData, int serialNo, GeneralMeetingDto meeting, GeneralMeetingTaskDto task) {
        int col = 0;
        rowData[col++] = String.valueOf(serialNo);

        String meetingId = meeting.getMeetingId() != null ? meeting.getMeetingId() : "-";
        rowData[col++] = meetingId;

        String meetingName = meeting.getMeetingName() != null ? meeting.getMeetingName() : "-";
        rowData[col++] = meetingName;

        String meetingDateStr = meeting.getMeetingDate() != null ? DateConverter.convertDateTime(meeting.getMeetingDate()) : "-";
        rowData[col++] = meetingDateStr;

        String hostId = "-";
        String hostName = "-";
        if (meeting.getHostIdName() != null && !meeting.getHostIdName().isEmpty()) {
            String[] parts = meeting.getHostIdName().split("-", 2);
            hostId = parts.length > 0 ? parts[0].trim() : "-";
            hostName = parts.length > 1 ? parts[1].trim() : "-";
        } else if (meeting.getScheduledBy() != null) {
            hostId = meeting.getScheduledBy();
            hostName = meeting.getHostIdName() != null ? meeting.getHostIdName() : "-";
        }
        rowData[col++] = hostId;
        rowData[col++] = hostName;

        String segments = (meeting.getSegmentDtos() != null && !meeting.getSegmentDtos().isEmpty())
                ? meeting.getSegmentDtos().stream().map(DepartmentDto::getName).reduce((a, b) -> a + ", " + b).orElse("-")
                : "-";
        rowData[col++] = segments;

        String departments = (meeting.getDepartmentDtos() != null && !meeting.getDepartmentDtos().isEmpty())
                ? meeting.getDepartmentDtos().stream().map(DepartmentDto::getName).reduce((a, b) -> a + ", " + b).orElse("-")
                : "-";
        rowData[col++] = departments;

        String attendees = (meeting.getMeetingParticipantsDtoList() != null && !meeting.getMeetingParticipantsDtoList().isEmpty())
                ? meeting.getMeetingParticipantsDtoList().stream()
                .map(MeetingParticipantsDto::getParticipantName)
                .reduce((a, b) -> a + ", " + b)
                .orElse("-")
                : "-";
        rowData[col++] = attendees;

        rowData[col++] = meeting.getMeetingStatus() != null ? meeting.getMeetingStatus() : "-";

        String assignedBy = "-";
        if (task != null && task.getCreatedBy() != null) {
            try {
                EmployeeProfileResponse profile = apiClient.getEmployeeProfile(task.getCreatedBy());
                if (profile != null && profile.getData() != null && !profile.getData().isEmpty()) {
                    assignedBy = profile.getData().get(0).getEmployeeFullName();
                } else {
                    assignedBy = task.getCreatedBy() + " - Unknown";
                    log.warn("No employee profile found for createdBy: {}", task.getCreatedBy());
                }
            } catch (Exception e) {
                assignedBy = task.getCreatedBy() + " - Unknown";
                log.error("Error fetching employee profile for createdBy: {}: {}", task.getCreatedBy(), e.getMessage());
            }
        }
        rowData[col++] = assignedBy;

        rowData[col++] = task != null && task.getTaskName() != null ? task.getTaskName() : "-";

        rowData[col++] = task != null && task.getRemark() != null ? task.getRemark() : "-";

        String employeeNames = (task != null && task.getMeetingTaskAssigneeDtos() != null && !task.getMeetingTaskAssigneeDtos().isEmpty())
                ? task.getMeetingTaskAssigneeDtos().stream()
                .map(MeetingTaskAssigneeDto::getEmployeeName)
                .filter(name -> name != null)
                .reduce((a, b) -> a + ", " + b)
                .orElse("-")
                : "-";
        rowData[col++] = employeeNames;

        String assignedDateStr = (task != null && task.getCreatedOn() != null) ? DateConverter.convertDateTime(task.getCreatedOn()) : "-";
        rowData[col++] = assignedDateStr;

        String targetDateStr = (task != null && task.getTargetDate() != null) ? DateConverter.convertDateTime(task.getTargetDate()) : "-";
        rowData[col++] = targetDateStr;

        String userExpectedDateStr = (task != null && task.getCompletionDate() != null) ? DateConverter.convertDateTime(task.getCompletionDate()) : "-";
        rowData[col++] = userExpectedDateStr;

        // Updated to use respondedOn from TaskRespondDto
        String completionDateStr = "-";
        if (task != null) {
            List<TaskRespond> taskResponds = taskRespondRepository.findByGeneralMeetingTasks_GeneralMeetingTaskId(task.getGeneralMeetingTaskId());
            completionDateStr = taskResponds.stream()
                    .filter(TaskRespond::isMarking)
                    .max(Comparator.comparing(TaskRespond::getRespondedOn))
                    .map(respond -> DateConverter.convertDateTime(respond.getRespondedOn()))
                    .orElse("-");
        }
        rowData[col++] = completionDateStr;

        String taskStatus = "-";
        if (task != null) {
            List<MeetingTaskStatus> statuses = meetingTaskStatusRepository.findByGeneralMeetingTaskId(Collections.singletonList(task.getGeneralMeetingTaskId()));
            taskStatus = statuses.stream()
                    .filter(status -> status.getMarkedOn() != null)
                    .max(Comparator.comparing(MeetingTaskStatus::getMarkedOn))
                    .map(MeetingTaskStatus::getTaskStatus)
                    .orElse("-");
        }
        rowData[col++] = taskStatus;

        String overdue = "No"; // Default to "No"
        if (task != null && task.getTargetDate() != null && task.getCompletionDate() == null && taskStatus != null && !taskStatus.equalsIgnoreCase("completed")) {
            LocalDate targetDate = task.getTargetDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            LocalDate currentDate = LocalDate.now();
            if (currentDate.isAfter(targetDate)) {
                overdue = "Yes";
            }
        }
        rowData[col++] = overdue;

        String pendingDuration = "-";
        if (overdue.equals("Yes") && task != null && task.getTargetDate() != null) {
            LocalDate targetDate = task.getTargetDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            LocalDate currentDate = LocalDate.now();
            long days = ChronoUnit.DAYS.between(targetDate, currentDate);
            pendingDuration = String.valueOf(days);
        }
        rowData[col++] = pendingDuration;
    }

    private void fillMeetingColumns(Row row, int serialNo, GeneralMeetingDto meeting, GeneralMeetingTaskDto task, CellStyle dataStyle) {
        int col = 0;

        row.createCell(col++).setCellValue(serialNo);

        String meetingId = meeting.getMeetingId() != null ? meeting.getMeetingId() : "-";
        row.createCell(col++).setCellValue(meetingId);
        if (meetingId.equals("-")) {
            log.warn("Meeting ID is null for meeting ID: {}", meeting.getId());
        }

        String meetingName = meeting.getMeetingName() != null ? meeting.getMeetingName() : "-";
        row.createCell(col++).setCellValue(meetingName);
        if (meetingName.equals("-")) {
            log.warn("Meeting Name is null for meeting ID: {}", meeting.getId());
        }

        String meetingDateStr = meeting.getMeetingDate() != null ? DateConverter.convertDateTime(meeting.getMeetingDate()) : "-";
        row.createCell(col++).setCellValue(meetingDateStr);

        String hostId = "-";
        String hostName = "-";
        if (meeting.getHostIdName() != null && !meeting.getHostIdName().isEmpty()) {
            String[] parts = meeting.getHostIdName().split("-", 2);
            hostId = parts.length > 0 ? parts[0].trim() : "-";
            hostName = parts.length > 1 ? parts[1].trim() : "-";
        } else if (meeting.getScheduledBy() != null) {
            hostId = meeting.getScheduledBy();
            hostName = meeting.getHostIdName() != null ? meeting.getHostIdName() : "-";
        }
        row.createCell(col++).setCellValue(hostId);
        row.createCell(col++).setCellValue(hostName);

        String segments = (meeting.getSegmentDtos() != null && !meeting.getSegmentDtos().isEmpty())
                ? meeting.getSegmentDtos().stream().map(DepartmentDto::getName).reduce((a, b) -> a + ", " + b).orElse("-")
                : "-";
        row.createCell(col++).setCellValue(segments);
        if (segments.equals("-")) {
            log.warn("Segments are empty for meeting ID: {}", meeting.getId());
        }

        String departments = (meeting.getDepartmentDtos() != null && !meeting.getDepartmentDtos().isEmpty())
                ? meeting.getDepartmentDtos().stream().map(DepartmentDto::getName).reduce((a, b) -> a + ", " + b).orElse("-")
                : "-";
        row.createCell(col++).setCellValue(departments);
        if (departments.equals("-")) {
            log.warn("Departments are empty for meeting ID: {}", meeting.getId());
        }

        String attendees = (meeting.getMeetingParticipantsDtoList() != null && !meeting.getMeetingParticipantsDtoList().isEmpty())
                ? meeting.getMeetingParticipantsDtoList().stream()
                .map(MeetingParticipantsDto::getParticipantName)
                .reduce((a, b) -> a + ", " + b)
                .orElse("-")
                : "-";
        row.createCell(col++).setCellValue(attendees);

        row.createCell(col++).setCellValue(meeting.getMeetingStatus() != null ? meeting.getMeetingStatus() : "-");

        String assignedBy = "-";
        if (task != null && task.getCreatedBy() != null) {
            try {
                EmployeeProfileResponse profile = apiClient.getEmployeeProfile(task.getCreatedBy());
                if (profile != null && profile.getData() != null && !profile.getData().isEmpty()) {
                    assignedBy = profile.getData().get(0).getEmployeeFullName();
                } else {
                    assignedBy = task.getCreatedBy() + " - Unknown";
                    log.warn("No employee profile found for createdBy: {}", task.getCreatedBy());
                }
            } catch (Exception e) {
                assignedBy = task.getCreatedBy() + " - Unknown";
                log.error("Error fetching employee profile for createdBy: {}: {}", task.getCreatedBy(), e.getMessage());
            }
        }
        row.createCell(col++).setCellValue(assignedBy);

        row.createCell(col++).setCellValue(task != null && task.getTaskName() != null ? task.getTaskName() : "-");

        row.createCell(col++).setCellValue(task != null && task.getRemark() != null ? task.getRemark() : "-");

        String employeeNames = (task != null && task.getMeetingTaskAssigneeDtos() != null && !task.getMeetingTaskAssigneeDtos().isEmpty())
                ? task.getMeetingTaskAssigneeDtos().stream()
                .map(MeetingTaskAssigneeDto::getEmployeeName)
                .filter(name -> name != null)
                .reduce((a, b) -> a + ", " + b)
                .orElse("-")
                : "-";
        row.createCell(col++).setCellValue(employeeNames);
        if (employeeNames.equals("-") && task != null) {
            log.warn("Employee names are empty for task ID: {}", task.getGeneralMeetingTaskId());
        }

        String assignedDateStr = (task != null && task.getCreatedOn() != null) ? DateConverter.convertDateTime(task.getCreatedOn()) : "-";
        row.createCell(col++).setCellValue(assignedDateStr);

        String targetDateStr = (task != null && task.getTargetDate() != null) ? DateConverter.convertDateTime(task.getTargetDate()) : "-";
        row.createCell(col++).setCellValue(targetDateStr);

        String userExpectedDateStr = (task != null && task.getCompletionDate() != null) ? DateConverter.convertDateTime(task.getCompletionDate()) : "-";
        row.createCell(col++).setCellValue(userExpectedDateStr);

        // Updated to use respondedOn from TaskRespondDto
        String completionDateStr = "-";
        if (task != null) {
            List<TaskRespond> taskResponds = taskRespondRepository.findByGeneralMeetingTasks_GeneralMeetingTaskId(task.getGeneralMeetingTaskId());
            completionDateStr = taskResponds.stream()
                    .filter(TaskRespond::isMarking)
                    .max(Comparator.comparing(TaskRespond::getRespondedOn))
                    .map(respond -> DateConverter.convertDateTime(respond.getRespondedOn()))
                    .orElse("-");
        }
        row.createCell(col++).setCellValue(completionDateStr);

        String taskStatus = "-";
        if (task != null) {
            List<MeetingTaskStatus> statuses = meetingTaskStatusRepository.findByGeneralMeetingTaskId(Collections.singletonList(task.getGeneralMeetingTaskId()));
            taskStatus = statuses.stream()
                    .filter(status -> status.getMarkedOn() != null)
                    .max(Comparator.comparing(MeetingTaskStatus::getMarkedOn))
                    .map(MeetingTaskStatus::getTaskStatus)
                    .orElse("-");
        }
        row.createCell(col++).setCellValue(taskStatus);

        String overdue = "No"; // Default to "No"
        if (task != null && task.getTargetDate() != null && task.getCompletionDate() == null && taskStatus != null && !taskStatus.equalsIgnoreCase("completed")) {
            LocalDate targetDate = task.getTargetDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            LocalDate currentDate = LocalDate.now();
            if (currentDate.isAfter(targetDate)) {
                overdue = "Yes";
            }
        }
        row.createCell(col++).setCellValue(overdue);

        String pendingDuration = "-";
        if (overdue.equals("Yes") && task != null && task.getTargetDate() != null) {
            LocalDate targetDate = task.getTargetDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            LocalDate currentDate = LocalDate.now();
            long days = ChronoUnit.DAYS.between(targetDate, currentDate);
            pendingDuration = String.valueOf(days);
        }
        row.createCell(col++).setCellValue(pendingDuration);

        for (int i = 0; i < row.getLastCellNum(); i++) {
            Cell cell = row.getCell(i);
            if (cell == null) {
                cell = row.createCell(i);
            }
            cell.setCellStyle(dataStyle);
        }
    }

    public void generateTaskReport(GeneralMeetingReportDTO generalMeetingReportDTO, String path) throws Exception {
        Workbook workbook = new XSSFWorkbook();
        try {
            List<GeneralMeetingTasks> generalMeetingTasks = new ArrayList<>();

            List<Integer> empIds = Arrays.asList(19954, 32721, 538, 32860);
            if (!empIds.contains(generalMeetingReportDTO.getEmpId())) {
                List<MeetingTaskAssignee> taskAssignees = meetingTaskAssigneeRepository.findByEmpId((long) generalMeetingReportDTO.getEmpId());
                List<GeneralMeetingTasks> tasks = new ArrayList<>(taskAssignees.stream().map(MeetingTaskAssignee::getGeneralMeetingTasks).filter(Objects::nonNull).toList());
                List<GeneralMeetingTasks> meetingTasks = generalMeetingTaskRepository.findByCreatedBy(String.valueOf(generalMeetingReportDTO.getEmpId()));
                tasks.addAll(meetingTasks.stream().filter(Objects::nonNull).toList());
                Set<GeneralMeetingTasks> tasksSet = new TreeSet<>(tasks);
                generalMeetingTasks = new ArrayList<>(tasksSet);
            } else {
                generalMeetingTasks = generalMeetingTaskRepository.findAll();
            }
            log.info("Fetched {} GeneralMeetingTasks from the database", generalMeetingTasks.size());
            List<GeneralMeetingTaskDto> generalMeetingTaskDtos = generalMeetingMapper.fromGeneralMeetingTask(generalMeetingTasks);
            log.info("Mapped {} GeneralMeetingTasks to GeneralMeetingTaskDto objects", generalMeetingTaskDtos.size());

            for (int i = 0; i < generalMeetingTasks.size(); i++) {
                GeneralMeetingTasks task = generalMeetingTasks.get(i);
                GeneralMeetingTaskDto dto = generalMeetingTaskDtos.get(i);

                if (task.getGeneralMeeting() != null) {
                    dto.setGeneralMeetingId(task.getGeneralMeeting().getId());
                } else {
                    dto.setGeneralMeetingId(null);
                }
            }

            for (GeneralMeetingTaskDto taskDto : generalMeetingTaskDtos) {
                List<GeneralMeetingTaskTimeline> timelines = generalMeetingTaskTimelineRepository.findByGeneralMeetingTasks_GeneralMeetingTaskId(taskDto.getGeneralMeetingTaskId());
                timelines.stream()
                        .filter(t -> t.getMarkDate() != null)
                        .max(java.util.Comparator.comparing(GeneralMeetingTaskTimeline::getMarkDate))
                        .ifPresent(timeline -> taskDto.setCompletionDate(timeline.getCompletionDate()));

                List<MeetingTaskAssignee> assignees = meetingTaskAssigneeRepository.findByGeneralMeetingTasks_GeneralMeetingTaskId(taskDto.getGeneralMeetingTaskId());
                List<MeetingTaskAssigneeDto> assigneeDtos = generalMeetingMapper.fromMeetingTaskAssignee(assignees);
                for (MeetingTaskAssigneeDto assigneeDto : assigneeDtos) {
                    try {
                        EmployeeProfileResponse profile = apiClient.getEmployeeProfile(String.valueOf(assigneeDto.getEmpId()));
                        if (profile != null && profile.getData() != null && !profile.getData().isEmpty()) {
                            assigneeDto.setEmployeeName(profile.getData().get(0).getEmployeeFullName());
                        } else {
                            assigneeDto.setEmployeeName("Unknown");
                            log.warn("No employee profile found for empId: {}", assigneeDto.getEmpId());
                        }
                    } catch (Exception e) {
                        log.error("Error fetching employee profile for empId: {}: {}", assigneeDto.getEmpId(), e.getMessage());
                        assigneeDto.setEmployeeName("Unknown");
                    }
                }
                taskDto.setMeetingTaskAssigneeDtos(assigneeDtos);

                // Fetch the latest task status from MeetingTaskStatus
                List<MeetingTaskStatus> statuses = meetingTaskStatusRepository.findByGeneralMeetingTaskId(Collections.singletonList(taskDto.getGeneralMeetingTaskId()));
                statuses.stream()
                        .filter(status -> status.getMarkedOn() != null)
                        .max(Comparator.comparing(MeetingTaskStatus::getMarkedOn))
                        .ifPresent(latest -> taskDto.setStatus(latest.getTaskStatus()));
            }

            List<GeneralMeeting> generalMeetings = generalMeetingRepository.findAll();
            List<GeneralMeetingDto> generalMeetingDtos = generalMeetingMapper.mapToGeneralMeetingDtoList(generalMeetings);
            generalMeetingDtos = generalMeetingServiceImpl.setFullData(generalMeetingDtos);

            generalMeetingTaskDtos = filterTasks(generalMeetingReportDTO, generalMeetingTaskDtos);
            log.info("After filtering, number of GeneralMeetingTaskDto objects for Task report: {}", generalMeetingTaskDtos.size());

            Sheet sheet = workbook.createSheet("Task Report");

            CellStyle headerStyle = createBorderedStyle(workbook, true);
            CellStyle dataStyle = createBorderedStyle(workbook, false);

            Row header = sheet.createRow(0);
            String[] headers = {
                    "SR. NO.", "MEETING ID", "MEETING NAME", "TASK ASSIGNED BY", "ASSIGNED DATE",
                    "TASK NAME", "TASK DETAILS", "SEGMENT", "DEPARTMENTS", "EMPLOYEE NAME",
                    "TARGET DATE", "USER EXPECTED DATE", "TASK COMPLETION DATE", "TASK - STATUS",
                    "OVERDUE", "PENDING DAYS"
            };

            for (int i = 0; i < headers.length; i++) {
                Cell cell = header.createCell(i);
                cell.setCellValue(headers[i]);
                cell.setCellStyle(headerStyle);
            }

            List<String[]> dataRows = new ArrayList<>();

            int rowCount = 1;
            int serialNo = 1;

            for (GeneralMeetingTaskDto task : generalMeetingTaskDtos) {
                GeneralMeetingDto meeting = generalMeetingDtos.stream()
                        .filter(m -> task.getGeneralMeetingId() != null && task.getGeneralMeetingId().equals(m.getId()))
                        .findFirst()
                        .orElse(null);

                String[] rowData = new String[headers.length];
                fillTaskReportColumnsArray(rowData, serialNo, meeting, task);
                dataRows.add(rowData);
                Row row = sheet.createRow(rowCount++);
                fillTaskReportColumns(row, serialNo++, meeting, task, dataStyle);
            }

            adjustColumnWidths(sheet, headers.length, dataRows, headers);

            try (FileOutputStream fos = new FileOutputStream(path)) {
                workbook.write(fos);
                log.info("Successfully wrote Task Report to: {}", path);
            }
        } finally {
            workbook.close();
        }
    }

    private void fillTaskReportColumnsArray(String[] rowData, int serialNo, GeneralMeetingDto meeting, GeneralMeetingTaskDto task) {
        int col = 0;
        rowData[col++] = String.valueOf(serialNo);
        rowData[col++] = (meeting != null && meeting.getMeetingId() != null) ? meeting.getMeetingId() : "-";
        rowData[col++] = (meeting != null && meeting.getMeetingName() != null) ? meeting.getMeetingName() : "-";
        String assignedBy = "-";
        if (task.getCreatedBy() != null) {
            try {
                EmployeeProfileResponse profile = apiClient.getEmployeeProfile(task.getCreatedBy());
                if (profile != null && profile.getData() != null && !profile.getData().isEmpty()) {
                    assignedBy = profile.getData().get(0).getEmployeeFullName();
                } else {
                    assignedBy = task.getCreatedBy() + " - Unknown";
                    log.warn("No employee profile found for createdBy: {}", task.getCreatedBy());
                }
            } catch (Exception e) {
                assignedBy = task.getCreatedBy() + " - Unknown";
                log.error("Error fetching employee profile for createdBy: {}: {}", task.getCreatedBy(), e.getMessage());
            }
        }
        rowData[col++] = assignedBy;
        rowData[col++] = (task.getCreatedOn() != null) ? DateConverter.convertDateTime(task.getCreatedOn()) : "-";
        rowData[col++] = task.getTaskName() != null ? task.getTaskName() : "-";
        rowData[col++] = task.getRemark() != null ? task.getRemark() : "-";
        rowData[col++] = (meeting != null && meeting.getSegmentDtos() != null && !meeting.getSegmentDtos().isEmpty())
                ? meeting.getSegmentDtos().stream().map(DepartmentDto::getName).reduce((a, b) -> a + ", " + b).orElse("-")
                : "-";
        rowData[col++] = (meeting != null && meeting.getDepartmentDtos() != null && !meeting.getDepartmentDtos().isEmpty())
                ? meeting.getDepartmentDtos().stream().map(DepartmentDto::getName).reduce((a, b) -> a + ", " + b).orElse("-")
                : "-";
        rowData[col++] = (task.getMeetingTaskAssigneeDtos() != null && !task.getMeetingTaskAssigneeDtos().isEmpty())
                ? task.getMeetingTaskAssigneeDtos().stream()
                .map(MeetingTaskAssigneeDto::getEmployeeName)
                .filter(name -> name != null)
                .reduce((a, b) -> a + ", " + b)
                .orElse("-")
                : "-";
        rowData[col++] = (task.getTargetDate() != null) ? DateConverter.convertDateTime(task.getTargetDate()) : "-";
        rowData[col++] = (task.getCompletionDate() != null) ? DateConverter.convertDateTime(task.getCompletionDate()) : "-";
        rowData[col++] = (task.getCompletionDate() != null) ? DateConverter.convertDateTime(task.getCompletionDate()) : "-";
        String taskStatus = "-";
        List<MeetingTaskStatus> statuses = meetingTaskStatusRepository.findByGeneralMeetingTaskId(Collections.singletonList(task.getGeneralMeetingTaskId()));
        taskStatus = statuses.stream()
                .filter(status -> status.getMarkedOn() != null)
                .max(Comparator.comparing(MeetingTaskStatus::getMarkedOn))
                .map(MeetingTaskStatus::getTaskStatus)
                .orElse("-");
        rowData[col++] = taskStatus;
        String overdue = "No"; // Default to "No"
        if (task.getTargetDate() != null && task.getCompletionDate() == null && taskStatus != null && !taskStatus.equalsIgnoreCase("completed")) {
            LocalDate targetDate = task.getTargetDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            LocalDate currentDate = LocalDate.now();
            if (currentDate.isAfter(targetDate)) {
                overdue = "Yes";
            }
        }
        rowData[col++] = overdue;
        String pendingDuration = "-";
        if (overdue.equals("Yes") && task.getCreatedOn() != null) {
            LocalDate createdOn = task.getCreatedOn().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            LocalDate endDate = task.getCompletionDate() != null
                    ? task.getCompletionDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate()
                    : LocalDate.now();
            long days = ChronoUnit.DAYS.between(createdOn, endDate);
            pendingDuration = String.valueOf(days);
        }
        rowData[col++] = pendingDuration;
    }

    private void fillTaskReportColumns(Row row, int serialNo, GeneralMeetingDto meeting, GeneralMeetingTaskDto task, CellStyle dataStyle) {
        int col = 0;
        row.createCell(col++).setCellValue(serialNo);
        String meetingId = (meeting != null && meeting.getMeetingId() != null) ? meeting.getMeetingId() : "-";
        row.createCell(col++).setCellValue(meetingId);
        if (meetingId.equals("-")) {
            log.warn("Meeting ID is null for task ID: {}", task.getGeneralMeetingTaskId());
        }
        String meetingName = (meeting != null && meeting.getMeetingName() != null) ? meeting.getMeetingName() : "-";
        row.createCell(col++).setCellValue(meetingName);
        if (meetingName.equals("-")) {
            log.warn("Meeting Name is null for task ID: {}", task.getGeneralMeetingTaskId());
        }
        String assignedBy = "-";
        if (task.getCreatedBy() != null) {
            try {
                EmployeeProfileResponse profile = apiClient.getEmployeeProfile(task.getCreatedBy());
                if (profile != null && profile.getData() != null && !profile.getData().isEmpty()) {
                    assignedBy = profile.getData().get(0).getEmployeeFullName();
                } else {
                    assignedBy = task.getCreatedBy() + " - Unknown";
                    log.warn("No employee profile found for createdBy: {}", task.getCreatedBy());
                }
            } catch (Exception e) {
                assignedBy = task.getCreatedBy() + " - Unknown";
                log.error("Error fetching employee profile for createdBy: {}: {}", task.getCreatedBy(), e.getMessage());
            }
        }
        row.createCell(col++).setCellValue(assignedBy);
        String assignedDateStr = (task.getCreatedOn() != null) ? DateConverter.convertDateTime(task.getCreatedOn()) : "-";
        row.createCell(col++).setCellValue(assignedDateStr);
        row.createCell(col++).setCellValue(task.getTaskName() != null ? task.getTaskName() : "-");
        row.createCell(col++).setCellValue(task.getRemark() != null ? task.getRemark() : "-");
        String segments = (meeting != null && meeting.getSegmentDtos() != null && !meeting.getSegmentDtos().isEmpty())
                ? meeting.getSegmentDtos().stream().map(DepartmentDto::getName).reduce((a, b) -> a + ", " + b).orElse("-")
                : "-";
        row.createCell(col++).setCellValue(segments);
        if (segments.equals("-") && meeting != null) {
            log.warn("Segments are empty for meeting ID: {}", meeting.getId());
        }
        String departments = (meeting != null && meeting.getDepartmentDtos() != null && !meeting.getDepartmentDtos().isEmpty())
                ? meeting.getDepartmentDtos().stream().map(DepartmentDto::getName).reduce((a, b) -> a + ", " + b).orElse("-")
                : "-";
        row.createCell(col++).setCellValue(departments);
        if (departments.equals("-") && meeting != null) {
            log.warn("Departments are empty for meeting ID: {}", meeting.getId());
        }
        String employeeNames = (task.getMeetingTaskAssigneeDtos() != null && !task.getMeetingTaskAssigneeDtos().isEmpty())
                ? task.getMeetingTaskAssigneeDtos().stream()
                .map(MeetingTaskAssigneeDto::getEmployeeName)
                .filter(name -> name != null)
                .reduce((a, b) -> a + ", " + b)
                .orElse("-")
                : "-";
        row.createCell(col++).setCellValue(employeeNames);
        if (employeeNames.equals("-")) {
            log.warn("Employee names are empty for task ID: {}", task.getGeneralMeetingTaskId());
        }
        String targetDateStr = (task.getTargetDate() != null) ? DateConverter.convertDateTime(task.getTargetDate()) : "-";
        row.createCell(col++).setCellValue(targetDateStr);
        String userExpectedDateStr = (task.getCompletionDate() != null) ? DateConverter.convertDateTime(task.getCompletionDate()) : "-";
        row.createCell(col++).setCellValue(userExpectedDateStr);
        if (userExpectedDateStr.equals("-")) {
            log.warn("User expected date is null for task ID: {}", task.getGeneralMeetingTaskId());
        }
        String completionDateStr = (task.getCompletionDate() != null) ? DateConverter.convertDateTime(task.getCompletionDate()) : "-";
        row.createCell(col++).setCellValue(completionDateStr);
        String taskStatus = "-";
        List<MeetingTaskStatus> statuses = meetingTaskStatusRepository.findByGeneralMeetingTaskId(Collections.singletonList(task.getGeneralMeetingTaskId()));
        taskStatus = statuses.stream()
                .filter(status -> status.getMarkedOn() != null)
                .max(Comparator.comparing(MeetingTaskStatus::getMarkedOn))
                .map(MeetingTaskStatus::getTaskStatus)
                .orElse("-");
        row.createCell(col++).setCellValue(taskStatus);
        String overdue = "No"; // Default to "No"
        if (task.getTargetDate() != null && task.getCompletionDate() == null && taskStatus != null && !taskStatus.equalsIgnoreCase("completed")) {
            LocalDate targetDate = task.getTargetDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            LocalDate currentDate = LocalDate.now();
            if (currentDate.isAfter(targetDate)) {
                overdue = "Yes";
            }
        }
        row.createCell(col++).setCellValue(overdue);
        String pendingDuration = "-";
        if (overdue.equals("Yes") && task.getCreatedOn() != null) {
            LocalDate createdOn = task.getCreatedOn().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            LocalDate endDate = task.getCompletionDate() != null
                    ? task.getCompletionDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate()
                    : LocalDate.now();
            long days = ChronoUnit.DAYS.between(createdOn, endDate);
            pendingDuration = String.valueOf(days);
        }
        row.createCell(col++).setCellValue(pendingDuration);

        for (int i = 0; i < row.getLastCellNum(); i++) {
            Cell cell = row.getCell(i);
            if (cell == null) {
                cell = row.createCell(i);
            }
            cell.setCellStyle(dataStyle);
        }
    }

    private List<GeneralMeetingTaskDto> filterTasks(GeneralMeetingReportDTO generalMeetingReportDTO, List<GeneralMeetingTaskDto> generalMeetingTaskDtos) {
        List<GeneralMeeting> generalMeetings = generalMeetingRepository.findAll();
        List<GeneralMeetingDto> generalMeetingDtos = generalMeetingMapper.mapToGeneralMeetingDtoList(generalMeetings);
        try {
            generalMeetingDtos = generalMeetingServiceImpl.setFullData(generalMeetingDtos);
        } catch (Exception e) {
            log.error("Error in setFullData during filterTasks: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to set full data for meetings: " + e.getMessage(), e);
        }

        if (generalMeetingTaskDtos == null || generalMeetingTaskDtos.isEmpty()) {
            log.warn("No tasks found to filter for the given criteria.");
            return new ArrayList<>();
        }

        List<GeneralMeetingDto> validGeneralMeetingDtos = generalMeetingDtos.stream()
                .filter(dto -> dto.getMeetingId() != null && dto.getMeetingName() != null)
                .filter(dto -> dto.getSegmentDtos() != null && !dto.getSegmentDtos().isEmpty())
                .filter(dto -> dto.getDepartmentDtos() != null && !dto.getDepartmentDtos().isEmpty())
                .collect(Collectors.toList());

        if (generalMeetingReportDTO.getSegment() != null && !generalMeetingReportDTO.getSegment().isEmpty()) {
            List<GeneralMeetingDto> finalGeneralMeetingDtos = validGeneralMeetingDtos;
            generalMeetingTaskDtos = generalMeetingTaskDtos.stream()
                    .filter(task -> {
                        GeneralMeetingDto meeting = finalGeneralMeetingDtos.stream()
                                .filter(m -> task.getGeneralMeetingId() != null && task.getGeneralMeetingId().equals(m.getId()))
                                .findFirst()
                                .orElse(null);
                        if (meeting == null) return false;
                        return meeting.getSegmentDtos() != null && meeting.getSegmentDtos().stream()
                                .anyMatch(segmentDto ->
                                        generalMeetingReportDTO.getSegment().stream()
                                                .anyMatch(seg -> seg.equalsIgnoreCase(segmentDto.getName()))
                                );
                    }).collect(Collectors.toList());
        }

        if (generalMeetingReportDTO.getDepartment() != null && !generalMeetingReportDTO.getDepartment().isEmpty()) {
            List<GeneralMeetingDto> finalGeneralMeetingDtos1 = validGeneralMeetingDtos;
            generalMeetingTaskDtos = generalMeetingTaskDtos.stream()
                    .filter(task -> {
                        GeneralMeetingDto meeting = finalGeneralMeetingDtos1.stream()
                                .filter(m -> task.getGeneralMeetingId() != null && task.getGeneralMeetingId().equals(m.getId()))
                                .findFirst()
                                .orElse(null);
                        if (meeting == null) return false;
                        return meeting.getDepartmentDtos() != null && meeting.getDepartmentDtos().stream()
                                .anyMatch(departmentDto ->
                                        generalMeetingReportDTO.getDepartment().stream()
                                                .anyMatch(dept -> dept.equalsIgnoreCase(departmentDto.getName()))
                                );
                    }).collect(Collectors.toList());
        }

        if (generalMeetingReportDTO.getAssignee() != null && !generalMeetingReportDTO.getAssignee().isEmpty()) {
            generalMeetingTaskDtos = generalMeetingTaskDtos.stream()
                    .filter(task -> task.getMeetingTaskAssigneeDtos() != null && task.getMeetingTaskAssigneeDtos().stream()
                            .anyMatch(assignee ->
                                    generalMeetingReportDTO.getAssignee().contains(assignee.getEmpId())
                            )).collect(Collectors.toList());
        }

        if (generalMeetingReportDTO.getAssignedBy() != null && !generalMeetingReportDTO.getAssignedBy().isEmpty()) {
            generalMeetingTaskDtos = generalMeetingTaskDtos.stream()
                    .filter(task -> task.getCreatedBy() != null && generalMeetingReportDTO.getAssignedBy().contains(Long.parseLong(task.getCreatedBy())))
                    .collect(Collectors.toList());
        }

        if (generalMeetingReportDTO.getTaskAssignedDateFrom() != null || generalMeetingReportDTO.getTaskAssignedDateTo() != null) {
            generalMeetingTaskDtos = generalMeetingTaskDtos.stream()
                    .filter(task -> {
                        Date createdOnDate = task.getCreatedOn();
                        if (createdOnDate == null) return false;
                        LocalDate createdOnLocalDate = createdOnDate.toInstant()
                                .atZone(ZoneId.systemDefault())
                                .toLocalDate();
                        boolean isAfterOrEqual = generalMeetingReportDTO.getTaskAssignedDateFrom() == null
                                || !createdOnLocalDate.isBefore(generalMeetingReportDTO.getTaskAssignedDateFrom());
                        boolean isBeforeOrEqual = generalMeetingReportDTO.getTaskAssignedDateTo() == null
                                || !createdOnLocalDate.isAfter(generalMeetingReportDTO.getTaskAssignedDateTo());
                        return isAfterOrEqual && isBeforeOrEqual;
                    }).collect(Collectors.toList());
        }

        return generalMeetingTaskDtos;
    }

    private List<GeneralMeetingDto> filterMeetings(List<GeneralMeetingDto> generalMeetingDtos, GeneralMeetingReportDTO generalMeetingReportDTO) {
        if (generalMeetingDtos == null || generalMeetingDtos.isEmpty()) {
            log.warn("No meetings found to filter for the given criteria.");
            return new ArrayList<>();
        }

        generalMeetingDtos = generalMeetingDtos.stream()
                .filter(dto -> dto.getMeetingId() != null && !dto.getMeetingId().isEmpty())
                .filter(dto -> dto.getMeetingName() != null && !dto.getMeetingName().isEmpty())
                .filter(dto -> dto.getSegmentDtos() != null && !dto.getSegmentDtos().isEmpty())
                .filter(dto -> dto.getDepartmentDtos() != null && !dto.getDepartmentDtos().isEmpty())
                .collect(Collectors.toList());

        if (generalMeetingDtos.isEmpty()) {
            log.warn("No meetings remain after filtering for non-null meetingId, meetingName, segments, and departments.");
            return generalMeetingDtos;
        }

        if (generalMeetingReportDTO.getSegment() != null && !generalMeetingReportDTO.getSegment().isEmpty()) {
            generalMeetingDtos = generalMeetingDtos.stream()
                    .filter(generalMeetingDto -> generalMeetingDto != null && generalMeetingDto.getSegmentDtos() != null)
                    .filter(generalMeetingDto ->
                            generalMeetingDto.getSegmentDtos().stream()
                                    .anyMatch(segmentDto ->
                                            generalMeetingReportDTO.getSegment().stream()
                                                    .anyMatch(seg -> seg.equalsIgnoreCase(segmentDto.getName()))
                                    )).collect(Collectors.toList());
        }

        if (generalMeetingReportDTO.getDepartment() != null && !generalMeetingReportDTO.getDepartment().isEmpty()) {
            generalMeetingDtos = generalMeetingDtos.stream()
                    .filter(generalMeetingDto -> generalMeetingDto != null && generalMeetingDto.getDepartmentDtos() != null)
                    .filter(generalMeetingDto ->
                            generalMeetingDto.getDepartmentDtos().stream()
                                    .anyMatch(departmentDto ->
                                            generalMeetingReportDTO.getDepartment().stream()
                                                    .anyMatch(dept -> dept.equalsIgnoreCase(departmentDto.getName()))
                                    )).collect(Collectors.toList());
        }

        if (generalMeetingReportDTO.getAssignee() != null && !generalMeetingReportDTO.getAssignee().isEmpty()) {
            generalMeetingDtos = generalMeetingDtos.stream()
                    .filter(generalMeetingDto -> generalMeetingDto != null && generalMeetingDto.getGeneralMeetingTaskDtos() != null)
                    .filter(generalMeetingDto ->
                            generalMeetingDto.getGeneralMeetingTaskDtos().stream()
                                    .anyMatch(task ->
                                            task.getMeetingTaskAssigneeDtos() != null && task.getMeetingTaskAssigneeDtos().stream()
                                                    .anyMatch(assignee ->
                                                            generalMeetingReportDTO.getAssignee().contains(assignee.getEmpId())
                                                    ))).collect(Collectors.toList());
        }

        if (generalMeetingReportDTO.getAssignedBy() != null && !generalMeetingReportDTO.getAssignedBy().isEmpty()) {
            generalMeetingDtos = generalMeetingDtos.stream()
                    .filter(generalMeetingDto -> generalMeetingDto != null && generalMeetingDto.getGeneralMeetingTaskDtos() != null)
                    .filter(generalMeetingDto ->
                            generalMeetingDto.getGeneralMeetingTaskDtos().stream()
                                    .anyMatch(task ->
                                            task.getCreatedBy() != null &&
                                                    generalMeetingReportDTO.getAssignedBy().contains(Long.parseLong(task.getCreatedBy()))
                                    )).collect(Collectors.toList());
        }

        if (generalMeetingReportDTO.getAttendees() != null && !generalMeetingReportDTO.getAttendees().isEmpty()) {
            generalMeetingDtos = generalMeetingDtos.stream()
                    .filter(generalMeetingDto -> generalMeetingDto != null && generalMeetingDto.getMeetingParticipantsDtoList() != null)
                    .filter(generalMeetingDto ->
                            generalMeetingDto.getMeetingParticipantsDtoList().stream()
                                    .anyMatch(participant ->
                                            generalMeetingReportDTO.getAttendees().contains(participant.getEmployeeId())
                                    )).collect(Collectors.toList());
        }

        if (generalMeetingReportDTO.getHosts() != null && !generalMeetingReportDTO.getHosts().isEmpty()) {
            generalMeetingDtos = generalMeetingDtos.stream()
                    .filter(generalMeetingDto -> generalMeetingDto != null && generalMeetingDto.getScheduledBy() != null)
                    .filter(generalMeetingDto ->
                            generalMeetingReportDTO.getHosts().contains(Long.valueOf(generalMeetingDto.getScheduledBy()))
                    ).collect(Collectors.toList());
        }

        if (generalMeetingReportDTO.getMeetingDateFrom() != null || generalMeetingReportDTO.getMeetingDateTo() != null) {
            generalMeetingDtos = generalMeetingDtos.stream()
                    .filter(generalMeetingDto -> generalMeetingDto != null && generalMeetingDto.getMeetingDate() != null)
                    .filter(generalMeetingDto -> {
                        Date date = generalMeetingDto.getMeetingDate();
                        LocalDate meetingDate = date.toInstant()
                                .atZone(ZoneId.systemDefault())
                                .toLocalDate();
                        boolean isAfterOrEqual = generalMeetingReportDTO.getMeetingDateFrom() == null
                                || !meetingDate.isBefore(generalMeetingReportDTO.getMeetingDateFrom());
                        boolean isBeforeOrEqual = generalMeetingReportDTO.getMeetingDateTo() == null
                                || !meetingDate.isAfter(generalMeetingReportDTO.getMeetingDateTo());
                        return isAfterOrEqual && isBeforeOrEqual;
                    }).collect(Collectors.toList());
        }

        if (generalMeetingReportDTO.getTaskAssignedDateFrom() != null || generalMeetingReportDTO.getTaskAssignedDateTo() != null) {
            generalMeetingDtos = generalMeetingDtos.stream()
                    .filter(generalMeetingDto -> generalMeetingDto != null && generalMeetingDto.getGeneralMeetingTaskDtos() != null)
                    .filter(generalMeetingDto ->
                            generalMeetingDto.getGeneralMeetingTaskDtos().stream()
                                    .anyMatch(task -> {
                                        Date createdOnDate = task.getCreatedOn();
                                        if (createdOnDate == null) return false;
                                        LocalDate createdOnLocalDate = createdOnDate.toInstant()
                                                .atZone(ZoneId.systemDefault())
                                                .toLocalDate();
                                        boolean isAfterOrEqual = generalMeetingReportDTO.getTaskAssignedDateFrom() == null
                                                || !createdOnLocalDate.isBefore(generalMeetingReportDTO.getTaskAssignedDateFrom());
                                        boolean isBeforeOrEqual = generalMeetingReportDTO.getTaskAssignedDateTo() == null
                                                || !createdOnLocalDate.isAfter(generalMeetingReportDTO.getTaskAssignedDateTo());
                                        return isAfterOrEqual && isBeforeOrEqual;
                                    })).collect(Collectors.toList());
        }

        return generalMeetingDtos;
    }

    public void generateMeetingMOMReport(GeneralMeetingReportDTO reportDTO, List<GeneralMeetingDto> generalMeetingDtos, String path) throws Exception {
        Workbook workbook = new XSSFWorkbook();
        try {
            generalMeetingDtos = filterMeetings(generalMeetingDtos, reportDTO);
            log.info("After filtering, number of GeneralMeetingDto objects for MOM report: {}", generalMeetingDtos.size());

            Sheet sheet = workbook.createSheet("Meeting MOM Report");

            CellStyle headerStyle = createBorderedStyle(workbook, true);
            CellStyle dataStyle = createBorderedStyle(workbook, false);

            Row header = sheet.createRow(0);
            String[] headers = {
                    "SR. NO.", "MEETING ID", "MEETING NAME", "MEETING DATE", "MEETING TIME",
                    "HOST ID", "HOST NAME", "SEGMENT", "DEPARTMENTS", "ATTENDEES",
                    "MEETING STATUS", "MOM"
            };

            for (int i = 0; i < headers.length; i++) {
                Cell cell = header.createCell(i);
                cell.setCellValue(headers[i]);
                cell.setCellStyle(headerStyle);
            }

            List<String[]> dataRows = new ArrayList<>();
            int rowCount = 1;
            int serialNo = 1;

            for (GeneralMeetingDto meeting : generalMeetingDtos) {
                String[] rowData = new String[headers.length];
                fillMOMReportColumnsArray(rowData, serialNo, meeting);
                dataRows.add(rowData);
                Row row = sheet.createRow(rowCount++);
                fillMOMReportColumns(row, serialNo++, meeting, dataStyle);
            }

            // Auto-adjust column widths based on content
            adjustColumnWidths(sheet, headers.length, dataRows, headers);

            try (FileOutputStream fos = new FileOutputStream(path)) {
                workbook.write(fos);
                log.info("Successfully wrote Meeting MOM Report to: {}", path);
            }
        } finally {
            workbook.close();
        }
    }

    private void fillMOMReportColumnsArray(String[] rowData, int serialNo, GeneralMeetingDto meeting) {
        int col = 0;
        rowData[col++] = String.valueOf(serialNo);
        rowData[col++] = meeting.getMeetingId() != null ? meeting.getMeetingId() : "-";
        rowData[col++] = meeting.getMeetingName() != null ? meeting.getMeetingName() : "-";
        rowData[col++] = meeting.getMeetingDate() != null ? DateConverter.convertDateTime(meeting.getMeetingDate()) : "-";
        rowData[col++] = (meeting.getFromTime() != null && meeting.getFromTime() != null)
                ? meeting.getFromTime() + " - " + meeting.getToTime() : "-";
        String hostId = "-";
        String hostName = "-";
        if (meeting.getHostIdName() != null && !meeting.getHostIdName().isEmpty()) {
            String[] parts = meeting.getHostIdName().split("-", 2);
            hostId = parts.length > 0 ? parts[0].trim() : "-";
            hostName = parts.length > 1 ? parts[1].trim() : "-";
        } else if (meeting.getScheduledBy() != null) {
            hostId = meeting.getScheduledBy();
            hostName = meeting.getHostIdName() != null ? meeting.getHostIdName() : "-";
        }
        rowData[col++] = hostId;
        rowData[col++] = hostName;
        rowData[col++] = (meeting.getSegmentDtos() != null && !meeting.getSegmentDtos().isEmpty())
                ? meeting.getSegmentDtos().stream()
                .map(DepartmentDto::getName)
                .filter(name -> name != null)
                .reduce((a, b) -> a + ", " + b)
                .orElse("-")
                : "-";
        rowData[col++] = (meeting.getDepartmentDtos() != null && !meeting.getDepartmentDtos().isEmpty())
                ? meeting.getDepartmentDtos().stream()
                .map(DepartmentDto::getName)
                .filter(name -> name != null)
                .reduce((a, b) -> a + ", " + b)
                .orElse("-")
                : "-";
        rowData[col++] = (meeting.getMeetingParticipantsDtoList() != null && !meeting.getMeetingParticipantsDtoList().isEmpty())
                ? meeting.getMeetingParticipantsDtoList().stream()
                .map(MeetingParticipantsDto::getParticipantName)
                .filter(name -> name != null)
                .reduce((a, b) -> a + ", " + b)
                .orElse("-")
                : "-";
        rowData[col++] = meeting.getMeetingStatus() != null ? meeting.getMeetingStatus() : "-";
        String mom = "-";
        if (("completed".equalsIgnoreCase(meeting.getMeetingStatus()) || "closed".equalsIgnoreCase(meeting.getMeetingStatus())) && meeting.getMom() != null && !meeting.getMom().isEmpty()) {
            mom = meeting.getMom();
        }
        rowData[col++] = mom;
    }

    private void fillMOMReportColumns(Row row, int serialNo, GeneralMeetingDto meeting, CellStyle dataStyle) {
        int col = 0;

        row.createCell(col++).setCellValue(serialNo);

        String meetingId = meeting.getMeetingId() != null ? meeting.getMeetingId() : "-";
        row.createCell(col++).setCellValue(meetingId);
        if (meetingId.equals("-")) {
            log.warn("Meeting ID is null for meeting ID: {}", meeting.getId());
        }

        String meetingName = meeting.getMeetingName() != null ? meeting.getMeetingName() : "-";
        row.createCell(col++).setCellValue(meetingName);
        if (meetingName.equals("-")) {
            log.warn("Meeting Name is null for meeting ID: {}", meeting.getId());
        }

        String meetingDateStr = meeting.getMeetingDate() != null ? DateConverter.convertDateTime(meeting.getMeetingDate()) : "-";
        row.createCell(col++).setCellValue(meetingDateStr);

        String meetingTime = (meeting.getFromTime() != null && meeting.getToTime() != null)
                ? meeting.getFromTime() + " - " + meeting.getToTime() : "-";
        row.createCell(col++).setCellValue(meetingTime);
        if (meetingTime.equals("-")) {
            log.warn("Meeting time is null for meeting ID: {}", meeting.getId());
        }

        String hostId = "-";
        String hostName = "-";
        if (meeting.getHostIdName() != null && !meeting.getHostIdName().isEmpty()) {
            String[] parts = meeting.getHostIdName().split("-", 2);
            hostId = parts.length > 0 ? parts[0].trim() : "-";
            hostName = parts.length > 1 ? parts[1].trim() : "-";
        } else if (meeting.getScheduledBy() != null) {
            hostId = meeting.getScheduledBy();
            hostName = meeting.getHostIdName() != null ? meeting.getHostIdName() : "-";
        }
        row.createCell(col++).setCellValue(hostId);
        row.createCell(col++).setCellValue(hostName);

        String segments = (meeting.getSegmentDtos() != null && !meeting.getSegmentDtos().isEmpty())
                ? meeting.getSegmentDtos().stream()
                .map(DepartmentDto::getName)
                .filter(name -> name != null)
                .reduce((a, b) -> a + ", " + b)
                .orElse("-")
                : "-";
        row.createCell(col++).setCellValue(segments);
        if (segments.equals("-")) {
            log.warn("Segments are empty for meeting ID: {}", meeting.getId());
        }

        String departments = (meeting.getDepartmentDtos() != null && !meeting.getDepartmentDtos().isEmpty())
                ? meeting.getDepartmentDtos().stream()
                .map(DepartmentDto::getName)
                .filter(name -> name != null)
                .reduce((a, b) -> a + ", " + b)
                .orElse("-")
                : "-";
        row.createCell(col++).setCellValue(departments);
        if (departments.equals("-")) {
            log.warn("Departments are empty for meeting ID: {}", meeting.getId());
        }

        String attendees = (meeting.getMeetingParticipantsDtoList() != null && !meeting.getMeetingParticipantsDtoList().isEmpty())
                ? meeting.getMeetingParticipantsDtoList().stream()
                .map(MeetingParticipantsDto::getParticipantName)
                .filter(name -> name != null)
                .reduce((a, b) -> a + ", " + b)
                .orElse("-")
                : "-";
        row.createCell(col++).setCellValue(attendees);

        String meetingStatus = meeting.getMeetingStatus() != null ? meeting.getMeetingStatus() : "-";
        row.createCell(col++).setCellValue(meetingStatus);

        String mom = "-";
        if (("completed".equalsIgnoreCase(meetingStatus) || "closed".equalsIgnoreCase(meetingStatus)) && meeting.getMom() != null && !meeting.getMom().isEmpty()) {
            mom = meeting.getMom();
        }
        row.createCell(col++).setCellValue(mom);

        for (int i = 0; i < row.getLastCellNum(); i++) {
            Cell cell = row.getCell(i);
            if (cell == null) {
                cell = row.createCell(i);
            }
            cell.setCellStyle(dataStyle);
        }
    }
}