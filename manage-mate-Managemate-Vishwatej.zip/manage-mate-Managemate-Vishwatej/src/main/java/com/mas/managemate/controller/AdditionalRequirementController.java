package com.mas.managemate.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mas.managemate.model.dto.AdditionalRequirementDto;
import com.mas.managemate.model.dto.ApiResponse;
import com.mas.managemate.service.AdditionalRequirementService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/additional-requirement")
@Slf4j
public class AdditionalRequirementController {

    @Autowired
    private AdditionalRequirementService additionalRequirementService;

    @PostMapping("/create")
    public ApiResponse<?> createAdditionalRequirement( @RequestParam("additionalRequirement") String additionalRequirementJson,
            @RequestParam(value = "file", required = false) MultipartFile file) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            AdditionalRequirementDto additionalRequirementDto = objectMapper.readValue(additionalRequirementJson, AdditionalRequirementDto.class);
            AdditionalRequirementDto createdDto = additionalRequirementService.create(additionalRequirementDto, file);
            return new ApiResponse<>(createdDto, "success", HttpStatus.OK);
        } catch (Exception e) {
            log.error("error occurred in creating additional requirement {}",e.getMessage());
            return new ApiResponse<>(e.getMessage(), "failed to add additional requirement "+e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
}
