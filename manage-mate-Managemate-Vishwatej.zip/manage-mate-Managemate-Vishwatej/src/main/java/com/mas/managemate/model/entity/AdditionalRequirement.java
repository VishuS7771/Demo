package com.mas.managemate.model.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;

@Entity
@Table(name = "additional_requirement",schema = "managemate")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AdditionalRequirement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long additionalRequirementId;

    @ManyToOne
    @JoinColumn(name = "taskId")
    private Tasks tasks;

    @Column(name = "requirement", length = 5000)
    private String requirement;

    private Date dateAndTime;

    private String attachmentPath;

    @PrePersist
    public void dateAndTime() {
        ZonedDateTime istNow = ZonedDateTime.now(ZoneId.of("Asia/Kolkata"));
        this.dateAndTime=Date.from(istNow.toInstant());
    }
}
