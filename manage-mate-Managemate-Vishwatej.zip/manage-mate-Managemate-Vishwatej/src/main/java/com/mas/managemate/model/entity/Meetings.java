package com.mas.managemate.model.entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "Meetings", schema = "managemate")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Meetings {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "meeting_seq_gen")
    @SequenceGenerator(name = "meeting_seq_gen", sequenceName = "meeting_seq", allocationSize = 1)
    private Long id; // Temporary numeric column for the sequence

    @Column(name = "meetingId", nullable = false, unique = true)
    private String meetingId;

    @Column(name = "meetingName")
    private String meetingName;

    @Column(name = "agenda", length = 500)
    private String agenda;

    @Column(name = "date")
    private Date date;

    @Column(name = "fromTime")
    private String fromTime;

    @Column(name = "toTime")
    private String toTime;

    @Column(name = "location", length = 500)
    private String location;

    @Column(name = "link")
    private String link;

    @ManyToOne
    @JoinColumn(name = "taskId")
    private Tasks tasks;

    @Lob
    @Column(name = "remarks")
    private String remarks;

    @Column(name = "createdBy")
    private long createdBy;

    @Column(name = "meetingStatus")
    private String meetingStatus;

    @Column(name = "reasonForCancellation")
    private String reasonForCancellation;

    @Lob
    @Column(name = "mom")
    private String mom;

    @OneToMany(mappedBy = "meeting", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private List<MeetingParticipants> meetingParticipants;

    @Column(name = "createdOn")
    private Date createdOn;

    @PrePersist
    public void setCreatedOn() {
        if (this.createdOn == null) {
            ZonedDateTime istNow = ZonedDateTime.now(ZoneId.of("Asia/Kolkata"));
            this.createdOn = Date.from(istNow.toInstant());
        }
        // Generate meetingId before the entity is persisted
        SimpleDateFormat dateFormat = new SimpleDateFormat("ddMMyy");
        String formattedDate = dateFormat.format(new Date());
        this.meetingId = "M" + formattedDate + "00" + id; // This will now work because id is already available
    }
}
