package com.mas.managemate;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.autoconfigure.liquibase.LiquibaseAutoConfiguration;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@SpringBootApplication(exclude = {LiquibaseAutoConfiguration.class}, scanBasePackages = {"com.mas.managemate"})
@EnableAsync
@EnableAspectJAutoProxy
@EnableCaching
@EnableJpaAuditing
@ComponentScan({"com.mas.managemate*"})
@EntityScan({"com.mas.managemate.model.*"})
@EnableJpaRepositories(basePackages = {"com.mas.managemate"})
@EnableTransactionManagement
public class ManageMateApplication {

	public static void main(String[] args) {
		SpringApplication.run(ManageMateApplication.class, args);
	}

}
