package com.mas.managemate.service;

import com.mas.managemate.model.dto.MeetingParticipantsDto;
import com.mas.managemate.model.dto.MeetingsDto;

import java.util.List;

public interface MeetingService {

    MeetingsDto createMeeting(MeetingsDto meetingsDto);

    MeetingsDto updateMeetingStatus(String meetingId, MeetingsDto meetingsDto);

    MeetingsDto editMeeting(String meetingId, MeetingsDto meetingsDto);

    MeetingsDto getByMeetingId(String meetingId);

    List<MeetingsDto> getByTaskId(String taskId);

    List<MeetingsDto> getAllMeetings()throws Exception;

    List<MeetingParticipantsDto> getAllActiveParticipant(Long meetingId) throws Exception;

    List<MeetingsDto> getMeetingsByEmployee(long employeeId) throws Exception;

    List<MeetingsDto> getMeetingByTaskId(long taskId) throws Exception ;
}