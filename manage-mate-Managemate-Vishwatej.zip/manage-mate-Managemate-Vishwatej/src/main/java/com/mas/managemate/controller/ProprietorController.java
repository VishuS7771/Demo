package com.mas.managemate.controller;

import com.mas.managemate.exception.NotFoundException;
import com.mas.managemate.model.dto.ApiResponse;
import com.mas.managemate.model.dto.ProprietorAssignmentsDto;
import com.mas.managemate.model.dto.ProprietorMasterDto;
import com.mas.managemate.service.ProprietorService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/proprietor")
@Slf4j
public class ProprietorController {

    @Autowired
    ProprietorService proprietorService;

    @PostMapping("/proprietor-assignments")
    public ApiResponse<?> createProprietorAssignment(@RequestBody ProprietorAssignmentsDto proprietorAssignmentsDto) {
        try {
            ProprietorAssignmentsDto createdProprietorAssignmentsDto = proprietorService.createProprietorAssignment(proprietorAssignmentsDto);
            return new ApiResponse<>(createdProprietorAssignmentsDto, "Proprietor assignment created successfully.", HttpStatus.CREATED);
        } catch (Exception e) {
            log.error("error occurred in assign proprietor {}",e.getMessage());
            return new ApiResponse<>(e.getMessage(), "Failed to save proprietor assignment "+e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/get-proprietor-assignments")
    public ApiResponse<?> getAllProprietorAssignments() {
        try {
            List<ProprietorAssignmentsDto> proprietorList = proprietorService.getAllProprietor();
            return new ApiResponse<>(proprietorList, "Proprietor assignments retrieved successfully.", HttpStatus.OK);
        } catch (Exception e) {
            log.error("Failed to retrieve proprietor assignments {}",e.getMessage());
            return new ApiResponse<>(e.getMessage(), "Failed to retrieve proprietor assignments "+e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/get-proprietor-assignments/{proprietorMappingId}")
    public ApiResponse<?> getProprietorAssignmentById(@PathVariable long proprietorMappingId) {
        try {
            ProprietorAssignmentsDto proprietorAssignmentsDto = proprietorService.getProprietorAssignmentById(proprietorMappingId);
            return new ApiResponse<>(proprietorAssignmentsDto, "Proprietor assignment retrieved successfully.", HttpStatus.OK);
        } catch (NotFoundException e) {
            log.error("Proprietor assignment not found {}",e.getMessage());
            return new ApiResponse<>(e.getMessage(), "Proprietor assignment not found "+e.getMessage(), HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            log.error("Failed to retrieve proprietor assignment {}",e.getMessage());
            return new ApiResponse<>(e.getMessage(), "Failed to retrieve proprietor assignment " +e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/proprietor-assignments/{id}")
    public ApiResponse<?> updateProprietorAssignment(
            @PathVariable long id, @RequestBody ProprietorAssignmentsDto proprietorAssignmentsDto) {
        try {
            ProprietorAssignmentsDto updatedProprietorAssignmentsDto = proprietorService.updateProprietorAssignment(id, proprietorAssignmentsDto);
            return new ApiResponse<>(updatedProprietorAssignmentsDto, "Proprietor assignment updated successfully.", HttpStatus.OK);
        } catch (NotFoundException e) {
            log.error("Proprietor assignment not found {}",e.getMessage());
            return new ApiResponse<>(e.getMessage(), "Proprietor assignment not found "+e.getMessage(), HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            log.error("Failed to update proprietor assignment {}",e.getMessage());
            return new ApiResponse<>(e.getMessage(), "Failed to update proprietor assignment "+e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/get-by-status-sub/{statusId}/{subStatusId}")
    public ApiResponse<?> getProprietor(@PathVariable long statusId,@PathVariable long subStatusId){
        try {
            List<ProprietorAssignmentsDto> proprietorMasters=proprietorService.getProprietors(statusId,subStatusId);
            return new ApiResponse<>(proprietorMasters,"success",HttpStatus.OK);
        }catch (Exception e){
            log.error("Failed to get proprietor by status and sub status {}",e.getMessage());
            return new ApiResponse<>(e.getMessage(),"Failed to get proprietor by status and sub status "+e.getMessage(),HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/get-proprietors-master")
    public ApiResponse<?> getAllProprietorMaster() {
        try {
            List<ProprietorMasterDto> proprietorList = proprietorService.getAllProprietorMaster();
            return new ApiResponse<>(proprietorList, "Proprietor Master retrieved successfully.", HttpStatus.OK);
        } catch (Exception e) {
            log.error("Failed to retrieve proprietor Master {}",e.getMessage());
            return new ApiResponse<>(e.getMessage(), "Failed to retrieve proprietor Master "+e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

}