package com.mas.managemate.model.entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Entity
@Table(name = "MeetingParticipants", schema = "managemate")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MeetingParticipants {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "meetingParticipantId")
    private long meetingParticipantId;

    @ManyToOne
    @JoinColumn(name = "meetingId")
    @JsonManagedReference
    private Meetings meeting;

    @ManyToOne
    @JoinColumn(name = "generalMeetingId")
    @JsonManagedReference
    private GeneralMeeting generalMeeting;

    @Column(name = "employeeId")
    private long employeeId;

    @Column(name = "assignedBy")
    private long assignedBy;

    @Column(name = "assignedDate")
    private Date assignedDate;

    @Column(name = "isActive")
    private int isActive;

}
