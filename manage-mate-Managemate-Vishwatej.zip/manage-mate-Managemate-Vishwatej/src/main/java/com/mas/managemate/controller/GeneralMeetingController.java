package com.mas.managemate.controller;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mas.managemate.model.dto.*;
import com.mas.managemate.service.GeneralMeetingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/general-meetings")
public class GeneralMeetingController {


    @Autowired
    private GeneralMeetingService generalMeetingService;


    @PostMapping("/create")
    public ApiResponse<?> createGeneralMeeting(@RequestBody GeneralMeetingDto generalMeetingDto) {
        GeneralMeetingDto createGeMeeting = generalMeetingService.createGeneralMeeting(generalMeetingDto);
        return new ApiResponse<>(createGeMeeting, "Meeting Created Succesdfully", HttpStatus.CREATED);
    }

    @PostMapping("/mark-status")
    public ApiResponse<?> markStatus(@RequestParam("markStatusDto") String meetingStatusMarkDtoJson, @RequestParam(value = "file", required = false) MultipartFile file) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            MeetingStatusMarkDto meetingStatusMarkDto = objectMapper.readValue(meetingStatusMarkDtoJson, MeetingStatusMarkDto.class);
            generalMeetingService.markStatus(meetingStatusMarkDto, file);
            return new ApiResponse<>(null, "status marked successfully", HttpStatus.OK);
        } catch (Exception e) {
            return new ApiResponse<>(null, "status Marking Failed", HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/get-all/{employeeNo}")
    public ApiResponse<?> getAllGeneralMeetings(@PathVariable("employeeNo") Long employeeNo) {
        try {
            List<GeneralMeetingDto> allGeneralMeetings = generalMeetingService.getAllGeneralMeetings(employeeNo);
            return new ApiResponse<>(allGeneralMeetings, "get all Meetings", HttpStatus.OK);
        } catch (Exception e) {
            return new ApiResponse<>(null, "get all Meetings Failed", HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/update-meetings/{generalMeetingId}")
    public ApiResponse<?> updateGeneralMeetings(@RequestBody GeneralMeetingDto generalMeetingDto, @PathVariable Long generalMeetingId) {
        try {
            GeneralMeetingDto generalMeetingDto1 = generalMeetingService.updateMeeting(generalMeetingId, generalMeetingDto);
            return new ApiResponse<>(null, "meeting updated successfully", HttpStatus.OK);
        } catch (Exception e) {
            return new ApiResponse<>(null, "Failed to update meeting", HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/reschedule-meeting/{generalMeetingId}")
    public ApiResponse<?> rescheduleMeeting(@RequestBody GeneralMeetingDto generalMeetingDto, @PathVariable Long generalMeetingId) {
        try {
            generalMeetingService.rescheduleMeeting(generalMeetingId, generalMeetingDto);
            return new ApiResponse<>(null, "meeting rescheduled successfully", HttpStatus.OK);
        } catch (Exception e) {
            return new ApiResponse<>(null, "Failed to reschedule meeting", HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/get-tasks/{meetingId}")
    public ApiResponse<?> getGeneralMeetingTasks(@PathVariable("meetingId") Long meetingId) {
        try {
            List<GeneralMeetingTaskDto> generalMeetingTaskDtos = generalMeetingService.getMeetingTask(meetingId);
            return new ApiResponse<>(generalMeetingTaskDtos, "get meeting task successfully", HttpStatus.OK);
        } catch (Exception e) {
            return new ApiResponse<>(null, "Failed to get meeting task", HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/task-respond")
    public ApiResponse<?> taskRespond(@RequestParam("taskRespondDto") String taskRespondDtoString, @RequestParam(value = "file", required = false) MultipartFile file) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            TaskRespondDto taskRespondDto = objectMapper.readValue(taskRespondDtoString, TaskRespondDto.class);
            generalMeetingService.taskRespond(taskRespondDto, file);
            return new ApiResponse<>(null, "task respond successfully", HttpStatus.OK);
        } catch (Exception e) {
            return new ApiResponse<>(null, "Failed to respond task", HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/task-marked")
    public ApiResponse<?> taskMarked(@RequestBody TaskRespondDto taskRespondDto) {
        try {
            generalMeetingService.taskMarking(taskRespondDto);
            return new ApiResponse<>(null, "task marked successfully", HttpStatus.OK);
        } catch (Exception e) {
            return new ApiResponse<>(null, "Failed to marked task", HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/add-task")
    public ApiResponse<?> addTasks(@RequestBody List<GeneralMeetingTaskDto> generalMeetingTaskDto) {
        try {
            generalMeetingService.saveMeetingTask(generalMeetingTaskDto);
            return new ApiResponse<>(null, "Added meeting task", HttpStatus.OK);
        } catch (Exception e) {
            return new ApiResponse<>(null, "Adding meeting task Failed", HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/edit-task/{taskId}")
    public ApiResponse<?> editTask(@PathVariable("taskId") long taskId, @RequestBody GeneralMeetingTaskDto generalMeetingTaskDto) {
        try {
            generalMeetingService.editTask(taskId, generalMeetingTaskDto);
            return new ApiResponse<>(null, "updated meeting task", HttpStatus.OK);
        } catch (Exception e) {
            return new ApiResponse<>(null, "updating meeting task Failed", HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/get-respond/{meetingTaskId}")
    public ApiResponse<?> getRespondAndMarking(@PathVariable("meetingTaskId") long meetingTaskId) {
        try {
            List<TaskRespondDto> respondAndMarkingDtos = generalMeetingService.getRespondAndMarking(meetingTaskId);
            return new ApiResponse<>(respondAndMarkingDtos, "getting meeting task marking/respond successful", HttpStatus.OK);
        } catch (Exception e) {
            return new ApiResponse<>(null, "getting meeting task marking/respond Failed", HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/get-general-meeting/{generalMeetingId}")
    public ApiResponse<?> getGeneralMeeting(@PathVariable("generalMeetingId") Long generalMeetingId) {
        try {
            GeneralMeetingDto generalMeetingDto = generalMeetingService.getMeetingById(generalMeetingId);
            return new ApiResponse<>(generalMeetingDto, "getting meeting by id successful", HttpStatus.OK);
        } catch (Exception e) {
            return new ApiResponse<>(null, "getting meeting by id Failed", HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/send-link/{meetingId}")
    public ApiResponse<?> sendMeetingLink(@PathVariable("meetingId") long meetingId) {
        try {
            generalMeetingService.sendMeetingLink(meetingId);
            return new ApiResponse<>(null, "meeting link send successful", HttpStatus.OK);
        } catch (Exception e) {
            return new ApiResponse<>(null, "meeting link send Failed", HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/timeline/{generalMeetingId}")
    public ApiResponse<?> getGeneralMeetingTimeline(@PathVariable("generalMeetingId") long id) {
        try {
            GeneralMeetingTimelineDto timelineDto = generalMeetingService.getGeneralMeetingTimeline(id);
            return new ApiResponse<>(timelineDto, "getting general meeting by id successful", HttpStatus.OK);
        } catch (Exception e) {
            return new ApiResponse<>(null, "getting general meeting by id Failed", HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/get-task-by-empid/{empId}/flag/{flag}")
    public ApiResponse<?> getGeneralMeetingTaskByEmp(@PathVariable("empId") Long empId, @PathVariable("flag") Boolean flag){
        List<GeneralMeetingTaskDto> generalMeetingTasks = null;
        try {
            generalMeetingTasks = generalMeetingService.getGeneralMeetingTaskByEmp(empId, flag);
            return new ApiResponse<>(generalMeetingTasks,"Fetched tasks successfully", HttpStatus.OK);
        } catch (Exception e) {
            return new ApiResponse<>(e.getMessage(), "Failed to fetch task Id", HttpStatus.BAD_REQUEST);
        }
    }
}
