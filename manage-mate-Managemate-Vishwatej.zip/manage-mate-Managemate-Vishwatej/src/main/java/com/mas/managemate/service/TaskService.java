package com.mas.managemate.service;

import com.mas.managemate.model.dto.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

public interface TaskService {

    TasksDto addTasks(TasksDto tasksDto, MultipartFile multipartFile) throws Exception;

    TasksDto getTaskByTaskId(long taskId);

    List<TasksDto> getAllTask();

    List<TasksDto> getTaskByDesignationId(long designationId,long empId) throws Exception;

    List<TasksDto> getTaskByDepartment(long departmentId);

    TasksDto editTask(TasksDto tasksDto) throws ParseException;

    List<TasksDto> getByParentTaskid(long taskId);

    TasksDto addSubTask(TasksDto tasksDto,long parentId,MultipartFile multipartFile) throws IOException, ParseException;

    TasksDto updateSubTask(TasksDto tasksDto, long taskId);

    void markSubTaskStatus(SubTaskStatusDto subTaskStatusDto);

//    Map<String, String> getLatestProprietorAndStatus(long empId);

    StatusProprietorResultDto getLatestProprietorAndStatus(long empId, String designation) throws Exception;

    List<TaskListResponse> getAllTaskList();

    StatusProprietorResultDto getProprietorAndStatusByStakeHolder(long empId, String designation);
}
