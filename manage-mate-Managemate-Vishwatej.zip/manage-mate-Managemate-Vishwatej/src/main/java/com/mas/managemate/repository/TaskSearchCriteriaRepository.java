package com.mas.managemate.repository;

import com.mas.managemate.model.entity.TaskSearchCriteria;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface TaskSearchCriteriaRepository extends JpaRepository<TaskSearchCriteria,Long> {

    Optional<TaskSearchCriteria> findByEmployeeId(long employeeId);
}
