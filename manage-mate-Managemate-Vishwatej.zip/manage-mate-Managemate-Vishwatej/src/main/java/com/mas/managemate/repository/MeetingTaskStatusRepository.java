package com.mas.managemate.repository;

import com.mas.managemate.model.entity.MeetingTaskStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MeetingTaskStatusRepository extends JpaRepository<MeetingTaskStatus,Long> {

    @Query(value = "SELECT * FROM task_status WHERE general_meeting_task_id IN :taskIds", nativeQuery = true)
    List<MeetingTaskStatus> findByGeneralMeetingTaskId( @Param("taskIds") List<Long> taskIds);
}
