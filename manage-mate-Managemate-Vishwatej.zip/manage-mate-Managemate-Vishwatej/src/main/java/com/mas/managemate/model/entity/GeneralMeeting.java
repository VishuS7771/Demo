package com.mas.managemate.model.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;

@Entity
@Table(name = "general_meeting", schema = "managemate")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class GeneralMeeting {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "general_meeting_seq_gen")
    @SequenceGenerator(name = "general_meeting_seq_gen", sequenceName = "general_meeting_seq", allocationSize = 1)
    private Long id;

    @Column(name = "meetingId", nullable = false, unique = true)
    private String meetingId;

    @Column(name = "meetingName")
    private String meetingName;

    @Column(name = "agenda", length = 500)
    private String agenda;

    @Column(name = "meetingDate")
    private Date meetingDate;

    @Column(name = "fromTime")
    private String fromTime;

    @Column(name = "toTime")
    private String toTime;

    @Column(name = "location", length = 500)
    private String location;

    @Column(name = "link")
    private String link;

    @Lob
    @Column(name = "remarks")
    private String remarks;

    @Column(name = "createdBy")
    private long createdBy;

    @Column(name = "reasonForCancellation")
    private String reasonForCancellation;

    @Lob
    @Column(name = "mom", length = 5000)
    private String mom;

    @Column(name = "createdOn")
    private Date createdOn;

    @Column(name = "scheduledBy")
    private String scheduledBy;

    @PrePersist
    public void setCreatedOn() {
        if (this.createdOn == null) {
            ZonedDateTime istNow = ZonedDateTime.now(ZoneId.of("Asia/Kolkata"));
            this.createdOn = Date.from(istNow.toInstant());
        }
        // Generate meetingId before the entity is persisted
        SimpleDateFormat dateFormat = new SimpleDateFormat("ddMMyy");
        String formattedDate = dateFormat.format(new Date());
        this.meetingId = "GNM" + formattedDate + "000" + id; // This will now work because id is already available
    }
}
