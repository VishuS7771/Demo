package com.mas.managemate.serviceImpl;

import com.mas.managemate.model.dto.EmployeeProfileResponse;
import com.mas.managemate.model.entity.*;
import com.mas.managemate.repository.*;
import com.mas.managemate.util.ApiClient;
import com.mas.managemate.util.DateConverter;
import com.mas.managemate.util.EmailSender;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class EmailService {

    @Autowired
    private ApiClient apiClient;

    @Autowired
    private EmailSender emailSender;

    private final Map<String, EmployeeProfileResponse.EmployeeData> employeeDataCache = new HashMap<>();

    @Autowired
    private TaskAssignmentsRepository taskAssignmentsRepository;

    @Autowired
    private GeneralMeetingTaskRepository generalMeetingTaskRepository;

    @Autowired
    private MeetingParticipantsRepository meetingParticipantsRepository;

    @Autowired
    private MeetingTaskAssigneeRepository meetingTaskAssigneeRepository;

    @Autowired
    private DepartmentSegmentMapperRepository departmentSegmentMapperRepository;

    @Autowired
    private GeneralMeetingStatusMarkRepository generalMeetingStatusMarkRepository;

    @Autowired
    private GeneralMeetingRepository generalMeetingRepository;


    // Email for Task Assigned
    public void sendTaskAssignEmail(TaskAssignments taskAssignments) {
        String createdByUserId = String.valueOf(taskAssignments.getAssignedBy());
        EmployeeProfileResponse.EmployeeData assignedByEmployee = getEmployeeData(createdByUserId);
        String subject = "Project Assigned - " + taskAssignments.getTasks().getTaskName() + " & " + taskAssignments.getTasks().getTaskId();
        String body = "<html>" +
                "<head>" +
                "<style>" +
                ".highlight { font-family: 'Lincoln', sans-serif; color: #D5006D; }" +
                "</style>" +
                "</head>" +
                "<body>" +
                "Dear Team,<br><br>" +
                "Below mentioned project has been assigned to you.<br>" +
                "Kindly refer to the ticket-raising module for more details.<br><br>" +
                "<strong><u>Project Details</u></strong><br><br>" +
                "Project Name & ID: " + taskAssignments.getTasks().getTaskName() + " " + taskAssignments.getTasks().getTaskId() + "<br>" +
                "Assigned By: " + assignedByEmployee.getEmployeeName() + "<br>" +
                "Date & Time: " + DateConverter.convertDateTime(new Date()) + "<br><br>" +
                "Regards,<br>" +
                "<span class='highlight'>MAS</span> Financial Services Ltd<br>" +
                "______________________________________________<br>" +
                "<em>This is a system-generated email. Please do not reply.</em>" +
                "</body>" +
                "</html>";
        Map<String, String> map = getEmployeeEmail(taskAssignments.getEmployeeId());
        String assignedCc = map.get("CC");
        String assignedTo = map.get("To");
        emailSender.sendEmail(assignedTo, assignedCc, subject, body);
    }

    // Email for Sub task assigned
    public void sendSubTaskAssignEmail(TaskAssignments taskAssignments) {
        String createdByUserId = String.valueOf(taskAssignments.getAssignedBy());
        EmployeeProfileResponse.EmployeeData assignedByEmployee = getEmployeeData(createdByUserId);
        String subject = "Project Assigned - " + taskAssignments.getTasks().getTaskName() + " & " + taskAssignments.getTasks().getTaskId();
        String body = "<html>" +
                "<head>" +
                "<style>" +
                ".highlight { font-family: 'Lincoln', sans-serif; color: #D5006D; }" +
                "</style>" +
                "</head>" +
                "<body>" +
                "Dear Team,<br><br>" +
                "Below mentioned project has been assigned to you.<br>" +
                "Kindly refer to the ticket-raising module for more details.<br><br>" +
                "<strong><u>Project Details</u></strong><br><br>" +
                "Project Name & ID: " + taskAssignments.getTasks().getTaskName() + "-" + taskAssignments.getTasks().getTaskId() + "<br>" +
                "Assigned By: " + assignedByEmployee.getEmployeeName() + "<br>" +
                "Date & Time: " + DateConverter.convertDateTime(new Date()) + "<br><br>" +
                "Regards,<br>" +
                "<span class='highlight'>MAS</span> Financial Services Ltd<br>" +
                "______________________________________________<br>" +
                "<em>This is a system-generated email. Please do not reply.</em>" +
                "</body>" +
                "</html>";

        Map<String, String> map = getEmployeeEmail(taskAssignments.getEmployeeId());
        String assignedCc = map.get("CC");
        String assignedTo = map.get("To");
        emailSender.sendEmail(assignedTo, assignedCc, subject, body);
    }

    // Email for Additional Requirement
    public void sendAdditionalRequirementEmail(AdditionalRequirement additionalRequirement) {
        String createdByUserId = String.valueOf(additionalRequirement.getTasks().getRaisedBy());
        EmployeeProfileResponse.EmployeeData raisedByEmployee = getEmployeeData(createdByUserId);
        String subject = "Additional Requirement - " + additionalRequirement.getTasks().getTaskName() + " & " + additionalRequirement.getTasks().getTaskId();
        String body = "<html>" +
                "<head>" +
                "<style>" +
                ".highlight { font-family: 'Lincoln', sans-serif; color: #D5006D; }" +
                "</style>" +
                "</head>" +
                "<body>" +
                "Dear Team,<br><br>" +
                "An additional requirement has been raised. <br>" +
                "Kindly refer to the ticket-raising module for more details.<br><br>" +
                "<strong><u>Requirement Details</u></strong><br><br>" +
                "Project Name & ID: " + additionalRequirement.getTasks().getTaskName() + " - " + additionalRequirement.getTasks().getTaskId() + "<br>" +
                "Assigned By: " + raisedByEmployee.getEmployeeName() + "<br>" +
                "Date & Time: " + DateConverter.convertDateTime(new Date()) + "<br><br>" +
                "Regards,<br>" +
                "<span class='highlight'>MAS</span> Financial Services Ltd<br>" +
                "______________________________________________<br>" +
                "<em>This is a system-generated email. Please do not reply.</em>" +
                "</body>" +
                "</html>";

        long taskId = additionalRequirement.getTasks().getId();
        List<TaskAssignments> taskAssignments = taskAssignmentsRepository.findByTaskId(taskId);
        TaskAssignments taskAssignments1 = taskAssignments.stream().max(Comparator.comparing(TaskAssignments::getAssignDate))
                .orElse(null);

        Map<String, String> map = getEmployeeEmail(taskAssignments1.getEmployeeId());
        String assignedCc = map.get("CC");
        String assignedTo = map.get("To");
        emailSender.sendEmail(assignedTo, assignedCc, subject, body);
    }

    // Email for Task status marked
    public void sendTaskStatusMarkedEmail(TaskTimelines taskTimelines) {
        String createdByUserId = String.valueOf(taskTimelines.getMarkedBy());
        EmployeeProfileResponse.EmployeeData markedByEmployee = getEmployeeData(createdByUserId);
        String subject = "Status Marked - " + taskTimelines.getTasks().getTaskName() + " & " + taskTimelines.getTasks().getTaskId();
        String body = "<html>" +
                "<head>" +
                "<style>" +
                ".highlight { font-family: 'Lincoln', sans-serif; color: #D5006D; }" +
                "</style>" +
                "</head>" +
                "<body>" +
                "Dear Team,<br><br>" +
                "Project/Sub-Task status has been marked. <br>" +
                "Kindly refer to the ticket-raising module for more details.<br><br>" +
                "<strong><u>Details</u></strong><br><br>" +
                "Project Name & ID: " + taskTimelines.getTasks().getTaskName() + " " + taskTimelines.getTasks().getTaskId() + "<br>" +
                "Status & Sub status: " + taskTimelines.getStatus().getStatus() + " - " + taskTimelines.getSubStatus().getSubStatus() + "<br>" +
                "Marked By: " + markedByEmployee.getEmployeeName() + "<br>" +
                "Date & Time: " + DateConverter.convertDateTime(new Date()) + "<br><br>" +
                "Regards,<br>" +
                "<span class='highlight'>MAS</span> Financial Services Ltd<br>" +
                "______________________________________________<br>" +
                "<em>This is a system-generated email. Please do not reply.</em>" +
                "</body>" +
                "</html>";

        long taskId = taskTimelines.getTasks().getId();
        List<TaskAssignments> taskAssignments = taskAssignmentsRepository.findByTaskId(taskId);
        TaskAssignments taskAssignments1 = taskAssignments.stream().max(Comparator.comparing(TaskAssignments::getAssignDate))
                .orElse(null);

        assert taskAssignments1 != null;
        Map<String, String> map = getEmployeeEmail(taskAssignments1.getEmployeeId());
        String assignedCc = map.get("CC");
        String assignedTo = map.get("To");
        emailSender.sendEmail(assignedTo, assignedCc, subject, body);
    }

    // Email for scheduled meeting
    public void sendMeetingScheduledEmail(Meetings saveMeeting) {
        String createdByUserId = String.valueOf(saveMeeting.getCreatedBy());
        EmployeeProfileResponse.EmployeeData createdByEmployee = getEmployeeData(createdByUserId);
        String subject = "Scheduled Meeting - " + saveMeeting.getTasks().getTaskId() + " - " + saveMeeting.getTasks().getTaskName();
        String body = "<html>" +
                "<head>" +
                "<style>" +
                ".highlight { font-family: 'Lincoln', sans-serif; color: #D5006D; }" +
                "</style>" +
                "</head>" +
                "<body>" +
                "Dear Team,<br><br>" +
                "A meeting has been scheduled for Task ID: " + saveMeeting.getTasks().getTaskId() + ".<br>" +
                "Kindly refer to the ticket-raising module for more details.<br><br>" +
                "<strong><u>Meeting Details</u></strong><br><br>" +
                "Meeting Objective: " + saveMeeting.getAgenda() + "<br>" +
                "Scheduled By: " + createdByEmployee.getEmployeeName() + "<br>" +
                "Date & Time: " + DateConverter.convertDateTime(new Date()) + " From: " + saveMeeting.getFromTime() + " To: " + saveMeeting.getToTime() + "<br><br>" +
                "Regards,<br>" +
                "<span class='highlight'>MAS</span> Financial Services Ltd<br>" +
                "______________________________________________<br>" +
                "<em>This is a system-generated email. Please do not reply.</em>" +
                "</body>" +
                "</html>";

        Map<String, List<String>> reportingManagerEmailsMap = saveMeeting.getMeetingParticipants().stream()
                .filter(participant -> participant.getIsActive() == 1) // Only active participants
                .collect(Collectors.groupingBy(participant -> {
                            String userId = String.valueOf(participant.getEmployeeId());
                            EmployeeProfileResponse.EmployeeData employeeData = getEmployeeData(userId);
                            return employeeData.getReportingManagerEmail(); // Group by reporting manager email
                        },
                        Collectors.mapping(participant -> {
                            String userId = String.valueOf(participant.getEmployeeId());
                            EmployeeProfileResponse.EmployeeData employeeData = getEmployeeData(userId);
                            return employeeData.getCompanyEmail();
                        }, Collectors.toList())));

        // Send emails for each reporting manager group
        reportingManagerEmailsMap.forEach((reportingManagerEmail, participantEmails) -> {
            String assignedTo = String.join(",", participantEmails);
            emailSender.sendEmail(assignedTo, "ba_3@mas.co.in", subject, body);
        });
    }

    //  Email for  rescheduled meeting
    public void sendMeetingReScheduledEmail(Meetings existingMeeting) {
        String createdByUserId = String.valueOf(existingMeeting.getCreatedBy());
        EmployeeProfileResponse.EmployeeData createdByEmployee = getEmployeeData(createdByUserId);
        String subject = "Meeting Re-scheduled - " + existingMeeting.getTasks().getTaskId() + " - " + existingMeeting.getTasks().getTaskName();
        String body = "<html>" +
                "<head>" +
                "<style>" +
                ".highlight { font-family: 'Lincoln', sans-serif; color: #D5006D; }" +
                "</style>" +
                "</head>" +
                "<body>" +
                "Dear Team,<br><br>" +
                "Meeting is Re-Scheduled for Task ID: " + existingMeeting.getTasks().getTaskId() + ".<br>" +
                "Kindly refer to the ticket-raising module for more details.<br><br>" +
                "<strong><u>Meeting Details</u></strong><br><br>" +
                "Meeting Objective: " + existingMeeting.getAgenda() + "<br>" +
                "Re-Scheduled By: " + createdByEmployee.getEmployeeName() + "<br>" +
                "Date & Time: " + DateConverter.convertDateTime(new Date()) + " From: " + existingMeeting.getFromTime() + " To: " + existingMeeting.getToTime() + "<br><br>" +
                "Regards,<br>" +
                "<span class='highlight'>MAS</span> Financial Services Ltd<br>" +
                "______________________________________________<br>" +
                "<em>This is a system-generated email. Please do not reply.</em>" +
                "</body>" +
                "</html>";

        Map<String, List<String>> reportingManagerEmailsMap = existingMeeting.getMeetingParticipants().stream()
                .filter(participant -> participant.getIsActive() == 1) // Only active participants
                .collect(Collectors.groupingBy(participant -> {
                            String userId = String.valueOf(participant.getEmployeeId());
                            EmployeeProfileResponse.EmployeeData employeeData = getEmployeeData(userId);
                            return employeeData.getReportingManagerEmail(); // Group by reporting manager email
                        },
                        Collectors.mapping(participant -> {
                            String userId = String.valueOf(participant.getEmployeeId());
                            EmployeeProfileResponse.EmployeeData employeeData = getEmployeeData(userId);
                            return employeeData.getCompanyEmail();
                        }, Collectors.toList())));

        // Send emails for each reporting manager group
        reportingManagerEmailsMap.forEach((reportingManagerEmail, participantEmails) -> {
            String assignedTo = String.join(",", participantEmails);
            emailSender.sendEmail(assignedTo, "ba_3@mas.co.in", subject, body);
        });
    }

    // Email for cancelled meeting
    public void sendMeetingCanceledEmail(Meetings existingMeeting) {
        String createdByUserId = String.valueOf(existingMeeting.getCreatedBy());
        EmployeeProfileResponse.EmployeeData createdByEmployee = getEmployeeData(createdByUserId);
        String subject = "Meeting Canceled - " + existingMeeting.getTasks().getTaskId() + " - " + existingMeeting.getTasks().getTaskName();
        String body = "<html>" +
                "<head>" +
                "<style>" +
                ".highlight { font-family: 'Lincoln', sans-serif; color: #D5006D; }" +
                "</style>" +
                "</head>" +
                "<body>" +
                "Dear Team,<br><br>" +
                "The meeting for Task ID: " + existingMeeting.getTasks().getTaskId() + " has been canceled.<br>" +
                "Kindly refer to the ticket-raising module for more details.<br><br>" +
                "<strong><u>Meeting Details</u></strong><br><br>" +
                "Meeting Objective: " + existingMeeting.getAgenda() + "<br>" +
                "Canceled By: " + createdByEmployee.getEmployeeName() + "<br>" +
                "Date & Time: " + DateConverter.convertDateTime(new Date()) + " From: " + existingMeeting.getFromTime() + " To: " + existingMeeting.getToTime() + "<br><br>" +
                "Regards,<br>" +
                "<span class='highlight'>MAS</span> Financial Services Ltd<br>" +
                "______________________________________________<br>" +
                "<em>This is a system-generated email. Please do not reply.</em>" +
                "</body>" +
                "</html>";

        Map<String, List<String>> reportingManagerEmailsMap = existingMeeting.getMeetingParticipants().stream()
                .filter(participant -> participant.getIsActive() == 1) // Only active participants
                .collect(Collectors.groupingBy(participant -> {
                            String userId = String.valueOf(participant.getEmployeeId());
                            EmployeeProfileResponse.EmployeeData employeeData = getEmployeeData(userId);
                            return employeeData.getReportingManagerEmail(); // Group by reporting manager email
                        },
                        Collectors.mapping(participant -> {
                            String userId = String.valueOf(participant.getEmployeeId());
                            EmployeeProfileResponse.EmployeeData employeeData = getEmployeeData(userId);
                            return employeeData.getCompanyEmail();
                        }, Collectors.toList())));

        // Send emails for each reporting manager group
        reportingManagerEmailsMap.forEach((reportingManagerEmail, participantEmails) -> {
            String assignedTo = String.join(",", participantEmails);
            emailSender.sendEmail(assignedTo, "ba_3@mas.co.in", subject, body);
        });
    }

    // Email for Completed meeting
    public void sendMeetingStatusCompletedEmail(Meetings existingMeeting) {
        String createdByUserId = String.valueOf(existingMeeting.getCreatedBy());
        EmployeeProfileResponse.EmployeeData createdByEmployee = getEmployeeData(createdByUserId);
        String subject = "Meeting Completed - " + existingMeeting.getTasks().getTaskId() + " - " + existingMeeting.getTasks().getTaskName();
        String body = "<html>" +
                "<head>" +
                "<style>" +
                ".highlight { font-family: 'Lincoln', sans-serif; color: #D5006D; }" +
                "</style>" +
                "</head>" +
                "<body>" +
                "Dear Team,<br><br>" +
                "Meeting has been marked as completed for Task ID: " + existingMeeting.getTasks().getTaskId() + ".<br>" +
                "Kindly refer to the ticket-raising module for more details.<br><br>" +
                "<strong><u>Meeting Details</u></strong><br><br>" +
                "Meeting Objective: " + existingMeeting.getAgenda() + "<br>" +
                "Marked By: " + createdByEmployee.getEmployeeName() + "<br>" +
                "Date & Time: " + DateConverter.convertDateTime(new Date()) + " From: " + existingMeeting.getFromTime() + " To: " + existingMeeting.getToTime() + "<br><br>" +
//                "MOM Link: <a href='" + existingMeeting.getMom() + "'>Click here</a><br><br>" +
                "Regards,<br>" +
                "<span class='highlight'>MAS</span> Financial Services Ltd<br>" +
                "______________________________________________<br>" +
                "<em>This is a system-generated email. Please do not reply.</em>" +
                "</body>" +
                "</html>";

        Map<String, List<String>> reportingManagerEmailsMap = existingMeeting.getMeetingParticipants().stream()
                .filter(participant -> participant.getIsActive() == 1) // Only active participants
                .collect(Collectors.groupingBy(participant -> {
                            String userId = String.valueOf(participant.getEmployeeId());
                            EmployeeProfileResponse.EmployeeData employeeData = getEmployeeData(userId);
                            return employeeData.getReportingManagerEmail(); // Group by reporting manager email
                        },
                        Collectors.mapping(participant -> {
                            String userId = String.valueOf(participant.getEmployeeId());
                            EmployeeProfileResponse.EmployeeData employeeData = getEmployeeData(userId);
                            return employeeData.getCompanyEmail();
                        }, Collectors.toList())));

        reportingManagerEmailsMap.forEach((reportingManagerEmail, participantEmails) -> {
            String assignedTo = String.join(",", participantEmails);
            emailSender.sendEmail(assignedTo, "ba_3@mas.co.in", subject, body);
        });
    }

    public void sendMailGeneralMeetingStatusCompleted(GeneralMeeting generalMeeting){
        List<GeneralMeetingTasks> generalMeetingTasks=generalMeetingTaskRepository.findByGeneralMeeting_Id(generalMeeting.getId());
        String scheduledBy = String.valueOf(generalMeeting.getScheduledBy());
        EmployeeProfileResponse.EmployeeData scheduledByEmployee = getEmployeeData(scheduledBy);
        String subject = "Meeting | " + generalMeeting.getMeetingName() + " | Date :  " + DateConverter.convertDateTime(generalMeeting.getMeetingDate());

        List<MeetingParticipants> meetingParticipants=meetingParticipantsRepository.findByGeneralMeeting_Id(generalMeeting.getId());

        List<GeneralMeetingStatusMark> generalMeetingStatusMarksList=generalMeetingStatusMarkRepository.findByGeneralMeeting_Id(generalMeeting.getId());
        Optional<GeneralMeetingStatusMark> latestStatusMark = generalMeetingStatusMarksList.stream()
                .max(Comparator.comparing(GeneralMeetingStatusMark::getMarkedOn));

        StringBuilder taskRows = new StringBuilder();
        int count = 1;
        for (GeneralMeetingTasks task : generalMeetingTasks) {
            List<MeetingTaskAssignee> meetingTaskAssignees =meetingTaskAssigneeRepository.findByGeneralMeetingTasks_GeneralMeetingTaskId(task.getGeneralMeetingTaskId());
            String employeeNames = meetingTaskAssignees.stream()
                    .map(participant -> {
                        String userId = String.valueOf(participant.getEmpId());
                        EmployeeProfileResponse.EmployeeData employeeData = getEmployeeData(userId);
                        return toTitleCase(employeeData.getEmployeeName());
                    })
                    .filter(Objects::nonNull) // Optional: filter out null names
                    .collect(Collectors.joining(", "));

            taskRows.append("<tr>")
                    .append("<td>").append(count++).append("</td>")
                    .append("<td>").append(safeValue(task.getTaskName())).append("</td>")
                    .append("<td>").append(safeValue(task.getRemark())).append("</td>")
                    .append("<td>").append(safeValue(employeeNames)).append("</td>")
                    .append("<td>").append(safeValue(DateConverter.convertDateTime(task.getTargetDate()))).append("</td>")
                    .append("<td>").append(safeValue(task.getStatus())).append("</td>")
                    .append("</tr>");
        }
        String employeeNames = meetingParticipants.stream()
                .filter(participant -> participant.getIsActive() == 1)
                .map(participant -> {
                    String userId = String.valueOf(participant.getEmployeeId());
                    EmployeeProfileResponse.EmployeeData employeeData = getEmployeeData(userId);
                    return toTitleCase(employeeData.getEmployeeName());
                })
                .filter(Objects::nonNull) // Optional: filter out null names
                .collect(Collectors.joining(", "));

        Map<String,String> deptsegMap=getDepartmentSegment(generalMeeting.getId());
        String body = "<html>" +
                "<head>" +
                "<style>" +
                ".highlight { font-family: 'Lincoln', sans-serif; color: #D5006D; }" +
                "table { border-collapse: collapse; width: 100%; font-family: Arial, sans-serif; }" +
                "th, td { border: 1px solid #dddddd; text-align: left; padding: 8px; }" +
                "th { background-color: #f2f2f2; }" +
                "</style>" +
                "</head>" +
                "<body>" +
                "Hello,<br><br>" +
                "Please find the meeting details below which was scheduled and completed..<br>" +
                "<strong><u>Meeting Details</u></strong><br><br>" +
                "<table>" +
                "<tr><td>Meeting Name</td><td>" + safeValue(generalMeeting.getMeetingName()) + "</td></tr>" +
                "<tr><td>Agenda</td><td>" + safeValue(generalMeeting.getAgenda()) + "</td></tr>" +
                "<tr><td>Attendees</td><td>" + safeValue(employeeNames) + "</td></tr>" +
                "<tr><td>Scheduled By</td><td>" + safeValue(toTitleCase(scheduledByEmployee.getEmployeeName())) + "</td></tr>" +
                "<tr><td>Meeting Date</td><td>" + safeValue(DateConverter.convertDateTime(generalMeeting.getMeetingDate())) + "</td></tr>" +
                "<tr><td>From Time</td><td>" + safeValue(generalMeeting.getFromTime()) + "</td></tr>" +
                "<tr><td>To Time</td><td>" + safeValue(generalMeeting.getToTime()) + "</td></tr>" +
                "<tr><td>Departments</td><td>" + safeValue(deptsegMap.get("departments")) + "</td></tr>" +
                "<tr><td>Segment</td><td>" + safeValue(deptsegMap.get("segments")) + "</td></tr>" +
                "<tr><td>Location</td><td>" + safeValue(generalMeeting.getLocation()) + "</td></tr>" +
                "<tr><td>Link</td><td>" + safeValue(generalMeeting.getLink()) + "</td></tr>" +
                "<tr><td>Remarks</td><td>" + safeValue(generalMeeting.getRemarks()) + "</td></tr>" +
                "</table><br><br>"+

                "<strong>Meeting Status:</strong> " + safeValue(latestStatusMark.get().getStatus()) + "<br><br>" +
                "<strong>Minutes Of Meeting:</strong> " + safeValue(generalMeeting.getMom()) + "<br><br>" +

                (!taskRows.isEmpty() ?
                "<strong><u>Task Details</u></strong><br><br>" +
                "<table>" +
                "<tr>" +
                "<th>Sr. No</th>" +
                "<th>Task Name</th>" +
                "<th>Remark</th>" +
                "<th>Employee Names</th>" +
                "<th>Target Date</th>" +
                "<th>Status</th>" +
                "</tr>" +
                taskRows.toString() +
                "</table><br><br>" : "")+
                "Kindly check Manage mate for more details.<br><br>" +

                "Regards,<br>" +
                "<span class='highlight'>MAS</span> Financial Services Ltd<br>" +
                "______________________________________________<br>" +
                "<em>This is a system-generated email. Please do not reply.</em>" +
                "</body>" +
                "</html>";


        List<String> participantEmails=getAllParticipantEmails(meetingParticipants);
        EmployeeProfileResponse.EmployeeData createdBy = getEmployeeData(String.valueOf(generalMeeting.getCreatedBy()));
        String scheduledByEmail=scheduledByEmployee.getCompanyEmail();
        String createdByMail=createdBy.getCompanyEmail();
      //  String combinedCC = String.join(",", scheduledByEmail, createdByMail);//cc
        participantEmails.removeIf(createdByMail::contains);
        participantEmails.removeIf(scheduledByEmail::contains);
        String assignedTo = String.join(",", participantEmails);
        emailSender.sendEmail(assignedTo, null, subject, body);

    }

    public void mailOnMeetingScheduled(GeneralMeeting generalMeeting){
        String scheduledBy = String.valueOf(generalMeeting.getScheduledBy());
        EmployeeProfileResponse.EmployeeData scheduledByEmployee = getEmployeeData(scheduledBy);
        String subject = "Meeting | " + generalMeeting.getMeetingName() + " | Date :  " + DateConverter.convertDateTime(generalMeeting.getMeetingDate());

        List<MeetingParticipants> meetingParticipants=meetingParticipantsRepository.findByGeneralMeeting_Id(generalMeeting.getId());

        String employeeNames = meetingParticipants.stream()
                .filter(participant -> participant.getIsActive() == 1)
                .map(participant -> {
                    String userId = String.valueOf(participant.getEmployeeId());
                    EmployeeProfileResponse.EmployeeData employeeData = getEmployeeData(userId);
                    return toTitleCase(employeeData.getEmployeeName());
                })
                .filter(Objects::nonNull) // Optional: filter out null names
                .collect(Collectors.joining(", "));

        Map<String,String> deptsegMap=getDepartmentSegment(generalMeeting.getId());

        String body = "<html>" +
                "<head>" +
                "<style>" +
                ".highlight { font-family: 'Lincoln', sans-serif; color: #D5006D; }" +
                "table { border-collapse: collapse; width: 100%; font-family: Arial, sans-serif; }" +
                "th, td { border: 1px solid #dddddd; text-align: left; padding: 8px; }" +
                "th { background-color: #f2f2f2; }" +
                "</style>" +
                "</head>" +
                "<body>" +
                "Hello,<br><br>" +
                "Please find the meeting details below which is scheduled on " +
                DateConverter.convertDateTime(generalMeeting.getMeetingDate()) +
                " at " + generalMeeting.getFromTime() + "<br>"+
                "<strong><u>Meeting Details</u></strong><br><br>" +
                "<table>" +
                "<tr><td>Meeting Name</td><td>" + safeValue(generalMeeting.getMeetingName()) + "</td></tr>" +
                "<tr><td>Agenda</td><td>" + safeValue(generalMeeting.getAgenda()) + "</td></tr>" +
                "<tr><td>Attendees</td><td>" + safeValue(employeeNames) + "</td></tr>" +
                "<tr><td>Scheduled By</td><td>" +  safeValue(toTitleCase(scheduledByEmployee.getEmployeeName())) + "</td></tr>" +
                "<tr><td>Meeting Date</td><td>" + safeValue(DateConverter.convertDateTime(generalMeeting.getMeetingDate())) + "</td></tr>" +
                "<tr><td>From Time</td><td>" + safeValue(generalMeeting.getFromTime()) + "</td></tr>" +
                "<tr><td>To Time</td><td>" + safeValue(generalMeeting.getToTime()) + "</td></tr>" +
                "<tr><td>Departments</td><td>" + safeValue(deptsegMap.get("departments")) + "</td></tr>" +
                "<tr><td>Segment</td><td>" + safeValue(deptsegMap.get("segments")) + "</td></tr>" +
                "<tr><td>Location</td><td>" + safeValue(generalMeeting.getLocation()) + "</td></tr>" +
                "<tr><td>Link</td><td>" + safeValue(generalMeeting.getLink()) + "</td></tr>" +
                "<tr><td>Remarks</td><td>" + safeValue(generalMeeting.getRemarks()) + "</td></tr>" +
                "</table><br><br>"+

                "Kindly check Manage mate for more details.<br><br>" +

                "Regards,<br>" +
                "<span class='highlight'>MAS</span> Financial Services Ltd<br>" +
                "______________________________________________<br>" +
                "<em>This is a system-generated email. Please do not reply.</em>" +
                "</body>" +
                "</html>";

        List<String> participantEmails=getAllParticipantEmails(meetingParticipants);
        EmployeeProfileResponse.EmployeeData createdBy = getEmployeeData(String.valueOf(generalMeeting.getCreatedBy()));
        String scheduledByEmail=scheduledByEmployee.getCompanyEmail();
        String createdByMail=createdBy.getCompanyEmail();
       // String combinedCC = String.join(",", scheduledByEmail, createdByMail);//cc
        participantEmails.removeIf(createdByMail::contains);
        participantEmails.removeIf(scheduledByEmail::contains);
        String assignedTo = String.join(",", participantEmails);
        emailSender.sendEmail(assignedTo, null, subject, body);

    }

    //  Email for  rescheduled general meeting
    public void sendGeneralMeetingReScheduledEmail(GeneralMeeting existingMeeting) {
        String scheduledBy = String.valueOf(existingMeeting.getScheduledBy());
        EmployeeProfileResponse.EmployeeData scheduledByEmployee = getEmployeeData(scheduledBy);
        EmployeeProfileResponse.EmployeeData createdByEmployee = getEmployeeData(scheduledBy);
        List<MeetingParticipants> meetingParticipants=meetingParticipantsRepository.findByGeneralMeeting_Id(existingMeeting.getId());
        String subject = "Meeting Re-scheduled - " + existingMeeting.getMeetingId() + " - " + existingMeeting.getMeetingName();
        String body = "<html>" +
                "<head>" +
                "<style>" +
                ".highlight { font-family: 'Lincoln', sans-serif; color: #D5006D; }" +
                "</style>" +
                "</head>" +
                "<body>" +
                "Dear Team,<br><br>" +
                "Meeting is Re-Scheduled for Meeting ID: " + existingMeeting.getMeetingId() + ".<br>" +
                "Kindly refer to the ticket-raising module for more details.<br><br>" +
                "<strong><u>Meeting Details</u></strong><br><br>" +
                "Meeting Objective: " + existingMeeting.getAgenda() + "<br>" +
                "Re-Scheduled By: " + createdByEmployee.getEmployeeName() + "<br>" +
                "Date & Time: " + DateConverter.convertDateTime(new Date()) + " From: " + existingMeeting.getFromTime() + " To: " + existingMeeting.getToTime() + "<br><br>" +
                "Regards,<br>" +
                "<span class='highlight'>MAS</span> Financial Services Ltd<br>" +
                "______________________________________________<br>" +
                "<em>This is a system-generated email. Please do not reply.</em>" +
                "</body>" +
                "</html>";

        List<String> participantEmails=getAllParticipantEmails(meetingParticipants);
        EmployeeProfileResponse.EmployeeData createdBy = getEmployeeData(String.valueOf(existingMeeting.getCreatedBy()));
        String scheduledByEmail=scheduledByEmployee.getCompanyEmail();
        String createdByMail=createdBy.getCompanyEmail();
       // String combinedCC = String.join(",", scheduledByEmail, createdByMail);//cc
        participantEmails.removeIf(createdByMail::contains);
        participantEmails.removeIf(scheduledByEmail::contains);
        String assignedTo = String.join(",", participantEmails);
        emailSender.sendEmail(assignedTo, null, subject, body);
    }

    //  Email for  update general meeting
    public void sendGeneralMeetingUpdateEmail(GeneralMeeting existingMeeting, List<MeetingParticipants> participants) {
        String scheduledBy = String.valueOf(existingMeeting.getScheduledBy());
        EmployeeProfileResponse.EmployeeData scheduledByEmployee = getEmployeeData(scheduledBy);

        String subject = existingMeeting.getMeetingId() + " - " + existingMeeting.getMeetingName() + " - Update";

        String body = "<html>" +
                "<head>" +
                "<style>" +
                ".highlight { font-family: 'Lincoln', sans-serif; color: #D5006D; }" +
                "</style>" +
                "</head>" +
                "<body>" +
                "Dear Team,<br><br>" +
                "For the " + existingMeeting.getMeetingId() + " - " + existingMeeting.getMeetingName() +
                ", There is an update kindly check Manage-Mate for more information.<br><br>" +
                "Regards,<br>" +
                "<span class='highlight'>MAS</span> Financial Services Ltd<br>" +
                "______________________________________________<br>" +
                "<em>This is a system-generated email. Please do not reply.</em>" +
                "</body>" +
                "</html>";

        List<String> participantEmails = getAllParticipantEmails(participants);
        EmployeeProfileResponse.EmployeeData createdBy = getEmployeeData(String.valueOf(existingMeeting.getCreatedBy()));
        String scheduledByEmail = scheduledByEmployee.getCompanyEmail();
        String createdByMail = createdBy.getCompanyEmail();
       // String combinedCC = String.join(",", scheduledByEmail, createdByMail);
        participantEmails.removeIf(createdByMail::contains);
        participantEmails.removeIf(scheduledByEmail::contains);
        String assignedTo = String.join(",", participantEmails);
        emailSender.sendEmail(assignedTo, null, subject, body);

    }

    //  Email for user added general meeting
    public void sendGeneralMeetingUserAddedEmail(GeneralMeeting existingMeeting, List<MeetingParticipants> newParticipants) {
        String scheduledBy = String.valueOf(existingMeeting.getScheduledBy());
        EmployeeProfileResponse.EmployeeData scheduledByEmployee = getEmployeeData(scheduledBy);

        String subject = existingMeeting.getMeetingId() + " - " + existingMeeting.getMeetingName() + " - User Update";

        String body = "<html>" +
                "<head>" +
                "<style>" +
                ".highlight { font-family: 'Lincoln', sans-serif; color: #D5006D; }" +
                "</style>" +
                "</head>" +
                "<body>" +
                "Dear Team,<br><br>" +
                "You have been added to " + existingMeeting.getMeetingId() + " - " + existingMeeting.getMeetingName() +
                ", Kindly check Manage-Mate for more information.<br><br>" +
                "Regards,<br>" +
                "<span class='highlight'>MAS</span> Financial Services Ltd<br>" +
                "______________________________________________<br>" +
                "<em>This is a system-generated email. Please do not reply.</em>" +
                "</body>" +
                "</html>";

        List<String> participantEmails = getAllParticipantEmails(newParticipants);
        EmployeeProfileResponse.EmployeeData createdBy = getEmployeeData(String.valueOf(existingMeeting.getCreatedBy()));
        String scheduledByEmail = scheduledByEmployee.getCompanyEmail();
        String createdByMail = createdBy.getCompanyEmail();
//        String combinedCC = String.join(",", scheduledByEmail, createdByMail);
        participantEmails.removeIf(createdByMail::contains);
        participantEmails.removeIf(scheduledByEmail::contains);
        String assignedTo = String.join(",", participantEmails);
        emailSender.sendEmail(assignedTo, null, subject, body);

    }

    public void meetingCancelled(GeneralMeeting generalMeeting){
        String scheduledBy = String.valueOf(generalMeeting.getScheduledBy());
        EmployeeProfileResponse.EmployeeData scheduledByEmployee = getEmployeeData(scheduledBy);
        String subject = "Meeting Cancelled | " + generalMeeting.getMeetingName();
        List<MeetingParticipants> meetingParticipants=meetingParticipantsRepository.findByGeneralMeeting_Id(generalMeeting.getId());

        String body = "<html>" +
                "<head>" +
                "<style>" +
                ".highlight { font-family: 'Lincoln', sans-serif; color: #D5006D; }" +
                "table { border-collapse: collapse; width: 100%; font-family: Arial, sans-serif; }" +
                "th, td { border: 1px solid #dddddd; text-align: left; padding: 8px; }" +
                "th { background-color: #f2f2f2; }" +
                "</style>" +
                "</head>" +
                "<body>" +
                "Hello,<br><br>" +
               "We regret to inform you that Meeting for "+ safeValue(generalMeeting.getMeetingName()) +" is now cancelled. " + "<br>"+
                "Kindly check Manage mate for more details.<br><br>" +

                "Regards,<br>" +
                "<span class='highlight'>MAS</span> Financial Services Ltd<br>" +
                "______________________________________________<br>" +
                "<em>This is a system-generated email. Please do not reply.</em>" +
                "</body>" +
                "</html>";

        List<String> participantEmails=getAllParticipantEmails(meetingParticipants);
        EmployeeProfileResponse.EmployeeData createdBy = getEmployeeData(String.valueOf(generalMeeting.getCreatedBy()));
        String scheduledByEmail=scheduledByEmployee.getCompanyEmail();
        String createdByMail=createdBy.getCompanyEmail();
        //String combinedCC = String.join(",", scheduledByEmail, createdByMail);//cc
        participantEmails.removeIf(createdByMail::contains);
        participantEmails.removeIf(scheduledByEmail::contains);
        String assignedTo = String.join(",", participantEmails);
        emailSender.sendEmail(assignedTo, null, subject, body);
    }

    public void taskRespondMail(TaskRespond taskRespond,  GeneralMeeting generalMeeting ){
        String scheduledBy = String.valueOf(generalMeeting.getScheduledBy());
        EmployeeProfileResponse.EmployeeData scheduledByEmployee = getEmployeeData(scheduledBy);
        String subject = "Task Responded | " + generalMeeting.getMeetingName();
        String respondedByEmployee=taskRespond.getRespondedBy();
        String employeeId = respondedByEmployee.split(" - ")[0];
        EmployeeProfileResponse.EmployeeData respondedBy=getEmployeeData(employeeId);
        List<MeetingParticipants> meetingParticipants=meetingParticipantsRepository.findByGeneralMeeting_Id(generalMeeting.getId());

        String body = "<html>" +
                "<head>" +
                "<style>" +
                ".highlight { font-family: 'Lincoln', sans-serif; color: #D5006D; }" +
                "table { border-collapse: collapse; width: 100%; font-family: Arial, sans-serif; }" +
                "th, td { border: 1px solid #dddddd; text-align: left; padding: 8px; }" +
                "th { background-color: #f2f2f2; }" +
                "</style>" +
                "</head>" +
                "<body>" +
                "Hello,<br><br>" +
                "Assigned Task is responded by the " + toTitleCase(respondedBy.getEmployeeName())+"<br>"+
                "Kindly check Manage mate for more details.<br><br>" +

                "Regards,<br>" +
                "<span class='highlight'>MAS</span> Financial Services Ltd<br>" +
                "______________________________________________<br>" +
                "<em>This is a system-generated email. Please do not reply.</em>" +
                "</body>" +
                "</html>";

        List<String> participantEmails=getAllParticipantEmails(meetingParticipants);
        EmployeeProfileResponse.EmployeeData createdBy = getEmployeeData(String.valueOf(generalMeeting.getCreatedBy()));
        String scheduledByEmail=scheduledByEmployee.getCompanyEmail();
        String createdByMail=createdBy.getCompanyEmail();
        String to = String.join(",", scheduledByEmail, createdByMail);//cc
        participantEmails.removeIf(createdByMail::contains);
        participantEmails.removeIf(scheduledByEmail::contains);
        //String cc = String.join(",", participantEmails);
        emailSender.sendEmail(to, null, subject, body);
    }

    // New method for when GeneralMeeting is null
    public void taskRespondMailNoMeeting(TaskRespond taskRespond) {
        String taskName = taskRespond.getGeneralMeetingTasks().getTaskName();
        String subject = taskName + " Task Responded";
        String to = getEmployeeData(String.valueOf(taskRespond.getGeneralMeetingTasks().getCreatedBy())).getCompanyEmail();
        String body = "<html>" +
                "<head>" +
                "<style>" +
                "body { font-family: Arial, sans-serif; font-size: 14px; }" +
                ".highlight { font-family: 'Lincoln', sans-serif; color: #D5006D; }" +
                "</style>" +
                "</head>" +
                "<body>" +
                "Hi Team,<br><br>" +
                "The Task-<strong>" + taskName + "</strong> has been responded. Kindly check <strong>Manage-Mate</strong> for more information.<br><br>" +
                "Regards,<br>" +
                "<span class='highlight'>MAS Financial Services Ltd</span>" +
                "</body>" +
                "</html>";

        emailSender.sendEmail(to, "", subject, body); // No CC
    }

    // create a General Meeting Task
    public void sendGeneralMeetingTaskCreateEmail(GeneralMeetingTasks generalMeetingTasks ) {
        String createdBy = String.valueOf(generalMeetingTasks.getCreatedBy());
        EmployeeProfileResponse.EmployeeData scheduledByEmployee = getEmployeeData(createdBy);

        String subject = generalMeetingTasks.getTaskName() + " - Task Assigned";

        String body = "<html>" +
                "<head>" +
                "<style>" +
                ".highlight { font-family: 'Lincoln', sans-serif; color: #D5006D; }" +
                "body { font-family: Arial, sans-serif; font-size: 14px; }" +
                "</style>" +
                "</head>" +
                "<body>" +
                "Hi Team,<br><br>" +
                "A task <strong>" + generalMeetingTasks.getTaskName() + "</strong> has been assigned.<br><br>" +
                "Kindly check <strong>Manage-Mate</strong> for more information.<br><br>" +
                "Regards,<br>" +
                "<span class='highlight'>MAS Financial Services Ltd</span><br>" +
                "______________________________________________<br>" +
                "<em>This is a system-generated email. Please do not reply.</em>" +
                "</body>" +
                "</html>";

        // Get Task Assignees
        List<MeetingTaskAssignee> assignees = meetingTaskAssigneeRepository
                .findByGeneralMeetingTasks_GeneralMeetingTaskId(generalMeetingTasks.getGeneralMeetingTaskId());

        // Get TO Emails (assignees)
        List<String> toEmails = assignees.stream()
                .map(assignee -> getEmployeeData(String.valueOf(assignee.getEmpId())).getCompanyEmail())
                .filter(Objects::nonNull)
                .distinct()
                .toList();

        // Add creator's email to CC
        String companyEmail = scheduledByEmployee.getCompanyEmail();
        List<String> allToEmails = new ArrayList<>(toEmails);
        allToEmails.add(companyEmail);

        // Get CC Emails (HoDs)
/*       // Set<String> ccEmails = assignees.stream()
                .map(assignee -> getEmployeeData(String.valueOf(assignee.getEmpId())).getReportingManagerEmail())
                .filter(Objects::nonNull)
                .collect(Collectors.toSet());*/



        String to = String.join(",", allToEmails);
       // String cc = String.join(",", ccEmails);
        emailSender.sendEmail(to, null, subject, body);
    }

    public void taskMarkedMail(TaskRespond taskRespond,  GeneralMeeting generalMeeting ){
        String scheduledBy = String.valueOf(generalMeeting.getScheduledBy());
        EmployeeProfileResponse.EmployeeData scheduledByEmployee = getEmployeeData(scheduledBy);
        String subject = "Task Responded | " + generalMeeting.getMeetingName();
        String respondedByEmployee=taskRespond.getRespondedBy();
        String employeeId = respondedByEmployee.split(" - ")[0];
        EmployeeProfileResponse.EmployeeData respondedBy=getEmployeeData(employeeId );
        List<MeetingParticipants> meetingParticipants=meetingParticipantsRepository.findByGeneralMeeting_Id(generalMeeting.getId());

        GeneralMeetingTasks generalMeetingTasks=generalMeetingTaskRepository.findById(taskRespond.getGeneralMeetingTasks().getGeneralMeetingTaskId()).orElseThrow(() -> new IllegalArgumentException("Meeting not found for the provided meetingId: " +taskRespond.getGeneralMeetingTasks().getGeneralMeetingTaskId()));
        List<MeetingTaskAssignee> meetingTaskAssignees=meetingTaskAssigneeRepository.findByGeneralMeetingTasks_GeneralMeetingTaskId(generalMeetingTasks.getGeneralMeetingTaskId());
        String body = "<html>" +
                "<head>" +
                "<style>" +
                ".highlight { font-family: 'Lincoln', sans-serif; color: #D5006D; }" +
                "table { border-collapse: collapse; width: 100%; font-family: Arial, sans-serif; }" +
                "th, td { border: 1px solid #dddddd; text-align: left; padding: 8px; }" +
                "th { background-color: #f2f2f2; }" +
                "</style>" +
                "</head>" +
                "<body>" +
                "Hello,<br><br>" +
                "Assigned Task is marked by the " + toTitleCase(respondedBy.getEmployeeName())+"<br>"+
                "Kindly check Manage mate for more details.<br><br>" +

                "Regards,<br>" +
                "<span class='highlight'>MAS</span> Financial Services Ltd<br>" +
                "______________________________________________<br>" +
                "<em>This is a system-generated email. Please do not reply.</em>" +
                "</body>" +
                "</html>";

        List<String> toCompanyMails = meetingTaskAssignees.stream()
                .map(participant -> {
                    String userId = String.valueOf(participant.getEmpId());
                    EmployeeProfileResponse.EmployeeData employeeData = getEmployeeData(userId);
                    return employeeData.getCompanyEmail();
                })
                .filter(Objects::nonNull)
                .toList();

        List<String> participantEmails=getAllParticipantEmails(meetingParticipants);
        EmployeeProfileResponse.EmployeeData createdBy = getEmployeeData(String.valueOf(generalMeeting.getCreatedBy()));
        participantEmails.removeIf(toCompanyMails::contains);
        participantEmails.add(createdBy.getCompanyEmail());
        participantEmails.add(scheduledByEmployee.getCompanyEmail());

        emailSender.sendEmail(String.join(",", toCompanyMails), null, subject, body);
    }

    // task marked for "Justification Required" status email
    public void taskMarkedJustificationMail(TaskRespond taskRespond) {
        String taskName = taskRespond.getGeneralMeetingTasks().getTaskName();
        String subject = " " + taskName + " - Task Responded";
        String respondedByEmployee = taskRespond.getRespondedBy();
        String employeeId = respondedByEmployee.split(" - ")[0];
        EmployeeProfileResponse.EmployeeData respondedBy = getEmployeeData(employeeId);
        String to = respondedBy.getCompanyEmail();
        String cc = respondedBy.getReportingManagerEmail();

        String body = "<html>" +
                "<head>" +
                "<style>" +
                ".highlight { font-family: 'Lincoln', sans-serif; color: #D5006D; }" +
                "body { font-family: Arial, sans-serif; font-size: 14px; }" +
                "</style>" +
                "</head>" +
                "<body>" +
                "Hi Team,<br><br>" +
                "For the Task-<strong>\"" + taskName + "\"</strong> Justification raised has been marked. Kindly check <strong>Manage-Mate</strong> for more information.<br><br>" +
                "Regards,<br>" +
                "<span class='highlight'>MAS Financial Services Ltd</span>" +
                "</body>" +
                "</html>";

        emailSender.sendEmail(to, null, subject, body);
    }

    // task marked  for "Completed" status  email
    public void taskMarkedCompletedMail(TaskRespond taskRespond) {
        String taskName = taskRespond.getGeneralMeetingTasks().getTaskName();
        String subject = " " + taskName + " - Task Responded";
        String respondedByEmployee = taskRespond.getRespondedBy();
        String employeeId = respondedByEmployee.split(" - ")[0];
        EmployeeProfileResponse.EmployeeData respondedBy = getEmployeeData(employeeId);
        String to = respondedBy.getCompanyEmail();
        String cc = respondedBy.getReportingManagerEmail();

        String body = "<html>" +
                "<head>" +
                "<style>" +
                ".highlight { font-family: 'Lincoln', sans-serif; color: #D5006D; }" +
                "body { font-family: Arial, sans-serif; font-size: 14px; }" +
                "</style>" +
                "</head>" +
                "<body>" +
                "Hi Team,<br><br>" +
                "The Task-<strong>\"" + taskName + "\"</strong> is marked as Completed. Kindly check <strong>Manage-Mate</strong> for more information.<br><br>" +
                "Regards,<br>" +
                "<span class='highlight'>MAS Financial Services Ltd</span>" +
                "</body>" +
                "</html>";

        emailSender.sendEmail(to, null, subject, body);
    }

    public void resendMeetingLinkMail( GeneralMeeting generalMeeting ){
        String scheduledBy = String.valueOf(generalMeeting.getScheduledBy());
        EmployeeProfileResponse.EmployeeData scheduledByEmployee = getEmployeeData(scheduledBy);
        String subject = "Meeting Link | Resend | " + generalMeeting.getMeetingName();
        List<MeetingParticipants> meetingParticipants=meetingParticipantsRepository.findByGeneralMeeting_Id(generalMeeting.getId());

          String body = "<html>" +
                "<head>" +
                "<style>" +
                ".highlight { font-family: 'Lincoln', sans-serif; color: #D5006D; }" +
                "table { border-collapse: collapse; width: 100%; font-family: Arial, sans-serif; }" +
                "th, td { border: 1px solid #dddddd; text-align: left; padding: 8px; }" +
                "th { background-color: #f2f2f2; }" +
                "</style>" +
                "</head>" +
                "<body>" +
                "Hello,<br><br>" +
                "Please find the meeting link below for the meeting Name " + generalMeeting.getMeetingName()+"<br><br>"+
                "<strong>Meeting Link:</strong>" + generalMeeting.getLink()+"<br><br>"+
                "Kindly check Manage mate for more details.<br><br>" +

                "Regards,<br>" +
                "<span class='highlight'>MAS</span> Financial Services Ltd<br>" +
                "______________________________________________<br>" +
                "<em>This is a system-generated email. Please do not reply.</em>" +
                "</body>" +
                "</html>";

        List<String> participantEmails=getAllParticipantEmails(meetingParticipants);
        EmployeeProfileResponse.EmployeeData createdBy = getEmployeeData(String.valueOf(generalMeeting.getCreatedBy()));
        String scheduledByEmail=scheduledByEmployee.getCompanyEmail();
        String createdByMail=createdBy.getCompanyEmail();
      //  String cc = String.join(",", scheduledByEmail, createdByMail);//cc
        participantEmails.removeIf(createdByMail::contains);
        participantEmails.removeIf(scheduledByEmail::contains);
        String to = String.join(",", participantEmails);
        emailSender.sendEmail(to, null, subject, body);
    }

    public void completionDatePendingMail( GeneralMeeting generalMeeting, GeneralMeetingTasks generalMeetingTasks ){

        String body = "<html>" +
                "<head>" +
                "<style>" +
                ".highlight { font-family: 'Lincoln', sans-serif; color: #D5006D; }" +
                "table { border-collapse: collapse; width: 100%; font-family: Arial, sans-serif; }" +
                "th, td { border: 1px solid #dddddd; text-align: left; padding: 8px; }" +
                "th { background-color: #f2f2f2; }" +
                "</style>" +
                "</head>" +
                "<body>" +
                "Hi Team,<br><br>" +
                "For the " + generalMeeting.getMeetingId()+"-"+ generalMeeting.getMeetingName() + " the updation of 'Completion Date' for the assigned tasks are pending.<br><br>"+
                "Kindly update at the earliest.<br><br>" +

                "Regards,<br>" +
                "<span class='highlight'>MAS</span> Financial Services Ltd<br>" +
                "______________________________________________<br>" +
                "<em>This is a system-generated email. Please do not reply.</em>" +
                "</body>" +
                "</html>";

//        List<GeneralMeetingTasks> generalMeetTasks = generalMeetingTaskRepository.findByGeneralMeeting_Id(generalMeeting.getId());
//        List<Long> taskIds = generalMeetTasks.stream().map(GeneralMeetingTasks::getGeneralMeetingTaskId).toList();
//        List<TaskAssignments> taskAssignments = taskAssignmentsRepository.findByTaskId(generalMeetingTasks.getGeneralMeetingTaskId());

        List<MeetingTaskAssignee> taskAssignees = meetingTaskAssigneeRepository.findByGeneralMeetingTasks_GeneralMeetingTaskId(generalMeetingTasks.getGeneralMeetingTaskId());
        List<String> taskAssigneeEmails = getAllTaskAssigneeEmails(taskAssignees);

        String scheduledBy = String.valueOf(generalMeeting.getScheduledBy());
        EmployeeProfileResponse.EmployeeData scheduledByEmployee = getEmployeeData(scheduledBy);
        String subject = generalMeeting.getMeetingId() + " Completion Date pending";
        EmployeeProfileResponse.EmployeeData createdBy = getEmployeeData(String.valueOf(generalMeeting.getCreatedBy()));
        String scheduledByReportingManagerEmail=scheduledByEmployee.getReportingManagerEmail();
        String createdByReportingManagerEmail=createdBy.getReportingManagerEmail();
        String cc = String.join(",", scheduledByReportingManagerEmail, createdByReportingManagerEmail);//cc
        String to = String.join(",", taskAssigneeEmails);
        emailSender.sendEmail(to, null, subject, body);
    }

    public void completionDateUpdateMail( GeneralMeetingTasks generalMeetingTasks, GeneralMeetingTaskTimeline generalMeetingTaskTimeline ){
        Optional<GeneralMeeting> generalMeeting = generalMeetingRepository.findById(generalMeetingTasks.getGeneralMeeting().getId());

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        String formattedCompletionDate = dateFormat.format(generalMeetingTaskTimeline.getCompletionDate());

        String body = "<html>" +
                "<head>" +
                "<style>" +
                ".highlight { font-family: 'Lincoln', sans-serif; color: #D5006D; }" +
                "table { border-collapse: collapse; width: 100%; font-family: Arial, sans-serif; }" +
                "th, td { border: 1px solid #dddddd; text-align: left; padding: 8px; }" +
                "th { background-color: #f2f2f2; }" +
                "</style>" +
                "</head>" +
                "<body>" +
                "Hi Team,<br><br>" +
                generalMeeting.map(meeting ->
                        "For the " + meeting.getMeetingId() + "-" + meeting.getMeetingName() +
                                " the completion date has been updated to " + formattedCompletionDate + "<br><br>"
                ).orElse("Meeting information is unavailable.<br><br>") +

                "Regards,<br>" +
                "<span class='highlight'>MAS</span> Financial Services Ltd<br>" +
                "______________________________________________<br>" +
                "<em>This is a system-generated email. Please do not reply.</em>" +
                "</body>" +
                "</html>";

//        List<GeneralMeetingTasks> generalMeetTasks = generalMeetingTaskRepository.findByGeneralMeeting_Id(generalMeeting.getId());
//        List<Long> taskIds = generalMeetTasks.stream().map(GeneralMeetingTasks::getGeneralMeetingTaskId).toList();
        List<MeetingTaskAssignee> assignees = meetingTaskAssigneeRepository.findByGeneralMeetingTasks_GeneralMeetingTaskId(generalMeetingTasks.getGeneralMeetingTaskId());
        List<String> taskAssigneeEmails = getAllTaskAssigneeEmails(assignees);

        String subject = generalMeeting.get().getMeetingId() + " Completion Date updated";

        String to = String.join(",", taskAssigneeEmails);
        emailSender.sendEmail(to, null, subject, body);
    }

    public void completionDateReUpdateMail( GeneralMeetingTasks generalMeetingTasks, GeneralMeetingTaskTimeline generalMeetingTaskTimeline, Date prevDate ){
        Optional<GeneralMeeting> generalMeeting = generalMeetingRepository.findById(generalMeetingTasks.getGeneralMeeting().getId());

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        String toCompletionDate = dateFormat.format(generalMeetingTaskTimeline.getCompletionDate());
        String fromCompletionDate = dateFormat.format(prevDate);


        String body = "<html>" +
                "<head>" +
                "<style>" +
                ".highlight { font-family: 'Lincoln', sans-serif; color: #D5006D; }" +
                "table { border-collapse: collapse; width: 100%; font-family: Arial, sans-serif; }" +
                "th, td { border: 1px solid #dddddd; text-align: left; padding: 8px; }" +
                "th { background-color: #f2f2f2; }" +
                "</style>" +
                "</head>" +
                "<body>" +
                "Hi Team,<br><br>" +
                generalMeeting.map(meeting ->
                        "For the " + meeting.getMeetingId() + "-" + meeting.getMeetingName() +
                                " the completion date has been updated from " + fromCompletionDate + " to "+ toCompletionDate + "<br><br>"
                ).orElse("Meeting information is unavailable.<br><br>") +

                "Regards,<br>" +
                "<span class='highlight'>MAS</span> Financial Services Ltd<br>" +
                "______________________________________________<br>" +
                "<em>This is a system-generated email. Please do not reply.</em>" +
                "</body>" +
                "</html>";

//        List<GeneralMeetingTasks> generalMeetTasks = generalMeetingTaskRepository.findByGeneralMeeting_Id(generalMeeting.getId());
//        List<Long> taskIds = generalMeetTasks.stream().map(GeneralMeetingTasks::getGeneralMeetingTaskId).toList();
        List<MeetingTaskAssignee> assignees = meetingTaskAssigneeRepository.findByGeneralMeetingTasks_GeneralMeetingTaskId(generalMeetingTasks.getGeneralMeetingTaskId());
        List<String> taskAssigneeEmails = getAllTaskAssigneeEmails(assignees);

        String scheduledBy = String.valueOf(generalMeeting.get().getScheduledBy());
        String subject = generalMeeting.get().getMeetingId() + " Completion Date updated";
        String to = String.join(",", taskAssigneeEmails);
        emailSender.sendEmail(to, null, subject, body);
    }

    // Email for Task Completion Date Update
    public void taskCompletionDateUpdateMail(GeneralMeetingTasks generalMeetingTasks) {
        String subject = " " + generalMeetingTasks.getTaskName() + " - Completion date updated";

        String body = "<html>" +
                "<head>" +
                "<style>" +
                ".highlight { font-family: 'Lincoln', sans-serif; color: #D5006D; }" +
                "body { font-family: Arial, sans-serif; font-size: 14px; }" +
                "</style>" +
                "</head>" +
                "<body>" +
                "Hi Team,<br><br>" +
                "For " + generalMeetingTasks.getTaskName() + " Completion date has been updated. Kindly check <strong>Manage-Mate</strong> for more information.<br><br>" +
                "Regards,<br>" +
                "<span class='highlight'>MAS</span> Financial Services Ltd<br>" +
                "______________________________________________<br>" +
                "<em>This is a system-generated email. Please do not reply.</em>" +
                "</body>" +
                "</html>";

        String createdBy = generalMeetingTasks.getCreatedBy();
        EmployeeProfileResponse.EmployeeData scheduledByEmployee = getEmployeeData(createdBy);
        String companyEmail = scheduledByEmployee.getCompanyEmail();
//        List<MeetingTaskAssignee> assignees = meetingTaskAssigneeRepository.findByGeneralMeetingTasks_GeneralMeetingTaskId(generalMeetingTasks.getGeneralMeetingTaskId());
//        List<String> taskAssigneeEmails = getAllTaskAssigneeEmails(assignees);
        String to = String.join(",", companyEmail);
        emailSender.sendEmail(to, null, subject, body);
    }

    // Email for Task Completion Date Re-Update
    public void taskCompletionDateReUpdateMail(GeneralMeetingTasks generalMeetingTasks) {
        String subject = " " + generalMeetingTasks.getTaskName() + " - Completion date Re-updated";

        String body = "<html>" +
                "<head>" +
                "<style>" +
                ".highlight { font-family: 'Lincoln', sans-serif; color: #D5006D; }" +
                "body { font-family: Arial, sans-serif; font-size: 14px; }" +
                "</style>" +
                "</head>" +
                "<body>" +
                "Hi Team,<br><br>" +
                "For " + generalMeetingTasks.getTaskName() + " Completion date has been Re-updated. Kindly check <strong>Manage-Mate</strong> for more information.<br><br>" +
                "Regards,<br>" +
                "<span class='highlight'>MAS</span> Financial Services Ltd<br>" +
                "______________________________________________<br>" +
                "<em>This is a system-generated email. Please do not reply.</em>" +
                "</body>" +
                "</html>";

        String createdBy = generalMeetingTasks.getCreatedBy();
        EmployeeProfileResponse.EmployeeData scheduledByEmployee = getEmployeeData(createdBy);
        String companyEmail = scheduledByEmployee.getCompanyEmail();
//        List<MeetingTaskAssignee> assignees = meetingTaskAssigneeRepository.findByGeneralMeetingTasks_GeneralMeetingTaskId(generalMeetingTasks.getGeneralMeetingTaskId());
//        List<String> taskAssigneeEmails = getAllTaskAssigneeEmails(assignees);

        String to = String.join(",", companyEmail);
        emailSender.sendEmail(to, null, subject, body);
    }


    // Fetched Employee Data
    private EmployeeProfileResponse.EmployeeData getEmployeeData(String userId) {
        if (!employeeDataCache.containsKey(userId)) {
            try {
                EmployeeProfileResponse.EmployeeData employeeData = apiClient.getEmployeeProfile(userId).getData().stream()
                        .findFirst()
                        .orElseThrow(() -> new RuntimeException("Employee data not found for userId: " + userId));
                employeeDataCache.put(userId, employeeData);
            } catch (Exception e) {
                throw new RuntimeException("Error fetching employee data: " + e.getMessage(), e);
            }
        }
        return employeeDataCache.get(userId);
    }

    // Fetched Email from employee number
    public Map<String, String> getEmployeeEmail(long employeeId) {
        Map<String, String> emailMap = new HashMap<>();
        String userId = String.valueOf(employeeId);
        EmployeeProfileResponse.EmployeeData employeeData = getEmployeeData(userId);
        emailMap.put("To", employeeData.getCompanyEmail());
//        emailMap.put("CC", employeeData.getReportingManagerEmail());
        emailMap.put("CC", "ba_3@mas.co.in");
        return emailMap;
    }

    public Map<String, String> getDepartmentSegment(long generalMeetingId){
        Map<String,String> deptsegMap=new HashMap<>();
        List<DepartmentSegmentMapper> departmentSegmentMappers=departmentSegmentMapperRepository.findByGeneralMeeting_Id(generalMeetingId);
        String departmentNameString = departmentSegmentMappers.stream()
                .filter(DepartmentSegmentMapper::isDepartment)
                .map(DepartmentSegmentMapper::getName)
                .collect(Collectors.joining(", "));

        String segmentNameString = departmentSegmentMappers.stream()
                .filter(mapper -> !mapper.isDepartment())
                .map(DepartmentSegmentMapper::getName)
                .collect(Collectors.joining(", "));
        deptsegMap.put("departments",departmentNameString);
        deptsegMap.put("segments",segmentNameString);
        return deptsegMap;
    }

    public  List<String> getAllParticipantEmails(List<MeetingParticipants> meetingParticipants){
        return meetingParticipants.stream()
                .filter(participant -> participant.getIsActive() == 1)
                .map(participant -> {
                    String userId = String.valueOf(participant.getEmployeeId());
                    EmployeeProfileResponse.EmployeeData employeeData = getEmployeeData(userId);
                    return employeeData.getCompanyEmail();
                })
                .filter(Objects::nonNull)
                .distinct()
                .collect(Collectors.toList());
    }

    public  List<String> getAllTaskAssigneeEmails(List<MeetingTaskAssignee> meetingTaskAssignees){
        return meetingTaskAssignees.stream()
                .map(assignee -> {
                    String userId = String.valueOf(assignee.getEmpId());
                    EmployeeProfileResponse.EmployeeData employeeData = getEmployeeData(userId);
                    return employeeData.getCompanyEmail();
                })
                .filter(Objects::nonNull)
                .distinct()
                .collect(Collectors.toList());
    }

    private String safeValue(Object value) {
        return value != null ? value.toString() : "";
    }

    private String toTitleCase(String name) {
        if (name == null || name.isEmpty()) return "";
        return Arrays.stream(name.split(" "))
                .map(word -> word.isEmpty() ? "" :
                        Character.toUpperCase(word.charAt(0)) + word.substring(1).toLowerCase())
                .collect(Collectors.joining(" "));
    }


}
