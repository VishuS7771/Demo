package com.mas.managemate.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MeetingTaskAssigneeDto {

    private Long meetingTaskAssigneeId;

    private long empId;

    private String employeeName;

    private String employeeImgUrl;
}
