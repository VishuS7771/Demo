package com.mas.managemate.serviceImpl;

import com.mas.managemate.model.constant.Constants;
import com.mas.managemate.model.dto.*;
import com.mas.managemate.model.entity.*;
import com.mas.managemate.model.mapper.GeneralMeetingMapper;
import com.mas.managemate.repository.*;
import com.mas.managemate.service.GeneralMeetingService;
import com.mas.managemate.util.ApiClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Service
@Slf4j
public class GeneralMeetingServiceImpl implements GeneralMeetingService {
    @Autowired
    private MeetingTaskStatusRepository meetingTaskStatusRepository;

    @Autowired
    private GeneralMeetingRepository generalMeetingRepository;

    @Autowired
    private GeneralMeetingTaskRepository generalMeetingTaskRepository;

    @Autowired
    private GeneralMeetingMapper generalMeetingMapper;

    @Autowired
    private GeneralMeetingStatusMarkRepository generalMeetingStatusMarkRepository;

    @Autowired
    private FileSavePathRepository fileSavePathRepository;

    @Autowired
    private MeetingParticipantsRepository meetingParticipantsRepository;

    @Autowired
    private DepartmentSegmentMapperRepository departmentSegmentMapperRepository;

    @Autowired
    private MeetingTaskAssigneeRepository meetingTaskAssigneeRepository;

    @Autowired
    private ApiClient apiClient;

    @Autowired
    private TaskRespondRepository taskRespondRepository;

    @Autowired
    private EmailService emailService;

    @Autowired
    ScheduledExecutorService taskReminderExecutor;

    @Autowired
    GeneralMeetingTaskTimelineRepository generalMeetingTaskTimelineRepository;

    private static final String filePath = "D:/UploadedFiles/GeneralMeetings";

    private static final String respondFilePath = "D:/UploadedFiles/GeneralMeetings/MeetingTask";

    @Override
    @Transactional
    public GeneralMeetingDto createGeneralMeeting(GeneralMeetingDto generalMeetingDto) {
        try {
            if (generalMeetingDto.getMeetingDate() == null || generalMeetingDto.getFromTime() == null || generalMeetingDto.getToTime() == null) {
                throw new IllegalArgumentException("Date and Timing fields are mandatory");
            }

            if (generalMeetingDto.getEmployeeId() != null && !generalMeetingDto.getEmployeeId().contains(generalMeetingDto.getCreatedBy())) {
                generalMeetingDto.getEmployeeId().add(generalMeetingDto.getCreatedBy());
            }
            GeneralMeeting generalMeeting = generalMeetingMapper.mapToGeneralMeeting(generalMeetingDto);

            GeneralMeeting savedGeneralMeeting = generalMeetingRepository.save(generalMeeting);

            List<MeetingParticipants> participants = generalMeetingDto.getEmployeeId().stream().map(employeeId -> MeetingParticipants.builder().employeeId(employeeId).assignedBy(generalMeetingDto.getCreatedBy()).isActive(1).generalMeeting(savedGeneralMeeting).assignedDate(new Date()).build()).collect(Collectors.toList());

            meetingParticipantsRepository.saveAll(participants);

            // Map departmentDtos, segmentDtos, and segmentGroupDtos to DepartmentSegmentMapper
            List<DepartmentSegmentMapper> departmentSegmentMappers = new ArrayList<>();

            // Handle departmentDtos
            if (generalMeetingDto.getDepartmentDtos() != null) {
                for (DepartmentDto department : generalMeetingDto.getDepartmentDtos()) {
                    departmentSegmentMappers.add(DepartmentSegmentMapper.builder().id(department.getId()).name(department.getName()).isDepartment(true).createdBy(generalMeetingDto.getCreatedBy()).createdOn(new Date()).generalMeeting(savedGeneralMeeting).build());
                }
            }

            // Handle segmentDtos
            if (generalMeetingDto.getSegmentDtos() != null) {
                for (DepartmentDto segment : generalMeetingDto.getSegmentDtos()) {
                    departmentSegmentMappers.add(DepartmentSegmentMapper.builder().id(segment.getId()).name(segment.getName()).isDepartment(false).createdBy(generalMeetingDto.getCreatedBy()).createdOn(new Date()).generalMeeting(savedGeneralMeeting).build());
                }
            }

            departmentSegmentMapperRepository.saveAll(departmentSegmentMappers);

            GeneralMeetingStatusMark generalMeetingStatusMark = new GeneralMeetingStatusMark();
            generalMeetingStatusMark.setGeneralMeeting(generalMeeting);
            generalMeetingStatusMark.setStatus(Constants.PENDING);
            generalMeetingStatusMark.setMarkedBy(String.valueOf(generalMeeting.getCreatedBy()));
            generalMeetingStatusMark.setMarkedOn(new Date());

            generalMeetingStatusMarkRepository.save(generalMeetingStatusMark);

            emailService.mailOnMeetingScheduled(savedGeneralMeeting);

            log.info("Meeting creation successful");
            return generalMeetingMapper.mapToGeneralMeetingDto(savedGeneralMeeting);

        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Validation Error: " + e.getMessage(), e);
        } catch (Exception e) {
            throw new RuntimeException("Failed to create meeting", e);
        }
    }

    @Override
    public List<GeneralMeetingDto> getAllGeneralMeetings(Long employeeNo) throws Exception {
        List<GeneralMeeting> generalMeetings = generalMeetingRepository.findAll();

        List<GeneralMeeting> newMeetingsList = generalMeetings.stream().filter(generalMeeting -> generalMeeting.getScheduledBy().equalsIgnoreCase(String.valueOf(employeeNo)) || generalMeeting.getCreatedBy() == employeeNo || meetingParticipantsRepository.findByGeneralMeeting_Id(generalMeeting.getId()).stream().anyMatch(participant -> participant.getEmployeeId() == employeeNo) || generalMeetingTaskRepository.findByGeneralMeeting_Id(generalMeeting.getId()).stream().anyMatch(task -> meetingTaskAssigneeRepository.findByGeneralMeetingTasks_GeneralMeetingTaskId(task.getGeneralMeetingTaskId()).stream().anyMatch(a -> a.getEmpId() == employeeNo))).collect(Collectors.toList());
        List<GeneralMeetingDto> generalMeetingDtos = generalMeetingMapper.mapToGeneralMeetingDtoList(newMeetingsList);
        generalMeetingDtos = setFullData(generalMeetingDtos);
        return generalMeetingDtos;
    }

    @Override
    @Transactional
    public GeneralMeetingDto updateMeeting(Long generalMeetingId, GeneralMeetingDto generalMeetingDto) {
        GeneralMeeting existingMeeting = generalMeetingRepository.findById(generalMeetingId).orElseThrow(() -> new IllegalArgumentException("Meeting not found for the provided meetingId: " + generalMeetingId));

        GeneralMeetingDto checkGeneralMeet = generalMeetingDto;
        GeneralMeeting generalMeeting = generalMeetingMapper.mapToGeneralMeeting(generalMeetingDto);
        generalMeetingMapper.updateMeeting(existingMeeting, generalMeeting);
        existingMeeting = generalMeetingRepository.save(existingMeeting);
        generalMeetingDto = generalMeetingMapper.mapToGeneralMeetingDto(existingMeeting);

        // Store existing active participants before update
        List<MeetingParticipants> existingActiveParticipants = meetingParticipantsRepository.findByGeneralMeetingIdAndIsActive(generalMeeting.getId(), 1);

        if (checkGeneralMeet.getEmployeeId() != null) {
            Set<Long> newEmployeeIds = new HashSet<>(checkGeneralMeet.getEmployeeId());

            // Update existing participants
            for (MeetingParticipants participant : existingActiveParticipants) {
                if (newEmployeeIds.contains(participant.getEmployeeId())) {
                    participant.setIsActive(1);
                    newEmployeeIds.remove(participant.getEmployeeId());
                } else {
                    participant.setIsActive(0);
                }
            }
            meetingParticipantsRepository.saveAll(existingActiveParticipants);

            // Create new participants
            GeneralMeeting finalGeneralMeeting = generalMeeting;
            List<MeetingParticipants> newParticipants = newEmployeeIds.stream().map(employeeId -> MeetingParticipants.builder().generalMeeting(finalGeneralMeeting).employeeId(employeeId).assignedBy(finalGeneralMeeting.getCreatedBy()).assignedDate(new Date()).isActive(1).build()).collect(Collectors.toList());

            meetingParticipantsRepository.saveAll(newParticipants);

            // Send email to existing active participants for meeting update
            if (!existingActiveParticipants.isEmpty()) {
                emailService.sendGeneralMeetingUpdateEmail(existingMeeting, existingActiveParticipants);
            }

            // Send email to new participants
            if (!newParticipants.isEmpty()) {
                emailService.sendGeneralMeetingUserAddedEmail(existingMeeting, newParticipants);
            }
        } else {
            // If no employee changes, send update email to all active participants
            if (!existingActiveParticipants.isEmpty()) {
                emailService.sendGeneralMeetingUpdateEmail(existingMeeting, existingActiveParticipants);
            }
        }

        // Fetch existing DepartmentSegmentMapper for the meeting
        List<DepartmentSegmentMapper> existingMappings = departmentSegmentMapperRepository.findByGeneralMeetingId(generalMeeting.getId());
        departmentSegmentMapperRepository.deleteAll(existingMappings);

        // Filter out already existing departments and segments from incoming DTOs
        List<DepartmentDto> newDepartments = Optional.ofNullable(checkGeneralMeet.getDepartmentDtos()).orElse(new ArrayList<>());
        List<DepartmentDto> newSegments = Optional.ofNullable(checkGeneralMeet.getSegmentDtos()).orElse(new ArrayList<>());

        // Prepare new mappings
        List<DepartmentSegmentMapper> departmentSegmentMappers = new ArrayList<>();
        for (DepartmentDto department : newDepartments) {
            departmentSegmentMappers.add(DepartmentSegmentMapper.builder().id(department.getId()).name(department.getName()).isDepartment(true).createdBy(checkGeneralMeet.getCreatedBy()).createdOn(new Date()).generalMeeting(generalMeeting).build());
        }

        for (DepartmentDto segment : newSegments) {
            departmentSegmentMappers.add(DepartmentSegmentMapper.builder().id(segment.getId()).name(segment.getName()).isDepartment(false).createdBy(checkGeneralMeet.getCreatedBy()).createdOn(new Date()).generalMeeting(generalMeeting).build());
        }
        // Save only filtered new mappings
        departmentSegmentMapperRepository.saveAll(departmentSegmentMappers);
        return generalMeetingDto;
    }

    @Override
    public void rescheduleMeeting(Long generalMeetingId, GeneralMeetingDto generalMeetingDto) {
        GeneralMeeting existingMeeting = generalMeetingRepository.findById(generalMeetingId).orElseThrow(() -> new IllegalArgumentException("Meeting not found for the provided meetingId: " + generalMeetingId));
        existingMeeting.setMeetingDate(generalMeetingDto.getMeetingDate());
        existingMeeting.setFromTime(generalMeetingDto.getFromTime());
        existingMeeting.setToTime(generalMeetingDto.getToTime());
        existingMeeting.setLocation(generalMeetingDto.getLocation());
        existingMeeting.setLink(generalMeetingDto.getLink());
        existingMeeting.setRemarks(generalMeetingDto.getRemarks());
        emailService.sendGeneralMeetingReScheduledEmail(existingMeeting);
        generalMeetingRepository.save(existingMeeting);
    }

    @Override
    public List<GeneralMeetingTaskDto> getMeetingTask(long meetingId) throws Exception {
        List<GeneralMeetingTasks> generalMeetingTasks = generalMeetingTaskRepository.findByGeneralMeeting_Id(meetingId);
        List<GeneralMeetingTaskDto> generalMeetingTaskDtos = generalMeetingMapper.fromGeneralMeetingTask(generalMeetingTasks);
        for (GeneralMeetingTaskDto generalMeetingTaskDto : generalMeetingTaskDtos) {
            generalMeetingTaskDto.setGeneralMeetingId(meetingId);
            List<MeetingTaskStatus> meetingTaskStatusList = meetingTaskStatusRepository.findByGeneralMeetingTaskId(List.of(generalMeetingTaskDto.getGeneralMeetingTaskId()));

            Optional<MeetingTaskStatus> latestStatusMark = meetingTaskStatusList.stream().max(Comparator.comparing(MeetingTaskStatus::getMarkedOn));
            latestStatusMark.ifPresent(meetingTaskStatus -> generalMeetingTaskDto.setStatus(meetingTaskStatus.getTaskStatus()));
            List<MeetingTaskAssignee> meetingTaskAssignees = meetingTaskAssigneeRepository.findByGeneralMeetingTasks_GeneralMeetingTaskId(generalMeetingTaskDto.getGeneralMeetingTaskId());
            List<MeetingTaskAssigneeDto> meetingTaskAssigneeDtos = generalMeetingMapper.fromMeetingTaskAssignee(meetingTaskAssignees);
            for (MeetingTaskAssigneeDto meetingTaskAssigneeDto : meetingTaskAssigneeDtos) {
                EmployeeProfileResponse fetchProfiles = apiClient.getEmployeeProfile(String.valueOf(meetingTaskAssigneeDto.getEmpId()));
                List<EmployeeProfileResponse.EmployeeData> profileData = fetchProfiles.getData();
                meetingTaskAssigneeDto.setEmployeeName(profileData.get(0).getEmployeeFullName());
                meetingTaskAssigneeDto.setEmployeeImgUrl(profileData.get(0).getImageUrl());
            }
            generalMeetingTaskDto.setMeetingTaskAssigneeDtos(meetingTaskAssigneeDtos);
            List<GeneralMeetingTaskTimeline> meetingTaskTimelines = generalMeetingTaskTimelineRepository.findByGeneralMeetingTasks_GeneralMeetingTaskId(generalMeetingTaskDto.getGeneralMeetingTaskId());
            meetingTaskTimelines.stream().filter(a -> a.getMarkDate() != null).max(Comparator.comparing(GeneralMeetingTaskTimeline::getMarkDate)).ifPresent(latest -> generalMeetingTaskDto.setCompletionDate(latest.getCompletionDate()));

        }
        return generalMeetingTaskDtos;
    }

    @Override
    @Transactional
    public void taskRespond(TaskRespondDto taskRespondDto, MultipartFile file) throws Exception {
        GeneralMeetingTasks generalMeetingTasks = generalMeetingTaskRepository.findById(taskRespondDto.getMeetingTaskId()).get();
        GeneralMeeting existingMeeting = new GeneralMeeting();
        if (generalMeetingTasks.getGeneralMeeting() != null) {
            existingMeeting = generalMeetingRepository.findById(generalMeetingTasks.getGeneralMeeting().getId()).orElseThrow(() -> new IllegalArgumentException("Meeting not found for the provided meetingId: " + generalMeetingTasks.getGeneralMeeting().getId()));

        }
        TaskRespond taskRespond = generalMeetingMapper.fromTaskRespond(taskRespondDto);
        taskRespond.setGeneralMeetingTasks(generalMeetingTasks);
        taskRespond.setRespond(true);
        taskRespond.setMarking(false);
        EmployeeProfileResponse fetchProfiles = apiClient.getEmployeeProfile(String.valueOf(taskRespondDto.getRespondedBy()));
        List<EmployeeProfileResponse.EmployeeData> profileData = fetchProfiles.getData();
        taskRespond.setRespondedBy(profileData.get(0).getEmployeeFullName());
        taskRespond = taskRespondRepository.save(taskRespond);
        if (file != null) {
            String path = saveFile(file, String.valueOf(taskRespond.getTaskRespondId()), respondFilePath);
            taskRespond.setFilePath(path);
            taskRespondRepository.save(taskRespond);
        }
        MeetingTaskStatus status = new MeetingTaskStatus();
        status.setMarkedOn(new Date());
        status.setMarkedBy(taskRespond.getRespondedBy());
        status.setTaskStatus("Responded");
        status.setTaskId(generalMeetingTasks);
        meetingTaskStatusRepository.save(status);
        if (generalMeetingTasks.getGeneralMeeting() != null) {
            emailService.taskRespondMail(taskRespond, existingMeeting);
        } else {
            emailService.taskRespondMailNoMeeting(taskRespond);
        }
    }

    @Override
    @Transactional
    public void taskMarking(TaskRespondDto taskRespondDto) throws Exception {
        GeneralMeetingTasks generalMeetingTasks = generalMeetingTaskRepository.findById(taskRespondDto.getMeetingTaskId()).get();
        GeneralMeeting existingMeeting = new GeneralMeeting();
        if (generalMeetingTasks.getGeneralMeeting() != null) {
            existingMeeting = generalMeetingRepository.findById(generalMeetingTasks.getGeneralMeeting().getId()).orElseThrow(() -> new IllegalArgumentException("Meeting not found for the provided meetingId: " + generalMeetingTasks.getGeneralMeeting().getId()));

        }
        TaskRespond taskRespond = generalMeetingMapper.fromTaskRespond(taskRespondDto);
        taskRespond.setGeneralMeetingTasks(generalMeetingTasks);
        taskRespond.setRespond(false);
        taskRespond.setMarking(true);
        EmployeeProfileResponse fetchProfiles = apiClient.getEmployeeProfile(String.valueOf(taskRespondDto.getRespondedBy()));
        List<EmployeeProfileResponse.EmployeeData> profileData = fetchProfiles.getData();
        taskRespond.setRespondedBy(profileData.get(0).getEmployeeFullName());
        taskRespondRepository.save(taskRespond);
        MeetingTaskStatus status = new MeetingTaskStatus();
        status.setMarkedOn(new Date());
        status.setMarkedBy(taskRespond.getRespondedBy());
        status.setTaskStatus(taskRespondDto.getStatus());
        status.setTaskId(generalMeetingTasks);
        meetingTaskStatusRepository.save(status);

        if (generalMeetingTasks.getGeneralMeeting() != null) {
            emailService.taskMarkedMail(taskRespond, existingMeeting);
        } else if (taskRespondDto.getStatus().equals("Justification Required")) {
            emailService.taskMarkedJustificationMail(taskRespond);
        } else if (taskRespondDto.getStatus().equals("Completed")) {
            emailService.taskMarkedCompletedMail(taskRespond);
        }
    }

    @Override
    @Transactional
    public void saveMeetingTask(List<GeneralMeetingTaskDto> generalMeetingTaskDtos) {
        GeneralMeeting existingMeeting = new GeneralMeeting();
        for (GeneralMeetingTaskDto generalMeetingTaskDto : generalMeetingTaskDtos) {
            if (generalMeetingTaskDto.getGeneralMeetingId() != null) {
                existingMeeting = generalMeetingRepository.findById(generalMeetingTaskDto.getGeneralMeetingId()).orElseThrow(() -> new IllegalArgumentException("Meeting not found for the provided meetingId: " + generalMeetingTaskDto.getGeneralMeetingId()));
            } else {
                existingMeeting = null;
            }
            GeneralMeetingTasks generalMeetingTasks = generalMeetingMapper.fromGeneralMeetingTaskDto(generalMeetingTaskDto);
            generalMeetingTasks.setGeneralMeeting(existingMeeting);
            generalMeetingTasks.setCreatedOn(new Date());
            generalMeetingTasks = generalMeetingTaskRepository.save(generalMeetingTasks);

            // Map departmentDtos, segmentDtos, and segmentGroupDtos to DepartmentSegmentMapper
            List<DepartmentSegmentMapper> departmentSegmentMappers = new ArrayList<>();

            // Handle departmentDtos
            if (generalMeetingTaskDto.getDepartmentDtos() != null) {
                for (DepartmentDto department : generalMeetingTaskDto.getDepartmentDtos()) {
                    departmentSegmentMappers.add(DepartmentSegmentMapper.builder().id(department.getId()).name(department.getName()).isDepartment(true).createdBy(Long.parseLong(generalMeetingTaskDto.getCreatedBy())).createdOn(new Date()).generalMeetingTasks(generalMeetingTasks).build());
                }
            }

            // Handle segmentDtos
            if (generalMeetingTaskDto.getSegmentDtos() != null) {
                for (DepartmentDto segment : generalMeetingTaskDto.getSegmentDtos()) {
                    departmentSegmentMappers.add(DepartmentSegmentMapper.builder().id(segment.getId()).name(segment.getName()).isDepartment(false).createdBy(Long.parseLong(generalMeetingTaskDto.getCreatedBy())).createdOn(new Date()).generalMeetingTasks(generalMeetingTasks).build());
                }
            }

            departmentSegmentMapperRepository.saveAll(departmentSegmentMappers);

            List<Long> employeeIds = generalMeetingTaskDto.getEmployeeIds();
            for (Long empId : employeeIds) {
                MeetingTaskAssignee meetingTaskAssignee = new MeetingTaskAssignee();
                meetingTaskAssignee.setEmpId(empId);
                meetingTaskAssignee.setGeneralMeetingTasks(generalMeetingTasks);
                meetingTaskAssignee.setActive(true);
                meetingTaskAssigneeRepository.save(meetingTaskAssignee);
            }
            emailService.sendGeneralMeetingTaskCreateEmail(generalMeetingTasks);
            scheduleReminder(generalMeetingTasks.getGeneralMeetingTaskId(), 0.0333);
            scheduleReminder(generalMeetingTasks.getGeneralMeetingTaskId(), 0.05);
            scheduleReminder(generalMeetingTasks.getGeneralMeetingTaskId(), 0.0583);
        }
    }

    @Override
    @Transactional
    public void editTask(long taskId, GeneralMeetingTaskDto generalMeetingTaskDto) {
        GeneralMeetingTasks existingTask = generalMeetingTaskRepository.findById(taskId).orElseThrow(() -> new IllegalArgumentException("task not found: " + taskId));
        GeneralMeetingTasks generalMeetingTasks = generalMeetingMapper.fromGeneralMeetingTaskDto(generalMeetingTaskDto);
        generalMeetingTasks.setGeneralMeeting(existingTask.getGeneralMeeting());
        generalMeetingMapper.updateMeetingTask(existingTask, generalMeetingTasks);
        generalMeetingTasks = generalMeetingTaskRepository.save(generalMeetingTasks);

        // Fetch existing DepartmentSegmentMapper for the meeting
        List<DepartmentSegmentMapper> existingMappings = departmentSegmentMapperRepository.findByGeneralMeetingTasks_GeneralMeetingTaskId(taskId);
        departmentSegmentMapperRepository.deleteAll(existingMappings);

        List<DepartmentDto> newDepartments = Optional.ofNullable(generalMeetingTaskDto.getDepartmentDtos()).orElse(new ArrayList<>());
        List<DepartmentDto> newSegments = Optional.ofNullable(generalMeetingTaskDto.getSegmentDtos()).orElse(new ArrayList<>());

        // Prepare new mappings
        List<DepartmentSegmentMapper> departmentSegmentMappers = new ArrayList<>();
        for (DepartmentDto department : newDepartments) {
            departmentSegmentMappers.add(DepartmentSegmentMapper.builder().id(department.getId()).name(department.getName()).isDepartment(true).createdBy(Long.parseLong(generalMeetingTaskDto.getCreatedBy())).createdOn(new Date()).generalMeetingTasks(generalMeetingTasks).build());
        }

        for (DepartmentDto segment : newSegments) {
            departmentSegmentMappers.add(DepartmentSegmentMapper.builder().departmentSegmentId(existingMappings.get(0).getDepartmentSegmentId()).id(segment.getId()).name(segment.getName()).isDepartment(false).createdBy(Long.parseLong(generalMeetingTaskDto.getCreatedBy())).createdOn(new Date()).generalMeetingTasks(generalMeetingTasks).build());
        }

        // Save only filtered new mappings
        departmentSegmentMapperRepository.saveAll(departmentSegmentMappers);

        List<Long> employeeIds = generalMeetingTaskDto.getEmployeeIds();
        List<MeetingTaskAssignee> meetingTaskAssignees = meetingTaskAssigneeRepository.findByGeneralMeetingTasks_GeneralMeetingTaskId(taskId);
        Map<Long, MeetingTaskAssignee> existingAssigneesMap = meetingTaskAssignees.stream().collect(Collectors.toMap(MeetingTaskAssignee::getEmpId, Function.identity()));

        List<MeetingTaskAssignee> finalAssigneeList = new ArrayList<>();
        for (Long empId : employeeIds) {
            MeetingTaskAssignee existing = existingAssigneesMap.get(empId);
            if (existing != null) {
                existing.setActive(true);
                finalAssigneeList.add(existing);
            } else {
                MeetingTaskAssignee newAssignee = new MeetingTaskAssignee();
                newAssignee.setEmpId(empId);
                newAssignee.setActive(true);
                newAssignee.setGeneralMeetingTasks(generalMeetingTasks);

                finalAssigneeList.add(newAssignee);
            }
        }
        for (MeetingTaskAssignee assignee : meetingTaskAssignees) {
            if (!employeeIds.contains(assignee.getEmpId())) {
                assignee.setActive(false);
                finalAssigneeList.add(assignee);
            }
        }
        meetingTaskAssigneeRepository.saveAll(finalAssigneeList);

    }

    @Override
    public List<TaskRespondDto> getRespondAndMarking(long meetingTaskId) {
        List<TaskRespond> taskResponds = taskRespondRepository.findByGeneralMeetingTasks_GeneralMeetingTaskId(meetingTaskId);
        List<MeetingTaskStatus> statusList = meetingTaskStatusRepository.findByGeneralMeetingTaskId(List.of(meetingTaskId));
        statusList.removeIf(status -> status.getTaskStatus() != null && status.getTaskStatus().equalsIgnoreCase("Task Assigned"));

        return IntStream.range(0, Math.min(taskResponds.size(), statusList.size())).mapToObj(i -> {
            TaskRespondDto taskRespondDto = generalMeetingMapper.fromTaskRespondAndMarkingDto(taskResponds.get(i));
            taskRespondDto.setStatus(statusList.get(i).getTaskStatus());
            return taskRespondDto;
        }).collect(Collectors.toList());

    }

    @Override
    public GeneralMeetingDto getMeetingById(Long generalMeetingId) {
        GeneralMeeting existingMeeting = generalMeetingRepository.findById(generalMeetingId).orElseThrow(() -> new IllegalArgumentException("Meeting not found for the provided meetingId: " + generalMeetingId));
        GeneralMeetingDto generalMeetingDto = generalMeetingMapper.mapToGeneralMeetingDto(existingMeeting);
        List<GeneralMeetingStatusMark> generalMeetingStatusMark = generalMeetingStatusMarkRepository.findByGeneralMeeting_Id(existingMeeting.getId());
        Optional<GeneralMeetingStatusMark> latestStatusMark = generalMeetingStatusMark.stream().max(Comparator.comparing(GeneralMeetingStatusMark::getMarkedOn));
        latestStatusMark.ifPresent(statusMark -> generalMeetingDto.setMeetingStatus(statusMark.getStatus()));

        // Fetch and map participants
        List<MeetingParticipants> participants = meetingParticipantsRepository.findByGeneralMeeting_Id(existingMeeting.getId());
        List<MeetingParticipantsDto> participantsDtos = participants.stream().map(generalMeetingMapper::mapToMeetingParticipantsDto).collect(Collectors.toList());
        generalMeetingDto.setMeetingParticipantsDtoList(participantsDtos);
        return generalMeetingDto;
    }

    @Override
    public void sendMeetingLink(long meetingId) {
        GeneralMeeting existingMeeting = generalMeetingRepository.findById(meetingId).orElseThrow(() -> new IllegalArgumentException("Meeting not found for the provided meetingId: " + meetingId));
        emailService.resendMeetingLinkMail(existingMeeting);
    }

    @Override
    public GeneralMeetingTimelineDto getGeneralMeetingTimeline(long id) {
        // Fetch GeneralMeetingStatusMark and GeneralMeetingTasks
        List<GeneralMeetingStatusMark> generalMeetingStatusList = generalMeetingStatusMarkRepository.findByGeneralMeeting_Id(id);
        List<GeneralMeetingTasks> generalMeetingTaskList = generalMeetingTaskRepository.findByGeneralMeeting_Id(id);

        // Extract task IDs from GeneralMeetingTasks
        List<Long> taskIds = generalMeetingTaskList.stream().map(GeneralMeetingTasks::getGeneralMeetingTaskId).collect(Collectors.toList());

        // Fetch MeetingTaskStatus based on task IDs
        List<MeetingTaskStatus> meetingTaskStatusList = meetingTaskStatusRepository.findByGeneralMeetingTaskId(taskIds);

        // Map GeneralMeetingStatusMark to MeetingStatusMarkResponseDto
        List<MeetingStatusMarkResponseDto> meetingStatusMarkDtos = generalMeetingStatusList.stream().map(statusMark -> {
            EmployeeProfileResponse profileResponse = null;
            String markedBy = "Unknown";
            try {
                profileResponse = apiClient.getEmployeeProfile(statusMark.getMarkedBy());
            } catch (Exception e) {
                throw new RuntimeException("Failed to fetch employee profile for employee Id : " + statusMark.getMarkedBy(), e);
            }

            if (profileResponse != null && profileResponse.getData() != null && !profileResponse.getData().isEmpty()) {
                markedBy = profileResponse.getData().get(0).getEmployeeFullName();
            }
            return MeetingStatusMarkResponseDto.builder().meetingName(statusMark.getGeneralMeeting().getMeetingName()).status(statusMark.getStatus()).markedOn(statusMark.getMarkedOn()).markedBy(markedBy).build();
        }).collect(Collectors.toList());

        // Map GeneralMeetingTasks to GeneralMeetingTaskResponseDto and  MeetingTaskStatus
        List<GeneralMeetingTaskResponseDto> generalMeetingTaskDtos = generalMeetingTaskList.stream().map(task -> {
            // Filter MeetingTaskStatus based on the taskId
            List<MeetingTaskStatusResponseDto> taskStatusDtos = meetingTaskStatusList.stream().filter(taskStatus -> taskStatus.getTaskId().getGeneralMeetingTaskId().equals(task.getGeneralMeetingTaskId())).map(taskStatus -> MeetingTaskStatusResponseDto.builder().markedBy(taskStatus.getMarkedBy()).markedOn(taskStatus.getMarkedOn()).taskStatus(task.getTaskName()).meetingTaskSubStatus(taskStatus.getTaskStatus()).build()).collect(Collectors.toList());

            return GeneralMeetingTaskResponseDto.builder().meetingTaskStatus(taskStatusDtos).build();
        }).collect(Collectors.toList());

        // Return GeneralMeetingTimelineDto
        return GeneralMeetingTimelineDto.builder().meetingStatusMark(meetingStatusMarkDtos).generalMeetingTask(generalMeetingTaskDtos).build();
    }

    public List<GeneralMeetingTaskDto> getGeneralMeetingTaskByEmp(Long id, Boolean flag) throws Exception {
        if (id == null) {
            return Collections.emptyList();
        }

        // Fetch tasks assigned to the employee
        List<MeetingTaskAssignee> taskAssignees = meetingTaskAssigneeRepository.findByEmpId(id);
        List<GeneralMeetingTasks> tasks = taskAssignees.stream().map(MeetingTaskAssignee::getGeneralMeetingTasks).filter(Objects::nonNull).collect(Collectors.toList());

        // Filter tasks based on flag only if flag is false
        if (Boolean.FALSE.equals(flag)) {
            tasks = tasks.stream().filter(a -> a.getGeneralMeeting() == null).collect(Collectors.toList());
        }

        // Fetch tasks created by the employee
        List<GeneralMeetingTasks> meetingTasks = generalMeetingTaskRepository.findByCreatedBy(String.valueOf(id));
        // Filter created tasks based on flag only if flag is false
        if (Boolean.FALSE.equals(flag)) {
            meetingTasks = meetingTasks.stream().filter(a -> a.getGeneralMeeting() == null).toList();
        }
        tasks.addAll(meetingTasks.stream().filter(Objects::nonNull).toList());
        Set<GeneralMeetingTasks> tasksSet = new TreeSet<>(tasks);
        ArrayList<GeneralMeetingTasks> taskList = new ArrayList<>(tasksSet);
        List<GeneralMeetingTaskDto> generalMeetingTaskDtos = generalMeetingMapper.fromGeneralMeetingTask(taskList);

        for (int i = 0; i < taskList.size(); i++) {
            GeneralMeetingTasks task = taskList.get(i);
            GeneralMeetingTaskDto dto = generalMeetingTaskDtos.get(i);
            if (task.getGeneralMeeting() != null) {
                dto.setGeneralMeetingId(task.getGeneralMeeting().getId());
            } else {
                dto.setGeneralMeetingId(null);
            }
        }

        for (GeneralMeetingTaskDto dto : generalMeetingTaskDtos) {
            Long generalMeetingTaskId = dto.getGeneralMeetingTaskId();
            List<MeetingTaskAssignee> assignees = meetingTaskAssigneeRepository.findByGeneralMeetingTasks_GeneralMeetingTaskId(generalMeetingTaskId);
            List<MeetingTaskAssigneeDto> taskAssigneeDtos = generalMeetingMapper.fromMeetingTaskAssignee(assignees);
            for (MeetingTaskAssigneeDto taskAssignee : taskAssigneeDtos) {
                EmployeeProfileResponse fetchProfiles = apiClient.getEmployeeProfile(String.valueOf(taskAssignee.getEmpId()));
                List<EmployeeProfileResponse.EmployeeData> profileData = fetchProfiles.getData();
                taskAssignee.setEmployeeImgUrl(profileData.get(0).getImageUrl());
                taskAssignee.setEmployeeName(profileData.get(0).getEmployeeFullName());
            }

            List<MeetingTaskStatus> statuses = meetingTaskStatusRepository.findByGeneralMeetingTaskId(Collections.singletonList(generalMeetingTaskId));
            statuses.stream().filter(a -> a.getMarkedOn() != null).max(Comparator.comparing(MeetingTaskStatus::getMarkedOn)).ifPresent(latest -> dto.setStatus(latest.getTaskStatus()));
            List<DepartmentDto> department = new ArrayList<>();
            List<DepartmentDto> segment = new ArrayList<>();

            if (dto.getGeneralMeetingId() != null) {
                GeneralMeeting generalMeeting = generalMeetingRepository.findById(dto.getGeneralMeetingId()).orElse(null);
                if (generalMeeting != null) {
                    List<DepartmentSegmentMapper> depSeg = departmentSegmentMapperRepository.findByGeneralMeeting_Id(generalMeeting.getId());
                    dto.setGeneralMeetingName(generalMeeting.getMeetingName());
                    for (DepartmentSegmentMapper departmentSegment : depSeg) {
                        DepartmentDto departmentDto = DepartmentDto.builder().id(departmentSegment.getDepartmentSegmentId()).name(departmentSegment.getName()).build();
                        if (departmentSegment.isDepartment()) {
                            department.add(departmentDto);
                        } else {
                            segment.add(departmentDto);
                        }
                    }
                    dto.setDepartmentDtos(department);
                    dto.setSegmentDtos(segment);
                }
            }

            dto.setMeetingTaskAssigneeDtos(taskAssigneeDtos);
            Long taskId = dto.getGeneralMeetingTaskId();
            List<GeneralMeetingTaskTimeline> timelines = generalMeetingTaskTimelineRepository.findByGeneralMeetingTasks_GeneralMeetingTaskId(taskId);
            timelines.stream().filter(a -> a.getMarkDate() != null).max(Comparator.comparing(GeneralMeetingTaskTimeline::getMarkDate)).ifPresent(latest -> dto.setCompletionDate(latest.getCompletionDate()));

            List<DepartmentSegmentMapper> departmentSegmentMappers = departmentSegmentMapperRepository.findByGeneralMeetingTasks_GeneralMeetingTaskId(generalMeetingTaskId);

            for (DepartmentSegmentMapper departmentSegment : departmentSegmentMappers) {
                DepartmentDto departmentDto = DepartmentDto.builder().id(departmentSegment.getDepartmentSegmentId()).name(departmentSegment.getName()).build();
                if (departmentSegment.isDepartment()) {
                    department.add(departmentDto);
                } else {
                    segment.add(departmentDto);
                }
            }
            dto.setDepartmentDtos(department);
            dto.setSegmentDtos(segment);
        }
        return generalMeetingTaskDtos;
    }

    @Override
    @Transactional
    public void markStatus(MeetingStatusMarkDto meetingStatusMarkDto, MultipartFile file) throws Exception {
        GeneralMeeting generalMeeting = generalMeetingRepository.findById(meetingStatusMarkDto.getGeneralMeetingId()).orElseThrow(() -> new IllegalArgumentException("Meeting not found for the provided meetingId: " + meetingStatusMarkDto.getGeneralMeetingId()));
        generalMeeting.setMom(meetingStatusMarkDto.getMom());
        generalMeeting.setReasonForCancellation(meetingStatusMarkDto.getReasonForCancellation());
        generalMeeting = generalMeetingRepository.save(generalMeeting);

        GeneralMeetingStatusMark generalMeetingStatusMark = new GeneralMeetingStatusMark();

        generalMeetingStatusMark.setStatus(meetingStatusMarkDto.getStatus());
        generalMeetingStatusMark.setMarkedBy(meetingStatusMarkDto.getMarkedBy());
        generalMeetingStatusMark.setMarkedOn(new Date());
        generalMeetingStatusMark.setGeneralMeeting(generalMeeting);
        generalMeetingStatusMark = generalMeetingStatusMarkRepository.save(generalMeetingStatusMark);

        if (meetingStatusMarkDto.getGeneralMeetingTaskDto() != null) {
            List<GeneralMeetingTaskDto> generalMeetingTaskDto = meetingStatusMarkDto.getGeneralMeetingTaskDto();
            for (GeneralMeetingTaskDto generalMeetingTaskDto1 : generalMeetingTaskDto) {
                List<Long> employeeIds = generalMeetingTaskDto1.getEmployeeIds();
                GeneralMeetingTasks generalMeetingTasks = generalMeetingMapper.fromGeneralMeetingTaskDto(generalMeetingTaskDto1);
                generalMeetingTasks.setGeneralMeeting(generalMeeting);
                generalMeetingTasks.setCreatedOn(new Date());
                generalMeetingTasks = generalMeetingTaskRepository.save(generalMeetingTasks);
                MeetingTaskStatus status = new MeetingTaskStatus();
                status.setMarkedOn(new Date());
                EmployeeProfileResponse employeeProfileResponse = apiClient.getEmployeeProfile(meetingStatusMarkDto.getMarkedBy());
                status.setMarkedBy(employeeProfileResponse.getData().get(0).getEmployeeFullName());
                status.setTaskStatus("Task Assigned");
                status.setTaskId(generalMeetingTasks);
                meetingTaskStatusRepository.save(status);
                for (Long meetingTaskAssignees : employeeIds) {
                    MeetingTaskAssignee meetingTaskAssignee = new MeetingTaskAssignee();
                    meetingTaskAssignee.setEmpId(meetingTaskAssignees);
                    meetingTaskAssignee.setGeneralMeetingTasks(generalMeetingTasks);
                    meetingTaskAssigneeRepository.save(meetingTaskAssignee);
                }
            }
        }

        if (file != null) {
            String path = saveFile(file, generalMeeting.getMeetingName(), filePath);
            FileSavePath fileSavePath = new FileSavePath();

            fileSavePath.setPath(path);
            fileSavePath.setStatusMark(true);
            fileSavePath.setGeneralMeeting(generalMeeting);
            fileSavePath.setGeneralMeetingStatusMark(generalMeetingStatusMark);
            fileSavePath.setCreatedOn(new Date());
            fileSavePathRepository.save(fileSavePath);
        }

        if (meetingStatusMarkDto.getEmployeeIds() != null) {
            List<MeetingParticipants> existingMeetingParticipants = meetingParticipantsRepository.findByGeneralMeeting_Id(generalMeeting.getId());

            Set<Long> newEmployeeIds = new HashSet<>(meetingStatusMarkDto.getEmployeeIds());

            for (MeetingParticipants participant : existingMeetingParticipants) {
                if (newEmployeeIds.contains(participant.getEmployeeId())) {
                    participant.setIsActive(1);
                    newEmployeeIds.remove(participant.getEmployeeId());
                } else {
                    participant.setIsActive(0);
                }
            }
            meetingParticipantsRepository.saveAll(existingMeetingParticipants);

            GeneralMeeting finalGeneralMeeting = generalMeeting;
            List<MeetingParticipants> newParticipants = newEmployeeIds.stream().map(employeeId -> MeetingParticipants.builder().generalMeeting(finalGeneralMeeting).employeeId(employeeId).assignedBy(finalGeneralMeeting.getCreatedBy()).assignedDate(new Date()).isActive(1).build()).collect(Collectors.toList());

            meetingParticipantsRepository.saveAll(newParticipants);
            if (generalMeetingStatusMark.getStatus().equalsIgnoreCase(Constants.COMPLETED)) {
                emailService.sendMailGeneralMeetingStatusCompleted(generalMeeting);
            } else if (generalMeetingStatusMark.getStatus().equalsIgnoreCase(Constants.CANCELLED)) {
                emailService.meetingCancelled(generalMeeting);
            }
        }

    }

    public String saveFile(MultipartFile multipartFile, String originalFileName, String path) throws IOException {
        String currentDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date());

        File directory = new File(path + File.separator + currentDate + File.separator + originalFileName);
        if (!directory.exists()) {
            directory.mkdirs();
        }
        String fileName = multipartFile.getOriginalFilename();
        fileName = (fileName != null && !fileName.isEmpty()) ? fileName : "attachment_" + System.currentTimeMillis();

        File file = new File(directory, fileName);
        multipartFile.transferTo(file);

        return file.getAbsolutePath();
    }

    public List<GeneralMeetingDto> setFullData(List<GeneralMeetingDto> generalMeetingDtos) throws Exception {

        for (GeneralMeetingDto generalMeetingDto : generalMeetingDtos) {
            EmployeeProfileResponse fetchProfiles = apiClient.getEmployeeProfile(generalMeetingDto.getScheduledBy());
            List<EmployeeProfileResponse.EmployeeData> profileData = fetchProfiles.getData();
            if (!profileData.isEmpty()) {
                generalMeetingDto.setHostIdName(fetchProfiles.getData().get(0).getEmployeeFullName());
                generalMeetingDto.setDesignation(fetchProfiles.getData().get(0).getDesignation() + " - " + fetchProfiles.getData().get(0).getDepartmentName());
            } else {
                log.warn("No profile data for CreatedBy: {}", generalMeetingDto.getCreatedBy());
                generalMeetingDto.setHostIdName("Unknown");
                generalMeetingDto.setDesignation("Unknown");
            }
            List<GeneralMeetingTasks> generalMeetingTasks = generalMeetingTaskRepository.findByGeneralMeeting_Id(generalMeetingDto.getId());
            List<GeneralMeetingTaskDto> generalMeetingTaskDtos = generalMeetingMapper.fromGeneralMeetingTask(generalMeetingTasks);
            for (GeneralMeetingTaskDto generalMeetingTaskDto : generalMeetingTaskDtos) {
                List<MeetingTaskAssignee> meetingTaskAssignees = meetingTaskAssigneeRepository.findByGeneralMeetingTasks_GeneralMeetingTaskId(generalMeetingDto.getId());
                List<MeetingTaskAssigneeDto> meetingTaskAssigneeDtos = generalMeetingMapper.fromMeetingTaskAssignee(meetingTaskAssignees);
                generalMeetingTaskDto.setMeetingTaskAssigneeDtos(meetingTaskAssigneeDtos);
            }
            generalMeetingDto.setGeneralMeetingTaskDtos(generalMeetingTaskDtos);

            List<MeetingParticipants> meetingParticipantslist = meetingParticipantsRepository.findByGeneralMeetingIdAndIsActive(generalMeetingDto.getId(), 1);
            List<MeetingParticipantsDto> participantsDtoList = new ArrayList<>();
            for (MeetingParticipants meetingParticipants : meetingParticipantslist) {
                EmployeeProfileResponse employeeProfile = apiClient.getEmployeeProfile(String.valueOf(meetingParticipants.getEmployeeId()));
                MeetingParticipantsDto meetingParticipantsDto = new MeetingParticipantsDto();
                if (employeeProfile != null && employeeProfile.getData() != null && !employeeProfile.getData().isEmpty()) {
                    String employeeName = employeeProfile.getData().get(0).getEmployeeFullName();
                    String employeeNo = employeeProfile.getData().get(0).getEmployeeNo();
                    meetingParticipantsDto.setParticipantName(employeeName);
                    meetingParticipantsDto.setEmployeeId(Long.parseLong(employeeNo));
                    participantsDtoList.add(meetingParticipantsDto);
                }
            }
            generalMeetingDto.setMeetingParticipantsDtoList(participantsDtoList);

//            List<DepartmentSegmentMapper> depSeg = departmentSegmentMapperRepository.findByGeneralMeetingId(generalMeetingDto.getId());
            List<DepartmentSegmentMapper> depSeg;
            try {
                depSeg = departmentSegmentMapperRepository.findByGeneralMeetingId(generalMeetingDto.getId());
            } catch (Exception e) {
                log.error("Error fetching DepartmentSegmentMapper for meeting ID {}: {}", generalMeetingDto.getId(), e.getCause(), e);
                depSeg = new ArrayList<>();
            }

            List<DepartmentDto> department = new ArrayList<>();
            List<DepartmentDto> segment = new ArrayList<>();

            for (DepartmentSegmentMapper departmentSegment : depSeg) {
                DepartmentDto dto = DepartmentDto.builder().id(departmentSegment.getDepartmentSegmentId()).name(departmentSegment.getName()).build();

                if (departmentSegment.isDepartment()) {
                    department.add(dto);
                } else {
                    segment.add(dto);
                }
            }
            generalMeetingDto.setDepartmentDtos(department);
            generalMeetingDto.setSegmentDtos(segment);
//            generalMeetingDto.setSegmentGroupDtos(segmentGroup);

            generalMeetingDtos = generalMeetingDtos.stream().sorted(Comparator.comparing(GeneralMeetingDto::getCreatedOn, Comparator.nullsLast(Comparator.reverseOrder()))).collect(Collectors.toList());

            List<FileSavePath> fileSavePaths = fileSavePathRepository.findByGeneralMeeting_Id(generalMeetingDto.getId());
            Optional<FileSavePath> latestFile = fileSavePaths.stream().filter(file -> file.getCreatedOn() != null).max(Comparator.comparing(FileSavePath::getCreatedOn));
            latestFile.ifPresent(file -> generalMeetingDto.setPath(file.getPath()));
            List<GeneralMeetingStatusMark> generalMeetingStatusMark = generalMeetingStatusMarkRepository.findByGeneralMeeting_Id(generalMeetingDto.getId());
            Optional<GeneralMeetingStatusMark> latestStatusMark = generalMeetingStatusMark.stream().max(Comparator.comparing(GeneralMeetingStatusMark::getMarkedOn));
            latestStatusMark.ifPresent(statusMark -> generalMeetingDto.setMeetingStatus(statusMark.getStatus()));
        }
        return generalMeetingDtos;
    }

    private void scheduleReminder(Long taskId, double delayInHours) {
        long delayInMillis = (long) (delayInHours * 60 * 60 * 1000);

        taskReminderExecutor.schedule(() -> {
            List<GeneralMeetingTaskTimeline> taskTimeline = generalMeetingTaskTimelineRepository.findByGeneralMeetingTasks_GeneralMeetingTaskId(taskId);
            if (taskTimeline.isEmpty()) {

                Optional<GeneralMeetingTasks> task = generalMeetingTaskRepository.findById(taskId);
                if (task.isPresent()) {
                    Optional<GeneralMeeting> generalMeeting = generalMeetingRepository.findById(task.get().getGeneralMeeting().getId());
                    generalMeeting.ifPresent(meeting -> emailService.completionDatePendingMail(meeting, task.get()));
                }
            }
        }, delayInMillis, TimeUnit.MILLISECONDS);
    }

}

