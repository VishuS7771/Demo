package com.mas.managemate.controller;

import com.mas.managemate.model.dto.ApiResponse;
import com.mas.managemate.model.dto.SubStatusDefinitionsDto;
import com.mas.managemate.service.SubStatusDefinitionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/sub-status")
@Slf4j
public class SubStatusDefinitionController {

    @Autowired
    private SubStatusDefinitionService subStatusDefinitionService;

    @PostMapping("/create")
    public ApiResponse<?> createSubStatusMapping(@RequestBody SubStatusDefinitionsDto subStatusDefinitionsDto) {
        try {
            SubStatusDefinitionsDto subStatusMapping = subStatusDefinitionService.createSubStatusMapping(subStatusDefinitionsDto);
            return new ApiResponse<>(subStatusMapping, "Created Sub Status Mapping", HttpStatus.CREATED);
        } catch (Exception e) {
            log.error("Error while creating sub-status mapping: {}", e.getMessage(), e);
            return new ApiResponse<>(null, "Failed to create Sub Status Mapping: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/all")
    public ApiResponse<?> getAllSubStatus() {
        try {
            return new ApiResponse<>(subStatusDefinitionService.getAllSubStatus(), "All Sub Status", HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error while fetching all sub-status mappings: {}", e.getMessage(), e);
            return new ApiResponse<>(null, "Failed to fetch all Sub Status: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/update/{id}")
    public ApiResponse<?> updateSubStatus(@RequestBody SubStatusDefinitionsDto subStatusDefinitionsDto, @PathVariable Long id) {
        try {
            SubStatusDefinitionsDto updatedSubStatusDefinitionsDto = subStatusDefinitionService.updateSubStatus(subStatusDefinitionsDto, id);
            return new ApiResponse<>(updatedSubStatusDefinitionsDto, "Sub-status updated successfully.", HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error while updating sub-status with ID {}: {}", id, e.getMessage(), e);
            return new ApiResponse<>(e.getMessage(), "Failed to update sub-status "+e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/sub-status-by-status/{statusId}")
    public ApiResponse<?> getSubStatusByStatus(@PathVariable long statusId) {
        try {
            List<SubStatusDefinitionsDto> statusDefinitionsDtos = subStatusDefinitionService.getSubStatusByStatus(statusId);
            return new ApiResponse<>(statusDefinitionsDtos, "Success", HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error while fetching sub-status by status ID {}: {}", statusId, e.getMessage(), e);
            return new ApiResponse<>(e.getMessage(), "Failed to fetch sub-status by status "+e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/sub-status-by-id/{subStatusId}")
    public ApiResponse<?> getSubStatusBySubStatus(@PathVariable long subStatusId) {
        try {
            SubStatusDefinitionsDto statusDefinitionsDtos = subStatusDefinitionService.getSubStatusBySubStatus(subStatusId);
            return new ApiResponse<>(statusDefinitionsDtos, "Success", HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error while fetching sub-status by status ID {}: {}", subStatusId, e.getMessage(), e);
            return new ApiResponse<>(e.getMessage(), "Failed to fetch sub-status by status "+e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

}
