package com.mas.managemate.util;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.mas.managemate.model.dto.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import com.fasterxml.jackson.core.type.TypeReference;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;

@Configuration
@Slf4j
public class ApiClient {

    @Value("${api.get-employee}")
    private String getEmployeeUrl;

    @Value("${api.get-allemployee}")
    private String getAllEmployeeUrl;

    @Value("${api.access-token}")
    private String accessTokenUrl;

    @Value("${api.login-hr}")
    private String loginHrUrl;

    @Value("${api.department-designation}")
    private String departmentdesignation;

    @Value("${api.hierarchy-matrix}")
    private String hierarchyMatrixUrl;

    private static final HttpClient client = HttpClient.newHttpClient();
    private static final ObjectMapper objectMapper = new ObjectMapper();

    public  EmployeeProfileResponse getAllEmployeeProfile() throws Exception {
        log.info("fetching all employees from HR Application");
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(getAllEmployeeUrl))
                .GET()
                .build();

        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        log.info("fetching all employees from HR Application successfully");
        return objectMapper.readValue(response.body(), EmployeeProfileResponse.class);
    }

    public EmployeeProfileResponse getEmployeeProfile(String userId) throws Exception {
        log.info("fetching employees from HR Application using employee Id {}",userId);
        String requestBody = "{ \"user_id\": \"" + userId + "\" }";
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(getEmployeeUrl))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                .build();

        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        log.info("fetching employees from HR Application using employee Id {} Successfully",userId);
        return objectMapper.readValue(response.body(), EmployeeProfileResponse.class);
    }

    public AccessTokenResponseDto getAccessToken() throws Exception {
        String auth = "MASTOHR" + ":" + "MASTOHR";
        String encodedAuth = Base64.getEncoder().encodeToString(auth.getBytes(StandardCharsets.UTF_8));

        String formData = "grant_type=password&username=" + "MASTOHR" + "&password=" + "MASTOHR";
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(accessTokenUrl))
                .header("Authorization", "Basic " + "TUFTVVNFUk5BTUU6TUFTUEFTU1dPUkQ=")
                .header("Content-Type", "application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyPublishers.ofString(formData))
                .build();

        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() == 200) {
            return objectMapper.readValue(response.body(), AccessTokenResponseDto.class);
        } else {
            throw new RuntimeException("Failed to get access token. Status code: " + response.statusCode());
        }
    }

    public HrLoginResponse login(AuthRequestDto authRequestDto) throws Exception {
        log.info("started login process from HR Application using employee Id {}",authRequestDto.getUsername());
        AccessTokenResponseDto token=getAccessToken();
        String requestBody = objectMapper.writeValueAsString(authRequestDto);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(loginHrUrl))
                .header("Authorization", "Bearer " + token.getAccess_token()) // Bearer token header
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                .build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() == 200) {
            log.info("log in process successful for employee Id {}",authRequestDto.getUsername());
            return objectMapper.readValue(response.body(), HrLoginResponse.class);
        } else {
            throw new RuntimeException("Failed to login. Status code: " + response.statusCode());
        }
    }

    public HierarchyMatrixResponse getHierarchyMatrix(String userId) throws Exception {
        log.info("getting hierarchy matrix for employee Id {}",userId);
        String requestBody = "{ \"user_id\": \"" + userId + "\" }";
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(hierarchyMatrixUrl))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                .build();

        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        log.info("getting hierarchy matrix for employee Id {} successful",userId);
        return objectMapper.readValue(response.body(), HierarchyMatrixResponse.class);
    }

    public  List<DepartmentDto> getMaster(String param,String para2) throws Exception {
        ObjectNode requestJson = objectMapper.createObjectNode();
        requestJson.put("para1", param);
        if (para2 != null && !para2.trim().isEmpty()) {
            requestJson.put("para2", para2);
        }
        String requestBody = objectMapper.writeValueAsString(requestJson);
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(departmentdesignation))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                .build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        JsonNode rootNode = objectMapper.readTree(response.body());
        JsonNode dataNode = rootNode.get("data");
        log.info("getting master for param {} successful",param);
        return objectMapper.readValue(dataNode.toString(), new TypeReference<List<DepartmentDto>>() {});
    }
}
