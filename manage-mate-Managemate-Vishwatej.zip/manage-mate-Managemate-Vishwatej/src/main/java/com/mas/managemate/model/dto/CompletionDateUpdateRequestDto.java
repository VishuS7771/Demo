package com.mas.managemate.model.dto;

import lombok.Data;

import java.util.Date;

@Data
public class CompletionDateUpdateRequestDto {
    private Date completionDate;
    private Long generalMeetingTaskId;
    private String remarks;
    private String markedBy;
}
