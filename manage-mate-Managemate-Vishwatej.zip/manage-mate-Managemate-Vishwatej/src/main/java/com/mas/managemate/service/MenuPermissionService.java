package com.mas.managemate.service;

import com.mas.managemate.model.entity.MenuPermission;
import com.mas.managemate.model.entity.MenuPermissionAccess;

import java.util.List;

public interface MenuPermissionService {
    
    MenuPermission addMenuPermission(MenuPermission menuPermission);
    
    MenuPermission getMenuPermission(long empId);

    List<MenuPermissionAccess> getMenuPermissionAccess();
}
