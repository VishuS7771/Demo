package com.mas.managemate.serviceImpl;

import com.mas.managemate.component.JwtTokenProvider;
import com.mas.managemate.model.dto.*;
import com.mas.managemate.model.entity.MenuPermission;
import com.mas.managemate.model.entity.MenuPermissionAccess;
import com.mas.managemate.repository.MenuPermissionAccessRepository;
import com.mas.managemate.repository.MenuPermissionRepository;
import com.mas.managemate.service.AuthService;
import com.mas.managemate.util.AESUtil;
import com.mas.managemate.util.ApiClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@Slf4j
public class AuthServiceImpl implements AuthService {

    @Autowired
    private ApiClient apiClient;

    @Autowired
    private JwtTokenProvider tokenProvider;

    @Autowired
    private MenuPermissionRepository menuPermissionRepository;

    @Autowired
    private MenuPermissionAccessRepository menuPermissionAccessRepository;

    @Override
    public ApiResponse<?> authenticate(AuthRequestDto authRequestDto) throws Exception {
        log.info("started login process for employee Id {}",authRequestDto.getUsername());
        String decryptedPassword = AESUtil.decrypt(authRequestDto.getPassword());
        authRequestDto.setPassword(decryptedPassword);
        Optional<MenuPermission> menuPermission =menuPermissionRepository.findByEmployeeId(Long.parseLong(authRequestDto.getUsername()));
        boolean isPermissionGranted = menuPermission.isPresent() && (
                menuPermission.get().isStatus() ||
                        menuPermission.get().isSubStatus() ||
                        menuPermission.get().isProprietor() ||
                        menuPermission.get().isAssign() ||
                        menuPermission.get().isDashboard() ||
                        menuPermission.get().isTask() ||
                        menuPermission.get().isModule() ||
                        menuPermission.get().isGeneralMeeting() ||
                        menuPermission.get().isUser()
        );
        Optional<MenuPermissionAccess> permission = menuPermissionAccessRepository.findByEmployeeId(Long.parseLong(authRequestDto.getUsername()));
        boolean flag = permission.isPresent();
        if(menuPermission.isPresent() && isPermissionGranted){
          HrLoginResponse hrLoginResponse =apiClient.login(authRequestDto);
          if (hrLoginResponse.isResponse()){
              EmployeeProfileResponse employeeProfile =apiClient.getEmployeeProfile(authRequestDto.getUsername());
              String jwt = tokenProvider.generateToken(employeeProfile);
              LogInResponse response=LogInResponse.builder().employeeNo(authRequestDto.getUsername()).isLogin(hrLoginResponse.isResponse()).jwt(jwt)
                      .message(hrLoginResponse.getMessage()).employeeData(employeeProfile.getData().get(0))
                      .menuPermission(menuPermission.get()).isMenuPermissionAccess(flag).build();
              log.error("login success for employee Id {}",authRequestDto.getUsername());
              return new ApiResponse<>(response,"success", HttpStatus.OK);
          }
            log.error("login failed for employee Id {}",authRequestDto.getUsername());
          LogInResponse response= LogInResponse.builder().employeeNo(authRequestDto.getUsername()).isMenuPermissionAccess(flag).isLogin(hrLoginResponse.isResponse()).jwt(null).message(hrLoginResponse.getMessage()).employeeData(null).build();
          return new ApiResponse<>(response, hrLoginResponse.getMessage(), HttpStatus.BAD_REQUEST);
      }
        log.error("employee Id {} don`t have permission to access",authRequestDto.getUsername());
        LogInResponse response= LogInResponse.builder().employeeNo(authRequestDto.getUsername()).isMenuPermissionAccess(flag).isLogin(false).jwt(null).message("you don`t have permission to access").employeeData(null).build();
        return new ApiResponse<>(response,"you don`t have permission to access",HttpStatus.BAD_REQUEST);
    }
}
