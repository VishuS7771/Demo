package com.mas.managemate.controller;

import com.mas.managemate.model.dto.ApiResponse;
import com.mas.managemate.model.dto.ModuleAssignmentDto;
import com.mas.managemate.service.ModuleAssignmentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/module-assignment")
@Slf4j
public class ModuleAssignmentController {

    @Autowired
    private ModuleAssignmentService moduleAssignmentService;

    @PostMapping("/save-assignment")
    public ApiResponse<?> createModuleAssignment(@RequestBody ModuleAssignmentDto moduleAssignmentDto) {
        try {
            ModuleAssignmentDto createdModuleAssignmentDto = moduleAssignmentService.createModuleAssignment(moduleAssignmentDto);
            return new ApiResponse<>(createdModuleAssignmentDto, "Module assignment created successfully.", HttpStatus.CREATED);
        } catch (Exception e) {
            log.error("error occurred in saving module assignment {}",e.getMessage());
            return new ApiResponse<>(e.getMessage(), "Failed to save module assignment "+e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/update-assignment/{moduleMappingId}")
    public ApiResponse<?> updateModuleAssignment(@PathVariable long moduleMappingId, @RequestBody ModuleAssignmentDto moduleAssignmentDto) {
        try {
            ModuleAssignmentDto updatedModuleAssignmentDto = moduleAssignmentService.updateModuleAssignment(moduleMappingId, moduleAssignmentDto);
            return new ApiResponse<>(updatedModuleAssignmentDto, "Module assignment updated successfully.", HttpStatus.OK);
        } catch (Exception e) {
            log.error("error occurred in updating module assignment {}",e.getMessage());
            return new ApiResponse<>(e.getMessage(), "Failed to update module assignment "+e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/get-by-module-name/{module}")
    public ApiResponse<?> getModuleAssignmentByName(@PathVariable String module) {
        try {
            ModuleAssignmentDto moduleAssignmentsDto = moduleAssignmentService.findByModuleName(module);
            if (moduleAssignmentsDto != null) {
                return new ApiResponse<>(moduleAssignmentsDto, "Module assignment found successfully.", HttpStatus.OK);
            } else {
                return new ApiResponse<>("Module assignment not found", "Module not found", HttpStatus.BAD_REQUEST);
            }
        } catch (Exception e) {
            log.error("error occurred in get module assignment by name {}",e.getMessage());
            return new ApiResponse<>(e.getMessage(), "Failed to fetch module assignment " +e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/getAll")
    public ApiResponse<?> getAllModules(){
        try{
            List<ModuleAssignmentDto> moduleAssignmentDtos =moduleAssignmentService.getAllModules();
            return new ApiResponse<>(moduleAssignmentDtos,"success",HttpStatus.OK);
        }catch (Exception e){
            log.error("error occurred in get all modules {}",e.getMessage());
            return new ApiResponse<>(e.getMessage(), "Failed to fetch module assignment " +e.getMessage(), HttpStatus.BAD_REQUEST);

        }
    }
}
