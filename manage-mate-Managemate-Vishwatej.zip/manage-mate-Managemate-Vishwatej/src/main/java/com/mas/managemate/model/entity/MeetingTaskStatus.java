package com.mas.managemate.model.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Entity
@Table(name = "task_status", schema = "managemate")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MeetingTaskStatus
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "markedBy")
    private String markedBy;

    @Column(name = "markedOn")
    private Date markedOn;

    @Column(name = "taskStatus")
    private String taskStatus;

    @ManyToOne(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
    @JoinColumn(name = "general_meeting_task_Id", referencedColumnName = "generalMeetingTaskId")
    private GeneralMeetingTasks taskId;
}
