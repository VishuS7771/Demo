package com.mas.managemate.model.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "general_meeting_status",schema = "managemate")
public class GeneralMeetingStatusMark {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long generalMeetingStatusId;

    private String status;

    private Date markedOn;

    private String markedBy;

    @ManyToOne
    @JoinColumn(name = "general_meeting_id",referencedColumnName = "id")
    private GeneralMeeting generalMeeting;
}
