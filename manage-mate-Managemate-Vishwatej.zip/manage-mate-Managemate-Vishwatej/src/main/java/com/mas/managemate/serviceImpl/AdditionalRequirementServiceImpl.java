package com.mas.managemate.serviceImpl;

import com.mas.managemate.model.dto.AdditionalRequirementDto;
import com.mas.managemate.model.entity.AdditionalRequirement;
import com.mas.managemate.model.mapper.TasksMapper;
import com.mas.managemate.repository.AdditionalRequirementRepository;
import com.mas.managemate.service.AdditionalRequirementService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Date;

@Service
@Slf4j
public class AdditionalRequirementServiceImpl implements AdditionalRequirementService {

    @Autowired
    private AdditionalRequirementRepository additionalRequirementRepository;

    @Autowired
    private TaskServiceImpl taskServiceImpl;

    @Autowired
    private TasksMapper tasksMapper;

    @Autowired
    private EmailService emailService;

    private static final String additionalRequirementPath="D:/UploadedFiles/Additional-Requirement";

    @Override
    public AdditionalRequirementDto create(AdditionalRequirementDto additionalRequirementDto, MultipartFile multipartFile) throws IOException {
        log.info("Adding additional requirement for task id {}",additionalRequirementDto.getTasksDto().getTaskId());
        AdditionalRequirement additionalRequirement =tasksMapper.mapToAdditionalRequirement(additionalRequirementDto);
        additionalRequirement.setDateAndTime(new Date());
        if(!additionalRequirementDto.getAttachment().isEmpty()){
            String attachmentPath=taskServiceImpl.saveFile(multipartFile, additionalRequirementDto.getTasksDto().getTaskName(),additionalRequirementPath);
            additionalRequirement.setAttachmentPath(attachmentPath);

        }
        additionalRequirement=additionalRequirementRepository.save(additionalRequirement);
        log.info("Added additional requirement for task id {}",additionalRequirementDto.getTasksDto().getTaskId());
        emailService.sendAdditionalRequirementEmail(additionalRequirement); // for send email
        return tasksMapper.mapToAdditionalRequirementDto(additionalRequirement);
    }
}
