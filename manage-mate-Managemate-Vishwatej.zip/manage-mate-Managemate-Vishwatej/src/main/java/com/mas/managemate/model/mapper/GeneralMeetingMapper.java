package com.mas.managemate.model.mapper;

import com.mas.managemate.model.dto.*;
import com.mas.managemate.model.entity.*;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import java.util.List;

@Mapper(componentModel = "spring")
public abstract class GeneralMeetingMapper {

    public abstract GeneralMeeting mapToGeneralMeeting(GeneralMeetingDto generalMeetingDto);

    public abstract GeneralMeetingDto mapToGeneralMeetingDto(GeneralMeeting generalMeeting);

    public abstract GeneralMeetingTasks fromGeneralMeetingTaskDto(GeneralMeetingTaskDto generalMeetingTaskDto);

    public abstract List<GeneralMeetingDto> mapToGeneralMeetingDtoList(List<GeneralMeeting> generalMeeting);

    @Mapping(target = "id", ignore = true)
    @Mapping(target ="createdBy",ignore = true )
    @Mapping(target = "createdOn",ignore = true)
    public abstract void updateMeeting(@MappingTarget GeneralMeeting existingMeeting,GeneralMeeting generalMeeting);

    @Mapping(target = "generalMeetingTaskId",ignore = true)
    @Mapping(target = "createdOn",ignore = true)
    @Mapping(target = "createdBy",ignore = true)
    public abstract void updateMeetingTask(@MappingTarget GeneralMeetingTasks existingMeetingTask,GeneralMeetingTasks generalMeetingTasks);

    public abstract List<GeneralMeetingTaskDto> fromGeneralMeetingTask(List<GeneralMeetingTasks> generalMeetingTasks);

    public abstract List<MeetingTaskAssigneeDto> fromMeetingTaskAssignee(List<MeetingTaskAssignee> meetingTaskAssignees);

    public abstract List<MeetingTaskAssignee> fromMeetingTaskAssigneeDto(List<MeetingTaskAssigneeDto> meetingTaskAssignees);

    public abstract TaskRespond fromTaskRespond(TaskRespondDto taskRespondDto);


    public abstract List<TaskRespondDto> fromTaskRespondAndMarking(List <TaskRespond> taskResponds );

    public abstract TaskRespondDto fromTaskRespondAndMarkingDto(TaskRespond taskResponds );

    public abstract GeneralMeetingStatusMarkDto toGeneralMeetingStatusMarkDto(GeneralMeetingStatusMark generalMeetingStatusMark);

    public abstract GeneralMeetingStatusMark toGeneralMeetingStatusMark(GeneralMeetingStatusMarkDto generalMeetingStatusMarkDto);

    public abstract GeneralMeetingTaskDto mapToDto(GeneralMeetingTasks generalMeetingTasks);

    public abstract MeetingParticipants mapToMeetingParticipants(MeetingParticipantsDto meetingParticipantsDto);

    public abstract MeetingParticipantsDto mapToMeetingParticipantsDto(MeetingParticipants meetingParticipants);


}
