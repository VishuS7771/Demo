package com.mas.managemate.repository;

import com.mas.managemate.model.entity.AdditionalRequirement;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@RequestMapping
public interface AdditionalRequirementRepository extends JpaRepository<AdditionalRequirement,Long> {

    @Query("SELECT ta FROM AdditionalRequirement ta WHERE ta.tasks.id IN :taskIds")
    List<AdditionalRequirement> findByTaskIds(@Param("taskIds") List<Long> taskIds);

}
