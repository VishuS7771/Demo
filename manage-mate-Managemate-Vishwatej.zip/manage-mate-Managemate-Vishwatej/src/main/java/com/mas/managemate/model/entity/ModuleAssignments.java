package com.mas.managemate.model.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;

@Entity
@Table(name = "ModuleAssignments", schema = "managemate")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ModuleAssignments {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "moduleMappingId")
    private long moduleMappingId;

    @Column(name = "module")
    private String module;

    @Column(name = "moduleId")
    private long moduleId;

    @Column(name = "employeeId")
    private long employeeId;

    @Column(name = "isActive")
    private int isActive;

    @Column(name = "createdBy")
    private long createdBy;

    @Column(name = "createdOn")
    private Date createdOn;

    @PrePersist
    public void setCreatedOn() {
        if (this.createdOn == null) {
            // Set current time in IST
            ZonedDateTime istNow = ZonedDateTime.now(ZoneId.of("Asia/Kolkata"));
            this.createdOn = Date.from(istNow.toInstant());
        }
    }
}
