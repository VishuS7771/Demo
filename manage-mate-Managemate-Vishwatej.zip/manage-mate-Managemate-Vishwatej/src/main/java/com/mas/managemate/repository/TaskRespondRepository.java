package com.mas.managemate.repository;

import com.mas.managemate.model.entity.TaskRespond;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TaskRespondRepository extends JpaRepository<TaskRespond,Long> {

    List<TaskRespond> findByGeneralMeetingTasks_GeneralMeetingTaskId(Long generalMeetingTaskId);

}
