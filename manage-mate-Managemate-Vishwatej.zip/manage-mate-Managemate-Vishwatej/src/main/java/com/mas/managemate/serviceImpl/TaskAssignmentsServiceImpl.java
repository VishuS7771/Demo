package com.mas.managemate.serviceImpl;

import com.mas.managemate.model.dto.EmployeeProfileResponse;
import com.mas.managemate.model.dto.TaskAssignmentDto;
import com.mas.managemate.model.dto.TasksDto;
import com.mas.managemate.model.entity.TaskAssignments;
import com.mas.managemate.model.entity.Tasks;
import com.mas.managemate.model.mapper.TasksMapper;
import com.mas.managemate.repository.TaskAssignmentsRepository;
import com.mas.managemate.service.TaskAssignmentsService;
import com.mas.managemate.util.ApiClient;
import com.mas.managemate.util.DateConverter;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class TaskAssignmentsServiceImpl implements TaskAssignmentsService {

    @Autowired
    private TaskAssignmentsRepository taskAssignmentsRepository;
    @Autowired
    private TasksMapper tasksMapper;

    @Autowired
    private  ApiClient apiClient;

    @Autowired
    private EmailService emailService;

    @Autowired
    private TaskServiceImpl taskServiceImpl;

    private static final String path="D:/UploadedFiles/assign_Attachments";

    @Override
    @Transactional
    public TaskAssignmentDto assignTask(TaskAssignmentDto taskAssignmentDto, MultipartFile multipartFile) throws IOException {
        String filePath = "";
        if(multipartFile != null){
            filePath=taskServiceImpl.saveFile(multipartFile,taskAssignmentDto.getTask().getTaskName()+"-"+taskAssignmentDto.getEmployeeId(),path);
        }
        TaskAssignments taskAssignments = tasksMapper.mapToTaskAssignments(taskAssignmentDto);
        taskAssignments.setAssignDate(new Date());
        taskAssignments.setAttachmentPath(filePath);
        taskAssignments.setIsAssigned(1);
        log.info("Before saving taskAssignments: {}", taskAssignments);
        TaskAssignments save = taskAssignmentsRepository.save(taskAssignments);
        log.info("After saving taskAssignments: {}", save);
        emailService.sendTaskAssignEmail(save);
        log.info("Task {} assigned to employee {} successfully ",taskAssignments.getTasks().getTaskName(),taskAssignments.getEmployeeId());
        return tasksMapper.mapToTaskAssignmentDto(save);
    }

    @Override
    public List<TaskAssignmentDto> getByTaskId(long taskId) throws Exception {
        List<TaskAssignments> assignments = taskAssignmentsRepository.findByTaskIds(List.of(taskId));

        Set<Long> employeeIds = assignments.stream()
                .map(TaskAssignments::getEmployeeId)
                .collect(Collectors.toSet());
        Set<Long> assignedByIds = assignments.stream()
                .map(TaskAssignments::getAssignedBy)
                .collect(Collectors.toSet());

        Map<Long, EmployeeProfileResponse> employeeProfiles = fetchProfiles(employeeIds);
        Map<Long, EmployeeProfileResponse> assignedByProfiles = fetchProfiles(assignedByIds);
        log.info("get task assignment by task Id {}",taskId);
        return assignments.stream()
                .map(taskAssignment -> {
                    EmployeeProfileResponse employeeProfile = employeeProfiles.get(taskAssignment.getEmployeeId());
                    EmployeeProfileResponse assignedByProfile = assignedByProfiles.get(taskAssignment.getAssignedBy());

                    if (employeeProfile == null || assignedByProfile == null) {
                        return null;
                    }
                    TaskAssignmentDto taskAssignmentDto = tasksMapper.mapToTaskAssignmentDto(taskAssignment);
                    taskAssignmentDto.setEmployeeNameAndId(
                            employeeProfile.getData().get(0).getEmployeeFullName());
                    taskAssignmentDto.setAssignedByNameAndId(
                            assignedByProfile.getData().get(0).getEmployeeFullName());

                    return taskAssignmentDto;
                })
                .filter(Objects::nonNull)
                .collect(Collectors.collectingAndThen(Collectors.toList(), list -> {
                    Collections.reverse(list);
                    return list;
                }));
    }

    @Override
    public List<TasksDto> getTaskListForMeeting(long empId) {
        List<TaskAssignments> taskAssignments=taskAssignmentsRepository.findByEmployeeId(empId);
        List<TaskAssignments> filteredAssignments = taskAssignments.stream()
                .filter(assignment -> assignment.getTasks().getParentTask() == null)
                .toList();

        log.info("get task for meetings by employee {}",empId);

         return filteredAssignments.stream()
                 .map(a -> tasksMapper.mapToTaskDto(a.getTasks()))
                 .filter(Objects::nonNull)
                 .distinct()
                 .toList();

    }

    public Map<Long, EmployeeProfileResponse> fetchProfiles(Set<Long> employeeIds) throws Exception {
        Map<Long, EmployeeProfileResponse> profilesMap = new HashMap<>();
        employeeIds.forEach(employeeId -> {
            try {
                profilesMap.put(employeeId, apiClient.getEmployeeProfile(String.valueOf(employeeId)));
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        return profilesMap;
    }

}
