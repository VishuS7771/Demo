package com.mas.managemate.controller;

import com.mas.managemate.model.dto.ApiResponse;
import com.mas.managemate.model.dto.CompletionDateUpdateRequestDto;
import com.mas.managemate.model.dto.GeneralMeetingTaskTimelineDto;
import com.mas.managemate.model.entity.GeneralMeetingTaskTimeline;
import com.mas.managemate.model.entity.GeneralMeetingTasks;
import com.mas.managemate.service.CompletionDateService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/completion-date")
@Slf4j
public class CompletionDateController {

    @Autowired
    CompletionDateService completionDateService;

    @PostMapping("/update")
    public ApiResponse<?> updateCompletionDate(@RequestBody CompletionDateUpdateRequestDto requestDto){

        try {
            completionDateService.updateCompletionDate(requestDto);
            return new ApiResponse<>(null, "Successfully Updated Completion Date", HttpStatus.OK);
        } catch (Exception e){
            return new ApiResponse<>(null, "Failed to Updated Completion Date", HttpStatus.BAD_REQUEST);
        }

    }

    @GetMapping("/task-timeline/{taskId}")
    public  ApiResponse<?> getGeneralMeetingTaskTimeline(@PathVariable Long taskId){
        try{
            List<GeneralMeetingTaskTimelineDto> generalMeetingTaskTimelineList = completionDateService.getGeneralMeetingTaskTimeline(taskId);
            return new ApiResponse<>(generalMeetingTaskTimelineList, "Data Fetched Successfully", HttpStatus.OK);
        }
        catch (Exception e){
            return new ApiResponse<>(null, "Failed to Fetch Data", HttpStatus.BAD_REQUEST);
        }
    }
}
