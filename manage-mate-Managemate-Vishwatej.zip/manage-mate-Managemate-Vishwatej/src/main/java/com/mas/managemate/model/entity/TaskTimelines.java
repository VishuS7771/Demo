package com.mas.managemate.model.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;

@Entity
@Table(name = "TaskTimelines", schema = "managemate")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TaskTimelines {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long taskTimeLineId;

    @ManyToOne
    @JoinColumn(name = "taskId")
    private Tasks tasks;

//    @ManyToOne
//    @JoinColumn(name = "assignId")
//    private TaskAssignments assignment;

    @Column(name = "dateAndTime")
    private Date dateAndTime;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "statusId")
    private StatusDefinitions status;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "subStatusId")
    private SubStatusDefinitions subStatus;

   @ManyToOne(fetch = FetchType.LAZY)
   @JoinColumn(name = "proprietorMappingId")
   private ProprietorAssignments proprietor;

   @Column(name = "markedBy")
   private long markedBy;

   @Column(name = "proprietorUserId")
   private long proprietorUserId;

    @PrePersist
    public void setCreatedOn() {
        ZonedDateTime istNow = ZonedDateTime.now(ZoneId.of("Asia/Kolkata"));
        this.dateAndTime = Date.from(istNow.toInstant());

    }

}
