package com.mas.managemate.serviceImpl;

import com.mas.managemate.model.dto.StatusDefinitionsDto;
import com.mas.managemate.model.entity.StatusDefinitions;
import com.mas.managemate.model.entity.TrayMaster;
import com.mas.managemate.model.mapper.StatusMapper;
import com.mas.managemate.repository.StatusDefinitionsRepository;
import com.mas.managemate.repository.TrayMasterRepository;
import com.mas.managemate.service.StatusDefinitionsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
public class StatusDefinitionsServiceImpl implements StatusDefinitionsService {

    @Autowired
    private StatusMapper statusMapper;

    @Autowired
    private StatusDefinitionsRepository statusDefinitionsRepository;

    @Autowired
    private TrayMasterRepository trayMasterRepository;

    @Override
    public StatusDefinitionsDto createStatusDefinitions(StatusDefinitionsDto statusDefinitionsDto) {
        StatusDefinitions statusDefinitions = statusMapper.mapToStatusDefinitions(statusDefinitionsDto);
        StatusDefinitions saveStatusDefinitions = statusDefinitionsRepository.save(statusDefinitions);
        log.info("creating status mapping successfully");
        return statusMapper.mapToStatusDefinitionsDto(saveStatusDefinitions);
    }

    @Override
    public List<StatusDefinitionsDto> getAllStatus() {
        List<StatusDefinitions> statusDefinitionsList = statusDefinitionsRepository.findAll();
        log.info("get all status mapping successfully");
        return statusDefinitionsList.stream().map(statusMapper::mapToStatusDefinitionsDto).collect(Collectors.toList());
    }

    @Override
    public StatusDefinitionsDto getStatusById(Long id) {
        StatusDefinitions statusDefinitions = statusDefinitionsRepository.findById(id).orElseThrow(() -> new RuntimeException("Status with ID " + id + " not found."));
        log.info("get status mapping successfully by Id {}",id);
        return statusMapper.mapToStatusDefinitionsDto(statusDefinitions);
    }

    @Override
    public StatusDefinitionsDto updateStatusDefinitions(Long id, StatusDefinitionsDto statusDefinitionsDto) {
        // Retrieve the existing record
        StatusDefinitions existingStatus = statusDefinitionsRepository.findById(id).orElseThrow(() -> new RuntimeException("Status with ID " + id + " not found."));
        StatusDefinitions updatedStatusDefinitions = statusMapper.mapToStatusDefinitions(statusDefinitionsDto);
        updatedStatusDefinitions.setStatusId(existingStatus.getStatusId());
        updatedStatusDefinitions.setCreatedOn(existingStatus.getCreatedOn());
        StatusDefinitions savedStatusDefinitions = statusDefinitionsRepository.save(updatedStatusDefinitions);
        log.info("updating status mapping by id {} successfully",id);
        return statusMapper.mapToStatusDefinitionsDto(savedStatusDefinitions);
    }

    @Override
    public List<StatusDefinitionsDto> getStatusByTray(String designation) {
        TrayMaster trayMaster =trayMasterRepository.findByTrayName(designation);
        if (trayMaster==null){
            throw new RuntimeException("tray not found");
        }
        List<StatusDefinitions> statusDefinitions=statusDefinitionsRepository.findByTrayId(trayMaster.getTrayId());
        log.info("get status mapping by tray {} successfully",trayMaster.getTrayName());
        return statusDefinitions.stream().map(a-> statusMapper.mapToStatusDefinitionsDto(a)).toList();
    }

}