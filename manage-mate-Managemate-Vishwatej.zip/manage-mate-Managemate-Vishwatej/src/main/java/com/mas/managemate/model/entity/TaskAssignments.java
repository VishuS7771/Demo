package com.mas.managemate.model.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;

@Entity
@Table(name = "TaskAssignments", schema = "managemate")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TaskAssignments {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "assignTaskId")
    private long assignTaskId;

    @ManyToOne
    @JoinColumn(name = "taskId")
    private Tasks tasks;

    @Column(name = "employeeId")
    private long employeeId;

    @Column(name = "assignDate")
    private Date assignDate;

    @Column(name = "remarks")
    private String remarks;

    @Column(name = "assignedBy")
    private long assignedBy;

    @Column(name = "isAssigned")
    private int isAssigned;

    @Column(name = "attachmentPath")
    private String attachmentPath;

    @PrePersist
    public void setCreatedOn() {
        ZonedDateTime istNow = ZonedDateTime.now(ZoneId.of("Asia/Kolkata"));
        this.assignDate = Date.from(istNow.toInstant());

    }
}
