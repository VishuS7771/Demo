package com.mas.managemate.model.constant;

public final class Constants {

    public static final String PENDING = "Pending";
    public static final String RE_SCHEDULE = "Re-Schedule";
    public static final String COMPLETED = "Completed";
    public static final String CANCELLED = "Cancelled";
}