package com.mas.managemate.model.mapper;

import com.mas.managemate.model.dto.MeetingParticipantsDto;
import com.mas.managemate.model.dto.MeetingsDto;
import com.mas.managemate.model.entity.MeetingParticipants;
import com.mas.managemate.model.entity.Meetings;
import lombok.extern.slf4j.Slf4j;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Slf4j
@Mapper(componentModel = "spring")
public abstract class MeetingMapper {

    /* This is below method using Meeting API */
    @Mapping(source = "tasksDto", target = "tasks")
    @Mapping(source = "meetingParticipantsDtoList", target = "meetingParticipants")
    public abstract Meetings mapToMeetings(MeetingsDto meetingsDto);

    @Mapping(source = "tasks", target = "tasksDto")
    @Mapping(source = "meetingParticipants", target = "meetingParticipantsDtoList")
    public abstract MeetingsDto mapToMeetingsDto(Meetings meetings);

    @Mapping(target = "meeting", ignore = true)
    public abstract MeetingParticipants mapToMeetingParticipants(MeetingParticipantsDto meetingParticipantsDto);

    @Mapping(target = "meetingsDto", ignore = true) // Ignore the nested meeting reference
    public abstract MeetingParticipantsDto mapToMeetingParticipantsDto(MeetingParticipants meetingParticipants);

}
