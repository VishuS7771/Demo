package com.mas.managemate.repository;

import com.mas.managemate.model.entity.StakeHolderMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface StakeHolderMasterRepository extends JpaRepository<StakeHolderMaster,Long>
{
    boolean existsByStakeHolderId(long stakeHolderId);
}
