package com.mas.managemate.component;

import com.mas.managemate.model.dto.EmployeeProfileResponse;
import com.mas.managemate.util.ApiClient;
import lombok.SneakyThrows;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Component;

@Component
public class CustomAuthenticationProvider implements AuthenticationProvider {

    private final ApiClient apiClient;

    public CustomAuthenticationProvider(ApiClient apiClient) {
        this.apiClient = apiClient;
    }


    @SneakyThrows
    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        String token = (String) authentication.getCredentials();

        String employeeNo = extractEmployeeNoFromToken(token);

        EmployeeProfileResponse response = apiClient.getEmployeeProfile(employeeNo);

        if (response == null || response.getData().isEmpty()) {
            throw new BadCredentialsException("Employee data not found for token");
        }

        if (!response.getData().get(0).getEmployeeNo().equals(employeeNo)) {
            throw new BadCredentialsException("Token employee number mismatch");
        }

        return new UsernamePasswordAuthenticationToken(
                employeeNo, null, null
        );
    }

    @Override
    public boolean supports(Class<?> authentication) {
        return UsernamePasswordAuthenticationToken.class.isAssignableFrom(authentication);
    }

    private String extractEmployeeNoFromToken(String token) {
        return JwtTokenProvider.getUserIdFromJWT(token);
    }
}
