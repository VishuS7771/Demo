package com.mas.managemate.controller;

import com.mas.managemate.model.dto.*;
import com.mas.managemate.model.entity.StakeHolderMaster;
import com.mas.managemate.service.MasterService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/master")
@Slf4j
public class MasterController {

    @Autowired
    private MasterService masterService;

    @GetMapping("/get-all-tray")
    public ApiResponse<?> getAllTray() {
        try {
            List<TrayResponse> allTrays = masterService.getAllTrays();
            return new ApiResponse<>(allTrays, "success", HttpStatus.OK);
        } catch (Exception e) {
            log.error("error occurred when tried get all tray {}", e.getMessage());
            return new ApiResponse<>(e.getMessage(), "failed", HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/get-users-by-tray/{tray}")
    public ApiResponse<?> getUsersByTray(@PathVariable String tray) {
        try {
            List<UserDataResponse> employeeData = masterService.getUsersByTray(tray);
            return new ApiResponse<>(employeeData, "success", HttpStatus.OK);
        } catch (Exception e) {
            log.error("error occurred in get user by tray {}", e.getMessage());
            return new ApiResponse<>(e.getMessage(), "failed to get user by tray " + e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/get-all-employees")
    public ApiResponse<?> getAllEmployees() {
        try {
            List<UserDataResponse> employees = masterService.getAllEmployees();
            return new ApiResponse<>(employees, "success", HttpStatus.OK);
        } catch (Exception e) {
            log.error("error occurred when get All employee {}", e.getMessage());
            return new ApiResponse<>(e.getMessage(), "failed to get all employees " + e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/get-module/{empId}")
    public ApiResponse<?> getModuleList(@PathVariable("empId") long empId) {
        try {
            List<ModuleResponseDto> moduleResponseDtos = masterService.getModuoleList(empId);
            return new ApiResponse<>(moduleResponseDtos, "success", HttpStatus.OK);
        } catch (Exception e) {
            log.error("error occurred in get module List {}", e.getMessage());
            return new ApiResponse<>(e.getMessage(), "failed to get modules " + e.getMessage(), HttpStatus.BAD_REQUEST);

        }
    }

    @GetMapping("/get-users-by-department/{taskId}")
    public ApiResponse<?> getUsersByDepartment(@PathVariable long taskId) {
        try {
            List<UserDataResponse> employeeData = masterService.getUsersByDepartment(taskId);
            return new ApiResponse<>(employeeData, "success", HttpStatus.OK);
        } catch (Exception e) {
            log.error("error occurred in get user by department {}", e.getMessage());
            return new ApiResponse<>(e.getMessage(), "failed to get employees by department " + e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/get-stakeholders")
    public ApiResponse<?> getStakeHolders() {
        try {
            List<StakeHolderMaster> stakeHolderMasters = masterService.getAllStakeHolders();
            return new ApiResponse<>(stakeHolderMasters, "get all stakeholder successfully", HttpStatus.OK);
        } catch (Exception e) {
            return new ApiResponse<>(e.getMessage(), "failed to get stakeholders ", HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/create-user")
    public ApiResponse<?> createStakeholderManagementUser(@RequestBody UserDto userDto) {
        try {
            UserDto savedUser = masterService.createStakeholderManagementUser(userDto);
            return new ApiResponse<>(savedUser, "User created successfully", HttpStatus.CREATED);
        } catch (IllegalArgumentException e) {
            log.warn("Duplicate entry attempt: {}", e.getMessage());
            return new ApiResponse<>(e.getMessage(), "Duplicate entry", HttpStatus.CONFLICT);
        } catch (Exception e) {
            log.error("Error occurred in create user: {}", e.getMessage());
            return new ApiResponse<>(e.getMessage(), "Failed to create user", HttpStatus.BAD_REQUEST);
        }
    }

    @DeleteMapping("/delete-user")
    public ApiResponse<?> deleteStakeholderManagementUser(@RequestBody UserDto userDto) {
        try {
            masterService.deleteStakeholderManagementUser(userDto);
            return new ApiResponse<>(null, "User deleted successfully", HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error occurred while deleting user: {}", e.getMessage());
            return new ApiResponse<>(e.getMessage(), "Failed to delete user", HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/get-all-users")
    public ApiResponse<?> getAllStakeholderManagementUser() {
        try {
            List<UserDto> users = masterService.getAllStakeholderManagementUser();
            return new ApiResponse<>(users, "Users fetched successfully", HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error occurred while fetching all users: {}", e.getMessage());
            return new ApiResponse<>(e.getMessage(), "Failed to fetch users", HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/check-user-exists/{userType}/{userId}")
    public ApiResponse<?> checkUserExistence(@PathVariable String userType, @PathVariable long userId) {
        try {
            // Call service method to check if the user exists
            Map<String, Boolean> exists = masterService.checkUserExistence(userType, userId);
            return new ApiResponse<>(exists, "User existence check successful", HttpStatus.OK);
        } catch (IllegalArgumentException e) {
            log.error("Invalid user type: {}", e.getMessage());
            return new ApiResponse<>(e.getMessage(), "Invalid user type", HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            log.error("Error occurred while checking user existence: {}", e.getMessage());
            return new ApiResponse<>(e.getMessage(), "Failed to check user existence", HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/download-file")
    public ResponseEntity<FileSystemResource> downloadFile(@RequestParam String filepath) {
        File file = new File(filepath);

        if (file.exists() && file.isFile()) {
            try {
                String mimeType = Files.probeContentType(Paths.get(filepath));

                if (mimeType == null) {
                    mimeType = "application/octet-stream";
                }
                FileSystemResource resource = new FileSystemResource(file);

                return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=\"" + file.getName() + "\"").contentType(MediaType.parseMediaType(mimeType))  // Set dynamic MIME type
                        .body(resource);
            } catch (IOException e) {
                log.error("error occurred in download file {}", e.getMessage());
                return ResponseEntity.status(500).body(null);
            }
        } else {
            return ResponseEntity.status(404).body(null);
        }
    }

    @GetMapping("/get-master/{param}")
    public ApiResponse<?> getMaster(@PathVariable String param,@RequestParam (name = "para2",required = false)List<String> para2){
        try{
            List<DepartmentDto> departmentDtos=masterService.getMasterData(param,para2);
            return new ApiResponse<>(departmentDtos, "get master successfully", HttpStatus.OK);
        }catch (Exception e){
            log.error("Failed get master: {}", e.getMessage());
            return new ApiResponse<>(e.getMessage(), "Failed get master", HttpStatus.BAD_REQUEST);
        }
    }

}
