package com.mas.managemate.controller;

import com.mas.managemate.model.dto.ApiResponse;
import com.mas.managemate.model.dto.TaskSearchCriteriaDto;
import com.mas.managemate.service.TaskSearchCriteriaService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/task-search-criteria")
@Slf4j
public class TaskSearchCriteriaController {

    @Autowired
    private TaskSearchCriteriaService taskSearchCriteriaService;

    @PostMapping("/create")
    public ApiResponse<?> createTaskCriteria(@RequestBody TaskSearchCriteriaDto searchCriteriaDto){
        try {
            searchCriteriaDto=taskSearchCriteriaService.create(searchCriteriaDto);
            return new ApiResponse<>(searchCriteriaDto,"create search criteria success",HttpStatus.OK);
        }catch (Exception e){
            log.error("failed to create search criteria {}",e.getMessage());
            return new ApiResponse<>(null,"failed to create search criteria "+e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/get-by-employee/{empId}")
    public ApiResponse<?> getByEmployee(@PathVariable long empId){
        try {
            TaskSearchCriteriaDto searchCriteriaDto=taskSearchCriteriaService.getByEmployee(empId);
            return new ApiResponse<>(searchCriteriaDto,"get search criteria by employee success",HttpStatus.OK);
        }catch (Exception e){
            log.error("failed to get search criteria by employees {}",e.getMessage());
            return new ApiResponse<>(null,"failed to get search criteria by employees "+e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
}
