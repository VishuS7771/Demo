package com.mas.managemate.repository;

import com.mas.managemate.model.entity.SubStatusDefinitions;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SubStatusDefinitionRepository extends JpaRepository<SubStatusDefinitions, Long> {
    List<SubStatusDefinitions> findByStatus_statusId(long subStatusId);
}
