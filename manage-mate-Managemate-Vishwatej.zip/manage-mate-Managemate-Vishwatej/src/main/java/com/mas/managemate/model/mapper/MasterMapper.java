package com.mas.managemate.model.mapper;


import com.mas.managemate.model.dto.TrayResponse;
import com.mas.managemate.model.entity.TrayMaster;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public abstract class MasterMapper {

    public abstract List<TrayResponse> mapToTrayMasterDto(List<TrayMaster> trayMaster);

}
