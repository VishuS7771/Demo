package com.mas.managemate.serviceImpl;

import com.mas.managemate.model.dto.*;
import com.mas.managemate.model.entity.ManagementUserMaster;
import com.mas.managemate.model.entity.StakeHolderMaster;
import com.mas.managemate.model.entity.TaskAssignments;
import com.mas.managemate.model.entity.TrayMaster;
import com.mas.managemate.model.mapper.MasterMapper;
import com.mas.managemate.repository.ManagementUserMasterRepository;
import com.mas.managemate.repository.StakeHolderMasterRepository;
import com.mas.managemate.repository.TaskAssignmentsRepository;
import com.mas.managemate.repository.TrayMasterRepository;
import com.mas.managemate.service.MasterService;
import com.mas.managemate.util.ApiClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class MasterServiceImpl implements MasterService {

    @Autowired
    private TrayMasterRepository trayMasterRepository;

    @Autowired
    private MasterMapper masterMapper;

    @Autowired
    private ApiClient apiClient;

    @Autowired
    private TaskAssignmentsRepository taskAssignmentsRepository;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private StakeHolderMasterRepository stakeHolderMasterRepository;

    @Autowired
    private ManagementUserMasterRepository managementUserMasterRepository;


    @Override
    public List<TrayResponse> getAllTrays() {
        List<TrayMaster> trayMasters = trayMasterRepository.findAll();
        return masterMapper.mapToTrayMasterDto(trayMasters);
    }

    @Override
    public List<UserDataResponse> getUsersByTray(String tray) throws Exception {
        log.info("fetching user for tray{}", tray);
        EmployeeProfileResponse employeeProfileResponse = apiClient.getAllEmployeeProfile();
        List<UserDataResponse> userDataResponses = new ArrayList<>();
        if (employeeProfileResponse.isResponse()) {
            List<EmployeeProfileResponse.EmployeeData> employeeData = employeeProfileResponse.getData();
            if ("BA Tray".equalsIgnoreCase(tray)) {
                userDataResponses = employeeData.stream().filter(a -> a.getDepartment().contains("Project Management")).map(employeeData2 -> UserDataResponse.builder().employeeName(employeeData2.getEmployeeName()).employeeId(employeeData2.getEmployeeNo()).build()).collect(Collectors.toList());
            } else if ("Developer Tray".equalsIgnoreCase(tray)) {
                userDataResponses = employeeData.stream().filter(a -> a.getDepartment().contains("Software Development")).map(employeeData2 -> UserDataResponse.builder().employeeName(employeeData2.getEmployeeName()).employeeId(employeeData2.getEmployeeNo()).build()).collect(Collectors.toList());
            } else if ("Legal".equalsIgnoreCase(tray)) {
                userDataResponses = employeeData.stream().filter(a -> a.getDepartment().contains("Legal")).map(employeeData2 -> UserDataResponse.builder().employeeName(employeeData2.getEmployeeName()).employeeId(employeeData2.getEmployeeNo()).build()).collect(Collectors.toList());
            } else if ("stakeHolder".equalsIgnoreCase(tray)) {
                List<StakeHolderMaster> stakeHolderMasters = stakeHolderMasterRepository.findAll();
                Set<Long> stakeHolderIds = stakeHolderMasters.stream().map(StakeHolderMaster::getStakeHolderId).collect(Collectors.toSet());
                userDataResponses = employeeData.stream().filter(employeeData2 -> stakeHolderIds.contains(Long.parseLong(employeeData2.getEmployeeNo()))).map(employeeData2 -> UserDataResponse.builder().employeeName(employeeData2.getEmployeeName()).employeeId(employeeData2.getEmployeeNo()).build()).collect(Collectors.toList());
            } else if ("Management".equalsIgnoreCase(tray)) {
                List<ManagementUserMaster> managementUserMasters = managementUserMasterRepository.findAll();
                Set<Long> managementUserIds = managementUserMasters.stream().map(ManagementUserMaster::getManagementUserId).collect(Collectors.toSet());
                userDataResponses = employeeData.stream().filter(employeeData2 -> managementUserIds.contains(Long.parseLong(employeeData2.getEmployeeNo()))).map(employeeData2 -> UserDataResponse.builder().employeeName(employeeData2.getEmployeeName()).employeeId(employeeData2.getEmployeeNo()).build()).collect(Collectors.toList());
            }
        }
        log.info("returning user for tray{}", tray);
        return userDataResponses;
    }

    @Override
    public List<ModuleResponseDto> getModuoleList(long empId) {
        log.info("fetching modules from CRM");
        List<Map<String, Object>> mapList = jdbcTemplate.queryForList("EXEC GetModuleData ?", empId);

        return mapList.stream().filter(a -> !a.get("ID").toString().equals("0")) // Exclude entries where ID is 0
                .map(a -> {
                    String id = a.get("ID").toString();
                    String moduleName = a.get("MODULE_NAME").toString();
                    return ModuleResponseDto.builder().id(Long.parseLong(id)).moduleName(moduleName).build();
                }).toList();

    }

    @Override
    public List<UserDataResponse> getUsersByDepartment(long taskId) throws Exception {
        log.info("Fetching users by department");
        List<TaskAssignments> assignments = taskAssignmentsRepository.findByTaskId(taskId);
        if (assignments.isEmpty()) {
            throw new RuntimeException("assignees not found for given task Id");
        }

        TaskAssignments taskAssignments = assignments.stream().max(Comparator.comparing(TaskAssignments::getAssignDate)).orElse(null);
        EmployeeProfileResponse employeeProfileResponse = apiClient.getAllEmployeeProfile();
        List<UserDataResponse> userDataResponses = List.of();
        if (employeeProfileResponse.isResponse()) {
            List<EmployeeProfileResponse.EmployeeData> employeeData = employeeProfileResponse.getData();

            EmployeeProfileResponse.EmployeeData employeeData1 = employeeData.stream().filter(a -> {
                if (a.getEmployeeNo() == null) return false;
                assert taskAssignments != null;
                return a.getEmployeeNo().equals(String.valueOf(taskAssignments.getEmployeeId()));
            }).findFirst().orElse(null);
            assert employeeData1 != null;
            if (employeeData1.getDepartment().equals("Operations -> Information Technology -> Information Technology")) {
                userDataResponses = employeeData.stream().filter(a -> a.getDepartment() != null && a.getDepartmentName().equals(employeeData1.getDepartmentName())).map(employeeData2 -> UserDataResponse.builder().employeeName(employeeData2.getEmployeeName()).employeeId(employeeData2.getEmployeeNo()).build()).toList();
            } else {
                userDataResponses = employeeData.stream().filter(a -> a.getDepartment() != null && a.getDepartment().equals(employeeData1.getDepartment())).map(employeeData2 -> UserDataResponse.builder().employeeName(employeeData2.getEmployeeName()).employeeId(employeeData2.getEmployeeNo()).build()).toList();
            }
        }
        return userDataResponses;
    }

    @Override
    public List<UserDataResponse> getAllEmployees() throws Exception {
        log.info("Fetching total active employees in mas");
        EmployeeProfileResponse employeeProfileResponse = apiClient.getAllEmployeeProfile();
        List<EmployeeProfileResponse.EmployeeData> employeeData = employeeProfileResponse.getData();
        List<UserDataResponse> userDataResponses = new ArrayList<>();
        return employeeData.stream().map(employee -> UserDataResponse.builder().employeeId(employee.getEmployeeNo()).employeeName(employee.getEmployeeName()).employeeFullName(employee.getEmployeeFullName()).designation(employee.getDesignation()).department(employee.getDepartment()).departmentName(employee.getDepartmentName()).build()).collect(Collectors.toList());
    }

    @Override
    public List<StakeHolderMaster> getAllStakeHolders() {
        return stakeHolderMasterRepository.findAll();
    }

    @Override
    public UserDto createStakeholderManagementUser(UserDto userDto) {
        if ("STAKEHOLDER".equalsIgnoreCase(userDto.getUserType())) {
            // Check if StakeHolder already exists
            if (stakeHolderMasterRepository.existsByStakeHolderId(userDto.getUserId())) {
                log.warn("Stakeholder with ID {} already exists", userDto.getUserId());
                throw new IllegalArgumentException("Stakeholder already exists with ID: " + userDto.getUserId());
            }

            // Save new StakeHolder
            StakeHolderMaster stakeHolderMaster = StakeHolderMaster.builder().stakeHolderId(userDto.getUserId()).build();
            stakeHolderMasterRepository.save(stakeHolderMaster);

            log.info("StakeHolderMaster saved with ID: {}", stakeHolderMaster.getId());
            return userDto;

        } else if ("MANAGEMENT-USER".equalsIgnoreCase(userDto.getUserType())) {
            // Check if Management User already exists
            if (managementUserMasterRepository.existsByManagementUserId(userDto.getUserId())) {
                log.warn("Management User with ID {} already exists", userDto.getUserId());
                throw new IllegalArgumentException("Management User already exists with ID: " + userDto.getUserId());
            }

            // Save new Management User
            ManagementUserMaster managementUserMaster = ManagementUserMaster.builder().managementUserId(userDto.getUserId()).build();
            managementUserMasterRepository.save(managementUserMaster);

            log.info("ManagementUserMaster saved with ID: {}", managementUserMaster.getId());
            return userDto;
        } else {
            throw new IllegalArgumentException("Invalid user type: " + userDto.getUserType());
        }
    }

    @Override
    public void deleteStakeholderManagementUser(UserDto userDto) {
        long id = userDto.getId();
        String userType = userDto.getUserType();

        log.info("Attempting to delete user with ID: {} and Type: {}", id, userType);

        if ("STAKEHOLDER".equalsIgnoreCase(userType)) {
            // Delete StakeHolderMaster by primary key id
            if (stakeHolderMasterRepository.existsById(id)) {
                stakeHolderMasterRepository.deleteById(id);
                log.info("StakeHolderMaster deleted with ID: {}", id);
            } else {
                log.error("StakeHolderMaster not found with ID: {}", id);
                throw new RuntimeException("Stakeholder not found with ID: " + id);
            }
        } else if ("MANAGEMENT-USER".equalsIgnoreCase(userType)) {
            // Delete ManagementUserMaster by primary key id
            if (managementUserMasterRepository.existsById(id)) {
                managementUserMasterRepository.deleteById(id);
                log.info("ManagementUserMaster deleted with ID: {}", id);
            } else {
                log.error("ManagementUserMaster not found with ID: {}", id);
                throw new RuntimeException("Management user not found with ID: " + id);
            }
        } else {
            log.error("Invalid user type: {}", userType);
            throw new IllegalArgumentException("Invalid user type: " + userType);
        }
    }

    @Override
    public List<UserDto> getAllStakeholderManagementUser() {
        log.info("Fetching all users...");
        List<StakeHolderMaster> stakeHolders = stakeHolderMasterRepository.findAll();
        List<UserDto> stakeHolderDtos = stakeHolders.stream().map(stakeHolder -> {
            try {
                return UserDto.builder().id(stakeHolder.getId()).userId(stakeHolder.getStakeHolderId()).userType("STAKEHOLDER").empName(String.valueOf(apiClient.getEmployeeProfile(String.valueOf(stakeHolder.getStakeHolderId())).getData().get(0).getEmployeeFullName())).build();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }).toList();

        List<ManagementUserMaster> managementUsers = managementUserMasterRepository.findAll();
        List<UserDto> managementUserDtos = managementUsers.stream().map(managementUser -> {
            try {
                return UserDto.builder().id(managementUser.getId()).userId(managementUser.getManagementUserId()).userType("MANAGEMENT_USER").empName(String.valueOf(apiClient.getEmployeeProfile(String.valueOf(managementUser.getManagementUserId())).getData().get(0).getEmployeeFullName())).build();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }).toList();
        List<UserDto> allUsers = new ArrayList<>();
        allUsers.addAll(stakeHolderDtos);
        allUsers.addAll(managementUserDtos);
        log.info("Total users fetched: {}", allUsers.size());
        return allUsers;
    }

    @Override
    public Map<String, Boolean> checkUserExistence(String userType, long userId) {
        boolean exists = false;

        if ("STAKEHOLDER".equalsIgnoreCase(userType)) {
            // Check if Stakeholder exists
            exists = stakeHolderMasterRepository.existsByStakeHolderId(userId);
        } else if ("MANAGEMENT-USER".equalsIgnoreCase(userType)) {
            // Check if Management User exists
            exists = managementUserMasterRepository.existsByManagementUserId(userId);
        } else {
            throw new IllegalArgumentException("Invalid user type: " + userType);
        }

        return Map.of("exists", exists);
    }

    @Override
    public List<DepartmentDto> getMasterData(String param,List<String> para2) throws Exception {
        List<DepartmentDto> departmentDtosList=new ArrayList<>();
        if(para2!=null){
            for(String para:para2){
                List<DepartmentDto> departmentDtos=apiClient.getMaster(param,para);
                departmentDtosList.addAll(departmentDtos);
            }
            return departmentDtosList;
        }else {
            return apiClient.getMaster(param,null);
        }

    }
}
