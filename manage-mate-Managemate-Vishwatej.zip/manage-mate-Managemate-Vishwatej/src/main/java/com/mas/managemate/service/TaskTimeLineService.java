package com.mas.managemate.service;

import com.mas.managemate.model.dto.TaskTimelineDto;

import java.util.List;

public interface TaskTimeLineService {
    List<TaskTimelineDto> getByTaskId(long taskId) throws Exception;

    void markStatus(long taskId, TaskTimelineDto taskTimelineDto);
}
