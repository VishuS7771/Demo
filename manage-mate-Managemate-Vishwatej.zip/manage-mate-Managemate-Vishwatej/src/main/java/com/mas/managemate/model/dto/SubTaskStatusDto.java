package com.mas.managemate.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SubTaskStatusDto {

    private long subTaskStatusMarkId;

    private String markedStatus;

    private long statusMarkedBy;

    private TasksDto tasksDto;

    private String remark;

    private Date statusMarkedDate;
}
