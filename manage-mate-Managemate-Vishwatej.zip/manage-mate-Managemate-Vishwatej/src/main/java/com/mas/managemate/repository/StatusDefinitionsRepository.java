package com.mas.managemate.repository;

import com.mas.managemate.model.entity.StatusDefinitions;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StatusDefinitionsRepository extends JpaRepository<StatusDefinitions,Long>{

    @Query("FROM StatusDefinitions s WHERE s.trayMaster.trayId = :trayId")
    List<StatusDefinitions> findByTrayId(@Param("trayId") Long trayId);

}
