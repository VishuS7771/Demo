package com.mas.managemate.service;

import com.mas.managemate.model.dto.TaskSearchCriteriaDto;

public interface TaskSearchCriteriaService {

    TaskSearchCriteriaDto create(TaskSearchCriteriaDto searchCriteriaDto);

    TaskSearchCriteriaDto getByEmployee(long empId);
}
