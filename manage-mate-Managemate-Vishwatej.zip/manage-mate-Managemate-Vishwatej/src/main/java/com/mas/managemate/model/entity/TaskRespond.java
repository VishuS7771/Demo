package com.mas.managemate.model.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "task_respond",schema = "managemate")
public class TaskRespond {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long taskRespondId;

    private String remark;

    private String respondedBy;

    private Date respondedOn;

    private String filePath;

    private boolean isMarking;

    private boolean isRespond;

    @ManyToOne
    @JoinColumn(name = "general_meeting_task_id")
    private GeneralMeetingTasks generalMeetingTasks;
}
