package com.mas.managemate.repository;

import com.mas.managemate.model.entity.GeneralMeetingTaskTimeline;
import com.mas.managemate.model.entity.GeneralMeetingTasks;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface GeneralMeetingTaskTimelineRepository extends JpaRepository<GeneralMeetingTaskTimeline, Long> {
    List<GeneralMeetingTaskTimeline> findByGeneralMeetingTasks_GeneralMeetingTaskId(Long id);

}