package com.mas.managemate.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class EmployeeProfileResponse {
    private String message;
    private boolean response;
    private List<EmployeeData> data;


    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class EmployeeData {
        @JsonProperty("EmployeeNo")
        private String employeeNo;

        @JsonProperty("EmployeeName")
        private String employeeName;

        @JsonProperty("EmployeeFullName")
        private String employeeFullName;

        @JsonProperty("DesignationId")
        private String designationId;

        @JsonProperty("Designation")
        private String designation;

        @JsonProperty("Company")
        private String company;

        @JsonProperty("DepartmentId")
        private String departmentId;

        @JsonProperty("DepartmentName")
        private String departmentName;

        @JsonProperty("Department")
        private String department;

        @JsonProperty("JoiningDate")
        private String joiningDate;

        @JsonProperty("BirthDate")
        private String birthDate;

        @JsonProperty("MobileNo1")
        private String mobileNo1;

        @JsonProperty("MobileNo2")
        private String mobileNo2;

        @JsonProperty("Gender")
        private String gender;

        @JsonProperty("CurrentAddress")
        private String currentAddress;

        @JsonProperty("PermentantAddress")
        private String permanentAddress;

        @JsonProperty("CompanyEmail")
        private String companyEmail;

        @JsonProperty("PersonalEmail")
        private String personalEmail;

        @JsonProperty("State")
        private String state;

        @JsonProperty("Branch")
        private String branch;

        @JsonProperty("Product")
        private String product;

        @JsonProperty("ReportingManager")
        private String reportingManager;

        @JsonProperty("Manager")
        private String manager;

        @JsonProperty("HRManager")
        private String hrManager;

        @JsonProperty("PayrollManager")
        private String payrollManager;

        @JsonProperty("ImageUrl")
        private String imageUrl;

        @JsonProperty("ReportingManagerEmail")
        private String reportingManagerEmail;

    }
}
