package com.mas.managemate.repository;

import com.mas.managemate.model.entity.GeneralMeetingTasks;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface GeneralMeetingTaskRepository extends JpaRepository<GeneralMeetingTasks,Long> {

    List<GeneralMeetingTasks> findByGeneralMeeting_Id(long meetingId);
    List<GeneralMeetingTasks> findByCreatedBy(String empId);

}
