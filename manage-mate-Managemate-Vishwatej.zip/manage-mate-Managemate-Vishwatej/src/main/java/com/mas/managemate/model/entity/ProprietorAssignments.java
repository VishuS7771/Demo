package com.mas.managemate.model.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;

@Entity
@Table(name = "ProprietorAssignments", schema = "managemate")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProprietorAssignments {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "proprietorMappingId")
    private long proprietorMappingId;

    @ManyToOne
    @JoinColumn(name = "statusId")
    private StatusDefinitions status;

    @ManyToOne
    @JoinColumn(name = "subStatusId")
    private SubStatusDefinitions subStatus;

    @ManyToOne
    @JoinColumn(name = "proprietorId")
    private ProprietorMaster proprietor;

    @ManyToOne
    @JoinColumn(name = "trayId")
    private TrayMaster tray;

    @Column(name = "isActive")
    private int isActive;

    @Column(name = "createdBy")
    private long createdBy;

    @Column(name = "createdOn")
    private Date createdOn;

    @PrePersist
    public void setCreatedOn() {
        if (this.createdOn == null) {
            // Set current time in IST
            ZonedDateTime istNow = ZonedDateTime.now(ZoneId.of("Asia/Kolkata"));
            this.createdOn = Date.from(istNow.toInstant());
        }
    }
}
