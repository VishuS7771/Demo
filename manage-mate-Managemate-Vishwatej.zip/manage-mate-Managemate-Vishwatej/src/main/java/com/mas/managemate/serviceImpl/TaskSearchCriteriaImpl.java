package com.mas.managemate.serviceImpl;

import com.mas.managemate.model.dto.TaskSearchCriteriaDto;
import com.mas.managemate.model.entity.TaskSearchCriteria;
import com.mas.managemate.model.mapper.TasksMapper;
import com.mas.managemate.repository.TaskSearchCriteriaRepository;
import com.mas.managemate.service.TaskSearchCriteriaService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Service
@Slf4j
public class TaskSearchCriteriaImpl implements TaskSearchCriteriaService {

    @Autowired
    private TaskSearchCriteriaRepository taskSearchCriteriaRepository;

    @Autowired
    private TasksMapper tasksMapper;

    @Override
    public TaskSearchCriteriaDto create(TaskSearchCriteriaDto searchCriteriaDto) {
        Optional<TaskSearchCriteria> taskSearchCriteria=taskSearchCriteriaRepository.findByEmployeeId(searchCriteriaDto.getEmployeeId());
        TaskSearchCriteria newCriteria=tasksMapper.mapToTaskSearchCriteria(searchCriteriaDto);
        String combinedStatus = searchCriteriaDto.getStatus() == null || searchCriteriaDto.getStatus().isEmpty()
                ? ""
                : String.join(", ", searchCriteriaDto.getStatus());
        String combinedSubStatus = searchCriteriaDto.getSubStatus() == null || searchCriteriaDto.getSubStatus().isEmpty()
                ? ""
                : String.join(", ", searchCriteriaDto.getSubStatus());
        TaskSearchCriteria searchCriteria= taskSearchCriteria.orElseGet(TaskSearchCriteria::new);
        searchCriteria.setTaskSearchCriteriaId(newCriteria.getTaskSearchCriteriaId());
        searchCriteria.setFromDate(newCriteria.getFromDate());
        searchCriteria.setToDate(newCriteria.getToDate());
        searchCriteria.setStatus(combinedStatus);
        searchCriteria.setSubStatus(combinedSubStatus);
        searchCriteria.setEmployeeId(newCriteria.getEmployeeId());
        searchCriteria=taskSearchCriteriaRepository.save(searchCriteria);
        log.info("task search criteria created successfully");
        return tasksMapper.mapToTaskSearchCriteriaDto(searchCriteria);
    }

    @Override
    public TaskSearchCriteriaDto getByEmployee(long empId) {
        Optional<TaskSearchCriteria> taskSearchCriteria=taskSearchCriteriaRepository.findByEmployeeId(empId);
        if(taskSearchCriteria.isPresent()){
            TaskSearchCriteriaDto taskSearchCriteriaDto=tasksMapper.mapToTaskSearchCriteriaDto(taskSearchCriteria.get());
            List<String> statusList = Arrays.asList(taskSearchCriteria.get().getStatus().split("\\s*,\\s*"));
            List<String> subStatusList = Arrays.asList(taskSearchCriteria.get().getSubStatus().split("\\s*,\\s*"));
            taskSearchCriteriaDto.setStatus(statusList);
            taskSearchCriteriaDto.setSubStatus(subStatusList);
            return taskSearchCriteriaDto;
        }
        log.info("get task search criteria for employee {} successfully",empId);
     return new TaskSearchCriteriaDto();
    }
}
