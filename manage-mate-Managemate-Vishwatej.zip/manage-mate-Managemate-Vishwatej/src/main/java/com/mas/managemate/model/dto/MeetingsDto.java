package com.mas.managemate.model.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MeetingsDto {
    private Long id;
    private String meetingId;
    private String meetingName;
    private String agenda;
    private List<Long> employeeId;
    private Date date;
    private String fromTime;
    private String toTime;
    private String location;
    private String link;
    private TasksDto tasksDto;
    private String remarks;
    private long createdBy;
    private String meetingStatus;
    private String reasonForCancellation;
    private String mom;
    private  String hostIdName;
    private String designation;
    private String departmentName;
    private List<MeetingParticipantsDto> meetingParticipantsDtoList;
    @JsonFormat(pattern = "yyyy-dd-MM HH:mm:ss", timezone = "Asia/Kolkata")
    private Date createdOn;

}
