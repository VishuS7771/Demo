package com.mas.managemate.model.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;



@Entity
@Table(name = "task_search_criteria",schema = "managemate")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TaskSearchCriteria {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long taskSearchCriteriaId;

    private String fromDate;

    private String toDate;

    private String status;

    private String subStatus;

    private long employeeId;
}
