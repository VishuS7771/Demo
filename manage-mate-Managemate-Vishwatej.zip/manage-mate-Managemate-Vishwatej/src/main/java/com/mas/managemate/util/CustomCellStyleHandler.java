package com.mas.managemate.util;

import com.alibaba.excel.metadata.Head;
import com.alibaba.excel.write.handler.context.CellWriteHandlerContext;
import com.alibaba.excel.write.style.AbstractCellStyleStrategy;
import org.apache.poi.ss.usermodel.*;

public class CustomCellStyleHandler extends AbstractCellStyleStrategy {

    @Override
    public void afterCellCreate(CellWriteHandlerContext context) {
        // Apply bold style to the first row (header row)
        if (context.getRowIndex() == 0) {
            Cell cell = context.getCell();
            applyHeaderStyle(cell);
        } else {
            Cell cell = context.getCell();
            applyContentCellStyle(cell);
        }
    }

    @Override
    public void afterCellDispose(CellWriteHandlerContext context) {
        // Optional: Any cleanup or other post-processing logic if needed
    }

    @Override
    protected void setHeadCellStyle(Cell cell, Head head, Integer relativeRowIndex) {
        applyHeaderStyle(cell);
    }

    @Override
    protected void setContentCellStyle(Cell cell, Head head, Integer relativeRowIndex) {
        applyContentCellStyle(cell);
    }

    private void applyHeaderStyle(Cell cell) {
        Workbook workbook = cell.getSheet().getWorkbook();
        CellStyle cellStyle = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setBold(true); // Set font to bold
        cellStyle.setFont(font);

        // Set background color to gray
        cellStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        applyBorders(cellStyle);
        cell.setCellStyle(cellStyle);
    }

    private void applyContentCellStyle(Cell cell) {
        Workbook workbook = cell.getSheet().getWorkbook();
        CellStyle cellStyle = workbook.createCellStyle();
        applyBorders(cellStyle);
        cell.setCellStyle(cellStyle);
    }

    private void applyBorders(CellStyle cellStyle) {
        cellStyle.setBorderTop(BorderStyle.THIN);
        cellStyle.setBorderBottom(BorderStyle.THIN);
        cellStyle.setBorderLeft(BorderStyle.THIN);
        cellStyle.setBorderRight(BorderStyle.THIN);
    }
}

