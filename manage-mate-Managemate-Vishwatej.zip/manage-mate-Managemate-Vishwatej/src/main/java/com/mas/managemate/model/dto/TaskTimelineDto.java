package com.mas.managemate.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TaskTimelineDto {

    private long taskTimeLineId;

    private TasksDto tasks;

//    private TaskAssignmentDto assignment;

    private Date dateAndTime;

    private StatusDefinitionsDto statusDefinitionsDto;

    private SubStatusDefinitionsDto subStatusDefinitionsDto;

    private ProprietorAssignmentsDto proprietorAssignmentsDto;

    private String statusMarkedBy;

    private long proprietorUserId;

}
