package com.mas.managemate.service;

import com.mas.managemate.exception.NotFoundException;
import com.mas.managemate.model.dto.ProprietorAssignmentsDto;
import com.mas.managemate.model.dto.ProprietorMasterDto;

import java.util.List;

public interface ProprietorService {

    ProprietorAssignmentsDto createProprietorAssignment(ProprietorAssignmentsDto proprietorAssignmentsDto);

    List<ProprietorAssignmentsDto> getAllProprietor();

    ProprietorAssignmentsDto getProprietorAssignmentById(long proprietorMappingId) throws NotFoundException;

    ProprietorAssignmentsDto updateProprietorAssignment(long id, ProprietorAssignmentsDto proprietorAssignmentsDto)throws NotFoundException ;

    List<ProprietorAssignmentsDto> getProprietors(long statusId, long subStatusId);

    List<ProprietorMasterDto> getAllProprietorMaster();
}
