package com.mas.managemate.service;

import com.mas.managemate.model.dto.*;
import com.mas.managemate.model.entity.StakeHolderMaster;

import java.util.List;
import java.util.Map;

public interface MasterService {

    List<TrayResponse> getAllTrays();

    List<UserDataResponse> getUsersByTray(String tray) throws Exception;

    List<ModuleResponseDto> getModuoleList(long empId);

    List<UserDataResponse> getUsersByDepartment(long taskId) throws Exception;

    List<UserDataResponse> getAllEmployees() throws Exception;

    List<StakeHolderMaster> getAllStakeHolders();

    UserDto createStakeholderManagementUser(UserDto userDto);

    void deleteStakeholderManagementUser(UserDto userDto);

    List<UserDto> getAllStakeholderManagementUser();

    Map<String, Boolean> checkUserExistence(String userType, long userId);

    List<DepartmentDto> getMasterData(String Param,List<String> para2) throws Exception;
}
