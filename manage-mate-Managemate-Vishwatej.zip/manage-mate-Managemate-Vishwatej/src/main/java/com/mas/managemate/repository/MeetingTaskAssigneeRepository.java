package com.mas.managemate.repository;

import com.mas.managemate.model.entity.MeetingTaskAssignee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MeetingTaskAssigneeRepository extends JpaRepository<MeetingTaskAssignee,Long> {

    List<MeetingTaskAssignee> findByGeneralMeetingTasks_GeneralMeetingTaskId(Long id);
    List<MeetingTaskAssignee> findByEmpId(Long id);



}
