package com.mas.managemate.model.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Entity
@Table(name = "subStatusMark",schema = "managemate")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SubTaskStatusMark {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long subTaskStatusMarkId;

    private String markedStatus;

    private Date statusMarkedDate;

    private long statusMarkedBy;

    @ManyToOne
    @JoinColumn(name = "taskId")
    private Tasks tasks;

    private String remark;

}
