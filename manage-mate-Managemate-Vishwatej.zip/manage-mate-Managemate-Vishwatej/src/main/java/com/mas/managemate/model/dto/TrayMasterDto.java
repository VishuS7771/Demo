package com.mas.managemate.model.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.persistence.Column;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TrayMasterDto {

    private long trayId;

    private String trayName;

    private int isActive;

    private long createdBy;

    private Date createdOn;
}
