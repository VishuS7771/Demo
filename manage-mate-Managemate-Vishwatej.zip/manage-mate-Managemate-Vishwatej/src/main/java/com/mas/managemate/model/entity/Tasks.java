package com.mas.managemate.model.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;

@Entity
@Table(name = "Tasks", schema = "managemate")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Tasks {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "task_seq_gen")
    @SequenceGenerator(name = "task_seq_gen", sequenceName = "task_seq", allocationSize = 1)
    private Long id;

    @Column(name = "TaskId", nullable = false, unique = true)
    private String taskId;

    @Column(name = "taskName")
    private String taskName;

    @Column(name = "DateandTime")
    private Date dateAndTime;

    @Column(name = "EmployeeId")
    private long employeeId;

    @Column(name = "DesignationId")
    private long designationId;

    @Column(name = "DepartmentId")
    private long departmentId;

    @Column(name = "MobileNo")
    private String mobileNo;

    @Column(name = "EmailId")
    private String emailId;

    @Column(name = "RequirementType")
    private String requirementType;

    @Column(name = "ModuleId")
    private long moduleId;

    @Column(name = "moduleName")
    private String moduleName;

    @Column(name = "RequirementSubject")
    private String requirementSubject;

    @Column(name = "RequirementinDetail", length = 10000)
    private String requirementInDetail;

    @Column(name = "platform")
    private String platform;

    @Column(name = "taskPriority")
    private String taskPriority;

    @Column(name = "attachmentPath",length = 1000)
    private String attachmentPath;

    @Column(name = "description",length =5000)
    private String description;

    @ManyToOne(fetch = FetchType.EAGER,cascade = CascadeType.ALL)
    @JoinColumn(name = "parentTaskId", nullable = true)
    @ToString.Exclude
    private Tasks parentTask;

    @Column(name = "raisedBy")
    private long raisedBy;

    @Column(name = "startDate")
    private Date startDate;

    @Column(name = "endDate")
    private Date endDate;

    @Column(name = "tentativeEndDate")
    private Date tentativeEndDate;

    @Column(name = "delayInDays")
    private int delayInDays;

    @Column(name = "remarks")
    private String remarks;


    @PrePersist
    public void setCreatedOn() {
            ZonedDateTime istNow = ZonedDateTime.now(ZoneId.of("Asia/Kolkata"));
            this.startDate = Date.from(istNow.toInstant());
            this.endDate = Date.from(istNow.toInstant());
            this.tentativeEndDate =Date.from(istNow.toInstant());
            this.dateAndTime=Date.from(istNow.toInstant());
            if(parentTask==null){
                this.taskId = "PROJECT" + id;
            }else {
                this.taskId = "SUB-TASK" + id;

            }
    }

}
