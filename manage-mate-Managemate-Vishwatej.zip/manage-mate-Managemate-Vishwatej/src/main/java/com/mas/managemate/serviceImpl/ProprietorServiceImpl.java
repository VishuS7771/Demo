package com.mas.managemate.serviceImpl;

import com.mas.managemate.exception.NotFoundException;
import com.mas.managemate.model.dto.ProprietorAssignmentsDto;
import com.mas.managemate.model.dto.ProprietorMasterDto;
import com.mas.managemate.model.entity.ProprietorAssignments;
import com.mas.managemate.model.entity.ProprietorMaster;
import com.mas.managemate.model.mapper.ProprietorMapper;
import com.mas.managemate.repository.ProprietorAssignmentsRepository;
import com.mas.managemate.repository.ProprietorMasterRepository;
import com.mas.managemate.service.ProprietorService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Slf4j
public class ProprietorServiceImpl implements ProprietorService {

    @Autowired
    private ProprietorMapper proprietorMapper;

    @Autowired
    private ProprietorAssignmentsRepository proprietorAssignmentsRepository;

    @Autowired
    private ProprietorMasterRepository proprietorMasterRepository;

    @Override
    public ProprietorAssignmentsDto createProprietorAssignment(ProprietorAssignmentsDto proprietorAssignmentsDto) {
        ProprietorAssignments proprietorAssignment = proprietorMapper.mapToProprietorAssignment(proprietorAssignmentsDto);
        ProprietorAssignments saveProprietorAssignment = proprietorAssignmentsRepository.save(proprietorAssignment);
        log.info("proprietor assignment created successful");
        return proprietorMapper.mapToProprietorAssignmentsDto(saveProprietorAssignment);
    }

    @Override
    public List<ProprietorAssignmentsDto> getAllProprietor() {
        List<ProprietorAssignments> proprietorAssignmentsList = proprietorAssignmentsRepository.findAll();
        log.info("get all proprietor assignment successful");
        return proprietorAssignmentsList.stream().map(proprietorMapper::mapToProprietorAssignmentsDto).collect(Collectors.toList());
    }

    @Override
    public ProprietorAssignmentsDto getProprietorAssignmentById(long proprietorMappingId) throws NotFoundException {
        log.info("get proprietor assignment by Id {} successful",proprietorMappingId);
        Optional<ProprietorAssignments> proprietorAssignments = proprietorAssignmentsRepository.findById(proprietorMappingId);
        if (proprietorAssignments.isPresent()) {
            return proprietorMapper.mapToProprietorAssignmentsDto(proprietorAssignments.get());
        } else {
            throw new NotFoundException("ProprietorAssignment not found for id: " + proprietorMappingId);
        }
    }

    @Override
    public ProprietorAssignmentsDto updateProprietorAssignment(long id, ProprietorAssignmentsDto proprietorAssignmentsDto) throws NotFoundException {
        ProprietorAssignments existingProprietorAssignment = proprietorAssignmentsRepository.findById(id).orElseThrow(() -> new NotFoundException("ProprietorAssignment not found with id: " + id));
        ProprietorAssignments updatedProprietorAssignment = proprietorMapper.mapToProprietorAssignment(proprietorAssignmentsDto);
        updatedProprietorAssignment.setProprietorMappingId(existingProprietorAssignment.getProprietorMappingId());
        updatedProprietorAssignment.setCreatedOn(existingProprietorAssignment.getCreatedOn());
        ProprietorAssignments savedProprietorAssignment = proprietorAssignmentsRepository.save(updatedProprietorAssignment);
        log.info("updating  proprietor assignment by Id {} successful",id);
        return proprietorMapper.mapToProprietorAssignmentsDto(savedProprietorAssignment);
    }

    @Override
    public List<ProprietorAssignmentsDto> getProprietors(long statusId, long subStatusId) {
         List<ProprietorAssignments> proprietorAssignments=proprietorAssignmentsRepository.findByStatus_statusIdAndSubStatus_subStatusId(statusId,subStatusId);
        log.info("get  proprietor assignment by status and sub status successful");
        return proprietorAssignments.stream()
                .map(a->proprietorMapper.mapToProprietorAssignmentsDto(a))  // Map each Proprietor to ProprietorAssignmentsDto
                .toList();
    }

    @Override
    public List<ProprietorMasterDto> getAllProprietorMaster() {
        List<ProprietorMaster> proprietorMasters = proprietorMasterRepository.findAll();
        log.info("get All proprietor assignment successful");
        return proprietorMapper.mapToProprietorMaster(proprietorMasters);
    }
}