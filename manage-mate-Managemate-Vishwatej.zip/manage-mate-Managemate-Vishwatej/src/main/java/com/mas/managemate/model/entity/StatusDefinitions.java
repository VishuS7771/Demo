package com.mas.managemate.model.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;

@Entity
@Table(name = "StatusDefinitions", schema = "managemate")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class StatusDefinitions {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "statusId")
    private long statusId;

    @Column(name = "status")
    private String status;

    @Column(name = "createdBy")
    private long createdBy;

    @ManyToOne
    @JoinColumn(name = "tray_master_id")
    private TrayMaster trayMaster;

    @Column(name = "createdOn")
    private Date createdOn;

    @Column(name = "isActive")
    private int isActive;

    @PrePersist
    public void setCreatedOn() {
        if (this.createdOn == null) {
            // Set current time in IST
            ZonedDateTime istNow = ZonedDateTime.now(ZoneId.of("Asia/Kolkata"));
            this.createdOn = Date.from(istNow.toInstant());
        }
    }
}
