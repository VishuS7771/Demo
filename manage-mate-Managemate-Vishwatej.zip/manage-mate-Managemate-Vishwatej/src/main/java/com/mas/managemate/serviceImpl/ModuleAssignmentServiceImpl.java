package com.mas.managemate.serviceImpl;

import com.mas.managemate.exception.ResourceNotFoundException;
import com.mas.managemate.model.dto.EmployeeProfileResponse;
import com.mas.managemate.model.dto.ModuleAssignmentDto;
import com.mas.managemate.model.entity.ModuleAssignments;
import com.mas.managemate.model.mapper.ModuleMapper;
import com.mas.managemate.repository.ModuleAssignmentRepository;
import com.mas.managemate.service.ModuleAssignmentService;
import com.mas.managemate.util.ApiClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Slf4j
public class ModuleAssignmentServiceImpl implements ModuleAssignmentService {

    @Autowired
    private ModuleMapper moduleMapper;

    @Autowired
    private ModuleAssignmentRepository moduleAssignmentRepository;

    @Autowired
    private ApiClient apiClient;


    @Override
    public ModuleAssignmentDto createModuleAssignment(ModuleAssignmentDto moduleAssignmentDto) {
        Optional<ModuleAssignments> moduleAssignmentsOptional=  moduleAssignmentRepository.findByModule(moduleAssignmentDto.getModule());
        if (moduleAssignmentsOptional.isPresent()){
            throw new RuntimeException("module is already assigned");
        }
        ModuleAssignments moduleAssignments = moduleMapper.mapToModuleAssignments(moduleAssignmentDto);
        ModuleAssignments saveModuleAssignments = moduleAssignmentRepository.save(moduleAssignments);
        log.info("module assignments created successful");
        return moduleMapper.mapToModuleAssignmentDto(saveModuleAssignments);
    }

    @Override
    public ModuleAssignmentDto updateModuleAssignment(long moduleMappingId, ModuleAssignmentDto moduleAssignmentDto) {
        ModuleAssignments existingModuleAssignment = moduleAssignmentRepository.findById(moduleMappingId)
                .orElseThrow(() -> new ResourceNotFoundException(HttpStatus.NOT_FOUND,
                        "Module assignment not found with id: " + moduleMappingId));
        ModuleAssignments updatedModuleAssignment = moduleMapper.mapToModuleAssignments(moduleAssignmentDto);
        updatedModuleAssignment.setModuleMappingId(existingModuleAssignment.getModuleMappingId());
        updatedModuleAssignment.setCreatedOn(existingModuleAssignment.getCreatedOn());
        ModuleAssignments savedModuleAssignment = moduleAssignmentRepository.save(updatedModuleAssignment);
        log.info("module assignments updated successful");
        return moduleMapper.mapToModuleAssignmentDto(savedModuleAssignment);
    }

    @Override
    public List<ModuleAssignmentDto> getAllModules() {
      List<ModuleAssignments> moduleAssignments=moduleAssignmentRepository.findAll();
      List<ModuleAssignmentDto> moduleAssignmentDtos=moduleAssignments.stream().map(moduleMapper::mapToModuleAssignmentDto).toList();
        moduleAssignmentDtos = moduleAssignmentDtos.stream()
                .map(module -> {
                    try {
                        EmployeeProfileResponse employeeProfile = apiClient.getEmployeeProfile(String.valueOf(module.getEmployeeId()));
                        if (employeeProfile.isResponse() && employeeProfile.getData() != null && !employeeProfile.getData().isEmpty()) {
                            module.setMappedEmployee(employeeProfile.getData().get(0).getEmployeeFullName());
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    return module;
                })
                .collect(Collectors.toList());
        log.info("get all module assignments successful");
      return moduleAssignmentDtos;

    }

    @Override
    public ModuleAssignmentDto findByModuleName(String moduleName) {
        Optional<ModuleAssignments> moduleAssignments = moduleAssignmentRepository.findByModule(moduleName);
        log.info("get module assignments by module name {} successful",moduleName);
        return moduleAssignments.map(moduleMapper::mapToModuleAssignmentDto).orElse(null);
    }

}
