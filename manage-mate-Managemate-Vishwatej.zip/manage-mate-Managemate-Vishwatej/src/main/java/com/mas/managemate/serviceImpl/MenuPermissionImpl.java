package com.mas.managemate.serviceImpl;

import com.mas.managemate.model.entity.MenuPermission;
import com.mas.managemate.model.entity.MenuPermissionAccess;
import com.mas.managemate.repository.MenuPermissionAccessRepository;
import com.mas.managemate.repository.MenuPermissionRepository;
import com.mas.managemate.service.MenuPermissionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@Slf4j
public class MenuPermissionImpl implements MenuPermissionService {

    @Autowired
    private MenuPermissionRepository menuPermissionRepository;

    @Autowired
    private MenuPermissionAccessRepository menuPermissionAccessRepository;


    @Override
    public MenuPermission addMenuPermission(MenuPermission menuPermission) {
        log.info("adding menu permission for employee {}",menuPermission.getEmployeeId());
        Optional<MenuPermission> menuPermission1=menuPermissionRepository.findByEmployeeId(menuPermission.getEmployeeId());
        MenuPermission permission= menuPermission1.orElseGet(MenuPermission::new);
        permission.setEmployeeId(menuPermission.getEmployeeId());
        permission.setMenuPermissionId(menuPermission.getMenuPermissionId());
        permission.setTask(menuPermission.isTask());
        permission.setDashboard(menuPermission.isDashboard());
        permission.setAssign(menuPermission.isAssign());
        permission.setUser(menuPermission.isUser());
        permission.setProprietor(menuPermission.isProprietor());
        permission.setStatus(menuPermission.isStatus());
        permission.setSubStatus(menuPermission.isSubStatus());
        permission.setModule(menuPermission.isModule());
        permission.setProject(menuPermission.isProject());
        permission.setReport(menuPermission.isReport());
        permission.setGeneralMeeting(menuPermission.isGeneralMeeting());
        permission=menuPermissionRepository.save(permission);
        log.info("added menu permission for employee {}",menuPermission.getEmployeeId());
       return permission;
    }


    @Override
    public MenuPermission getMenuPermission(long empId) {
        Optional<MenuPermission> menuPermission1=menuPermissionRepository.findByEmployeeId(empId);
        return menuPermission1.orElseGet(MenuPermission::new);
    }

    @Override
    public List<MenuPermissionAccess> getMenuPermissionAccess() {
        return menuPermissionAccessRepository.findAll();
    }
}
