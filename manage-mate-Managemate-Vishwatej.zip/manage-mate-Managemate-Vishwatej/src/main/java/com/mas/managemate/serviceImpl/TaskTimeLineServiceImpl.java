package com.mas.managemate.serviceImpl;

import com.mas.managemate.model.dto.EmployeeProfileResponse;
import com.mas.managemate.model.dto.TaskTimelineDto;
import com.mas.managemate.model.entity.TaskTimelines;
import com.mas.managemate.model.mapper.TasksMapper;
import com.mas.managemate.repository.TaskTimeLinesRepository;
import com.mas.managemate.service.TaskTimeLineService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@Slf4j
public class TaskTimeLineServiceImpl implements TaskTimeLineService {

    @Autowired
    private TaskTimeLinesRepository taskTimeLinesRepository;

    @Autowired
    private TasksMapper tasksMapper;

    @Autowired
    private TaskAssignmentsServiceImpl taskAssignmentsService;

    @Autowired
    private EmailService emailService;

    @Override
    public List<TaskTimelineDto> getByTaskId(long taskId) throws Exception {
        List<TaskTimelines> taskTimelines =taskTimeLinesRepository.findByTaskIds(List.of(taskId));
        taskTimelines.sort(Comparator.comparing(TaskTimelines::getTaskTimeLineId).reversed());
        List<TaskTimelineDto> timelineDtos=new ArrayList<>();
        for(TaskTimelines taskTimelines1:taskTimelines){
            TaskTimelineDto taskTimelineDto=tasksMapper.mapToTaskTimeLineDto(taskTimelines1);
            Map<Long, EmployeeProfileResponse> fetchProfiles= taskAssignmentsService.fetchProfiles(Collections.singleton(taskTimelines1.getMarkedBy()));
            EmployeeProfileResponse employeeProfile = fetchProfiles.get(taskTimelines1.getMarkedBy());
            taskTimelineDto.setStatusMarkedBy( employeeProfile.getData().get(0).getEmployeeFullName());
            timelineDtos.add(taskTimelineDto);
        }
        log.info("Fetching task timeline for task Id {}",taskId);
        return timelineDtos;
    }

    @Override
    public void markStatus(long taskId, TaskTimelineDto taskTimelineDto) {
        TaskTimelines mapToTaskTimelines=tasksMapper.mapToTaskTimelines(taskTimelineDto);
        mapToTaskTimelines.setMarkedBy(Long.parseLong(taskTimelineDto.getStatusMarkedBy()));
        taskTimeLinesRepository.save(mapToTaskTimelines);
        emailService.sendTaskStatusMarkedEmail(mapToTaskTimelines); // for send email
        log.info("status marking for task Id {} successfully",taskId);
    }
}
