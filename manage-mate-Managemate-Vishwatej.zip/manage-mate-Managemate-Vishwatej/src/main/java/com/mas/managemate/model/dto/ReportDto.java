package com.mas.managemate.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ReportDto {

    private String reportType;

    private String taskId;

    private List<Long> statusId;

    private List<Long> subStatusId;

    private Date fromDate;

    private Date toDate;

}
