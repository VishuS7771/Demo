package com.mas.managemate.model.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "file_save_path",schema = "managemate")
public class FileSavePath {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    private String path;

    private Date createdOn;

    private boolean isStatusMark;

    @ManyToOne
    @JoinColumn(name = "general_meeting_id",referencedColumnName = "id")
    private GeneralMeeting generalMeeting;

    @ManyToOne
    @JoinColumn(name = "meeting_status_mark_id")
    private GeneralMeetingStatusMark generalMeetingStatusMark;
}
