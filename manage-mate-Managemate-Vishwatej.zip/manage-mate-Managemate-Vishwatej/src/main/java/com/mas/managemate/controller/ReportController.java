package com.mas.managemate.controller;


import com.mas.managemate.model.dto.GeneralMeetingReportDTO;
import com.mas.managemate.model.dto.ReportDto;
import com.mas.managemate.service.GeneralMeetingRepostService;
import com.mas.managemate.service.ReportService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


@RestController
@RequestMapping("/report")
@Slf4j
public class ReportController {


    @Autowired
    private ReportService reportService;

    @Autowired
    private GeneralMeetingRepostService generalMeetingRepostService;

    @PostMapping("/download-report")
    public ResponseEntity<FileSystemResource> downloadFile(@RequestBody ReportDto reportDto) throws Exception {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss");
        String formattedTime = LocalDateTime.now().format(formatter);
        String directoryPath = "D:\\UploadedFiles" + "\\reports\\" + reportDto.getTaskId() + "\\" + formattedTime;
        String filePath = directoryPath + "\\Project_Tracker.xlsx";

        try {
            File dir = new File(directoryPath);
            if (!dir.exists()) {
                dir.mkdirs(); // Create directory if it doesn't exist
            }

            reportService.generateExcel(reportDto, directoryPath);

            File file = new File(filePath);
            if (!file.exists()) {
                throw new RuntimeException("Excel file generation failed");
            }

            String mimeType = Files.probeContentType(Paths.get(filePath));
            if (mimeType == null) {
                mimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"; // Default MIME type for Excel
            }

            FileSystemResource resource = new FileSystemResource(file);

            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getName() + "\"")
                    .contentType(MediaType.parseMediaType(mimeType))  // Set dynamic MIME type
                    .body(resource);

        } catch (IOException e) {
            throw new RuntimeException("Error generating Excel file", e);
        }
    }

    @PostMapping("/general-meeting-report")
    public ResponseEntity<FileSystemResource> downloadReport(@RequestBody GeneralMeetingReportDTO generalMeetingReportDTO) throws IOException {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss");
        String formattedTime = LocalDateTime.now().format(formatter);

        String directoryPath = "D:\\UploadedFiles\\GeneralMeetingReport\\" + formattedTime; // OK

        String filePath = "";
        if (generalMeetingReportDTO.getReportType().equalsIgnoreCase("GeneralMeetingReport")) {
            filePath = directoryPath + "\\GeneralMeetingReport.xlsx";
        } else if (generalMeetingReportDTO.getReportType().equalsIgnoreCase("MeetingMOMReport")) {
            filePath = directoryPath + "\\MeetingMOMReport.xlsx";
        } else if (generalMeetingReportDTO.getReportType().equalsIgnoreCase("TaskReport")) {
            filePath = directoryPath + "\\TaskReport.xlsx";
        }

        try {
            File dir = new File(directoryPath);
            if (!dir.exists()) {
                dir.mkdirs(); // Create directory if it doesn't exist
            }
            generalMeetingRepostService.generateReport(generalMeetingReportDTO, filePath);

            File file = new File(filePath);
            if (!file.exists()) {
                throw new RuntimeException("Excel file generation failed");
            }

            String mimeType = Files.probeContentType(Paths.get(filePath));
            if (mimeType == null) {
                mimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"; // Default MIME type for Excel
            }

            FileSystemResource resource = new FileSystemResource(file);

            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getName() + "\"")
                    .contentType(MediaType.parseMediaType(mimeType))
                    .body(resource);

        } catch (Exception e) {
            throw new RuntimeException("Error generating Excel file", e);
        }
    }


    }
