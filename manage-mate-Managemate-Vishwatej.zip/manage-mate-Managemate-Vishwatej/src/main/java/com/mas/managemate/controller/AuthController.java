package com.mas.managemate.controller;

import com.mas.managemate.model.dto.ApiResponse;
import com.mas.managemate.model.dto.AuthRequestDto;
import com.mas.managemate.service.AuthService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/auth")
@Slf4j
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/login")
    public ApiResponse<?> authenticateUser(@RequestBody AuthRequestDto authRequestDto) throws Exception {
        try {
            return authService.authenticate(authRequestDto);
        }catch (Exception e){
            log.error("error occurred on try to log in {}",e.getMessage());
            return new ApiResponse<>(e.getMessage(),"failed to login "+e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
}
