package com.mas.managemate.service;

import com.mas.managemate.exception.NotFoundException;
import com.mas.managemate.model.dto.SubStatusDefinitionsDto;

import java.util.List;

public interface SubStatusDefinitionService {

    SubStatusDefinitionsDto createSubStatusMapping(SubStatusDefinitionsDto subStatusDefinitionsDto);

    List<SubStatusDefinitionsDto> getAllSubStatus();

    SubStatusDefinitionsDto updateSubStatus(SubStatusDefinitionsDto subStatusDefinitionsDto, Long id) throws NotFoundException;

    List<SubStatusDefinitionsDto> getSubStatusByStatus(long statusId);

    SubStatusDefinitionsDto getSubStatusBySubStatus(long subStatusId);
}
