package com.mas.managemate.service;

import com.mas.managemate.model.dto.StatusDefinitionsDto;

import java.util.List;

public interface StatusDefinitionsService {
    StatusDefinitionsDto createStatusDefinitions(StatusDefinitionsDto statusDefinitionsDto);

    List<StatusDefinitionsDto> getAllStatus();

    StatusDefinitionsDto getStatusById(Long id);

    StatusDefinitionsDto updateStatusDefinitions(Long id, StatusDefinitionsDto statusDefinitionsDto);

    List<StatusDefinitionsDto> getStatusByTray(String designation);
}