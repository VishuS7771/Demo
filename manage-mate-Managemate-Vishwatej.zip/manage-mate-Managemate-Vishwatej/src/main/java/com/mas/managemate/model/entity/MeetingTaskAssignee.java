package com.mas.managemate.model.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "meeting_task_assignee",schema = "managemate")
public class MeetingTaskAssignee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long meetingTaskAssigneeId;

    private long empId;

    @Column(nullable = true)
    private boolean isActive;

    @ManyToOne
    @JoinColumn(name = "general_meeting_task_id")
    private GeneralMeetingTasks generalMeetingTasks;
}
