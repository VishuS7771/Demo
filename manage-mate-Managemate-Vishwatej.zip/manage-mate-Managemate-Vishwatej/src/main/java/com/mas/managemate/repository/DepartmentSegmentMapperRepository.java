package com.mas.managemate.repository;

import com.mas.managemate.model.entity.DepartmentSegmentMapper;
import com.mas.managemate.model.entity.MeetingParticipants;
import com.mas.managemate.model.entity.GeneralMeetingTasks;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DepartmentSegmentMapperRepository extends JpaRepository<DepartmentSegmentMapper,Long> {
    List<DepartmentSegmentMapper> findByGeneralMeetingId(Long id);
    List<DepartmentSegmentMapper> findByGeneralMeeting_Id(long meetingId);
    List<DepartmentSegmentMapper> findByGeneralMeetingTasks_GeneralMeetingTaskId(long taskId);
}