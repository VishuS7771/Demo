package com.mas.managemate.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.web.multipart.MultipartFile;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TaskRespondDto {
    private long taskRespondId;
    private String remark;
    private String respondedBy;
    private Date respondedOn;
    private String filePath;
    private boolean isMarking;
    private boolean isRespond;
    private long meetingTaskId;
    private String status;

    private GeneralMeetingTaskDto generalMeetingTaskDto;
}
