package com.mas.managemate.controller;

import com.mas.managemate.model.dto.ApiResponse;
import com.mas.managemate.model.dto.TaskTimelineDto;
import com.mas.managemate.model.mapper.TasksMapper;
import com.mas.managemate.service.TaskTimeLineService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/task-time-line")
@Slf4j
public class TaskTimeLineController {

    @Autowired
    private TaskTimeLineService taskTimeLineService;

    @Autowired
    private TasksMapper tasksMapper;


    @GetMapping("/get-by-task/{taskId}")
    public ApiResponse<?> getTaskTimeLine(@PathVariable long taskId){
        try{
            List<TaskTimelineDto> taskTimelineDto =taskTimeLineService.getByTaskId(taskId);
            return new ApiResponse<>(taskTimelineDto,"get timeline for task success", HttpStatus.OK);
        } catch (Exception e){
            log.error("failed get timeline for task {}",e.getMessage());
            return new ApiResponse<>(e.getMessage(),"failed get timeline for task "+e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/markStatus/{taskId}")
    public ApiResponse<?> markStatus(@PathVariable long taskId,@RequestBody TaskTimelineDto taskTimelineDto){
        try{
            taskTimeLineService.markStatus(taskId,taskTimelineDto);
            return new ApiResponse<>(null,"status marking for task success", HttpStatus.OK);
        }catch (Exception e){
            log.error("status marking for task failed {}",e.getMessage());
            return new ApiResponse<>(e.getMessage(),"status marking for task failed "+e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

}
