package com.mas.managemate.component;

import com.mas.managemate.model.dto.EmployeeProfileResponse;
import io.jsonwebtoken.*;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class JwtTokenProvider {

    public String generateToken(EmployeeProfileResponse authentication) {
        Date now = new Date();
        Date expiryDate = new Date(now.getTime() + 30 * 60 * 1000);

        return Jwts.builder()
                .setSubject(authentication.getData().get(0).getEmployeeNo())
                .setIssuedAt(new Date())
                .setExpiration(expiryDate)
                .signWith(SignatureAlgorithm.HS512, "mas-mfsl")
                .compact();
    }

    public static String getUserIdFromJWT(String token) {
        Claims claims = Jwts.parser()
                .setSigningKey("mas-mfsl")
                .parseClaimsJws(token)
                .getBody();

        return claims.getSubject();
    }

    public boolean validateToken(String authToken) {
        try {
            Jwts.parser().setSigningKey("mas-mfsl").parseClaimsJws(authToken);
            return true;
        } catch (SignatureException | MalformedJwtException | ExpiredJwtException | UnsupportedJwtException | IllegalArgumentException ex) {
            return false;
        }
    }
}
