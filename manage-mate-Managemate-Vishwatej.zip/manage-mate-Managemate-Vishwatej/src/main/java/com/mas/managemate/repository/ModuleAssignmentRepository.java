package com.mas.managemate.repository;

import com.mas.managemate.model.entity.ModuleAssignments;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ModuleAssignmentRepository extends JpaRepository<ModuleAssignments,Long> {
    Optional<ModuleAssignments> findByModule(String moduleName);
}
