package com.mas.managemate.serviceImpl;

import com.mas.managemate.model.dto.CompletionDateUpdateRequestDto;
import com.mas.managemate.model.dto.GeneralMeetingTaskTimelineDto;
import com.mas.managemate.model.entity.GeneralMeetingTaskTimeline;
import com.mas.managemate.model.entity.GeneralMeetingTasks;
import com.mas.managemate.repository.GeneralMeetingTaskRepository;
import com.mas.managemate.repository.GeneralMeetingTaskTimelineRepository;
import com.mas.managemate.service.CompletionDateService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Slf4j
@Service
public class CompletionDateServiceImpl implements CompletionDateService {
    @Autowired
    GeneralMeetingTaskTimelineRepository generalMeetingTaskTimelineRepository;
    @Autowired
    EmailService emailService;
    @Autowired
    GeneralMeetingTaskRepository generalMeetingTaskRepository;
    @Override
    public GeneralMeetingTaskTimeline updateCompletionDate(CompletionDateUpdateRequestDto requestDto) {
        List<GeneralMeetingTaskTimeline> timeline = generalMeetingTaskTimelineRepository.findByGeneralMeetingTasks_GeneralMeetingTaskId(requestDto.getGeneralMeetingTaskId());
        GeneralMeetingTaskTimeline latestTimeline = timeline.stream()
                .filter(a -> a.getMarkDate() != null)
                .max(Comparator.comparing(GeneralMeetingTaskTimeline::getMarkDate))
                .orElse(null);
        Optional<GeneralMeetingTasks> meetingTask = generalMeetingTaskRepository.findById(requestDto.getGeneralMeetingTaskId());

        GeneralMeetingTaskTimeline generalMeetingTaskTimeline = new GeneralMeetingTaskTimeline();

        meetingTask.ifPresent(generalMeetingTaskTimeline::setGeneralMeetingTasks);
        generalMeetingTaskTimeline.setCompletionDate(requestDto.getCompletionDate());
        generalMeetingTaskTimeline.setMarkDate(new Date());
        generalMeetingTaskTimeline.setMarkedBy(requestDto.getMarkedBy());

        if (!timeline.isEmpty()) {
            generalMeetingTaskTimeline.setActivity("Date Re-Updated");
            generalMeetingTaskTimeline.setRemarks(requestDto.getRemarks());

        }else {
            generalMeetingTaskTimeline.setActivity("Date Updated");
        }

        GeneralMeetingTaskTimeline taskTimeline = generalMeetingTaskTimelineRepository.save(generalMeetingTaskTimeline);
        if(meetingTask.get().getGeneralMeeting()==null){
            if (!timeline.isEmpty()) {
                meetingTask.ifPresent(generalMeetingTasks -> {
                    if (latestTimeline != null) {
                        emailService.taskCompletionDateReUpdateMail(generalMeetingTasks);
                    }
                });
            } else {
                meetingTask.ifPresent(generalMeetingTasks -> emailService.taskCompletionDateUpdateMail(generalMeetingTasks));
            }
        } else {
            if (!timeline.isEmpty()) {
                meetingTask.ifPresent(generalMeetingTasks -> {
                    if (latestTimeline != null) {
                        emailService.completionDateReUpdateMail(generalMeetingTasks, generalMeetingTaskTimeline, latestTimeline.getCompletionDate());
                    }
                });
            }else {
                meetingTask.ifPresent(generalMeetingTasks -> emailService.completionDateUpdateMail(generalMeetingTasks, generalMeetingTaskTimeline));
            }
        }
        return taskTimeline;
    }

    @Override
    public List<GeneralMeetingTaskTimelineDto> getGeneralMeetingTaskTimeline(Long taskId) {
        List<GeneralMeetingTaskTimeline> generalMeetingTask = generalMeetingTaskTimelineRepository.findByGeneralMeetingTasks_GeneralMeetingTaskId(taskId);
        List<GeneralMeetingTaskTimelineDto> generalMeetingTaskTimelineDtoList = new ArrayList<GeneralMeetingTaskTimelineDto>();
        for(GeneralMeetingTaskTimeline meetingTaskTimeline :generalMeetingTask){
            GeneralMeetingTaskTimelineDto generalMeetingTaskTimelineDto = new GeneralMeetingTaskTimelineDto();
            generalMeetingTaskTimelineDto.setMarkDate(meetingTaskTimeline.getMarkDate());
            generalMeetingTaskTimelineDto.setCompletionDate(meetingTaskTimeline.getCompletionDate());
            generalMeetingTaskTimelineDto.setActivity(meetingTaskTimeline.getActivity());
            generalMeetingTaskTimelineDto.setMarkedBy(meetingTaskTimeline.getMarkedBy());
            generalMeetingTaskTimelineDto.setRemarks(meetingTaskTimeline.getRemarks());
            generalMeetingTaskTimelineDtoList.add(generalMeetingTaskTimelineDto);
        }


        return generalMeetingTaskTimelineDtoList;
    }
}
