package com.mas.managemate.model.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Entity
@Table(name = "TrayMaster", schema = "managemate")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TrayMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "trayId")
    private long trayId;

    @Column(name = "trayName")
    private String trayName;

    @Column(name = "isActive")
    private int isActive;

    @Column(name = "createdBy")
    private long createdBy;

    @Column(name = "createdOn")
    private Date createdOn;
}
