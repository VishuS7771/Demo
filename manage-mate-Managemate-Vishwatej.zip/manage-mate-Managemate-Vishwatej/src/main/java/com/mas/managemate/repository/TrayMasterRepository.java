package com.mas.managemate.repository;

import com.mas.managemate.model.entity.TrayMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface TrayMasterRepository extends JpaRepository<TrayMaster,Long> {

//    @Query(value = "select * from managemate.TrayMaster where trayName like '%trayName:trayName%'",nativeQuery = true)
//    TrayMaster findByTrayName(@Param("trayName") String trayName);

    @Query("SELECT t FROM TrayMaster t WHERE t.trayName = :trayName")
    TrayMaster findByTrayName(@Param("trayName") String trayName);

}
