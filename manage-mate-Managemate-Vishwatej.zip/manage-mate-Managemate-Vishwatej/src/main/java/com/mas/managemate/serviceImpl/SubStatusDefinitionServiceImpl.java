package com.mas.managemate.serviceImpl;

import com.mas.managemate.exception.NotFoundException;
import com.mas.managemate.model.dto.SubStatusDefinitionsDto;
import com.mas.managemate.model.entity.SubStatusDefinitions;
import com.mas.managemate.model.mapper.StatusMapper;
import com.mas.managemate.repository.SubStatusDefinitionRepository;
import com.mas.managemate.service.SubStatusDefinitionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
public class SubStatusDefinitionServiceImpl implements SubStatusDefinitionService {

    @Autowired
    private SubStatusDefinitionRepository subStatusDefinitionRepository;

    @Autowired
    private StatusMapper statusMapper;

    @Override
    public SubStatusDefinitionsDto createSubStatusMapping(SubStatusDefinitionsDto subStatusDefinitionsDto) {
        SubStatusDefinitions obj = statusMapper.mapToSubStatusDefinitions(subStatusDefinitionsDto);
        SubStatusDefinitions subStatusMapping = subStatusDefinitionRepository.save(obj);
        log.info("creating sub status mapping successfully");
        return statusMapper.mapToSubStatusDefinitionsDto(subStatusMapping);
    }

    @Override
    public List<SubStatusDefinitionsDto> getAllSubStatus() {
        List<SubStatusDefinitions> allSubStatus = subStatusDefinitionRepository.findAll();
        log.info("get all sub status mapping successfully");
        return allSubStatus.stream()
                .map(statusMapper::mapToSubStatusDefinitionsDto)
                .toList();
    }

    @Override
    public List<SubStatusDefinitionsDto> getSubStatusByStatus(long statusId) {
        List<SubStatusDefinitions> subStatusDefinitions=subStatusDefinitionRepository.findByStatus_statusId(statusId);
        log.info("get sub status mapping by status Id {} successfully",statusId);
        return subStatusDefinitions.stream().map(subStatusDefinitions1 -> statusMapper.mapToSubStatusDefinitionsDto(subStatusDefinitions1)).toList();
    }

    @Override
    public SubStatusDefinitionsDto updateSubStatus(SubStatusDefinitionsDto subStatusDefinitionsDto, Long id) throws NotFoundException {
        SubStatusDefinitions existingSubStatus = subStatusDefinitionRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Sub-status not found with id: " + id));

        SubStatusDefinitions updatedSubStatus = statusMapper.mapToSubStatusDefinitions(subStatusDefinitionsDto);

        updatedSubStatus.setSubStatusId(existingSubStatus.getSubStatusId());
        updatedSubStatus.setCreatedOn(existingSubStatus.getCreatedOn());

        SubStatusDefinitions savedSubStatus = subStatusDefinitionRepository.save(updatedSubStatus);
        log.info("updating sub status mapping with id {} successfully",id);
        return statusMapper.mapToSubStatusDefinitionsDto(savedSubStatus);
    }

    @Override
    public SubStatusDefinitionsDto getSubStatusBySubStatus(long subStatusId) {
        SubStatusDefinitions subStatusDefinitions = subStatusDefinitionRepository.findById(subStatusId)
                .orElseThrow(() -> new RuntimeException("No Data Found with Id " + subStatusId));
        log.info("get  sub status mapping by Id {} successfully",subStatusId);
        return statusMapper.mapToSubStatusDefinitionsDto(subStatusDefinitions);
    }

//     subStatus.get().setSubStatusId(subStatusDefinitionsDto.getSubStatusId());
//        subStatus.get().setSubStatus(subStatusDefinitionsDto.getSubStatus());
//        subStatus.get().getStatus().setStatusId(subStatusDefinitionsDto.getStatusDefinitionsDto().getStatusId());
//        subStatus.get().set

}
