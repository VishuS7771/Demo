package com.mas.managemate.repository;

import com.mas.managemate.model.entity.GeneralMeetingTasks;
import com.mas.managemate.model.entity.MeetingParticipants;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MeetingParticipantsRepository  extends JpaRepository<MeetingParticipants,Long> {
    List<MeetingParticipants> findByMeetingId(Long id);

    List<MeetingParticipants> findByGeneralMeetingIdAndIsActive(Long id, int isActive);

    List<MeetingParticipants> findByMeetingIdAndIsActive(Long meetingId, int isActive);

    List<MeetingParticipants> findByGeneralMeeting_Id(long meetingId);

//    List<MeetingParticipants> findByMeeting(Meetings saveMeeting);

}
