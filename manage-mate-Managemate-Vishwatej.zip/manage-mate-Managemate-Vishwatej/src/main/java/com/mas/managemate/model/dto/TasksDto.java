package com.mas.managemate.model.dto;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.web.multipart.MultipartFile;

import java.util.Date;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TasksDto {

    private long id;

    private String taskId;

    private String taskName;

    private String dateAndTime;

    private long employeeId;

    private long designationId;

    private long departmentId;

    private String mobileNo;

    private String emailId;

    private String requirementType;

    private long moduleId;

    private String moduleName;

    private String requirementSubject;

    private String requirementInDetail;

    private String platform;

    private String taskPriority;

    private String attachmentPath;

    private String description;

    private long parentTaskId;

    private long assignedTo;

    private long raisedBy;

    private Date startDate;

    private Date endDate;

    private Date tentativeEndDate;

    private int delayInDays;

    private String remarks;

    private List<TaskAssignmentDto> taskAssignmentHistoryDto;

    private List<TaskTimelineDto> taskTimelineDto;

    private List<MeetingsDto> meetings;

    private List<AdditionalRequirementDto> additionalRequirementDtos;

    private List<SubTaskStatusDto> subTaskStatusDtos;

    private boolean isOnlySubTaskUser=false;

    private String raisedByName;

    private Date fromDate;

    private Date toDate;

    private String departmentAndDesignation;

}
