package com.mas.managemate.model.mapper;


import com.mas.managemate.model.dto.*;
import com.mas.managemate.model.entity.*;
import com.mas.managemate.model.dto.TasksDto;
import lombok.extern.slf4j.Slf4j;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

@Slf4j
@Mapper(componentModel = "spring")
public abstract class TasksMapper {

    @Mapping(target = "dateAndTime", ignore = true)
    @Mapping(target = "tentativeEndDate", ignore = true)
    public abstract Tasks mapToTask(TasksDto tasksDto);


    @Mapping(target = "dateAndTime", ignore = true)
    @Mapping(target = "tentativeEndDate", ignore = true)
    public abstract TasksDto mapToTaskDto(Tasks tasks);

    @Mapping(target = "dateAndTime", ignore = true)
    @Mapping(target = "tentativeEndDate", ignore = true)
    @Mapping(target = "startDate", ignore = true)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "taskId", ignore = true)
    @Mapping(target = "parentTask", ignore = true)
    public abstract void updateTasks(@MappingTarget Tasks existingTask,Tasks newTask);

    @Mapping(source = "task" , target = "tasks")
    @Mapping(target = "assignDate", ignore = true)
    public abstract TaskAssignments mapToTaskAssignments(TaskAssignmentDto taskAssignmentDto);

    @Mapping(source = "tasks" , target = "task")
    public  abstract TaskAssignmentDto mapToTaskAssignmentDto(TaskAssignments taskAssignments);

    @Mapping(source = "statusDefinitionsDto", target = "status")
    @Mapping(source = "subStatusDefinitionsDto", target = "subStatus")
    @Mapping(source = "proprietorAssignmentsDto", target = "proprietor")
    @Mapping(source = "proprietorAssignmentsDto.proprietorMasterDto", target = "proprietor.proprietor")
    public abstract TaskTimelines mapToTaskTimelines(TaskTimelineDto taskTimelineDto);

    @Mapping(source = "status", target = "statusDefinitionsDto")
    @Mapping(source = "subStatus", target = "subStatusDefinitionsDto")
    @Mapping(source = "proprietor", target = "proprietorAssignmentsDto")
    @Mapping(source = "proprietor.proprietor", target = "proprietorAssignmentsDto.proprietorMasterDto")
    public abstract TaskTimelineDto mapToTaskTimeLineDto(TaskTimelines taskTimelines);

    @Mapping(source = "tasksDto" ,target = "tasks")
    public abstract AdditionalRequirement mapToAdditionalRequirement(AdditionalRequirementDto additionalRequirementDto);

    @Mapping(source = "tasks" ,target = "tasksDto")
    public abstract AdditionalRequirementDto mapToAdditionalRequirementDto(AdditionalRequirement additionalRequirement);

    @Mapping(source = "proprietor.proprietorId", target = "proprietorId")
    @Mapping(source = "proprietor.proprietorName", target = "proprietorName")
    public abstract  ProprietorMasterDto mapToProprietorMasterDto(ProprietorMaster proprietor);

    @Mapping(source = "tasks",target = "tasksDto")
    public abstract SubTaskStatusDto mapToSubTaskStatusDto(SubTaskStatusMark taskStatusMark);

    @Mapping(target = "status", ignore = true)
    @Mapping(target = "subStatus", ignore = true)
    public abstract TaskSearchCriteria mapToTaskSearchCriteria(TaskSearchCriteriaDto searchCriteriaDto);

    @Mapping(target = "status", ignore = true)
    @Mapping(target = "subStatus", ignore = true)
    public abstract TaskSearchCriteriaDto mapToTaskSearchCriteriaDto(TaskSearchCriteria taskSearchCriteria);

    @Mapping(source = "tasks" ,target = "tasksDto")
    public abstract MeetingsDto mapToMeetingDto(Meetings additionalRequirement);

}
