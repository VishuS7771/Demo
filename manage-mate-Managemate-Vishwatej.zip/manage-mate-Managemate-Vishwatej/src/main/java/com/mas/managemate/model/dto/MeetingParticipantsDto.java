package com.mas.managemate.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MeetingParticipantsDto {
    private long meetingParticipantId;
    private MeetingsDto meetingsDto;
    private GeneralMeetingDto generalMeetingDto;
    private long employeeId;
    private long assignedBy;
    private Date assignedDate;
    private String participantName;
    private String designation;
    private String departmentName;
    private String employeeImgUrl;
    private int isActive;
}
