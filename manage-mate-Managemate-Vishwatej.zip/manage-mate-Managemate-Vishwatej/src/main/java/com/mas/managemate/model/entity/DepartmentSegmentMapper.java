package com.mas.managemate.model.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Entity
@Table(name = "department_segment_mapper", schema = "managemate")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DepartmentSegmentMapper {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "departmentSegmentId")
    private long departmentSegmentId;

    @Column(name = "id")
    private long id;

    @Column(name = "name")
    private String name;

    @Column(name = "isDepartment")
    private boolean isDepartment;

    @Column(name = "createdBy")
    private long createdBy;

    @Column(name = "createdOn")
    private Date createdOn;

    @ManyToOne
    @JoinColumn(name="generalMeetingId")
    private GeneralMeeting generalMeeting;

    @ManyToOne
    @JoinColumn(name = "generalMeetingTaskId")
    private GeneralMeetingTasks generalMeetingTasks;
}
