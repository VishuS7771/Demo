package com.mas.managemate.model.mapper;

import com.mas.managemate.model.dto.StatusDefinitionsDto;
import com.mas.managemate.model.dto.SubStatusDefinitionsDto;
import com.mas.managemate.model.entity.StatusDefinitions;
import com.mas.managemate.model.entity.SubStatusDefinitions;
import lombok.extern.slf4j.Slf4j;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Slf4j
@Mapper(componentModel = "spring")
public abstract class StatusMapper {

    @Mapping(source = "trayMasterDto", target = "trayMaster") // Map trayMasterDto to trayMaster
    public abstract StatusDefinitions mapToStatusDefinitions(StatusDefinitionsDto statusDefinitionsDto);

    @Mapping(source = "trayMaster", target = "trayMasterDto") // Map trayMaster to trayMasterDto
    public abstract StatusDefinitionsDto mapToStatusDefinitionsDto(StatusDefinitions statusDefinitions);

    @Mapping(source = "statusDefinitionsDto", target = "status")
    @Mapping(source = "trayMasterDto", target = "tray")
    public abstract SubStatusDefinitions mapToSubStatusDefinitions(SubStatusDefinitionsDto subStatusDefinitionsDto);

    @Mapping(source = "status", target = "statusDefinitionsDto")
    @Mapping(source = "tray", target = "trayMasterDto")
    public abstract SubStatusDefinitionsDto mapToSubStatusDefinitionsDto(SubStatusDefinitions subStatusMappings);
}
