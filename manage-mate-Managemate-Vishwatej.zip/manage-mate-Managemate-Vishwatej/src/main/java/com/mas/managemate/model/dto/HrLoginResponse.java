package com.mas.managemate.model.dto;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class HrLoginResponse {

    private String message;
    private boolean response;
    private Object data;
    private Object geodata;
    private Object geodataOUT;
}
