package com.mas.managemate.model.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Entity
@Table(name = "ProprietorMaster", schema = "managemate")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProprietorMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "proprietorId")
    private long proprietorId;

    @Column(name = "proprietorName")
    private String proprietorName;

    @Column(name = "isActive")
    private int isActive;

    @Column(name = "createdBy")
    private long createdBy;

    @Column(name = "createdOn")
    private Date createdOn;
}
