package com.mas.managemate.repository;

import com.mas.managemate.model.entity.TaskAssignments;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TaskAssignmentsRepository extends JpaRepository<TaskAssignments,Long> {

//    @Query("SELECT ta FROM TaskAssignments ta WHERE ta.tasks.id where :taskId")
//    List<TaskAssignments> findByTaskId(@Param("taskId") Long taskId);

    @Query("SELECT ta FROM TaskAssignments ta WHERE ta.tasks.id IN :taskIds")
    List<TaskAssignments> findByTaskIds(@Param("taskIds") List<Long> taskIds);

    @Query("SELECT ta FROM TaskAssignments ta WHERE ta.tasks.id =:taskId ")
    List<TaskAssignments> findByTaskId(@Param("taskId")Long taskId);

    @Query(value = "SELECT ta FROM TaskAssignments ta WHERE ta.employeeId =:employeeId")
    List<TaskAssignments> findByEmployeeId(@Param("employeeId") long employeeId);
}
