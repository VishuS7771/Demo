package com.mas.managemate.model.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.mas.managemate.model.entity.TrayMaster;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class StatusDefinitionsDto {

    private long statusId;

    private String status;

    private long createdBy;

    private TrayResponse trayMasterDto;

    @JsonFormat(pattern = "yyyy-dd-MM HH:mm:ss", timezone = "Asia/Kolkata")
    private Date createdOn;

    private int isActive;
}
