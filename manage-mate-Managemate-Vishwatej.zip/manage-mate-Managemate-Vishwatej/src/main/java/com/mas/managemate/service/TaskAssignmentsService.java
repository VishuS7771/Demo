package com.mas.managemate.service;

import com.mas.managemate.model.dto.TaskAssignmentDto;
import com.mas.managemate.model.dto.TasksDto;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

public interface TaskAssignmentsService {
    TaskAssignmentDto assignTask(TaskAssignmentDto taskAssignmentDto, MultipartFile multipartFile) throws IOException;

    List<TaskAssignmentDto> getByTaskId(long taskId) throws Exception;

    List<TasksDto> getTaskListForMeeting(long empId);
}
