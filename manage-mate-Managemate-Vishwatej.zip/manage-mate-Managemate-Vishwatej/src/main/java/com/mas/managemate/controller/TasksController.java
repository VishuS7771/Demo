package com.mas.managemate.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mas.managemate.model.dto.*;
import com.mas.managemate.model.entity.SubTaskStatusMark;
import com.mas.managemate.service.TaskService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/tasks")
@Slf4j
public class TasksController {

   @Autowired
   private TaskService taskService;

   @PostMapping("/add-task")
   public ApiResponse<?> addTask( @RequestParam("task") String taskJson, @RequestParam(value = "file", required = false) MultipartFile file) {
      try {
         ObjectMapper objectMapper = new ObjectMapper();
         TasksDto tasksDto = objectMapper.readValue(taskJson, TasksDto.class);
         TasksDto tasksDto1 = taskService.addTasks(tasksDto,file);
         return new ApiResponse<>(tasksDto1, "Task added successfully", HttpStatus.OK);
      } catch (Exception e) {
         log.error("failed to add task {}",e.getMessage());
         return new ApiResponse<>(e.getMessage(), "failed to add task "+e.getMessage(), HttpStatus.BAD_REQUEST);
      }
   }

   @GetMapping("/get-all-tasks")
   public ApiResponse<?> getAllTasks() {
      try {
         List<TasksDto> tasksDtoList = taskService.getAllTask();
         return new ApiResponse<>(tasksDtoList, "Fetch all tasks Successful", HttpStatus.OK);
      } catch (Exception e) {
         log.error("failed to fetch all tasks {}",e.getMessage());
         return new ApiResponse<>(e.getMessage(), "failed to fetch all tasks "+e.getMessage(), HttpStatus.BAD_REQUEST);
      }
   }

   @GetMapping("/get-by-designation/{designationId}")
   public ApiResponse<?> getTaskByDesignationId(@PathVariable(value = "designationId") long designationId,@RequestParam ("empId") long empId) {
      try {
         List<TasksDto> tasksDtoList = taskService.getTaskByDesignationId(designationId,empId);
         return new ApiResponse<>(tasksDtoList, "Fetch Task by designation and employee ", HttpStatus.OK);
      } catch (Exception e) {
         log.error("failed to get task by designation and employee {}",e.getMessage());
         return new ApiResponse<>(e.getMessage(), "failed to get task by designation and employee "+e.getMessage(), HttpStatus.BAD_REQUEST);
      }
   }

   @GetMapping("/get-by-department/{departmentId}")
   public ApiResponse<?> getTaskByDepartmentId(@PathVariable(value = "departmentId") long departmentId) {
      try {
         List<TasksDto> tasksDtoList = taskService.getTaskByDepartment(departmentId);
         return new ApiResponse<>(tasksDtoList, "get task by department success", HttpStatus.OK);
      } catch (Exception e) {
         log.error("failed to get task by department {}",e.getMessage());
         return new ApiResponse<>(e.getMessage(), "failed to get task by department "+e.getMessage(), HttpStatus.BAD_REQUEST);
      }
   }

   @GetMapping("/get-by-Id/{taskId}")
   public ApiResponse<?> getTaskByTaskId(@PathVariable(value = "taskId") long taskId) {
      try {
         TasksDto tasksDto1 = taskService.getTaskByTaskId(taskId);
         return new ApiResponse<>(tasksDto1, "Fetch by task Id success", HttpStatus.OK);
      } catch (Exception e) {
         log.error("failed to fetch by task Id {}",e.getMessage());
         return new ApiResponse<>(e.getMessage(), "failed to fetch by task Id "+e.getMessage(), HttpStatus.BAD_REQUEST);
      }
   }

   @PostMapping("/edit-task")
   public ApiResponse<?> editTask(@RequestBody TasksDto tasksDto) {
      try {
         TasksDto tasksDto1 = taskService.editTask(tasksDto);
         return new ApiResponse<>(tasksDto1, "edit task success", HttpStatus.OK);
      } catch (Exception e) {
         log.error("failed to edit task {}",e.getMessage());
         return new ApiResponse<>(e.getMessage(), "failed to edit task "+e.getMessage(), HttpStatus.BAD_REQUEST);
      }
   }

   @GetMapping("/get-by-parent/{taskId}")
   public ApiResponse<?> getTaskByParentTaskId(@PathVariable(value = "taskId") long taskId) {
      try {
         List<TasksDto> tasksDto1 = taskService.getByParentTaskid(taskId);
         return new ApiResponse<>(tasksDto1, "Fetch tasks by parent task success", HttpStatus.OK);
      } catch (Exception e) {
         log.error("failed to fetch task using parent task Id {}",e.getMessage());
         return new ApiResponse<>(e.getMessage(), "failed to fetch task using parent task Id "+e.getMessage(), HttpStatus.BAD_REQUEST);
      }
   }

   @PostMapping("/create-sub-task")
   public ApiResponse<?> createSubTask(@RequestParam("task") String taskJson,
                                       @RequestParam("parentTaskId") long parentTaskId,
                                       @RequestParam(value = "file", required = false) MultipartFile file) {
      try {
         ObjectMapper objectMapper = new ObjectMapper();
         TasksDto tasksDto = objectMapper.readValue(taskJson, TasksDto.class);
         TasksDto tasksDto1 = taskService.addSubTask(tasksDto, parentTaskId, file);
         return new ApiResponse<>(tasksDto1, "create sub task success", HttpStatus.OK);
      } catch (Exception e) {
         log.error("failed to create sub task {}",e.getMessage());
         return new ApiResponse<>(e.getMessage(), "failed to create sub task "+e.getMessage(), HttpStatus.BAD_REQUEST);
      }
   }

   @PostMapping("/edit-sub-task/{taskId}")
   public ApiResponse<?> editSubTask(@RequestBody TasksDto tasksDto, @PathVariable long taskId) {
      try {
         TasksDto tasksDto1 = taskService.updateSubTask(tasksDto, taskId);
         return new ApiResponse<>(tasksDto1, "edit sub task success", HttpStatus.OK);
      } catch (Exception e) {
         log.error("failed to edit sub task {}",e.getMessage());
         return new ApiResponse<>(e.getMessage(), "failed to edit sub task "+e.getMessage(), HttpStatus.BAD_REQUEST);
      }
   }

   @PostMapping("/mark-sub-task-status")
   public ApiResponse<?> markStatus(@RequestBody SubTaskStatusDto subTaskStatusDto) {
      try {
         taskService.markSubTaskStatus(subTaskStatusDto);
         return new ApiResponse<>(null, "mark sub task status success", HttpStatus.OK);
      } catch (Exception e) {
         log.error("mark sub task status failed {}",e.getMessage());
         return new ApiResponse<>(e.getMessage(), "mark sub task status failed "+e.getMessage(), HttpStatus.BAD_REQUEST);
      }
   }

   @GetMapping("/get-proprietor-status/{empId}/{designation}")
   public ApiResponse<?> getTaskByEmployeeId(@PathVariable (value = "empId") long empId, @PathVariable (value = "designation") String designation){
      try {
         designation = URLDecoder.decode(designation, StandardCharsets.UTF_8);
         StatusProprietorResultDto latestProprietorAndStatus = taskService.getLatestProprietorAndStatus(empId, designation);
         return new ApiResponse<>(latestProprietorAndStatus,"get proprietor status count success",HttpStatus.OK);
      }catch (Exception e){
         log.error("failed to get proprietor status count {}",e.getMessage());
         return new ApiResponse<>(e.getMessage(),"failed to get proprietor status count "+e.getMessage(), HttpStatus.BAD_REQUEST);
      }
   }

   @GetMapping("/get-task-list")
   public ApiResponse<?> getAllTaskList(){
      try {
         List<TaskListResponse> taskListResponseLIst =taskService.getAllTaskList();
         return new ApiResponse<>(taskListResponseLIst,"Task List fetched successfully",HttpStatus.OK);
      }catch (Exception e){
         log.error("failed to get Task List {}",e.getMessage());
         return new ApiResponse<>(e.getMessage(),"failed to get Task List "+e.getMessage(), HttpStatus.BAD_REQUEST);
      }
   }

   @GetMapping("/get-stakeholder-proprietor-status/{empId}/{designation}")
   public ApiResponse<?> getProprietorAndStatusByStakeHolder(@PathVariable (value = "empId") long empId, @PathVariable (value = "designation") String designation){
      try {
         designation = URLDecoder.decode(designation, StandardCharsets.UTF_8);
         StatusProprietorResultDto latestProprietorAndStatus = taskService.getProprietorAndStatusByStakeHolder(empId, designation);
         return new ApiResponse<>(latestProprietorAndStatus,"get proprietor status count success",HttpStatus.OK);
      }catch (Exception e){
         log.error("failed to get proprietor status count {}",e.getMessage());
         return new ApiResponse<>(e.getMessage(),"failed to get proprietor status count "+e.getMessage(), HttpStatus.BAD_REQUEST);
      }
   }

}
