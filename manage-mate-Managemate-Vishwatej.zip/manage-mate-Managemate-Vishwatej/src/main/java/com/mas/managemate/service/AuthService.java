package com.mas.managemate.service;

import com.mas.managemate.model.dto.ApiResponse;
import com.mas.managemate.model.dto.AuthRequestDto;

public interface AuthService {
    ApiResponse<?> authenticate(AuthRequestDto authRequestDto) throws Exception;
}
