package com.mas.managemate.service;

import com.mas.managemate.model.dto.ModuleAssignmentDto;

import java.util.List;

public interface ModuleAssignmentService {

    ModuleAssignmentDto createModuleAssignment(ModuleAssignmentDto moduleAssignmentDto);

    ModuleAssignmentDto findByModuleName(String module);

    ModuleAssignmentDto updateModuleAssignment(long moduleMappingId, ModuleAssignmentDto moduleAssignmentDto);

    List<ModuleAssignmentDto> getAllModules();
}
