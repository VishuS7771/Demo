package com.mas.managemate.service;

import com.mas.managemate.model.dto.CompletionDateUpdateRequestDto;
import com.mas.managemate.model.dto.GeneralMeetingTaskTimelineDto;
import com.mas.managemate.model.entity.GeneralMeetingTaskTimeline;
import com.mas.managemate.model.entity.GeneralMeetingTasks;

import java.util.List;

public interface CompletionDateService {
    GeneralMeetingTaskTimeline updateCompletionDate(CompletionDateUpdateRequestDto requestDto);

    List<GeneralMeetingTaskTimelineDto> getGeneralMeetingTaskTimeline(Long taskId);
}
