package com.mas.managemate.model.mapper;

import com.mas.managemate.model.dto.ModuleAssignmentDto;
import com.mas.managemate.model.entity.ModuleAssignments;
import lombok.extern.slf4j.Slf4j;
import org.mapstruct.Mapper;

@Slf4j
@Mapper(componentModel = "spring")
public abstract class ModuleMapper {


    public abstract ModuleAssignments mapToModuleAssignments(ModuleAssignmentDto moduleAssignmentDto);

    public abstract ModuleAssignmentDto mapToModuleAssignmentDto(ModuleAssignments moduleAssignments);
}
