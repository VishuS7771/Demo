package com.mas.managemate.model.dto;

import com.mas.managemate.model.entity.GeneralMeetingTasks;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MeetingTaskStatusResponseDto {
    private String markedBy;
    private Date markedOn;
    private String taskStatus;
    private String meetingTaskSubStatus;
}
