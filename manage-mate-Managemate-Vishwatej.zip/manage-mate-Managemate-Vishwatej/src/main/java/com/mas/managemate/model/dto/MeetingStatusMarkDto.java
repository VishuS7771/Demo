package com.mas.managemate.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MeetingStatusMarkDto {

    private String status;

    private Long generalMeetingId;

    private String mom;

    private String reasonForCancellation;

    private List<Long> employeeIds;

    private List<GeneralMeetingTaskDto> generalMeetingTaskDto;

    private String markedBy;
}
