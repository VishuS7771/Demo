package com.mas.managemate.model.dto;

import jakarta.persistence.Column;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProprietorMasterDto {

    private long proprietorId;

    private String proprietorName;

    private int isActive;

    private long createdBy;

    private Date createdOn;
}
