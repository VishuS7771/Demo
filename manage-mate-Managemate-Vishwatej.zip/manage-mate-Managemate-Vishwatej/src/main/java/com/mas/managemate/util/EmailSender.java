package com.mas.managemate.util;

import com.mas.managemate.repository.EmailNotificationsHistoryRepository;
import jakarta.mail.*;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Value;

import java.util.Properties;

@Slf4j
@Service
public class EmailSender {

    @Value("${spring.mail.host}")
    private String mailHost;

    @Value("${spring.mail.port}")
    private int mailPort;

    @Value("${spring.mail.username}")
    private String mailUsername;

    @Value("${spring.mail.password}")
    private String mailPassword;

    @Autowired
    private EmailNotificationsHistoryRepository emailNotificationsHistoryRepository;

    public void sendEmail(String assignedTo, String assignedCc, String subject, String body) {
        try {
            Properties properties = new Properties();
            properties.put("mail.smtp.host", mailHost);
            properties.put("mail.smtp.port", mailPort);
            properties.put("mail.smtp.auth", "true");
            properties.put("mail.smtp.starttls.enable", "true");
            Session session = Session.getInstance(properties, new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(mailUsername, mailPassword);
                }
            });
            // Create the email message
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(mailUsername));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(assignedTo));
            if (assignedCc != null && !assignedCc.isEmpty()) {
                message.setRecipients(Message.RecipientType.CC, InternetAddress.parse(assignedCc));
            }
            message.setSubject(subject);
            message.setContent(body, "text/html; charset=UTF-8");
            Transport.send(message); // Send the email
            log.info("Email sent successfully to {}", assignedTo);
//            saveEmailHistory(assignedTo, assignedCc, subject, body);

        } catch (MessagingException e) {
            log.error("Error occurred while sending the email: ", e);
            throw new RuntimeException("Failed to send email due to messaging issue", e);
        } catch (Exception e) {
            log.error("Unexpected error occurred while processing the email: ", e);
            throw new RuntimeException("An unexpected error occurred while processing the email", e);
        }
    }

    // Save the Send Email History.
//    private void saveEmailHistory(String to, String cc, String subject, String body) {
//        try {
//            EmailNotificationsHistory history = new EmailNotificationsHistory();
//            history.setEmailTo(to);
//            history.setEmailFrom(mailUsername);
//            history.setEmailCc(cc);
//            history.setEmailSubject(subject);
//            history.setEmailContent(body);
//            history.setSentDateTime(new Date());
//            emailNotificationsHistoryRepository.save(history);
//        } catch (Exception e) {
//            log.error("Error saving email history: ", e);
//            throw new RuntimeException("Failed to save email history", e);
//        }
//    }
}
