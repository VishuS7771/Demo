package com.mas.managemate.repository;

import com.mas.managemate.model.entity.GeneralMeetingStatusMark;
import com.mas.managemate.model.entity.GeneralMeetingTasks;
import com.mas.managemate.model.entity.MeetingTaskAssignee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface GeneralMeetingStatusMarkRepository extends JpaRepository<GeneralMeetingStatusMark,Long> {

    List<GeneralMeetingStatusMark> findByGeneralMeeting_Id(long meetingId);
}
