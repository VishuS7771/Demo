package com.mas.managemate.controller;

import com.mas.managemate.model.dto.ApiResponse;
import com.mas.managemate.model.dto.MeetingParticipantsDto;
import com.mas.managemate.model.dto.MeetingsDto;
import com.mas.managemate.model.mapper.MeetingMapper;
import com.mas.managemate.repository.MeetingParticipantsRepository;
import com.mas.managemate.service.MeetingService;
import com.mas.managemate.util.ApiClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/meetings")
@Slf4j
public class MeetingController {

    @Autowired
    private MeetingService meetingService;

    @Autowired
    private MeetingParticipantsRepository meetingParticipantsRepository;

    @Autowired
    private MeetingMapper meetingMapper;

    @Autowired
    private ApiClient apiClient;

    @PostMapping("/create-meeting")
    public ApiResponse<?> createMeeting(@RequestBody MeetingsDto meetingsDto) {
        try {
            MeetingsDto createdMeeting = meetingService.createMeeting(meetingsDto);
            return new ApiResponse<>(createdMeeting, "Meeting created successfully.", HttpStatus.CREATED);
        } catch (Exception e) {
            log.error("error occurred in creating meeting {}",e.getMessage());
            return new ApiResponse<>(e.getMessage(), "Failed to create meeting "+e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/update-meeting-status/{meetingId}")
    public ApiResponse<?> updateMeetingStatus(@PathVariable String meetingId, @RequestBody MeetingsDto meetingsDto) {
        try {
            MeetingsDto updatedMeeting = meetingService.updateMeetingStatus(meetingId, meetingsDto);
            return new ApiResponse<>(updatedMeeting, "Meeting updated successfully.", HttpStatus.OK);
        } catch (Exception e) {
            log.error("error occurred in updating meeting {}",e.getMessage());
            return new ApiResponse<>(e.getMessage(), "Failed to update meeting "+e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/edit-meeting/{meetingId}")
    public ApiResponse<?> editMeeting(@PathVariable String meetingId, @RequestBody MeetingsDto meetingsDto) {
        try {
            MeetingsDto updatedMeeting = meetingService.editMeeting(meetingId, meetingsDto);
            return new ApiResponse<>(updatedMeeting, "Meeting updated successfully.", HttpStatus.OK);
        } catch (Exception e) {
            log.error("error occurred in editing the meeting {}",e.getMessage());
            return new ApiResponse<>(e.getMessage(), "Failed to update meeting "+e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/get-by-meeting-id/{meetingId}")
    public ApiResponse<?> getByMeetingId(@PathVariable String meetingId) {
        try {
            MeetingsDto meeting = meetingService.getByMeetingId(meetingId);
            return new ApiResponse<>(meeting, "Meeting retrieved successfully.", HttpStatus.OK);
        } catch (Exception e) {
            log.error("error occurred in getting meeting by meetingId {}",e.getMessage());
            return new ApiResponse<>(e.getMessage(), "Failed to retrieve meeting " +e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/get-by-task-id/{taskId}")
    public ApiResponse<?> getByTaskId(@PathVariable String taskId) {
        try {
            List<MeetingsDto> meetings = meetingService.getByTaskId(taskId);
            return new ApiResponse<>(meetings, "Meetings retrieved successfully.", HttpStatus.OK);
        } catch (Exception e) {
            log.error("error occurred in getting meeting by taskId {}",e.getMessage());
            return new ApiResponse<>(e.getMessage(), "Failed to retrieve meetings "+e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/get-all-meetings")
    public ApiResponse<?> getAllMeetings() {
        try {
            List<MeetingsDto> meetings = meetingService.getAllMeetings();
            return new ApiResponse<>(meetings, "successfully", HttpStatus.OK);
        } catch (Exception e) {
            log.error("error occurred in get all meeting {}",e.getMessage());
            return new ApiResponse<>(e.getMessage(), "Failed to retrieve meetings "+e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/get-participants/{meetingId}")
    public ApiResponse<?> getParticipants(@PathVariable Long meetingId) {
        try {
            List<MeetingParticipantsDto> response = meetingService.getAllActiveParticipant(meetingId);
            return new ApiResponse<>(response, "Retrieved Successfully", HttpStatus.OK);
        } catch (Exception e) {
            log.error("error occurred in get meeting participants {}",e.getMessage());
            return new ApiResponse<>(e.getMessage(), "Failed to retrieve Participants "+e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/get-meetings-by-employee/{employeeId}")
    public ApiResponse<?> getMeetingsByEmployee(@PathVariable long employeeId) {
        try {
            List<MeetingsDto> meetings = meetingService.getMeetingsByEmployee(employeeId);
            return new ApiResponse<>(meetings, "Successfully fetched meetings", HttpStatus.OK);
        } catch (Exception e) {
            log.error("error occurred in get meetings by employee {}",e.getMessage());
            return new ApiResponse<>(e.getMessage(), "Failed to retrieve meeting s"+e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/get-meeting-by-task-id/{taskId}")
    public ApiResponse<?> getMeetingByTaskId(@PathVariable long taskId) {
        try {
            List<MeetingsDto> meetings = meetingService.getMeetingByTaskId(taskId);
            return new ApiResponse<>(meetings, "Meetings retrieved successfully.", HttpStatus.OK);
        } catch (Exception e) {
            log.error(e.getMessage());
            return new ApiResponse<>(e.getMessage(), "Failed to retrieve meetings "+e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }
}