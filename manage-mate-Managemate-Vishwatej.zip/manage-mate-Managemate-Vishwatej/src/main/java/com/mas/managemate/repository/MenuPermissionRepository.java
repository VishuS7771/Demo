package com.mas.managemate.repository;

import com.mas.managemate.model.entity.MenuPermission;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface MenuPermissionRepository extends JpaRepository<MenuPermission, Long> {
    Optional<MenuPermission> findByEmployeeId(long l);
}
