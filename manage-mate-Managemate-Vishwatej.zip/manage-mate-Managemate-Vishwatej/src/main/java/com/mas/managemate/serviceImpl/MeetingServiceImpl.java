package com.mas.managemate.serviceImpl;

import com.mas.managemate.model.constant.Constants;
import com.mas.managemate.model.dto.EmployeeProfileResponse;
import com.mas.managemate.model.dto.MeetingParticipantsDto;
import com.mas.managemate.model.dto.MeetingsDto;
import com.mas.managemate.model.entity.MeetingParticipants;
import com.mas.managemate.model.entity.Meetings;
import com.mas.managemate.model.mapper.MeetingMapper;
import com.mas.managemate.repository.MeetingParticipantsRepository;
import com.mas.managemate.repository.MeetingsRepository;
import com.mas.managemate.service.MeetingService;
import com.mas.managemate.util.ApiClient;
import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class MeetingServiceImpl implements MeetingService {

    @Autowired
    private MeetingMapper meetingMapper;

    @Autowired
    private MeetingsRepository meetingRepository;

    @Autowired
    private MeetingParticipantsRepository meetingParticipantsRepository;

    @Autowired
    private ApiClient apiClient;

    @Autowired
    private EmailService emailService;

    @Transactional
    @Override
    public MeetingsDto createMeeting(MeetingsDto meetingsDto) {
        log.info("Creating meeting in TaskId {}", meetingsDto.getTasksDto().getTaskId());
        try {
            if (meetingsDto.getDate() == null || meetingsDto.getFromTime() == null || meetingsDto.getToTime() == null) {
                throw new IllegalArgumentException("Date and Timing fields are mandatory");
            }

            if (meetingsDto.getEmployeeId() != null && !meetingsDto.getEmployeeId().contains(meetingsDto.getCreatedBy())) {
                meetingsDto.getEmployeeId().add(meetingsDto.getCreatedBy());
            }
            meetingsDto.setMeetingStatus(Constants.PENDING);
            Meetings meetings = meetingMapper.mapToMeetings(meetingsDto);

            List<MeetingParticipants> participants = meetingsDto.getEmployeeId()
                    .stream()
                    .map(employeeId -> MeetingParticipants.builder()
                            .meeting(meetings) // Set meeting reference
                            .employeeId(employeeId)
                            .assignedBy(meetingsDto.getCreatedBy())
                            .isActive(1)
                            .assignedDate(new Date())
                            .build())
                    .collect(Collectors.toList());
            meetings.setMeetingParticipants(participants); // Add participants to the meeting

            Meetings savedMeeting = meetingRepository.save(meetings);

            emailService.sendMeetingScheduledEmail(savedMeeting);

            log.info("Meeting creation successful");
            return meetingMapper.mapToMeetingsDto(savedMeeting);

        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Validation Error: " + e.getMessage(), e);
        } catch (Exception e) {
            throw new RuntimeException("Failed to create meeting", e);
        }
    }


    @Override
    public MeetingsDto updateMeetingStatus(String meetingId, MeetingsDto meetingsDto) {
        log.info("updating meeting with meeting Id {}",meetingId);
        try {
            Meetings existingMeeting = meetingRepository.findByMeetingId(meetingId).orElseThrow(() -> new IllegalArgumentException("Meeting not found for the provided meetingId: " + meetingId));

            // Handle for Cancelled Meeting
            if (Constants.CANCELLED.equals(meetingsDto.getMeetingStatus())) {
                if (meetingsDto.getReasonForCancellation() == null || meetingsDto.getReasonForCancellation().isEmpty()) {
                    throw new IllegalArgumentException("Reason for cancellation is mandatory for cancelled status.");
                }
                existingMeeting.setMeetingStatus(Constants.CANCELLED);
                existingMeeting.setReasonForCancellation(meetingsDto.getReasonForCancellation());
                existingMeeting.setRemarks(meetingsDto.getReasonForCancellation());
                emailService.sendMeetingCanceledEmail(existingMeeting);
            }

            // Handle rescheduling
            if (Constants.RE_SCHEDULE.equals(meetingsDto.getMeetingStatus())) {
                if (meetingsDto.getDate() == null || meetingsDto.getFromTime() == null || meetingsDto.getToTime() == null) {
                    throw new IllegalArgumentException("Date and Time are mandatory for rescheduling.");
                }
                existingMeeting.setMeetingStatus(Constants.RE_SCHEDULE);
                existingMeeting.setDate(meetingsDto.getDate());
                existingMeeting.setFromTime(meetingsDto.getFromTime());
                existingMeeting.setToTime(meetingsDto.getToTime());
                existingMeeting.setLocation(meetingsDto.getLocation());
                existingMeeting.setLink(meetingsDto.getLink());
                existingMeeting.setRemarks(meetingsDto.getRemarks());
                emailService.sendMeetingReScheduledEmail(existingMeeting);
            }

            // Handle for Completed Meeting
            if (Constants.COMPLETED.equals(meetingsDto.getMeetingStatus())) {
                if (meetingsDto.getMom() == null || meetingsDto.getMom().isEmpty()) {
                    throw new IllegalArgumentException("MOM is mandatory for Completed status.");
                }
                existingMeeting.setMeetingStatus(Constants.COMPLETED);
                existingMeeting.setMom(meetingsDto.getMom());
                emailService.sendMeetingStatusCompletedEmail(existingMeeting);

            }
            Meetings updatedMeeting = meetingRepository.save(existingMeeting);
            updatedMeeting.setCreatedOn(existingMeeting.getCreatedOn());

            // Update attendees if provided
            if (meetingsDto.getEmployeeId() != null) {
                List<MeetingParticipants> existingMeetingParticipants = meetingParticipantsRepository.findByMeetingId(existingMeeting.getId());

                Set<Long> newEmployeeIds = new HashSet<>(meetingsDto.getEmployeeId());

                // Update the isActive status for existing participants
                for (MeetingParticipants participant : existingMeetingParticipants) {
                    if (newEmployeeIds.contains(participant.getEmployeeId())) {
                        // Participant still exists, set isActive to 1
                        participant.setIsActive(1);
                        newEmployeeIds.remove(participant.getEmployeeId()); // Remove from new IDs to avoid duplication
                    } else {
                        // Participant is no longer in the new list, set isActive to 0
                        participant.setIsActive(0);
                    }
                }
                // Save updated existing participants
                meetingParticipantsRepository.saveAll(existingMeetingParticipants);

                // Add new participants not already in the existing list
                List<MeetingParticipants> newParticipants = newEmployeeIds.stream()
                        .map(employeeId -> MeetingParticipants.builder()
                                .meeting(updatedMeeting)
                                .employeeId(employeeId)
                                .assignedBy(updatedMeeting.getCreatedBy())
                                .assignedDate(new Date())
                                .isActive(1) // Set isActive to 1 for new participants
                                .build())
                        .collect(Collectors.toList());

                // Save new participants
                meetingParticipantsRepository.saveAll(newParticipants);
            }
            log.info("updating meeting with meeting Id {} successfully",meetingId);
            return meetingMapper.mapToMeetingsDto(updatedMeeting);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Validation Error: " + e.getMessage(), e);
        } catch (Exception e) {
            throw new RuntimeException("Failed to update meeting", e);
        }
    }

    @Override
    public MeetingsDto editMeeting(String meetingId, MeetingsDto meetingsDto) {
        log.info("editing  meeting with meeting Id {}",meetingId);
        try {
            Meetings existingMeeting = meetingRepository.findByMeetingId(meetingId).orElseThrow(() -> new IllegalArgumentException("Meeting not found for the provided meetingId: " + meetingId));

            // Allow updates only if meeting status is 'Pending'
            if (!Constants.PENDING.equals(existingMeeting.getMeetingStatus())) {
                throw new IllegalArgumentException("Meeting can only be edited if the status is PENDING.");
            }
            // Prevent modification of non-editable fields
            meetingsDto.setDate(existingMeeting.getDate());
            meetingsDto.setFromTime(existingMeeting.getFromTime());
            meetingsDto.setToTime(existingMeeting.getToTime());

            // Update editable fields
            existingMeeting.setMeetingName(meetingsDto.getMeetingName());
            existingMeeting.setAgenda(meetingsDto.getAgenda());
            existingMeeting.setLocation(meetingsDto.getLocation());
            existingMeeting.setLink(meetingsDto.getLink());
            existingMeeting.setRemarks(meetingsDto.getRemarks());
            existingMeeting.setCreatedOn(existingMeeting.getCreatedOn());

            if (meetingsDto.getEmployeeId() != null) {
                List<MeetingParticipants> existingParticipants = meetingParticipantsRepository.findByMeetingId(existingMeeting.getId());
                if (existingParticipants != null) {
                    meetingParticipantsRepository.deleteAll(existingParticipants);
                }
                // Add new attendees
                List<MeetingParticipants> updatedParticipants = meetingsDto.getEmployeeId().stream()
                        .map(employeeId -> MeetingParticipants.builder().meeting(existingMeeting)
                                .employeeId(employeeId).assignedBy(existingMeeting.getCreatedBy()).isActive(1)
                                .assignedDate(new Date()).build()).collect(Collectors.toList());
                meetingParticipantsRepository.saveAll(updatedParticipants);
            }


            Meetings updatedMeeting = meetingRepository.save(existingMeeting);
            log.info("editing meeting with meeting Id {} successfully",meetingId);
            return meetingMapper.mapToMeetingsDto(updatedMeeting);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Validation Error: " + e.getMessage(), e);
        } catch (Exception e) {
            throw new RuntimeException("Failed to update meeting", e);
        }
    }

    @Override
    public List<MeetingsDto> getByTaskId(String taskId) {
        log.info("get meeting with task Id {} successfully",taskId);
        try {
            List<Meetings> meetings = meetingRepository.findByTasks_TaskId(taskId);
            if (meetings.isEmpty()) {
                log.warn("No meetings found.");
                return Collections.emptyList();
            }
            return meetings.stream()
                    .map(meetingMapper::mapToMeetingsDto)
                    .toList();
        } catch (EntityNotFoundException e) {
            throw new RuntimeException("Error fetching meetings for taskId: " + taskId, e);
        }
    }


    @Override
    public MeetingsDto getByMeetingId(String meetingId) {
        log.info("get meeting with meetingId {} successfully",meetingId);
        try {
            Meetings meeting = meetingRepository.findByMeetingId(meetingId).orElseThrow(() -> new EntityNotFoundException("Meeting not found for meetingId: " + meetingId));
            return meetingMapper.mapToMeetingsDto(meeting);
        } catch (EntityNotFoundException e) {
            throw new RuntimeException("Meeting not found for meetingId: " + meetingId, e);
        }
    }

    @Override
    public List<MeetingsDto> getAllMeetings() throws Exception {
        log.info("get all meetings successfully");
       List<Meetings> meetingsList = meetingRepository.findAll();
        if (meetingsList.isEmpty()) {
            log.warn("No meetings found.");
            return Collections.emptyList();
        }
        List<MeetingsDto> meetingsDtos = meetingsList.stream().map(meetingMapper::mapToMeetingsDto).toList();
        for(MeetingsDto meetingsDto : meetingsDtos){
            EmployeeProfileResponse fetchProfiles = apiClient.getEmployeeProfile(String.valueOf(meetingsDto.getCreatedBy()));
            List<EmployeeProfileResponse.EmployeeData> profileData = fetchProfiles.getData();
            if (!profileData.isEmpty()) {
                meetingsDto.setHostIdName(fetchProfiles.getData().get(0).getEmployeeFullName());
                meetingsDto.setDesignation(fetchProfiles.getData().get(0).getDesignation());
                meetingsDto.setDepartmentName(fetchProfiles.getData().get(0).getDepartmentName());
            }else{
                log.warn("No profile data for CreatedBy: {}", meetingsDto.getCreatedBy());
                meetingsDto.setHostIdName("Unknown");
                meetingsDto.setDesignation("Unknown");
                meetingsDto.setDepartmentName("Unknown");
            }
        }
       return meetingsDtos;
    }

    @Override
    public List<MeetingParticipantsDto> getAllActiveParticipant(Long meetingId) throws Exception {
        log.info("get all active participant in meetingId {}  successfully",meetingId);
        List<MeetingParticipants> participants = meetingParticipantsRepository.findByMeetingIdAndIsActive(meetingId, 1);
        if (participants.isEmpty()) {
            log.warn("No meeting participants found.");
            return Collections.emptyList();
        }
        List<MeetingParticipantsDto> participantDtos = participants.stream()
                .map(meetingMapper::mapToMeetingParticipantsDto)
                .toList();

        for (MeetingParticipantsDto meetingParticipantsDto : participantDtos) {
            EmployeeProfileResponse fetchProfiles = apiClient.getEmployeeProfile(String.valueOf(meetingParticipantsDto.getEmployeeId()));
            List<EmployeeProfileResponse.EmployeeData> profileData = fetchProfiles.getData();
            if (!profileData.isEmpty()) {
                meetingParticipantsDto.setParticipantName(fetchProfiles.getData().get(0).getEmployeeFullName());
                meetingParticipantsDto.setDesignation(fetchProfiles.getData().get(0).getDesignation());
                meetingParticipantsDto.setDepartmentName(fetchProfiles.getData().get(0).getDepartmentName());
                meetingParticipantsDto.setEmployeeImgUrl(fetchProfiles.getData().get(0).getImageUrl());
            }else{
                log.warn("No profile data for CreatedBy: {}", meetingParticipantsDto.getEmployeeId());
                meetingParticipantsDto.setParticipantName("Unknown");
                meetingParticipantsDto.setDesignation("Unknown");
                meetingParticipantsDto.setDepartmentName("Unknown");
                meetingParticipantsDto.setEmployeeImgUrl("Unknown");
            }
        }

        return participantDtos;
    }

    @Override
    public List<MeetingsDto> getMeetingsByEmployee(long employeeId) throws Exception {
        log.info("get all meetings by employeeId {} successfully",employeeId);
        List<Meetings> meetingsList = meetingRepository.findAll();
        if (meetingsList.isEmpty()) {
            log.warn("No meetings found.");
            return Collections.emptyList();
        }
        List<MeetingsDto> meetingsDtos = meetingsList.stream().map(meetingMapper::mapToMeetingsDto).collect(Collectors.toList());

        // Filter meetings where employeeId is present in the participants list
        meetingsDtos = meetingsDtos.stream()
                .filter(meetingDto -> meetingDto.getMeetingParticipantsDtoList().stream()
                        .anyMatch(participant -> participant.getEmployeeId() == employeeId))
                .collect(Collectors.toList());
        for (MeetingsDto meetingsDto : meetingsDtos) {
            EmployeeProfileResponse fetchProfiles = apiClient.getEmployeeProfile(String.valueOf(meetingsDto.getCreatedBy()));
            List<EmployeeProfileResponse.EmployeeData> profileData = fetchProfiles.getData();
            if (!profileData.isEmpty()) {
                meetingsDto.setHostIdName(fetchProfiles.getData().get(0).getEmployeeFullName());
                meetingsDto.setDesignation(fetchProfiles.getData().get(0).getDesignation());
                meetingsDto.setDepartmentName(fetchProfiles.getData().get(0).getDepartmentName());
            }else{
                log.warn("No profile data for CreatedBy: {}", meetingsDto.getCreatedBy());
                meetingsDto.setHostIdName("Unknown");
                meetingsDto.setDesignation("Unknown");
                meetingsDto.setDepartmentName("Unknown");
            }
        }
        return meetingsDtos;
    }

    @Override
    public List<MeetingsDto> getMeetingByTaskId(long taskId) throws Exception {
        log.info("get all meetings by taskId {} successfully",taskId);
        List<Meetings> meetings = meetingRepository.findByTasks_Id(taskId);
        if (meetings.isEmpty()) {
            log.warn("No meetings found.");
            return Collections.emptyList();
        }

        List<MeetingsDto> meetingsDtos = meetings.stream()
                .map(meetingMapper::mapToMeetingsDto)
                .filter(meetingDto -> meetingDto.getMeetingParticipantsDtoList().stream()
                        .anyMatch(participant -> participant.getEmployeeId() == meetingDto.getCreatedBy()))
                .collect(Collectors.toList());

        for (MeetingsDto meetingsDto : meetingsDtos) {
            EmployeeProfileResponse fetchProfiles = apiClient.getEmployeeProfile(String.valueOf(meetingsDto.getCreatedBy()));
            List<EmployeeProfileResponse.EmployeeData> profileData = fetchProfiles.getData();
            if (!profileData.isEmpty()) {
                meetingsDto.setHostIdName(fetchProfiles.getData().get(0).getEmployeeFullName());
                meetingsDto.setDesignation(fetchProfiles.getData().get(0).getDesignation());
                meetingsDto.setDepartmentName(fetchProfiles.getData().get(0).getDepartmentName());
            }else{
                log.warn("No profile data for CreatedBy: {}", meetingsDto.getCreatedBy());
                meetingsDto.setHostIdName("Unknown");
                meetingsDto.setDesignation("Unknown");
                meetingsDto.setDepartmentName("Unknown");
            }
        }
        return meetingsDtos;
    }
}