package com.mas.managemate.repository;

import com.mas.managemate.model.entity.ProprietorMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProprietorMasterRepository extends JpaRepository<ProprietorMaster,Long> {

    ProprietorMaster findByProprietorName(String proprietorName);
}
