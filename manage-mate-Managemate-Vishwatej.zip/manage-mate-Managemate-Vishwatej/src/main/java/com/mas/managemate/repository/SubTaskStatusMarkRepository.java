package com.mas.managemate.repository;


import com.mas.managemate.model.entity.SubTaskStatusMark;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SubTaskStatusMarkRepository extends JpaRepository<SubTaskStatusMark,Long> {

    @Query("SELECT ta FROM SubTaskStatusMark ta WHERE ta.tasks.id IN :taskIds")
    List<SubTaskStatusMark> findByTaskIds(@Param("taskIds") List<Long> taskIds);
}
