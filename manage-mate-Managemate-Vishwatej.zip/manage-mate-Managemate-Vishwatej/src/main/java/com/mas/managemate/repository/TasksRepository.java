package com.mas.managemate.repository;

import com.mas.managemate.model.entity.Tasks;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TasksRepository extends JpaRepository<Tasks,Long> {

    Tasks findByTaskId(String taskId);

    List<Tasks> findByDesignationId(long designationId);

    List<Tasks> findByDepartmentId(long departmentId);

    List<Tasks> findByParentTaskId(long taskId);

    List<Tasks> findByEmployeeId(long empId);

    List<Tasks> findByRaisedBy(long empId);
}
