package com.mas.managemate.controller;

import com.mas.managemate.model.dto.ApiResponse;
import com.mas.managemate.model.dto.StatusDefinitionsDto;
import com.mas.managemate.service.StatusDefinitionsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/status-definitions")
@Slf4j
public class StatusDefinitionsController {

    @Autowired
    private StatusDefinitionsService statusDefinitionsService;

    @PostMapping("/create-status-definitions")
    public ApiResponse<?> createSubStatusMapping(@RequestBody StatusDefinitionsDto status) {
        try {
            StatusDefinitionsDto statusMapping = statusDefinitionsService.createStatusDefinitions(status);
            return new ApiResponse<>(statusMapping,"Status created successfully.",HttpStatus.OK);
        } catch (Exception e) {
            log.error("Failed to create status {}",e.getMessage());
            return new ApiResponse<>(e.getMessage(),"Failed to create status "+e.getMessage(),HttpStatus.OK);
        }
    }

    @GetMapping("/get-all-status")
    public ApiResponse<?> getAllStatus() {
        try {
            List<StatusDefinitionsDto> statusDefinitionsList = statusDefinitionsService.getAllStatus();
            return new ApiResponse<>(statusDefinitionsList,"Statuses fetched successfully",HttpStatus.OK);
        } catch (Exception e) {
            log.error("Failed to fetch status {}",e.getMessage());
            return new ApiResponse<>(e.getMessage(),"Failed to fetch status "+e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/get-status/{id}")
    public ApiResponse<?> getStatusById(@PathVariable Long id) {
        try {
            StatusDefinitionsDto statusDefinitionsDto = statusDefinitionsService.getStatusById(id);
            return new ApiResponse<>(statusDefinitionsDto,"Statuses fetched successfully.",HttpStatus.OK);
        } catch (Exception e) {
            log.error("Failed to fetch status {}",e.getMessage());
            return new ApiResponse<>(e.getMessage(),"Failed to fetch status "+e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/update-status/{id}")
    public ApiResponse<?> updateStatus(@PathVariable Long id, @RequestBody StatusDefinitionsDto statusDefinitionsDto) {
        try {
            StatusDefinitionsDto updatedStatus = statusDefinitionsService.updateStatusDefinitions(id, statusDefinitionsDto);
            return new ApiResponse<>(updatedStatus,"Statuses updated successfully.",HttpStatus.OK);
        } catch (Exception e) {
            log.error("Failed to update status {}",e.getMessage());
            return new ApiResponse<>(e.getMessage(),"Failed to update status "+e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/status-by-tray/{tray}")
    public ApiResponse<?> getStatusByTray(@PathVariable("tray") String designation) {
        try {
            List<StatusDefinitionsDto> statusDefinitionsDtos = statusDefinitionsService.getStatusByTray(designation);
            return new ApiResponse<>(statusDefinitionsDtos, "Statuses fetched successfully", HttpStatus.OK);
        } catch (Exception e) {
            log.error(e.getMessage());
            return new ApiResponse<>(e.getMessage(), "Failed to fetch status "+e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
