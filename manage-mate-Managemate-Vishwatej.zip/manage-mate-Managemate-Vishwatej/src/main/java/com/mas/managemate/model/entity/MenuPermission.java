package com.mas.managemate.model.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Table(name = "menu_permission", schema = "managemate")
public class MenuPermission {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long menuPermissionId;

    private long employeeId;

    @JsonProperty("isStatus")
    private boolean isStatus;

    @JsonProperty("isSubStatus")
    private boolean isSubStatus;

    @JsonProperty("isProprietor")
    private boolean isProprietor;

    @JsonProperty("isAssign")
    private boolean isAssign;

    @JsonProperty("isUser")
    private boolean isUser;

    @JsonProperty("isDashboard")
    private boolean isDashboard;

    @JsonProperty("isTask")
    private boolean isTask;

    @JsonProperty("isModule")
    private boolean isModule;

    @JsonProperty("isProject")
    private boolean isProject;

    @JsonProperty("isReport")
    private boolean isReport;

    @JsonProperty("isGeneralMeeting")
    private boolean isGeneralMeeting;
}
