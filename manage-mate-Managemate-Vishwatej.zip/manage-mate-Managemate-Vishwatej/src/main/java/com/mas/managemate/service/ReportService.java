package com.mas.managemate.service;


import com.mas.managemate.model.dto.ReportDto;
import org.springframework.core.io.ByteArrayResource;
;

public interface ReportService {

    ByteArrayResource generateExcel(ReportDto reportRequestDto,String filePath) throws Exception;
}
