package com.mas.managemate.repository;

import com.mas.managemate.model.entity.FileSavePath;
import com.mas.managemate.model.entity.GeneralMeetingStatusMark;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FileSavePathRepository extends JpaRepository<FileSavePath,Long> {
    List<FileSavePath> findByGeneralMeeting_Id(long meetingId);

}
