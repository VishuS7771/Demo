package com.mas.managemate.model.dto;

import lombok.Data;

import java.util.Date;

@Data
public class GeneralMeetingTaskTimelineDto {

    private String activity;
    private Date completionDate;
    private Date markDate;
    private String markedBy;
    private String remarks;
}
