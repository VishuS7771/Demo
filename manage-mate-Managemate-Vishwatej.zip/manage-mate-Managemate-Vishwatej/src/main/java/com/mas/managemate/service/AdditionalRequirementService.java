package com.mas.managemate.service;

import com.mas.managemate.model.dto.AdditionalRequirementDto;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

public interface AdditionalRequirementService {
    AdditionalRequirementDto create(AdditionalRequirementDto additionalRequirementDto, MultipartFile multipartFile) throws IOException;
}
