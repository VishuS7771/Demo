package com.mas.managemate.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class GeneralMeetingReportDTO {

    private String reportType;

    private List<String> segment;

    private List<String> department;

    private List<Long> assignedBy;

    private List<Long> assignee;

    private List<Long> attendees;

    private List<Long> hosts;

    private LocalDate meetingDateFrom;

    private LocalDate meetingDateTo;

    private LocalDate taskAssignedDateFrom;

    private LocalDate taskAssignedDateTo;

    private int empId;
}
