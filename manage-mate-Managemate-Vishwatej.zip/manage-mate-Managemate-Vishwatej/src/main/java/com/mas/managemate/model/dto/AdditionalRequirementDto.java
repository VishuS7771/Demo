package com.mas.managemate.model.dto;


import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AdditionalRequirementDto {

    private long additionalRequirementId;

    private TasksDto tasksDto;

    private String requirement;

    @JsonFormat(pattern = "yyyy-dd-MM HH:mm:ss", timezone = "Asia/Kolkata")
    private Date dateAndTime;

    private String attachment;
}
