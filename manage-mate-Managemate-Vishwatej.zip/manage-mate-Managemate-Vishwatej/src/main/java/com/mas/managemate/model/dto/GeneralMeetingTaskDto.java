package com.mas.managemate.model.dto;


import com.mas.managemate.model.entity.DepartmentSegmentMapper;
import com.mas.managemate.model.entity.MeetingTaskAssignee;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GeneralMeetingTaskDto {

    private Long generalMeetingTaskId;

    private String taskName;

    private String remark;

    private Date targetDate;

    private Date createdOn;

    private String status;

    private String createdBy;

    private List<Long> employeeIds;

    private Long generalMeetingId;

    private List<MeetingTaskAssigneeDto> meetingTaskAssigneeDtos;

    private List<DepartmentDto> departmentDtos;

    private List<DepartmentDto> segmentDtos;

    private Date completionDate;

    private String generalMeetingName;

    private List<DepartmentSegmentMapper> departmentSegmentMapper;
}
