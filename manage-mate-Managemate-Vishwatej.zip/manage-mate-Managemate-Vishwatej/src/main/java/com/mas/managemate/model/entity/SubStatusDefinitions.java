package com.mas.managemate.model.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;

@Entity
@Table(name = "SubStatusDefinitions", schema = "managemate")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SubStatusDefinitions {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "subStatusId")
    private long subStatusId;

    @Column(name = "subStatus")
    private String subStatus;

    @ManyToOne
    @JoinColumn(name = "statusId")
    private StatusDefinitions status;

    @Column(name = "createdBy")
    private long createdBy;

    @Column(name = "createdOn")
    private Date createdOn;

    @Column(name = "isActive")
    private int isActive;

    @ManyToOne
    @JoinColumn(name = "tray_master_id")
    private TrayMaster tray;

    @PrePersist
    public void setCreatedOn() {
        if (this.createdOn == null) {
            // Set current time in IST
            ZonedDateTime istNow = ZonedDateTime.now(ZoneId.of("Asia/Kolkata"));
            this.createdOn = Date.from(istNow.toInstant());
        }
    }
}
