package com.mas.managemate.controller;

import com.mas.managemate.model.dto.ApiResponse;
import com.mas.managemate.model.entity.MenuPermission;
import com.mas.managemate.model.entity.MenuPermissionAccess;
import com.mas.managemate.service.MenuPermissionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("/menu-permission")
@RestController
@Slf4j
public class MenuPermissionController {

    @Autowired
    private MenuPermissionService menuPermissionService;

    @PostMapping("/add")
    public ApiResponse<?> addMenuPermission(@RequestBody MenuPermission menuPermission){
        try {
            menuPermission=menuPermissionService.addMenuPermission(menuPermission);
            return new ApiResponse<>(menuPermission,"success",HttpStatus.OK);
        }catch (Exception e){
            log.error("error occurred in adding menu permission {}",e.getMessage());
            return new ApiResponse<>(e.getMessage(),"failed to add menu permission "+e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/get/{empId}")
    public ApiResponse<?> getMenuPermission(@PathVariable("empId") long empId){
        try {
            MenuPermission menuPermission=menuPermissionService.getMenuPermission(empId);
            return new ApiResponse<>(menuPermission,"success",HttpStatus.OK);
        }catch (Exception e){
            log.error("error occurred in get menu permission {}",e.getMessage());
            return new ApiResponse<>(e.getMessage(),"failed to get menu permission "+e.getMessage(),HttpStatus.BAD_REQUEST);

        }
    }

    @GetMapping("/get-menu-permission-access")
    public ApiResponse<?> getMenuPermissionAccess(){
        try {
            List<MenuPermissionAccess> menuPermissionAccesses=menuPermissionService.getMenuPermissionAccess();
            return new ApiResponse<>(menuPermissionAccesses,"success",HttpStatus.OK);
        }catch (Exception e){
            log.error("error occurred in  menu permission access {}",e.getMessage());
            return new ApiResponse<>(e.getMessage(),"failed to get menu permission access "+e.getMessage(),HttpStatus.BAD_REQUEST);
        }
    }

}
