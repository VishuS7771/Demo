package com.mas.managemate.model.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.mas.managemate.model.entity.StatusDefinitions;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SubStatusDefinitionsDto {

    private long subStatusId;

    private String subStatus;

    private StatusDefinitionsDto statusDefinitionsDto;

    private long createdBy;

    @JsonFormat(pattern = "yyyy-dd-MM HH:mm:ss", timezone = "Asia/Kolkata")
    private Date createdOn;

    private int isActive;

    private TrayMasterDto trayMasterDto;
}
