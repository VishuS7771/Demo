package com.mas.managemate.serviceImpl;

import com.mas.managemate.model.dto.*;
import com.mas.managemate.model.entity.*;
import com.mas.managemate.model.entity.TaskAssignments;
import com.mas.managemate.model.entity.TaskTimelines;
import com.mas.managemate.model.entity.Tasks;
import com.mas.managemate.model.mapper.ProprietorMapper;
import com.mas.managemate.model.mapper.TasksMapper;
import com.mas.managemate.repository.*;
import com.mas.managemate.service.TaskService;
import com.mas.managemate.util.ApiClient;
import com.mas.managemate.util.DateConverter;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;;
import java.text.ParseException;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class TaskServiceImpl implements TaskService {

    @Autowired
    private TasksMapper tasksMapper;

    @Autowired
    private ProprietorMapper proprietorMapper;

    @Autowired
    private TaskAssignmentsRepository taskAssignmentsRepository;

    @Autowired
    private TaskTimeLinesRepository taskTimeLinesRepository;

    @Autowired
    private TasksRepository tasksRepository;

    @Autowired
    private MeetingsRepository meetingsRepository;

    @Autowired
    private StatusDefinitionsRepository statusDefinitionsRepository;

    @Autowired
    private SubStatusDefinitionRepository subStatusDefinationRepository;

    @Autowired
    private ProprietorAssignmentsRepository proprietorAssignmentsRepository;

    @Autowired
    private AdditionalRequirementRepository additionalRequirementRepository;

    @Autowired
    private SubTaskStatusMarkRepository subTaskStatusMarkRepository;

    @Autowired
    private ApiClient apiClient;

    @Autowired
    private TrayMasterRepository trayMasterRepository;

    @Autowired
    private EmailService emailService;

    @Autowired
    private ModuleAssignmentRepository moduleAssignmentRepository;

    @Autowired
    private ProprietorMasterRepository proprietorMasterRepository;


    private static final String taskPath = "D:/UploadedFiles/Task";

    private static final String subTaskPath = "D:/UploadedFiles/SubTask";


    @Override
    @Transactional
    public TasksDto addTasks(TasksDto tasksDto, MultipartFile multipartFile) throws Exception {
        log.info("creating new task");
        String filePath = "";
        if (multipartFile != null) {
            filePath = saveFile(multipartFile, tasksDto.getTaskName(), taskPath);
        }
        Tasks tasks = tasksMapper.mapToTask(tasksDto);
        tasks.setAttachmentPath(filePath);
        tasks = tasksRepository.save(tasks);
        Optional<ModuleAssignments> moduleAssignments = moduleAssignmentRepository.findByModule(tasks.getModuleName());
        TaskAssignments taskAssignments = new TaskAssignments();
        TaskTimelines taskTimelines = new TaskTimelines();

        if (moduleAssignments.isPresent()) {
            taskAssignments = TaskAssignments.builder().assignedBy(tasks.getRaisedBy()).assignDate(new Date()).
                    employeeId(moduleAssignments.get().getEmployeeId()).tasks(tasks).isAssigned(1).attachmentPath(filePath).build();
            taskAssignments = taskAssignmentsRepository.save(taskAssignments);
            emailService.sendTaskAssignEmail(taskAssignments);
            EmployeeProfileResponse employeeProfile = apiClient.getEmployeeProfile(String.valueOf(moduleAssignments.get().getEmployeeId()));
            EmployeeProfileResponse.EmployeeData employeeData = employeeProfile.getData().get(0);

            if (employeeData.getDepartment().contains("Project Management")) {
                taskTimelines = TaskTimelines.builder().status(statusDefinitionsRepository.findById(2L).get()).
                        subStatus(subStatusDefinationRepository.findById(36L).get()).dateAndTime(new Date()).
                        proprietor(proprietorAssignmentsRepository.findById(35L).get()).tasks(tasks)
                        .markedBy(tasks.getRaisedBy()).build();

            } else if (employeeData.getDepartment().contains("Software Development")) {
                taskTimelines = TaskTimelines.builder().status(statusDefinitionsRepository.findById(15L).get()).
                        subStatus(subStatusDefinationRepository.findById(37L).get()).dateAndTime(new Date()).
                        proprietor(proprietorAssignmentsRepository.findById(36L).get()).tasks(tasks)
                        .markedBy(tasks.getRaisedBy()).build();
            }
        } else {

            taskAssignments = TaskAssignments.builder().assignedBy(tasks.getRaisedBy()).assignDate(new Date()).
                    employeeId(575L).tasks(tasks).isAssigned(1).attachmentPath(filePath).build();
            taskAssignments = taskAssignmentsRepository.save(taskAssignments);
            emailService.sendTaskAssignEmail(taskAssignments);
            taskTimelines = TaskTimelines.builder().status(statusDefinitionsRepository.findById(11L).get()).
                    subStatus(subStatusDefinationRepository.findById(33L).get()).dateAndTime(new Date()).
                    proprietor(proprietorAssignmentsRepository.findById(34L).get()).tasks(tasks)
                    .markedBy(tasks.getRaisedBy()).build();
        }

        taskTimeLinesRepository.save(taskTimelines);
        log.info("Task Created successfully with task Id {} ", tasksDto.getTaskId());
        return tasksMapper.mapToTaskDto(tasks);
    }

    @Override
    public TasksDto getTaskByTaskId(long taskId) {
        Tasks tasks = tasksRepository.findById(taskId).orElseThrow(() -> new RuntimeException("task  not found "));
        log.info("get task by Task Id {} successfully", taskId);
        return mapData(List.of(tasks)).get(0);

    }

    @Override
    public List<TasksDto> getAllTask() {
        List<Tasks> tasks = tasksRepository.findAll();
        tasks = tasks.stream().filter(a -> a.getParentTask().getId() == null).toList();
        log.info("get all task successfully");
        return mapData(tasks);
    }

    @Override
    public List<TasksDto> getTaskByDesignationId(long designationId, long empId) throws Exception {
        List<Tasks> tasks = tasksRepository.findAll();
        if (tasks.isEmpty()) {
            log.warn("No tasks found in the repository.");
            return Collections.emptyList();
        }

        List<Tasks> listTask = tasks.stream().filter(a -> a.getParentTask() != null).toList();
        if (listTask.isEmpty()) {
            log.warn("No tasks with parent task found.");
        }

        HierarchyMatrixResponse hierarchyMatrix = apiClient.getHierarchyMatrix(String.valueOf(empId));
        List<HierarchyMatrixResponse.Hierarchy> hierarchies = hierarchyMatrix.getData();
        if (hierarchies == null || hierarchies.isEmpty()) {
            log.warn("No hierarchy data found for employee {}", empId);
            return Collections.emptyList();
        }

        List<Long> employeeNoList = hierarchies.stream()
                .filter(a -> a.getLv().equalsIgnoreCase("Lower"))
                .map(a -> Long.parseLong(a.getEmployeeNo()))
                .toList();

        log.info("Employee No List: {}", employeeNoList);

        if (employeeNoList.isEmpty()) {
            log.warn("No valid employee numbers found.");
            return Collections.emptyList();
        }

        listTask = listTask.stream()
                .filter(tasks1 -> employeeNoList.contains(tasks1.getRaisedBy()) ||
                        taskAssignmentsRepository.findByTaskIds(List.of(tasks1.getId()))
                                .stream()
                                .anyMatch(taskAssignments1 -> employeeNoList.contains(taskAssignments1.getEmployeeId())))
                .toList();

        log.info("Filtered ListTask: {}", listTask);

        List<TasksDto> tasksDtos = mapData(tasks.stream().filter(a -> a.getParentTask() == null).toList());
        if (tasksDtos == null || tasksDtos.isEmpty()) {
            tasksDtos = Collections.emptyList();
        }

        tasksDtos = tasksDtos.stream()
                .filter(tasksDto -> employeeNoList.contains(tasksDto.getRaisedBy())
                        ||
                        (tasksDto.getTaskAssignmentHistoryDto() != null &&
                                tasksDto.getTaskAssignmentHistoryDto().stream()
                                        .anyMatch(history -> employeeNoList.contains(history.getEmployeeId()))))
                .toList();

        log.info("Filtered TasksDtos: {}", tasksDtos);

        if (tasksDtos.isEmpty()) {
            List<Long> list = listTask.stream()
                    .map(a -> a.getParentTask() != null ? a.getParentTask().getId() : null)
                    .filter(Objects::nonNull)
                    .toList();
            if (list.isEmpty()) {
                log.warn("No parent task IDs found to map.");
                return Collections.emptyList();
            }

            List<Tasks> filteredTasks = tasks.stream()
                    .filter(a -> list.contains(a.getId()))
                    .toList();

            if (filteredTasks.isEmpty()) {
                log.warn("No tasks found for the given parent task IDs.");
                return Collections.emptyList();
            }

            List<TasksDto> tasksDtoList = mapData(filteredTasks);
            tasksDtoList = tasksDtoList.stream()
                    .peek(a -> a.setOnlySubTaskUser(true))
                    .toList();
            log.info("Returning filtered tasksDtoList with only sub-task user");
            return tasksDtoList;
        }

        log.info("Get all tasks by employee {} successfully", empId);
        return tasksDtos;
    }
    @Override
    public List<TasksDto> getTaskByDepartment(long departmentId) {
        List<Tasks> tasks = tasksRepository.findByDepartmentId(departmentId);
        tasks = tasks.stream().filter(a -> a.getParentTask() == null).toList();
        log.info("get all task  by departmentId {} successfully", departmentId);
        return mapData(tasks);
    }

    @Override
    public TasksDto editTask(TasksDto tasksDto) throws ParseException {
        Tasks existingTask = tasksRepository.findByTaskId(tasksDto.getTaskId());
        if (existingTask == null) {
            throw new RuntimeException("Task not found");
        }
        Tasks saveTask = null;
        if (existingTask != null) {
            Tasks tasks = tasksMapper.mapToTask(tasksDto);
            tasks.setDateAndTime(existingTask.getDateAndTime());
            tasks.setId(existingTask.getId());
            saveTask = tasksRepository.save(tasks);

        }
        if (saveTask != null) {
            TasksDto tasksDto1 = tasksMapper.mapToTaskDto(saveTask);
            tasksDto1.setDateAndTime(DateConverter.convertDateTime(saveTask.getDateAndTime()));
            log.info("edit all task successfully");
            return tasksDto1;
        }
        return null;
    }

    @Override
    public List<TasksDto> getByParentTaskid(long taskId) {
        List<Tasks> tasks = tasksRepository.findByParentTaskId(taskId);
        log.info("get task by parent Id {} successfully", taskId);
        return mapData(tasks);
    }

    @Override
    @Transactional
    public TasksDto addSubTask(TasksDto tasksDto, long parentId, MultipartFile multipartFile) throws IOException, ParseException {
        String filePath = "";
        if (multipartFile != null) {
            filePath = saveFile(multipartFile, tasksDto.getTaskName(), subTaskPath);
        }
        Tasks tasks = tasksMapper.mapToTask(tasksDto);
        tasks.setAttachmentPath(filePath);
        tasks.setTentativeEndDate(tasksDto.getTentativeEndDate());
        tasks.setParentTask(tasksRepository.findById(parentId).get());
        tasks = tasksRepository.save(tasks);
        TaskAssignments taskAssignments = TaskAssignments.builder().assignedBy(tasks.getRaisedBy()).assignDate(new Date()).assignTaskId(tasks.getId()).employeeId(tasksDto.getAssignedTo()).tasks(tasks).isAssigned(1).build();
        taskAssignments = taskAssignmentsRepository.save(taskAssignments);
        SubTaskStatusMark subTaskStatusMark = SubTaskStatusMark.builder().tasks(tasks).statusMarkedDate(new Date()).markedStatus("Not Started").statusMarkedBy(tasks.getRaisedBy()).build();
        subTaskStatusMarkRepository.save(subTaskStatusMark);
        emailService.sendSubTaskAssignEmail(taskAssignments);
        log.info("sub task added in parent task Id {}", parentId);
        return tasksMapper.mapToTaskDto(tasks);
    }

    @Override
    public TasksDto updateSubTask(TasksDto tasksDto, long taskId) {
        Tasks existingTask = tasksRepository.findById(taskId).orElseThrow(() -> new RuntimeException("Task not found with id" + taskId));
        existingTask.setTaskName(tasksDto.getTaskName());
        existingTask.setDescription(tasksDto.getDescription());
        existingTask.setTaskPriority(tasksDto.getTaskPriority());
        existingTask.setTentativeEndDate(tasksDto.getTentativeEndDate());
        existingTask = tasksRepository.save(existingTask);
        TaskAssignments taskAssignments = TaskAssignments.builder().assignedBy(existingTask.getRaisedBy()).assignDate(new Date()).assignTaskId(existingTask.getId()).employeeId(tasksDto.getAssignedTo()).tasks(existingTask).isAssigned(1).build();
        taskAssignmentsRepository.save(taskAssignments);
        log.info("updating sub task by sub task Id {}", taskId);
        return mapData(List.of(existingTask)).get(0);
    }

    @Override
    public void markSubTaskStatus(SubTaskStatusDto subTaskStatusDto) {
        Tasks tasks = tasksMapper.mapToTask(subTaskStatusDto.getTasksDto());
        SubTaskStatusMark subTaskStatusMark = SubTaskStatusMark.builder().tasks(tasks).statusMarkedDate(new Date()).markedStatus(subTaskStatusDto.getMarkedStatus()).statusMarkedBy(subTaskStatusDto.getStatusMarkedBy()).remark(subTaskStatusDto.getRemark()).build();
        subTaskStatusMarkRepository.save(subTaskStatusMark);
        log.info("status marked for sub task id {}", subTaskStatusDto.getTasksDto().getTaskId());
    }

    @Override
    public StatusProprietorResultDto getLatestProprietorAndStatus(long empId, String designation) throws Exception {
        List<ProprietorAssignments> proprietorAssignments = List.of();
        if ("CHIEF TECHNOLOGY OFFICER".equalsIgnoreCase(designation) || "Management".equalsIgnoreCase(designation) || empId==19954) {
            proprietorAssignments = proprietorAssignmentsRepository.findAll();
        } else {
            //TrayMaster tray = trayMasterRepository.findByTrayName(designation);
            ProprietorMaster proprietorMaster = proprietorMasterRepository.findByProprietorName(designation);
            proprietorAssignments = proprietorAssignmentsRepository.findByProprietor_ProprietorId(proprietorMaster.getProprietorId());
        }

        HierarchyMatrixResponse hierarchyMatrix = apiClient.getHierarchyMatrix(String.valueOf(empId));
        List<HierarchyMatrixResponse.Hierarchy> hierarchies = hierarchyMatrix.getData();

        List<Long> employeeNoList = hierarchies.stream()
                .filter(a -> a.getLv().equalsIgnoreCase("Lower"))
                .map(a -> Long.parseLong(a.getEmployeeNo()))
                .toList();

        Map<String, Long> statusMap = proprietorAssignments.stream()
                .map(ProprietorAssignments::getStatus)
                .filter(Objects::nonNull)
                .collect(Collectors.toMap(StatusDefinitions::getStatus, status -> 0L, (existing, replacement) -> existing));


        Map<String, Long> proprietorMap = proprietorAssignments.stream()
                .map(ProprietorAssignments::getProprietor)
                .filter(Objects::nonNull)
                .collect(Collectors.toMap(ProprietorMaster::getProprietorName, proprietor -> 0L, (existing, replacement) -> existing));

        List<Tasks> allTask = tasksRepository.findAll().stream()
                .filter(task -> task.getParentTask() == null)
                .toList();

        List<Tasks> taskByEmp = allTask.stream()
                .filter(tasks1 -> employeeNoList.contains(tasks1.getRaisedBy()) ||
                        taskAssignmentsRepository.findByTaskIds(List.of(tasks1.getId()))
                                .stream()
                                .anyMatch(taskAssignments1 -> employeeNoList.contains(taskAssignments1.getEmployeeId())))
                .toList();

        Map<String, Map<String, Long>> stringMapMap = new HashMap<>();

        statusMap.keySet().forEach(status -> {
            Map<String, Long> initializedProprietorMap = proprietorMap.entrySet()
                    .stream()
                    .collect(Collectors.toMap(Map.Entry::getKey, entry -> 0L));
            stringMapMap.put(status, initializedProprietorMap);
        });

        taskByEmp.forEach(task -> {
            TaskTimelines latestTimeline = taskTimeLinesRepository.findByTaskIds(List.of(task.getId())).stream()
                    .max(Comparator.comparing(TaskTimelines::getDateAndTime))
                    .orElse(null);

            if (latestTimeline != null) {
                String taskStatus = latestTimeline.getStatus().getStatus();
                String taskProprietor = latestTimeline.getProprietor().getProprietor().getProprietorName();
                if (taskStatus != null && stringMapMap.containsKey(taskStatus)) {
                    Map<String, Long> proprietorMapForStatus = stringMapMap.get(taskStatus);
                    if (taskProprietor != null && proprietorMapForStatus.containsKey(taskProprietor)) {
                        proprietorMapForStatus.put(taskProprietor, proprietorMapForStatus.get(taskProprietor) + 1);
                    }
                }

                if (taskStatus != null && statusMap.containsKey(taskStatus)) {
                    statusMap.put(taskStatus, statusMap.get(taskStatus) + 1);
                }

                if (taskProprietor != null && proprietorMap.containsKey(taskProprietor)) {
                    proprietorMap.put(taskProprietor, proprietorMap.get(taskProprietor) + 1);
                }
            }
        });
        log.info("fetching status and proprietor count for dashboard successfully");
        return new StatusProprietorResultDto(statusMap, proprietorMap, stringMapMap);
    }

    @Override
    public List<TaskListResponse> getAllTaskList() {
        List<Tasks> tasksList=tasksRepository.findAll();
        tasksList=tasksList.stream().filter(a->a.getParentTask()==null).toList();
        return tasksList.stream()
                .map(tasks -> new TaskListResponse(tasks.getTaskId(), tasks.getTaskName()))
                .collect(Collectors.toList());
    }

    public String saveFile(MultipartFile multipartFile, String originalFileName, String path) throws IOException {
        String fileName = multipartFile.getOriginalFilename();

        fileName = (fileName != null && !fileName.isEmpty()) ? fileName : "attachment_" + System.currentTimeMillis();
        File directory = new File(path + File.separator + originalFileName);
        if (!directory.exists()) {
            directory.mkdirs();
        }
        File file = new File(directory, fileName);
        multipartFile.transferTo(file);
        return file.getAbsolutePath();
    }


    public List<TasksDto> mapData(List<Tasks> tasks) {
        List<Long> taskIds = tasks.stream().map(Tasks::getId).toList();
        Map<Long, List<TaskAssignments>> assignmentsByTaskId = taskAssignmentsRepository.findByTaskIds(taskIds)
                .stream()
                .collect(Collectors.groupingBy(assignment -> assignment.getTasks().getId()));

        Map<Long, List<TaskTimelines>> timelinesByTaskId = taskTimeLinesRepository.findByTaskIds(taskIds)
                .stream()
                .collect(Collectors.groupingBy(timeline -> timeline.getTasks().getId()));

        Map<Long, List<AdditionalRequirement>> additionalRequirementIds = additionalRequirementRepository.findByTaskIds(taskIds)
                .stream().
                collect(Collectors.groupingBy(additional -> additional.getTasks().getId()));

        Map<Long, List<SubTaskStatusMark>> subStatusMarkList = subTaskStatusMarkRepository.findByTaskIds(taskIds)
                .stream().
                collect(Collectors.groupingBy(taskStatusMark -> taskStatusMark.getTasks().getId()));

        Map<Long, List<Meetings>> meetingsByTask = meetingsRepository.findByTasks_TaskIds(taskIds)
                .stream()
                .collect(Collectors.groupingBy(meetings -> meetings.getTasks().getId()));

        return tasks.stream().map(task -> {
            TasksDto tasksDto = tasksMapper.mapToTaskDto(task);

            if (task.getDateAndTime() != null) {
                tasksDto.setDateAndTime(DateConverter.convertDateTime(task.getDateAndTime()));
            }
            tasksDto.setTentativeEndDate(task.getTentativeEndDate());

            List<TaskAssignments> assignments = assignmentsByTaskId.getOrDefault(task.getId(), List.of());
            List<TaskAssignmentDto> assignmentDtos = assignments.stream()
                    .map(tasksMapper::mapToTaskAssignmentDto)
                    .toList();
            if (task.getParentTask() != null) {
                tasksDto.setAssignedTo(assignmentDtos.get(0).getEmployeeId());
            }
            tasksDto.setTaskAssignmentHistoryDto(assignmentDtos);
            if (task.getParentTask() == null) {
                List<TaskTimelines> timelines = timelinesByTaskId.getOrDefault(task.getId(), List.of());
                List<TaskTimelineDto> timelineDtos = timelines.stream()
                        .map(tasksMapper::mapToTaskTimeLineDto)
                        .toList();
                tasksDto.setTaskTimelineDto(timelineDtos);
            } else {
                List<SubTaskStatusMark> subTaskStatusMarks = subStatusMarkList.getOrDefault(task.getId(), List.of());
                List<SubTaskStatusDto> subTaskStatusDtos = subTaskStatusMarks.stream().
                        map(tasksMapper::mapToSubTaskStatusDto)
                        .toList();
                tasksDto.setSubTaskStatusDtos(subTaskStatusDtos);
            }

            List<AdditionalRequirement> additionalRequirements = additionalRequirementIds.getOrDefault(task.getId(), List.of());
            List<AdditionalRequirementDto> additionalRequirementDtos = additionalRequirements.stream()
                    .map(tasksMapper::mapToAdditionalRequirementDto)
                    .toList();
            tasksDto.setAdditionalRequirementDtos(additionalRequirementDtos);

            List<Meetings> meetings = meetingsByTask.getOrDefault(task.getId(), List.of());
            List<MeetingsDto> meetingsDtos = meetings.stream().map(tasksMapper::mapToMeetingDto).toList();
            tasksDto.setMeetings(meetingsDtos);

            try {
                EmployeeProfileResponse employeeProfile = apiClient.getEmployeeProfile(String.valueOf(tasksDto.getRaisedBy()));
                tasksDto.setRaisedByName(employeeProfile.getData().get(0).getEmployeeFullName());
                tasksDto.setDepartmentAndDesignation(employeeProfile.getData().get(0).getDesignation()+" - "+employeeProfile.getData().get(0).getDepartmentName());
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            return tasksDto;
        }).toList();

    }

    @Override
    public StatusProprietorResultDto getProprietorAndStatusByStakeHolder(long empId, String designation) {
        List<Tasks> tasks = tasksRepository.findByRaisedBy(empId);
        List<TasksDto> tasksDtos = mapData(tasks);

        Map<String, Long> statusMap = tasksDtos.stream()
                .flatMap(taskDto -> taskDto.getTaskTimelineDto().stream())
                .map(TaskTimelineDto::getStatusDefinitionsDto)
                .filter(Objects::nonNull)
                .collect(Collectors.toMap(StatusDefinitionsDto::getStatus, status -> 0L, (existing, replacement) -> existing));

        Map<String, Long> proprietorMap = tasksDtos.stream()
                .flatMap(taskDto -> taskDto.getTaskTimelineDto().stream())
                .map(TaskTimelineDto::getProprietorAssignmentsDto)
                .filter(Objects::nonNull)
                .map(ProprietorAssignmentsDto::getProprietorMasterDto)
                .filter(Objects::nonNull)
                .collect(Collectors.toMap(ProprietorMasterDto::getProprietorName, proprietor -> 0L, (existing, replacement) -> existing));

        Map<String, Map<String, Long>> stringMapMap = new HashMap<>();

        statusMap.keySet().forEach(status -> {
            Map<String, Long> initializedProprietorMap = proprietorMap.entrySet()
                    .stream()
                    .collect(Collectors.toMap(Map.Entry::getKey, entry -> 0L));
            stringMapMap.put(status, initializedProprietorMap);
        });

        tasksDtos.forEach(task -> {
            TaskTimelines latestTimeline = taskTimeLinesRepository.findByTaskIds(List.of(task.getId())).stream()
                    .max(Comparator.comparing(TaskTimelines::getDateAndTime))
                    .orElse(null);

            if (latestTimeline != null) {
                String taskStatus = latestTimeline.getStatus().getStatus();
                String taskProprietor = latestTimeline.getProprietor().getProprietor().getProprietorName();
                if (taskStatus != null && stringMapMap.containsKey(taskStatus)) {
                    Map<String, Long> proprietorMapForStatus = stringMapMap.get(taskStatus);
                    if (taskProprietor != null && proprietorMapForStatus.containsKey(taskProprietor)) {
                        proprietorMapForStatus.put(taskProprietor, proprietorMapForStatus.get(taskProprietor) + 1);
                    }
                }

                if (taskStatus != null && statusMap.containsKey(taskStatus)) {
                    statusMap.put(taskStatus, statusMap.get(taskStatus) + 1);
                }

                if (taskProprietor != null && proprietorMap.containsKey(taskProprietor)) {
                    proprietorMap.put(taskProprietor, proprietorMap.get(taskProprietor) + 1);
                }
            }
        });
        log.info("fetching status and proprietor count for dashboard successfully");
        return new StatusProprietorResultDto(statusMap, proprietorMap, stringMapMap);
    }

}
