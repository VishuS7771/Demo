import axiosInstance from './Axios';  // Import your axiosInstance

export async function createProprietorAssignment(proprietorAssignmentDto: any) {
  const response = await axiosInstance.post(`/proprietor/proprietor-assignments`, proprietorAssignmentDto);
  return response.data;
}

export async function updateProprietorAssignment(id: number, proprietorAssignmentDto: any) {
  const response = await axiosInstance.put(`/proprietor/proprietor-assignments/${id}`, proprietorAssignmentDto);
  return response.data;
}

export async function getAllProprietorAssignments() {
  const response = await axiosInstance.get(`/proprietor/get-proprietor-assignments`);
  return response.data;
}

export async function getProprietorAssignmentById(proprietorMappingId: number) {
  const response = await axiosInstance.get(`/proprietor/get-proprietor-assignments/${proprietorMappingId}`);
  return response.data;
}

export async function getAllProprietorMaster() {
  const response = await axiosInstance.get(`/proprietor/get-proprietors-master`);
  return response.data;
}

