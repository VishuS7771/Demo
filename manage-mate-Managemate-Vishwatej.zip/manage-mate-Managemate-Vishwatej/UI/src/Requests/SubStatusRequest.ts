
import axiosInstance from "./Axios";

  export async function createSubStatusMapping(subStatus: {} | undefined) {
    const response = await axiosInstance.post(`/sub-status/create`, subStatus);
    return response.data;
  }

  export async function getAllTrays() {
    const response = await axiosInstance.get(`/master/get-all-tray`);
    return response.data;
  }

  export async function getAllSubStatus() {
    const response = await axiosInstance.get(`/sub-status/all`);
    return response.data;
  }

  export async function updateSubStatus(id: number, subStatusData: {} | undefined) {
    const response = await axiosInstance.put(`/sub-status/update/${id}`, subStatusData);
    return response.data;
  }