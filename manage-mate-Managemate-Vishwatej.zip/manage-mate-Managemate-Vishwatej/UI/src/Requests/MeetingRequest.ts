import axiosInstance from './Axios'; // Import your axiosInstance

export async function createMeeting(meetingsDto: {} | null) {
  const response = await axiosInstance.post('/meetings/create-meeting', meetingsDto);
  return response.data;
}

export async function updateMeetingStatus(meetingId: string, meetingsDto: any) {
  const response = await axiosInstance.put(`/meetings/update-meeting-status/${meetingId}`, meetingsDto);
  return response.data;
}

export async function editMeeting(meetingId: string, meetingsDto: any) {
  const response = await axiosInstance.put(`/meetings/edit-meeting/${meetingId}`, meetingsDto);
  return response.data;
}

export async function getMeetingById(meetingId: string) {
  const response = await axiosInstance.get(`/meetings/get-by-meeting-id/${meetingId}`);
  return response.data.data;
}

export async function getMeetingsByTaskId(taskId: string) {
  const response = await axiosInstance.get(`/meetings/get-by-task-id/${taskId}`);
  return response.data;
}

export async function getParticipantsByMeetingId(meetingId: number) {
  const response = await axiosInstance.get(`/meetings/get-participants/${meetingId}`);
  return response.data.data;
}

export async function getAllEmployees() {
  const response = await axiosInstance.get('/master/get-all-employees');
  return response.data.data;
}

export async function getAllMeetings() {
  const response = await axiosInstance.get('/meetings/get-all-meetings');
  return response.data.data;
}

export async function getTaskByEmployee(empId: number) {
    const response = await axiosInstance.post(`/task-assignments/get-task-assignment/${empId}`);
    return response.data.data;
}

export async function getMeetingsByEmployee(employeeId: number) {
  const response = await axiosInstance.get(`/meetings/get-meetings-by-employee/${employeeId}`);
  return response.data.data;
}

export async function getMeetingByTaskId(taskId: number) {
  const response = await axiosInstance.get(`/meetings/get-meeting-by-task-id/${taskId}`);
  return response.data.data;
}
