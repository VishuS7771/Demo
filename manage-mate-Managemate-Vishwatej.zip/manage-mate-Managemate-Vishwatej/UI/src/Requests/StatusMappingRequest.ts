import axiosInstance from './Axios';  // Import your axiosInstance

export async function getstatus(tray: string) {
    const response = await axiosInstance.get(`/status-definitions/status-by-tray/${tray}`);
    return response.data;
}

export async function getAllStatus() {
    const response = await axiosInstance.get(`/status-definitions/get-all-status`);
    return response.data;
}

export async function addStatus(status: {} | undefined) {
    const response = await axiosInstance.post(`/status-definitions/create-status-definitions`, status);
    return response.data;
}

export async function updateStatusMapping(id: number, statusMappingDto: any) {
    const response = await axiosInstance.put(`/status-definitions/update-status/${id}`, statusMappingDto);
    return response.data;
}