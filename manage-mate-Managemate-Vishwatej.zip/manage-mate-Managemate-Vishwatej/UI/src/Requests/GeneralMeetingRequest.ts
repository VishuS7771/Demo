
import { CompletionDatePayload, GeneralMeetingReportDTO, GeneralMeetingTaskDto, MeetingTimelineData, TaskRespondDto } from '../Interfaces/Generalmeeting';
import axiosInstance from './Axios';

export async function createMeeting(generalMeetingDto: {} | null) {
  const response = await axiosInstance.post('/general-meetings/create', generalMeetingDto);
  return response.data;
}

export async function markStatus(markStatusDto: {} | null, file: File | null) {

  const formData = new FormData();
  formData.append("markStatusDto", JSON.stringify(markStatusDto));
  if (file) {
    formData.append("file", file);
  }
  const response = await axiosInstance.post(`/general-meetings/mark-status`, formData, {
    headers: {
      "Content-Type": "multipart/form-data",
    },
  });
  return response.data;
}

export async function getAllMettings(employeeNo: Number) {
  const response = await axiosInstance.get(`/general-meetings/get-all/${employeeNo}`)
  return response.data.data;
}


export async function editMeeting(generalMeetingDto: {} | null, meetingId: number) {
  const response = await axiosInstance.post(`/general-meetings/update-meetings/${meetingId}`, generalMeetingDto)
  return response.data;
}

export async function resheduleMeetings(meetingId: number | undefined, generalMeetingDto: {} | null) {
  const response = await axiosInstance.post(`/general-meetings/reschedule-meeting/${meetingId}`, generalMeetingDto)
  return response.data;
}


export async function getMasterData(param1: string, param2: number[]) {
  let response;
  if (param1 === "SEGMENTGRP") {
    response = await axiosInstance.get(`/master/get-master/${param1}`)
  }
  else if (param1 === "SUBDEPARTMENT") {
    response = await axiosInstance.get(`/master/get-master/${param1}`)
  }
  else {
    response = await axiosInstance.get(`/master/get-master/${param1}?para2=${param2}`)
  }
  return response.data.data;
}

export async function updateMeeting(generalMeetingId: number | undefined, generalMeetingDto: {} | null) {
  const response = await axiosInstance.post(`/general-meetings/update-meetings/${generalMeetingId}`, generalMeetingDto);
  return response.data;
}
export async function getGeneralMeetingTasks(meetingId: number) {
  const response = await axiosInstance.get(`/general-meetings/get-tasks/${meetingId}`)
  return response.data.data;
}

export async function getGeneralTasks(empId: number,flag:boolean) {
  const response = await axiosInstance.get(`/general-meetings/get-task-by-empid/${empId}/flag/${flag}`)
  return response.data.data;
}

export async function RespondMeetingTask(respondTask: TaskRespondDto, file: File | null) {
  const formData = new FormData();
  formData.append("taskRespondDto", JSON.stringify(respondTask));
  if (file) {
    formData.append("file", file);
  }
  const response = await axiosInstance.post(`/general-meetings/task-respond`, formData, {
    headers: {
      "Content-Type": "multipart/form-data",
    },
  });
  return response.data;
}

export async function MarkingMeetingTask(respondTask: TaskRespondDto) {
  const response = await axiosInstance.post(`/general-meetings/task-marked`, respondTask)
  return response.data;
}


export async function getRespondAndMarking(meetingTaskId: number): Promise<TaskRespondDto[]> {
  const response = await axiosInstance.get(`/general-meetings/get-respond/${meetingTaskId}`);
  return response.data.data;
}

export async function AddGeneralMeetingTask(addedTasks: GeneralMeetingTaskDto[]) {
  const response = await axiosInstance.post(`/general-meetings/add-task`, addedTasks)
  return response.data;
}

export async function EditGeneralMeetingTask(task: GeneralMeetingTaskDto) {
  const response = await axiosInstance.post(`/general-meetings/edit-task/${task.generalMeetingTaskId}`, task);
  return response.data;
}


export async function getGeneralMeeting(meetingId: number) {
  const response = await axiosInstance.get(`/general-meetings/get-general-meeting/${meetingId}`)
  return response.data.data;
}

export async function resendMeetingLink(meetingId: number) {
  const response = await axiosInstance.post(`/general-meetings/send-link/${meetingId}`)
  return response.data;
}

export async function downLoadStatusDocument(filepath: string): Promise<void> {
  try {
    const response = await axiosInstance.get(`/master/download-file`, {
      params: { filepath },
      responseType: "blob",
    });

    const contentDisposition = response.headers["content-disposition"];
    const matches = contentDisposition?.match(/filename="([^"]*)"/);
    const fileName = matches?.[1] || "downloaded_file";

    const blob = new Blob([response.data], {
      type: response.headers["content-type"] || "application/octet-stream",
    });

    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = fileName;

    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

  } catch (error) {
    console.error("Error downloading the document:", error);
  }

}

// GeneralMeetingRequest.ts
export async function getGeneralMeetingTimeline(generalMeetingId: number): Promise<MeetingTimelineData> {
  const response = await axiosInstance.get(`/general-meetings/timeline/${generalMeetingId}`);
  return response.data.data;
}

export async function getGeneralMeetingTaskTimelineHistory(generalMeetingTaskId: number) {
  const response = await axiosInstance.get(`/completion-date/task-timeline/${generalMeetingTaskId}`)
  return response.data;
}

export async function updateCompletionDate(completionDatePayload: CompletionDatePayload) {
  const response = await axiosInstance.post(`/completion-date/update`, completionDatePayload);
  return response.data;
}

export async function downloadGeneralMeetingReport(reportPayload: GeneralMeetingReportDTO): Promise<Blob> {
  const response = await axiosInstance.post('/report/general-meeting-report', reportPayload, {
    responseType: 'blob', // Important to handle file download
  });

  // Create a download link from the response
  const blob = new Blob([response.data], { type: response.headers['content-type'] });
  const downloadUrl = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = downloadUrl;

  // Try to extract filename from content-disposition
  const contentDisposition = response.headers['content-disposition'];
  let filename = 'GeneralMeetingReport.xlsx';
  if (contentDisposition) {
    const match = contentDisposition.match(/filename="(.+)"/);
    if (match?.[1]) {
      filename = match[1];
    }
  }

  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  window.URL.revokeObjectURL(downloadUrl);

  return blob;
}