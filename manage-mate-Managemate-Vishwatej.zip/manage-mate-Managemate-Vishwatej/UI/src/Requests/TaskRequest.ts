import { AdditonalRequirement, Task, TaskAssignmentHistoryDto } from "../Interfaces/Task";
import axiosInstance from "./Axios";

export async function addTask(task: {} | undefined, file: File | null) {
  try {
      const formData = new FormData();
    if (task) {
      formData.append("task", JSON.stringify(task));
    }
    if (file) {
      formData.append("file", file);
    }
    const response = await axiosInstance.post(`/tasks/add-task`, formData, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    });

    return response;
  } catch (error) {
    console.error("Error adding task:", error);
    throw error;
  }
}

export async function addSubTask(task: {} | undefined,file:File|null, parentTaskId?: number) {
  try {
    const formData = new FormData();
    if (task) {
      formData.append("task", JSON.stringify(task));
    }
    if (file) {
      formData.append("file", file);
    }
    if (parentTaskId !== undefined) {
      formData.append("parentTaskId", parentTaskId.toString());
    }
    const response = await axiosInstance.post(`/tasks/create-sub-task`, formData, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    });

    return response;
  } catch (error) {
    console.error("Error adding subtask:", error);
    throw error;
  }
}


export async function updateSubTask(task: {} | undefined, taskid?: number) {
  try {
  const response = await axiosInstance.post(`/tasks/edit-sub-task/${taskid}`, task);
  return response;
} catch (error) {
  console.error("Error adding task:", error);
  throw error;
}
}

export async function getTaskByDepartMent(deptId: {} | undefined) {
  const response = await axiosInstance.get(`/tasks/get-by-department/${deptId}`);
  return response;
}

export async function getTaskByDesignation(designationId: string | undefined,empId:number): Promise<Task[]> {
  const response = await axiosInstance.get(`/tasks/get-by-designation/${designationId}?empId=${empId}`);
  return response.data.data;
}

export async function getTaskByTaskId(taskId: {} | undefined) :Promise<Task> {
  const response = await axiosInstance.get(`/tasks/get-by-Id/${taskId}`);
  return response.data.data;
}

export async function getAllTask() {
  const response = await axiosInstance.get(`/tasks/get-all-tasks`);
  return response.data;
}

export async function getstatus(tray: string) {
  const response = await axiosInstance.get(`/status-definitions/status-by-tray/${tray}`);
  return response.data;
}

export async function getSubStatus(subStatusId: number) {
  const response = await axiosInstance.get(`/sub-status/sub-status-by-status/${subStatusId}`);
  return response.data;
}

export async function getPropriotor(statusId: number, subStatusId: number) {
  const response = await axiosInstance.get(`/proprietor/get-by-status-sub/${statusId}/${subStatusId}`);
  return response.data;
}

export async function getTrayList() {
  const response = await axiosInstance.get(`/master/get-all-tray`);
  return response.data;
}


export async function getUserList(tray: string) {
  const response = await axiosInstance.get(`/master/get-users-by-tray/${tray}`);
  return response.data;
}

export async function getTaskAssignmetHistory(taskId: number) {
  const response = await axiosInstance.get(`/task-assignments/get-by-taskId/${taskId}`);
  return response.data;
}

export async function getTaskTimeLine(taskId: number) {
  const response = await axiosInstance.get(`/task-time-line/get-by-task/${taskId}`);
  return response.data;
}


export async function getTaskByParentTaskid(taskId: {} | undefined): Promise<Task[]> {
  const response = await axiosInstance.get(`/tasks/get-by-parent/${taskId}`);
  return response.data.data;
}

export async function assignTask(taskAssignmentHistoryDto: TaskAssignmentHistoryDto ,file: File | null):Promise<any> {
  try {
    const formData = new FormData();
    formData.append("taskAssignmentHistoryDto", JSON.stringify(taskAssignmentHistoryDto)); 
    if (file) {
      formData.append("file", file);
    }
    const response = await axiosInstance.post(`/task-assignments/assign`, formData, {
      headers: {
        "Content-Type": "multipart/form-data", 
      },
    });
    return response.data;
  }catch(error){
    console.error("Error creating additional requirement:", error);
    throw error;
  }
}

export async function additionalRequirementReq(additionalRequiremnt: AdditonalRequirement, file: File | null): Promise<any> {
  try {
    const formData = new FormData();
    formData.append("additionalRequirement", JSON.stringify(additionalRequiremnt)); 
    if (file) {
      formData.append("file", file);
    }
    const response = await axiosInstance.post(`/additional-requirement/create`, formData, {
      headers: {
        "Content-Type": "multipart/form-data", 
      },
    });
    return response;
  } catch (error) {
    console.error("Error creating additional requirement:", error);
    throw error;
  }
}

export async function getmModuleList(empId: number) {
  const response = await axiosInstance.get(`/master/get-module/${empId}`);
  return response.data;
}


export async function getUserListSubTask(taskId: number) {
  const response = await axiosInstance.get(`/master/get-users-by-department/${taskId}`);
  return response.data;
}


export async function markSubTaskStatus(subTaskStatusMark: {} | undefined) {
  const response = await axiosInstance.post(`/tasks/mark-sub-task-status`,subTaskStatusMark);
  return response.data;
}

export async function saveTaskSearchCriteria(taskSearchCriteria:{}){
  const response = await axiosInstance.post(`/task-search-criteria/create`,taskSearchCriteria)
  return response.data;
}

export async function getTaskSearchCriteria(empId:number) {
  const response= await axiosInstance.get(`task-search-criteria/get-by-employee/${empId}`)
  return response.data;
}

export async function addTimeline(taskTimeline: {} | undefined, taskId?: number) {
  const response = await axiosInstance.post(`/task-time-line/markStatus/${taskId}`, taskTimeline);
  return response.data;
}
export async function getProprietorAndStatus(empId: number, designation: string | undefined) {
  const response = await axiosInstance.get(`/tasks/get-proprietor-status/${empId}/${designation}`);
  return response.data.data;
}

export async function getStakeHolderProprietorAndStatus(empId: number, designation: string | undefined) {
  const response = await axiosInstance.get(`/tasks/get-stakeholder-proprietor-status/${empId}/${designation}`);
  return response.data.data;
}

export async function downLoadDocument(filepath: string): Promise<void> {
  try {
    const response = await axiosInstance.get(`/master/download-file`, {
      params: { filepath },
      responseType: "blob",
    });

    const contentDisposition = response.headers["content-disposition"];
    const matches = contentDisposition?.match(/filename="([^"]*)"/);
    const fileName = matches?.[1] || "downloaded_file";

    const blob = new Blob([response.data], {
      type: response.headers["content-type"] || "application/octet-stream",
    });

    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = fileName;

    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

  } catch (error) {
    console.error("Error downloading the document:", error);
  }

}

export async function addModule(module: {} | undefined) {
  const response = await axiosInstance.post(`/module-assignment/save-assignment`, module);
  return response.data;
}

export async function getAllModules() {
  const response = await axiosInstance.get('/module-assignment/getAll');
  return response.data;
}

export async function updateModuleMapping(moduleMappingId: number, moduleAssignmentDto: any) {
  const response = await axiosInstance.put(`/module-assignment/update-assignment/${moduleMappingId}`, moduleAssignmentDto);
  return response.data;
}

export async function getTaskList() {
  const response = await axiosInstance.get(`/tasks/get-task-list`);
  return response.data;
}

export async function updateTask(task: {} | undefined) {
  try {
  const response = await axiosInstance.post(`/tasks/edit-task`, task);
  return response;
} catch (error) {
  console.error("Error adding task:", error);
  throw error;
}
}