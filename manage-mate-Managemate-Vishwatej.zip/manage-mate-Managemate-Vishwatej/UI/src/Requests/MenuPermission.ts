import { StakeHolders } from "../component/DashBoard";
import { MenuPermission, MenuPermissionAccess } from "../Interfaces/MenuPermission";
import { ReportState, StakeHolderManagementUser } from "../Interfaces/Task";
import axiosInstance from "./Axios";

export async function addMenuPermission( menuPermission: MenuPermission | undefined) {
    const response = await axiosInstance.post(`/menu-permission/add`,menuPermission);
    return response.data;
  }

export async function getMenuPermission(empId:number){
  const response =await axiosInstance.get(`/menu-permission/get/${empId}`);
  return response.data;
}

export async function getMenuPermissionAccess(): Promise<MenuPermissionAccess[]>{
  const response =await axiosInstance.get(`/menu-permission/get-menu-permission-access`);
  return response.data.data;
}

export async function getAllStakeholders(): Promise<StakeHolders[]>{
  const response =await axiosInstance.get(`/master/get-stakeholders`)
  return response.data.data;
}

export async function downloadReport(report: ReportState): Promise<void> {
  try {

    const formattedReport = {
      ...report,
      fromDate: report.dateFrom ? new Date(report.dateFrom).toISOString() : null,
      toDate: report.dateTo ? new Date(report.dateTo).toISOString() : null,
    };

    const response = await axiosInstance.post(`/report/download-report`, formattedReport, {
      responseType: "blob",
    });

    const contentDisposition = response.headers["content-disposition"];
    const fileNameMatch = contentDisposition?.match(/filename="([^"]*)"/);
    const fileName = fileNameMatch ? fileNameMatch[1] : "Downloaded_Project_Tracker.xlsx";
    
    const blob = new Blob([response.data], {
      type: response.headers["content-type"] || "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });

    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = fileName; 
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

  } catch (error) {
    console.error("Error downloading the document:", error);
  }
}


export async function createStakeholderManagementUser(createStakeholderManagementUser: StakeHolderManagementUser | undefined) {
  if (!createStakeholderManagementUser) {
    throw new Error("Invalid user data");
  }

  const { userType } = createStakeholderManagementUser;

  try {
    if (userType === "MANAGEMENT-USER") {
      createStakeholderManagementUser.userType = "MANAGEMENT-USER";
    } else if (userType === "STAKEHOLDER") {
      createStakeholderManagementUser.userType = "STAKEHOLDER";
    }
    else {
      throw new Error("Invalid user type");
    }
    const response = await axiosInstance.post("/master/create-user", createStakeholderManagementUser);
    return response.data.data;
  } catch (error) {
    console.error("Error creating user:", error);
    throw error;
  }
}


export async function deleteStakeholderManagementUser(deleteStakeholderManagementUser: StakeHolderManagementUser | undefined) {
  if (!deleteStakeholderManagementUser) {
    throw new Error("Invalid user data");
  }

  const { userType } = deleteStakeholderManagementUser;

  try {
    if (userType === "MANAGEMENT_USER") {
      deleteStakeholderManagementUser.userType = "MANAGEMENT-USER";
    } else if (userType === "STAKEHOLDER") {
      deleteStakeholderManagementUser.userType = "STAKEHOLDER";
    }
    else {
      throw new Error("Invalid user type");
    }
    const response = await axiosInstance.delete(`/master/delete-user`, { data: deleteStakeholderManagementUser });
    return response.data;
  } catch (error) {
    console.error("Error creating user:", error);
    throw error;
  }
}

export async function getAllStakeholderManagementUser() {
  const response = await axiosInstance.get(`/master/get-all-users`);
  return response.data.data;
}

export async function checkIfUserExists(user: StakeHolderManagementUser) {
  try {
    const response = await axiosInstance.get(`/master/check-user-exists/${user.userType}/${user.userId}`);
    return response.data;
  } catch (error) {
    console.error("Error checking user existence:", error);
    throw error;
  }
}