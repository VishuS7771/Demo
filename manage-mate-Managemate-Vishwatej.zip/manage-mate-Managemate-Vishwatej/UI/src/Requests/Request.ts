import { MenuPermission } from "../Interfaces/MenuPermission";
import axiosInstance from "./Axios";

export async function logIn(LoginDto: {} | undefined) {
  try {
    const response = await axiosInstance.post("/auth/login", LoginDto);

    const { jwt, employeeNo, login, menuPermission,menuPermissionAccess }: LoginResponseData = response.data.data;

    localStorage.setItem('token', jwt);
    localStorage.setItem('employeeNo', employeeNo);
    localStorage.setItem('isLogin', String(login));
    localStorage.setItem('menuPermissionAccess', String(menuPermissionAccess));

    localStorage.setItem('menuPermission', JSON.stringify(menuPermission));

    return response.data.data;
  } catch (error) {
    console.error("Error during login:", error);
    throw new Error("Failed to log in. Please try again.");
  }
}
  interface LoginResponseData {
    jwt: string;
    employeeNo: string;
    login: boolean;
    menuPermission: MenuPermission;
    menuPermissionAccess:boolean
  }
  