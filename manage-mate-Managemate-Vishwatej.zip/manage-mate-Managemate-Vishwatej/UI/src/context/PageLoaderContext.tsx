import { createContext, useState, useContext, ReactNode } from 'react';

interface PageLoaderContextType {
  isLoading: boolean;
  showLoader: () => void;
  hideLoader: () => void;
}

interface PageLoaderProviderProps {
  children: ReactNode;
}

const PageLoaderContext = createContext<PageLoaderContextType>({
  isLoading: false,
  showLoader: () => {},
  hideLoader: () => {},
});

export const PageLoaderProvider = ({ children }: PageLoaderProviderProps) => {
  const [isLoading, setIsLoading] = useState(false);

  const showLoader = () => setIsLoading(true);
  const hideLoader = () => setIsLoading(false);

  return (
    <PageLoaderContext.Provider value={{ isLoading, showLoader, hideLoader }}>
      {children}
    </PageLoaderContext.Provider>
  );
};

export const usePageLoader = () => useContext(PageLoaderContext);
