import { BrowserRouter, Route, Routes, Navigate, useLocation } from "react-router-dom";
import Login from "./component/Login";
import AddTasks from "./component/Task/AddTasks";
import Header from "./component/Header";
// import Footer from "./component/Footer";
import AuthProvider from "./component/Auth/AuthContext";
import AddStatusMapping from "./component/StatusMapping/AddStatusMapping";
import Proprietor from "./component/Proprietor/Proprietor";
import SubStatusForm from "./component/SubStatus/SubStatusForm";
import Meeting from "./component/Meeting/Meeting";
import MenuPermissionTable from "./component/MenuPermission/MenuPermission";
import { ToastContainer } from "react-toastify";
import DashBoard from "./component/DashBoard";
import ProtectedRoute from "./component/ProtectedRoute";
import ViewPage from "./component/Task/ViewPage";
import ReportComponent from "./component/Report/Report";
import UserMapping from "./component/StatusMapping/UserMapping";
import { CSSProperties, useState } from "react";
import { PageLoaderProvider, usePageLoader } from "./context/PageLoaderContext";
import LinearProgressBar from "./component/Loader/Loader";
import MappingMaster from "./component/MappingMaster/MappingMaster";
import SubTasksDetails from "./component/Task/SubTasksDetails";
// import { ThemeProvider } from "@mui/material";
// import theme from "./util/theme";
import GeneralMeeting from "./component/GeneralMeeting/GeneralMeeting";
import AddGeneralMeetingTask from "./component/GeneralMeeting/AddGeneralMeetingTask";
import AddGeneralTasks from "./component/GeneralMeeting/AddGeneralTasks";
import BaTray from "./component/Tray/BaTray";
import InquiryTray from "./component/Tray/InquiryTray";
import MeetingDetails from "./component/Meeting/MeetingDetails";
import SidebarNav from "./component/Sidebar";
import { LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import MyTasks from "./component/GeneralMeeting/MyTasks";
import GeneralMeetingReport from "./component/GeneralMeeting/GeneralMeetingReport";

const containerStyle = {
  minHeight: "100vh",
  backgroundColor: "#f5f5f5",
};

const mainContentStyle = (isSidebarCollapsed: boolean, hideLayout: boolean): CSSProperties => ({
  flexGrow: 1,
  marginLeft: hideLayout
    ? "0"
    : window.innerWidth < 768
      ? "80px"
      : isSidebarCollapsed
        ? "80px"
        : "250px",
  display: "flex",
  flexDirection: "column",
  padding: "10px 20px 20px 20px",
  transition: hideLayout || window.innerWidth < 768 ? "none" : "width, left, right, 300ms",
});


// const contentStyle = {
//   flexGrow: 1,
//   backgroundColor: "#ffffff",
//   padding: "20px",
//   borderRadius: "10px",
//   boxShadow: "0px 4px 10px rgba(0, 0, 0, 0.1)",
//   transition: "width 0.3s ease-in-out", // Smooth transition for width
// };

function AppLayout({ children }: { children: React.ReactNode }) {
  const location = useLocation();
  const [isSidebarCollapsed, setSidebarCollapsed] = useState(false);
  const { isLoading } = usePageLoader();

  const hideLayout = ["/ui/login", "/ui/some-other-route"].includes(location.pathname);

  return (
    <div className="App" style={containerStyle}>
      <LinearProgressBar isLoading={isLoading} />
      {!hideLayout && <SidebarNav collapsed={isSidebarCollapsed} setCollapsed={setSidebarCollapsed} />}
      <div style={mainContentStyle(isSidebarCollapsed, hideLayout)}>
        {!hideLayout && <Header />}
        <div
        // style={contentStyle}
        >{children}</div>
      </div>
    </div>
  );
}

function App() {
  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <AuthProvider>
        <PageLoaderProvider>
          <BrowserRouter>
            <AppLayout>
              <Routes>

                <Route path="/ui/task/:TaskId" element={
                  <ProtectedRoute>
                    <AddTasks />
                  </ProtectedRoute>
                } />

                <Route path="/ui/BaTray" element={
                  <ProtectedRoute>
                    <BaTray />
                  </ProtectedRoute>
                } />

                <Route path="/ui/MappingMaster" element={
                  <ProtectedRoute>
                    <MappingMaster />
                  </ProtectedRoute>
                } />

                <Route path="/ui/SubStatus" element={
                  <ProtectedRoute>
                    <SubStatusForm />
                  </ProtectedRoute>
                } />

                <Route path="/ui/StatusMapping" element={
                  <ProtectedRoute>
                    <AddStatusMapping />
                  </ProtectedRoute>
                } />

                <Route path="/ui/Proprietor" element={
                  <ProtectedRoute>
                    <Proprietor />
                  </ProtectedRoute>
                } />

                <Route path="/ui/user-mapping" element={
                  <ProtectedRoute>
                    <UserMapping />
                  </ProtectedRoute>
                } />

                <Route path="/ui/Meeting" element={
                  <ProtectedRoute>
                    <Meeting />
                  </ProtectedRoute>
                } />

                <Route path="/ui/GeneralMeeting" element={
                  <ProtectedRoute>
                    <GeneralMeeting />
                  </ProtectedRoute>
                } />
                <Route path="/ui/AddGeneralTasks" element={
                  <ProtectedRoute>
                    <AddGeneralTasks />
                  </ProtectedRoute>
                } />
                <Route path="/ui/MyTasks" element={
                  <ProtectedRoute>
                    <MyTasks />
                  </ProtectedRoute>
                } />
                <Route path="/ui/GeneralMeetingReport" element={
                  <ProtectedRoute>
                    <GeneralMeetingReport />
                  </ProtectedRoute>
                } />
                <Route path="/ui/Meeting/Tasks/:meetingId" element={
                  <ProtectedRoute>
                    <AddGeneralMeetingTask />
                  </ProtectedRoute>
                } />

                <Route path="/ui/MeetingDetails/:taskId" element={
                  <ProtectedRoute>
                    <MeetingDetails />
                  </ProtectedRoute>
                } />

                <Route path="/ui/inquiry-tray" element={
                  <ProtectedRoute>
                    <InquiryTray />
                  </ProtectedRoute>
                } />

                <Route path="/ui/sub-task/:parentTaskId" element={
                  <ProtectedRoute>
                    <SubTasksDetails />
                  </ProtectedRoute>
                } />

                <Route path="/ui/menu-permission" element={
                  <ProtectedRoute>
                    <MenuPermissionTable />
                  </ProtectedRoute>
                } />

                <Route path="/ui/task-detail-view/:taskId" element={
                  <ProtectedRoute>
                    <ViewPage />
                  </ProtectedRoute>
                } />

                <Route path="/ui/report" element={
                  <ProtectedRoute>
                    <ReportComponent />
                  </ProtectedRoute>
                } />
                <Route path="/ui/login" element={<Login />} />
                <Route path="/" element={<Navigate to="/ui/login" />} />
                <Route path="/ui" element={<Navigate to="/ui/login" />} />
                <Route path="/ui/MeetingDetails" element={<MeetingDetails />} />
                <Route path="/ui/Meeting" element={<Meeting />} />
                <Route path="/ui/dashboard" element={<DashBoard />} />
              </Routes>
            </AppLayout>
            <ToastContainer />
          </BrowserRouter>
        </PageLoaderProvider>
      </AuthProvider>
    </LocalizationProvider>
  );
}

export default App;