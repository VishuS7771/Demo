
import { EmployeeOption, GeneralMeetingTaskDto, TaskValidationError, ValidationError } from "../../Interfaces/Generalmeeting";

interface ValidateFormParams {
    status: string;
    selectedEmployees: EmployeeOption[];
    reasonForCancellation: string;
    mom: string;
    setErrors: (errors: ValidationError) => void;
}

export const validateForm = ({
    status,
    selectedEmployees,
    reasonForCancellation,
    mom,
    setErrors,
}: ValidateFormParams): boolean => {
    let isValid = true;
    const newErrors: ValidationError = {};

    if (status === "Select") {
        newErrors.status = "Status not selected.";
        isValid = false;
    }

    if (status === "Cancelled" && !reasonForCancellation) {
        newErrors.reasonForCancellation = "Reason for cancellation is required when the meeting is cancelled.";
        isValid = false;
    }

    if (status === "Completed" && !mom) {
        newErrors.mom = "MOM is required when the meeting is completed.";
        isValid = false;
    }

    if (selectedEmployees.length === 0) {
        newErrors.participants = "Meeting participants not selected.";
        isValid = false;
    }

    setErrors(newErrors);
    return isValid;
};


export const validateTask = (task: GeneralMeetingTaskDto, setTaskErrors: (errors: TaskValidationError) => void
): boolean => {
    let isValid = true;
    const newErrors: TaskValidationError = {};

    if (!task.taskName.trim()) {
        newErrors.taskName = "Task name is required.";
        isValid = false;
    }

    if (!task.status.trim()) {
        newErrors.status = "Status is required.";
        isValid = false;
    }

    if (!task.remark.trim()) {
        newErrors.remark = "Remark is required.";
        isValid = false;
    }

    if (!task.employeeIds || task.employeeIds.length === 0) {
        newErrors.employeeIds = "At least one employee must be assigned.";
        isValid = false;
    }

    if (!task.targetDate) {
        newErrors.targetDate = "Target date is required.";
        isValid = false;
    }
    if ( !task.generalMeetingId &&  task.segmentDtos.length == 0) {
        newErrors.segment = "Please select at least one segment.";
        isValid = false;
    }
    if (!task.generalMeetingId  && task.departmentDtos.length == 0 ) {
        newErrors.department = "Please select at least one department.";
        isValid = false;
    }

    setTaskErrors(newErrors);
    return isValid;
};




