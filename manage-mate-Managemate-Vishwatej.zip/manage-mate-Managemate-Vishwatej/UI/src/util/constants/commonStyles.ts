import { Box, InputBase, styled } from "@mui/material";

export const Search = styled('div')(({ theme }) => ({
    position: 'relative',
    borderRadius: theme.shape.borderRadius,
    backgroundColor: "rgb(246, 247, 251)",
    '&:hover': {
        backgroundColor: "rgb(246, 247, 251)",
    },
    marginLeft: 0,
    width: '40ch',
    [theme.breakpoints.up('sm')]: {
        marginLeft: theme.spacing(1),
        // marginBottom: theme.spacing(2),
        marginRight: theme.spacing(2),
        width: '40ch',
    },
}));

export const SearchIconWrapper = styled('div')(() => ({
    height: '100%',
    position: 'absolute',
    pointerEvents: 'none',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
}));

export const StyledInputBase = styled(InputBase)(({ theme }) => ({
    color: 'inherit',
    width: '100%',
    '& .MuiInputBase-input': {
        padding: theme.spacing(1, 1, 1, 0),
        paddingLeft: `calc(1em + ${theme.spacing(4)})`,
        transition: theme.transitions.create('width'),
        [theme.breakpoints.up('sm')]: {
            width: '25ch',
            '&:focus': {
                width: '25ch',
            },
        },
    },
}));

export const iconButtonStyles = {
    transition: "0.3s",
    "&:hover": {
        backgroundColor: "#b3b3b3",
    },
};

export const actionButtonStyle = {
    backgroundColor: 'rgba(73, 102, 131, 0.15)',
    backdropFilter: 'blur(6px)',
    color: 'rgb(73, 102, 131)',
    border: '1px solid rgba(73, 102, 131, 0.3)',
    textTransform: 'none',
    fontWeight: 500,
    boxShadow: '0 1px 4px rgba(0,0,0,0.1)',
    '&:hover': {
        backgroundColor: 'rgba(73, 102, 131, 0.25)',
        color: 'rgb(73, 102, 131)',
    },
}

export const DropZone = styled(Box)(({ theme }) => ({
  border: `2px dashed ${theme.palette.divider}`,
  borderRadius: theme.shape.borderRadius,
  padding: theme.spacing(2),
  textAlign: "center",
  cursor: "pointer",
  backgroundColor: theme.palette.grey[200],
  "&:hover": {
    backgroundColor: theme.palette.grey[300],
  },
  "&.dragover": {
    borderColor: theme.palette.primary.main,
    backgroundColor: theme.palette.grey[900],
  },
}));

export const employeeCellStyles = {
    margin:"0 auto",
    width:"70px",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    gap: "8px",
    padding: "4px 8px",
    borderRadius: "16px",
    backgroundColor: "rgb(246, 247, 251)",
    border: "1px solid rgb(73, 102, 131)",
    transition: "0.3s",
    "&:hover": {
        backgroundColor: "rgb(230, 231, 235)",
        cursor: "pointer",
    },
};

export const tooltipProps = {
    componentsProps: {
        tooltip: {
            sx: {
                bgcolor: "#2c3e50",
                color: "white",
                fontSize: 12,
                maxWidth: 400,
                padding: '8px 12px',
                whiteSpace: 'pre-wrap',
            }
        }
    },
};

export const menuPermissionCardStyles = {
    selectAllBox: {
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        backgroundColor: "#e8ecef",
        p: 1.5,
        borderRadius: 2,
        mb: 4,
        transition: "all 0.3s ease",
        "&:hover": {
            backgroundColor: "#dfe4e8",
            boxShadow: "0 2px 8px rgba(0, 0, 0, 0.1)",
        },
    },
    selectAllText: {
        fontSize: { xs: 14, sm: 16 },
        color: "#1a3c34",
    },
    groupTitle: {
        display: "flex",
        alignItems: "center",
        gap: 1,
        mb: 1,
        "& .MuiTypography-root": {
            fontWeight: 600,
            color: "#1a3c34",
            fontSize: { xs: "1rem", sm: "1.25rem", md: "1.5rem" },
        },
        "& .MuiSvgIcon-root": {
            color: "#496683",
        },
    },
    permissionCard: {
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        backgroundColor: "#e8ecef",
        p: 1.5,
        borderRadius: 2,
        boxShadow: "0 2px 6px rgba(0, 0, 0, 0.05)",
        transition: "all 0.2s ease",
        "&:hover": {
            boxShadow: "0 4px 12px rgba(0, 0, 0, 0.1)",
            transform: "translateY(-2px)",
        },
    },
    permissionText: {
        fontSize: { xs: 14, sm: 16 },
        color: "#2e3b55",
    },
    switch: {
        "& .MuiSwitch-switchBase.Mui-checked": { color: "#388e3c" },
        "& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track": { backgroundColor: "#388e3c" },
        "& .MuiSwitch-switchBase:not(.Mui-checked)": { color: "#bdbdbd" },
        "& .MuiSwitch-switchBase:not(.Mui-checked) + .MuiSwitch-track": { backgroundColor: "#fffff" },
    },
    divider: {
        my: 3,
        borderColor: "#e0e4e8",
    },
    buttonContainer: {
        display: "flex",
        gap: 2,
        mt: 4,
        justifyContent: "flex-end",
        flexDirection: { xs: "column", sm: "row" },
    },
    button: {
        borderRadius: 2,
        px: 4,
        py: 1,
        fontWeight: "bold",
        textTransform: "uppercase",
        width: { xs: "100%", sm: "auto" },
        transition: "all 0.3s ease",
    },
    saveButton: {
        backgroundColor: "#1976d2",
        "&:hover": { backgroundColor: "#1565c0" },
        "&:disabled": { backgroundColor: "#90caf9", opacity: 0.7 },
    },
    clearButton: {
        borderColor: "#bdbdbd",
        color: "#1a3c34",
        "&:hover": { borderColor: "#9e9e9e", backgroundColor: "#f5f5f5" },
    },
};

export const getChipStyles = (status: string) => {
    switch (status.toLowerCase()) {
        case 'high':
            return {
                backgroundColor: '#fdecea',
                color: '#d32f2f',
                fontWeight: 600,
            };
        case 'medium':
            return {
                backgroundColor: '#fff4e5',
                color: '#ff9800',
                fontWeight: 500,
            };
        case 'low':
            return {
                backgroundColor: '#e0e0e0',
                color: '#616161',
                fontWeight: 500,
            };
        case 'critical':
            return {
                backgroundColor: '#f3e5f5',
                color: '#9c27b0',
                fontWeight: 600,
            };
        case 'completed':
            return {
                border: '1px solid #388e3c',
                backgroundColor: 'transparent',
                color: '#388e3c',
                fontWeight: 600,
            };
        case 'pending':
            return {
                border: '1px solid #9c27b0',
                backgroundColor: 'transparent',
                color: '#9c27b0',
                fontWeight: 600,
            };
        case 'cancelled':
            return {
                border: '1px solid #d84315',
                backgroundColor: 'transparent',
                color: '#d84315',
                fontWeight: 600,
            };
        case 're-schedule':
            return {
                border: '1px solid #f57f17',
                backgroundColor: 'transparent',
                color: '#f57f17',
                fontWeight: 600,
            };
        case 'closed':
            return {
                border: '1px solid #424242',
                backgroundColor: 'transparent',
                color: '#424242',
                fontWeight: 600,
            };
        default:
            return {
                border: '1px solid #757575',
                backgroundColor: 'transparent',
                color: '#757575',
                fontWeight: 500,
            };
    }
};

export const getStatusChipStyles = (status: string) => {
    const s = status.toLowerCase();

    if (s === 'not started' || s === 'not-started') {
        return {
            border: '1px solid #ff9800',
            color: '#ff9800',
            backgroundColor: 'transparent',
            fontWeight: 600,
        };
    }

    if (s === 'in progress' || s === 'in process') {
        return {
            border: '1px solid #2196f3',
            color: '#2196f3',
            backgroundColor: 'transparent',
            fontWeight: 600,
        };
    }

    if (s === 'completed') {
        return {
            border: '1px solid #4caf50',
            color: '#4caf50',
            backgroundColor: 'transparent',
            fontWeight: 600,
        };
    }

    if (s.includes('closed')) {
        return {
            border: '1px solid #1976D2',
            color: '#1976D2',
            backgroundColor: 'transparent',
            fontWeight: 600,
        };
    }

    if (s.includes('responded')) {
        return {
            border: '1px solid #7B1FA2',
            color: '#7B1FA2',
            backgroundColor: 'transparent',
            fontWeight: 600,
        };
    }

    if (s.includes('justification required')) {
        return {
            border: '1px solid #D32F2F',
            color: '#D32F2F',
            backgroundColor: 'transparent',
            fontWeight: 600,
        };
    }

    if (s.includes('another pending')) {
        return {
            border: '1px solid #F57C00',
            color: '#F57C00',
            backgroundColor: 'transparent',
            fontWeight: 600,
        };
    }

    if (s.includes('pending')) {
        return {
            border: '1px solid #FF9800',
            color: '#FF9800',
            backgroundColor: 'transparent',
            fontWeight: 600,
        };
    }

    if (s.includes('completed') || s.includes('low')) {
        return {
            border: '1px solid #2E7D32',
            color: '#2E7D32',
            backgroundColor: 'transparent',
            fontWeight: 600,
        };
    }

    if (s.includes('high') || s.includes('failed')) {
        return {
            border: '1px solid #FF3333',
            color: '#FF3333',
            backgroundColor: 'transparent',
            fontWeight: 600,
        };
    }

    if (s.includes('medium')) {
        return {
            border: '1px solid #FF9800',
            color: '#FF9800',
            backgroundColor: 'transparent',
            fontWeight: 600,
        };
    }

    if (s.includes('task assigned')) {
        return {
            border: '1px solid #0288D1',
            color: '#0288D1',
            backgroundColor: 'transparent',
            fontWeight: 600,
        };
    }

    return {
        border: '1px solid #bdbdbd',
        color: '#616161',
        backgroundColor: 'transparent',
        fontWeight: 600,
    };
};

export const getIconButtonStyle = (colorName: string) => ({
    color: getColorByName(colorName),
    transition: "0.3s",
    "&:hover": {
        backgroundColor: "rgb(237 239 245)",
        color: getColorByName(colorName),
    },
});

export const getColorByName = (name: string) => {
    switch (name) {
        case "success":
            return "#2e7d32"; // green[700]
        case "info":
            return "#0288d1"; // light blue
        case "warning":
            return "#ed6c02"; // orange
        case "primary":
            return "#1976d2"; // default blue
        case "secondary":
            return "#9c27b0"; // purple
        case "error":
            return "#d32f2f"; // red
        case "default":
        default:
            return "gray";
    }
};


