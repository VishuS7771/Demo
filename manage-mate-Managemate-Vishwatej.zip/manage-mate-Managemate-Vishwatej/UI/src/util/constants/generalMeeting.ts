export const defaultTask = {
    generalMeetingTaskId: 0,
    generalMeetingName:"",
    taskName: "",
    employeeIds: [],
    remark: "",
    targetDate: "",
    createdOn: "",
    status: "Task Assigned",
    createdBy: "",
    generalMeetingId: "0",
    meetingTaskAssigneeDtos: [],
    completionDate: "",
    departmentDtos: [],
    segmentDtos: []
}

export const statuses = ["Pending", "Completed", "Cancelled"];
export const completedtaskStatuses = ["Completed", "Closed"];
export const cancelledtaskStatuses = ["Cancelled"];
export const closedtaskStatuses = ["Closed"];
export const taskStatusOptions = [{
    value: 0,
    label: "Completed"
},
{
    value: 1,
    label: "Responded"
},
{
    value: 2,
    label: "Justification Required"
},
{
    value: 3,
    label: "Task Assigned"
}]

export const segmentsData = [
    { value: 1, label: "HOUSING LOAN" },
    { value: 2, label: "INSURANCE" },
    { value: 3, label: "NONE" },
    { value: 4, label: "PL - SERVICE CLASS" },
    { value: 5, label: "MSME LOAN" },
    { value: 6, label: "SRTO LOAN" },
    { value: 7, label: "SBL - SECURED" },
    { value: 8, label: "SME LOAN - SECURED" },
    { value: 9, label: "SME LOAN - UNSECURED" },
    { value: 10, label: "NEW TWO WHEELER" },
    { value: 11, label: "USED CAR" }
];


export const departmentsData = [
    { value: 1, label: "ACCOUNTS" },
    { value: 2, label: "ADMINISTRATION" },
    { value: 3, label: "CASH MANAGEMENT SYSTEM" },
    { value: 4, label: "CUSTOMER CARE" },
    { value: 5, label: "E.D.P." },
    { value: 6, label: "FINANCE" },
    { value: 7, label: "HUMAN RESOURCE DEVELOPMENT" },
    { value: 8, label: "INFORMATION TECHNOLOGY" },
    { value: 9, label: "INTERNAL AUDIT" },
    { value: 10, label: "LEGAL" },
    { value: 11, label: "MANAGEMENT" },
    { value: 12, label: "NONE" },
    { value: 13, label: "OPERATIONS" },
    { value: 14, label: "PORTFOLIO MANAGEMENT" },
    { value: 15, label: "CREDIT MANAGEMENT" },
    { value: 16, label: "RESOURCE & FINANCE" },
    { value: 17, label: "RETAIL ASSETS" },
    { value: 18, label: "RETAIL ASSETS CHANNEL" },
    { value: 19, label: "RISK & MONITORING" },
    { value: 20, label: "SALES & MARKETING" },
    { value: 21, label: "SECRETERIAL & COMPLIANCE" }
];
