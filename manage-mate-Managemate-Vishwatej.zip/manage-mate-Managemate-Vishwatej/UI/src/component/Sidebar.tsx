import { CSSProperties, useEffect, useState } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { MenuPermission } from "../Interfaces/MenuPermission";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
    faChartLine, faClipboardList, faFolderOpen, faEnvelopeOpen,
    faCalendarAlt, faCog, faFileInvoice, faAngleLeft, faAngleRight,
} from "@fortawesome/free-solid-svg-icons";
import { Sidebar, Menu, MenuItem, SubMenu } from "react-pro-sidebar";
import adminLogo from "../images/mas_logo.png";
import "../css/sidebarNew.css"
import { Box } from "@mui/material";

const sidebarStyle: CSSProperties = {
    minHeight: '100vh',
    boxShadow: '2px 0px 10px rgba(0, 0, 0, 0.1)',
    backgroundColor: '#ffffff',
    position: 'fixed',
    left: 0,
    top: 0,
    zIndex: 999,
    bottom: 0,
};

const defaultMenuPermission: MenuPermission = {
    menuPermissionId: 0,
    employeeId: 0,
    isStatus: false,
    isSubStatus: false,
    isProprietor: false,
    isAssign: false,
    isUser: false,
    isDashboard: false,
    isTask: false,
    isProject: false,
    isReport: false,
    isModule: false,
    isGeneralMeeting: false,
};

interface SidebarProps {
    collapsed: boolean;
    setCollapsed: (collapsed: boolean) => void;
}
const SidebarNav: React.FC<SidebarProps> = ({ collapsed, setCollapsed }) => {

    const navigate = useNavigate();
    const [isMaster, setIsMaster] = useState<boolean>(false);
    const [menuPermission, setMenuPermission] = useState<MenuPermission | null>(null);
    const [hasPermission, setHasPermission] = useState<boolean>(false);
    const toggleButtonStyle: CSSProperties = {
        position: 'absolute',
        top: collapsed ? '95px' : '55px',
        transition: "top 0.3s ease, height 0.3s ease",
        right: '-8px',
        transform: 'translateY(-50%)',
        backgroundColor: 'rgb(73, 102, 131)',
        color: 'rgb(255, 255, 255)',
        border: 'none',
        borderRadius: '50%',
        width: '20px',
        height: '20px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        cursor: 'pointer',
        zIndex: 10000
    };

    useEffect(() => {

        const storedMenuPermission = localStorage.getItem("menuPermission");
        if (storedMenuPermission) {
            try {
                const menuPermissionObj: MenuPermission = JSON.parse(storedMenuPermission);
                setMenuPermission(menuPermissionObj);
            } catch (error) {
                console.error("Error parsing menuPermission from localStorage:", error);
                setMenuPermission(defaultMenuPermission);
            }
        } else {
            setMenuPermission(defaultMenuPermission);
        }

        const menuPermissionAccess = localStorage.getItem("menuPermissionAccess");
        setHasPermission(menuPermissionAccess === "true");
    }, []);

    useEffect(() => {
        if (menuPermission) {
            setIsMaster(
                !!menuPermission?.isStatus ||
                !!menuPermission?.isModule ||
                !!menuPermission?.isSubStatus ||
                !!menuPermission?.isProprietor ||
                !!menuPermission?.isUser
            );
        }
    }, [menuPermission]);

    return (
        <Box style={sidebarStyle}>
            <Sidebar collapsed={collapsed} className="custom-sidebar" style={{ maxHeight: '100vh', overflowY: 'auto' }}>
                <Box sx={{ padding: '15px', textAlign: 'center' }}>
                    <img
                        src={adminLogo}
                        onClick={() => navigate("/ui/dashboard")}
                        alt="Logo"
                        style={{
                            height: collapsed ? "40px" : "90px",
                            width: collapsed ? "60px" : "180px",
                            transition: "width 0.3s ease, height 0.3s ease",
                            borderRadius: "10px",
                            cursor: "pointer"
                        }}
                    />
                </Box>
                <Menu>
                    {menuPermission?.isDashboard && (
                        <MenuItem icon={<FontAwesomeIcon icon={faChartLine} />} component={<NavLink to="/ui/dashboard" className={location.pathname === "/ui/dashboard" ? "active-link" : ""} />}> Dashboard </MenuItem>
                    )}
                    {menuPermission?.isTask && (
                        <MenuItem icon={<FontAwesomeIcon icon={faClipboardList} />} component={<NavLink to="/ui/task/0" className={location.pathname === "/ui/task/0" ? "active-link" : ""} />}> Add Project </MenuItem>
                    )}
                    {menuPermission?.isProject && (
                        <MenuItem icon={<FontAwesomeIcon icon={faFolderOpen} />} component={<NavLink to="/ui/BaTray" className={location.pathname === "/ui/BaTray" ? "active-link" : ""} />}> Projects </MenuItem>
                    )}
                    <MenuItem icon={<FontAwesomeIcon icon={faEnvelopeOpen} />} component={<NavLink to="/ui/inquiry-tray" className={location.pathname === "/ui/inquiry-tray" ? "active-link" : ""} />} > Inquiry Tray </MenuItem>

                    <MenuItem icon={<FontAwesomeIcon icon={faClipboardList} />} component={<NavLink to="/ui/MeetingDetails" className={location.pathname === "/ui/MeetingDetails" ? "active-link" : ""} />}> Meetings Tray</MenuItem>

                    {menuPermission?.isGeneralMeeting &&
                        <SubMenu label="General Meeting Tray"
                            defaultOpen={
                                location.pathname === "/ui/AddGeneralTasks" ||
                                location.pathname === "/ui/GeneralMeeting" ||
                                location.pathname === "/ui/MyTasks" || 
                                location.pathname === "/ui/GeneralMeetingReport" ||
                                location.pathname.startsWith("/ui/Meeting/Tasks/")
                            }
                            icon={<FontAwesomeIcon icon={faCalendarAlt}
                            />}>
                                 <MenuItem icon={<FontAwesomeIcon icon={faCalendarAlt} />} component={<NavLink to="/ui/GeneralMeeting"
                                className={
                                    location.pathname === "/ui/GeneralMeeting" ||
                                        location.pathname.startsWith("/ui/Meeting/Tasks/")
                                        ? "active-link"
                                        : ""
                                }
                            />}> General Meeting </MenuItem>
                            <MenuItem icon={<FontAwesomeIcon icon={faClipboardList} />} component={<NavLink to="/ui/MyTasks" className={location.pathname === "/ui/MyTasks" ? "active-link" : ""} />}> My Tasks </MenuItem>
                            <MenuItem icon={<FontAwesomeIcon icon={faClipboardList} />} component={<NavLink to="/ui/AddGeneralTasks" className={location.pathname === "/ui/AddGeneralTasks" ? "active-link" : ""} />}> General Tasks </MenuItem>
                            <MenuItem icon={<FontAwesomeIcon icon={faFileInvoice} />} component={<NavLink to="/ui/GeneralMeetingReport" className={location.pathname === "/ui/GeneralMeetingReport" ? "active-link" : ""} />}> Reports </MenuItem>
                        </SubMenu>
                    }

                    {isMaster && (
                        <MenuItem icon={<FontAwesomeIcon icon={faFolderOpen} />} component={<NavLink to="/ui/MappingMaster" className={location.pathname === "/ui/MappingMaster" ? "active-link" : ""} />}> Mapping Master </MenuItem>
                    )}
                    {hasPermission && (
                        <MenuItem icon={<FontAwesomeIcon icon={faCog} className="icon" />} component={<NavLink to="/ui/menu-permission" className={location.pathname === "/ui/menu-permission" ? "active-link" : ""} />} > Menu Permission </MenuItem>
                    )}
                    {menuPermission?.isReport && (
                        <MenuItem icon={<FontAwesomeIcon icon={faFileInvoice} className="icon" />} component={<NavLink to="/ui/report" className={location.pathname === "/ui/report" ? "active-link" : ""} />} > Report </MenuItem>
                    )}
                </Menu>
            </Sidebar>
            <button style={toggleButtonStyle} onClick={() => setCollapsed(!collapsed)}>
                <FontAwesomeIcon icon={collapsed ? faAngleRight : faAngleLeft} />
            </button>
        </Box>
    );
};

export default SidebarNav;
