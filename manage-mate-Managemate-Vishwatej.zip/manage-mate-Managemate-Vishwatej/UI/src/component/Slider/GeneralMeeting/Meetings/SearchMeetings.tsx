import React, { useEffect, useState } from "react";
import {
    Box,
    Grid,
    TextField,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    Chip,
    Button,
    Typography,
    Autocomplete
} from "@mui/material";
import { GridDeleteForeverIcon } from "@mui/x-data-grid";
import { GeneralMeetingSearchCriteriaProps, StatusDefinitionsDto } from "../../../../Interfaces/Task";
import { AssigneeOption, DepartmentOption, GeneralMeetingsDto, HostOption, SegmentOption } from "../../../../Interfaces/Generalmeeting";
import { getAllStatus } from "../../../../Requests/StatusMappingRequest";
import { departmentsData, segmentsData } from "../../../../util/constants/generalMeeting";

interface SearchMeetingsProps {
    setFilteredMeetings?: React.Dispatch<React.SetStateAction<GeneralMeetingsDto[]>>;
    meetings?: GeneralMeetingsDto[];
    setOpen: (value: boolean) => void;
    open: boolean;
}

const SearchMeetings: React.FC<SearchMeetingsProps> = ({ setFilteredMeetings, meetings, setOpen, open }) => {
    const [filteredStatusMappings, setFilteredStatusMappings] = useState<StatusDefinitionsDto[]>([]);
    const [hostOptions, setHostOptions] = useState<HostOption[]>([]);
    const [assigneeOptions, setAssigneeOptions] = useState<AssigneeOption[]>([]);
    const [searchCriteria, setSearchCriteria] = useState<GeneralMeetingSearchCriteriaProps>({
        meetingId: "",
        meetingName: "",
        hostId: "",
        hostName: "",
        fromDate: "",
        toDate: "",
        status: [],
        segments: [],
        departments: [],
        host: [],
        assignees: [],
    });

    // Load recent search criteria from sessionStorage on component mount
    useEffect(() => {
        const storedCriteria = sessionStorage.getItem('recentSearchMeetingCriteria');
        console.log('Component mounted, attempting to load recent search criteria:', storedCriteria);
        if (storedCriteria) {
            try {
                const parsedCriteria = JSON.parse(storedCriteria);
                console.log('Loaded recent search criteria:', parsedCriteria);
                setSearchCriteria({
                    meetingId: parsedCriteria?.meetingId || "",
                    meetingName: parsedCriteria?.meetingName || "",
                    hostId: parsedCriteria?.hostId || "",
                    hostName: parsedCriteria?.hostName || "",
                    fromDate: parsedCriteria?.fromDate || "",
                    toDate: parsedCriteria?.toDate || "",
                    status: parsedCriteria?.status || [],
                    segments: parsedCriteria?.segments || [],
                    departments: parsedCriteria?.departments || [],
                    host: parsedCriteria?.host || [],
                    assignees: parsedCriteria?.assignees || [],
                });
            } catch (error) {
                console.error("Error parsing recent search criteria:", error);
            }
        } else {
            console.log('No recent search criteria found in sessionStorage');
        }
    }, []);

    // Save search criteria to sessionStorage when slider closes
    useEffect(() => {
        if (!open) {
            console.log('Slider closed, saving search criteria:', searchCriteria);
            if (
                searchCriteria.meetingId ||
                searchCriteria.meetingName ||
                searchCriteria.hostId ||
                searchCriteria.hostName ||
                searchCriteria.fromDate ||
                searchCriteria.toDate ||
                searchCriteria.status.length > 0 ||
                searchCriteria.segments.length > 0 ||
                searchCriteria.departments.length > 0 ||
                searchCriteria.host.length > 0 ||
                searchCriteria.assignees.length > 0
            ) {
                sessionStorage.setItem('recentSearchMeetingCriteria', JSON.stringify(searchCriteria));
                console.log('Saved recent search criteria to sessionStorage');
            } else {
                console.log('Skipping save due to empty search criteria');
                sessionStorage.removeItem('recentSearchMeetingCriteria');
            }
        }
    }, [open, searchCriteria]);

    // Clear sessionStorage on page refresh
    useEffect(() => {
        const handleBeforeUnload = () => {
            console.log('Page refreshing, clearing recent search criteria');
            sessionStorage.removeItem('recentSearchMeetingCriteria');
        };

        window.addEventListener('beforeunload', handleBeforeUnload);
        return () => {
            window.removeEventListener('beforeunload', handleBeforeUnload);
        };
    }, []);

    // Derive unique host and assignee options from meetings
    useEffect(() => {
        if (meetings) {
            console.log('Deriving host and assignee options from meetings:', meetings);
            const uniqueHosts = Array.from(
                new Set(meetings.map((meeting) => meeting.hostIdName))
            ).map((hostIdName) => ({
                label: hostIdName,
                value: hostIdName,
            }));
            setHostOptions(uniqueHosts);

            const uniqueAssignees = Array.from(
                new Set(
                    meetings.flatMap((meeting) =>
                        meeting.meetingParticipantsDtoList.map((participant) => participant.participantName)
                    )
                )
            ).map((participantName) => ({
                label: participantName,
                value: participantName,
            }));
            setAssigneeOptions(uniqueAssignees);
            console.log('Host options:', uniqueHosts, 'Assignee options:', uniqueAssignees);
        }
    }, [meetings]);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        console.log(`Input changed: ${name} = ${value}`);
        setSearchCriteria((prev) => ({ ...prev, [name]: value }));
    };

    const handleSegmentSelection = (newValue: SegmentOption[]) => {
        console.log('Segment selection changed:', newValue);
        setSearchCriteria((prev) => ({ ...prev, segments: newValue || [] }));
    };

    const handleDepartmentSelection = (newValue: DepartmentOption[]) => {
        console.log('Department selection changed:', newValue);
        setSearchCriteria((prev) => ({ ...prev, departments: newValue || [] }));
    };

    const handleHostSelection = (newValue: HostOption[]) => {
        console.log('Host selection changed:', newValue);
        setSearchCriteria((prev) => ({ ...prev, host: newValue || [] }));
    };

    const handleAssigneeSelection = (newValue: AssigneeOption[]) => {
        console.log('Assignee selection changed:', newValue);
        setSearchCriteria((prev) => ({ ...prev, assignees: newValue || [] }));
    };

    const handleSearchStatus = (statuses: string[]) => {
        const empId = localStorage.getItem('employeeNo');
        const employeeId = Number(empId) || null;
        console.log('Status selection changed:', statuses, 'Employee ID:', employeeId);
        setSearchCriteria((prevCriteria) => ({
            ...prevCriteria,
            status: statuses,
            employeeId: employeeId,
        }));
    };

    const fetchAllStatusMappings = async () => {
        try {
            const response = await getAllStatus();
            console.log('Fetched status mappings:', response.data);
            setFilteredStatusMappings(Array.isArray(response.data) ? response.data : []);
        } catch (error) {
            console.error("Error fetching all status mappings:", error);
            setFilteredStatusMappings([]);
        }
    };

    const handleSearch = (e: React.MouseEvent<HTMLButtonElement>) => {
        e.preventDefault();
        e.stopPropagation();
        console.log('Search triggered with criteria:', searchCriteria);
        const filtered = meetings?.filter((meeting) => {
            if (!meeting.meetingDate) return false;

            const meetingDate = new Date(meeting.meetingDate);
            const fromDate = searchCriteria.fromDate ? new Date(searchCriteria.fromDate) : null;
            const toDate = searchCriteria.toDate ? new Date(searchCriteria.toDate) : null;
            const meetingSegments = (searchCriteria.segments || []).map(seg => seg.label.toLowerCase());
            const meetingDepartments = (searchCriteria.departments || []).map(dep => dep.label.toLowerCase());
            const meetingHosts = (searchCriteria.host || []).map(host => host.label.toLowerCase());
            const meetingAssignees = (searchCriteria.assignees || []).map(assignee => assignee.label.toLowerCase());

            return (
                (searchCriteria.meetingId
                    ? meeting.meetingId.toString().includes(searchCriteria.meetingId)
                    : true) &&
                (searchCriteria.meetingName
                    ? meeting.meetingName.toLowerCase().includes(searchCriteria.meetingName.toLowerCase())
                    : true) &&
                (searchCriteria.segments.length
                    ? meeting.segmentDtos.some(segment =>
                        meetingSegments.includes(segment.name?.toLowerCase() || '')
                    )
                    : true) &&
                (searchCriteria.departments.length
                    ? meeting.departmentDtos.some(department =>
                        meetingDepartments.includes(department.name?.toLowerCase() || '')
                    )
                    : true) &&
                (searchCriteria.host.length
                    ? meetingHosts.includes(meeting.hostIdName.toLowerCase())
                    : true) &&
                (searchCriteria.assignees.length
                    ? meeting.meetingParticipantsDtoList.some(participant =>
                        meetingAssignees.includes(participant.participantName.toLowerCase())
                    )
                    : true) &&
                (fromDate ? meetingDate >= fromDate : true) &&
                (toDate ? meetingDate <= toDate : true) &&
                (Array.isArray(searchCriteria.status) && searchCriteria.status.length > 0
                    ? searchCriteria.status.some(
                        (status) =>
                            status &&
                            typeof status === "string" &&
                            meeting.meetingStatus.toLowerCase() === status.toLowerCase()
                    )
                    : true)
            );
        });

        if (filtered) {
            console.log('Filtered meetings:', filtered);
            setFilteredMeetings?.(filtered);
            setOpen(false);
        }
    };

    useEffect(() => {
        const storedData = localStorage.getItem('employeedata');
        if (storedData) {
            const parsedData = JSON.parse(storedData);
            if (parsedData?.DesignationId) {
                console.log('Fetching status mappings for employee:', parsedData);
                fetchAllStatusMappings();
            }
        }
    }, []);

    return (
        <Box display="flex" flexDirection="column" alignItems="center" mt={3} px={2}>
            <Typography
                variant="h6"
                component="div"
                align="center"
                gutterBottom
                sx={{ fontWeight: "bold", color: "rgb(73, 102, 131)" }}
            >
                Search Meetings
            </Typography>

            <Grid container spacing={2}>
                {/* Meeting ID and Meeting Name */}
                <Grid item xs={12} sm={6}>
                    <TextField
                        fullWidth
                        label="Meeting ID"
                        name="meetingId"
                        placeholder="Meeting ID"
                        value={searchCriteria.meetingId}
                        onChange={handleInputChange}
                        variant="standard"
                    />
                </Grid>
                <Grid item xs={12} sm={6}>
                    <TextField
                        fullWidth
                        label="Meeting Name"
                        name="meetingName"
                        placeholder="Meeting Name"
                        value={searchCriteria.meetingName}
                        onChange={handleInputChange}
                        variant="standard"
                    />
                </Grid>

                {/* Status */}
                <Grid item xs={12}>
                    <FormControl variant="standard" sx={{ mb: 2 }} fullWidth>
                        <InputLabel>Status</InputLabel>
                        <Select
                            multiple
                            name="status"
                            value={searchCriteria.status || []}
                            onChange={(event) => handleSearchStatus(event.target.value as string[])}
                            renderValue={(selected) => (
                                <div>
                                    {selected.map((value) => (
                                        <Chip
                                            key={value}
                                            label={value}
                                            deleteIcon={<GridDeleteForeverIcon />}
                                            sx={{ margin: 0.5 }}
                                        />
                                    ))}
                                </div>
                            )}
                            MenuProps={{
                                PaperProps: {
                                    style: {
                                        maxHeight: 200,
                                        maxWidth: 300,
                                        overflow: 'auto',
                                    },
                                },
                            }}
                        >
                            {filteredStatusMappings.map((status) => (
                                <MenuItem key={status.status} value={status.status}>
                                    {status.status}
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                </Grid>

                {/* Segments and Departments */}
                <Grid item xs={12} sm={6}>
                    <FormControl fullWidth>
                        <Autocomplete
                            multiple
                            size="small"
                            style={{ width: "100%" }}
                            options={segmentsData}
                            getOptionLabel={(option) => option.label}
                            value={searchCriteria.segments}
                            onChange={(_, newValue) => handleSegmentSelection(newValue)}
                            renderInput={(params) => (
                                <TextField
                                    {...params}
                                    label="Segments"
                                    variant="standard"
                                />
                            )}
                        />
                    </FormControl>
                </Grid>
                <Grid item xs={12} sm={6}>
                    <FormControl fullWidth>
                        <Autocomplete
                            multiple
                            size="small"
                            style={{ width: "100%" }}
                            options={departmentsData}
                            getOptionLabel={(option) => option.label}
                            value={searchCriteria.departments}
                            onChange={(_, newValue) => handleDepartmentSelection(newValue)}
                            renderInput={(params) => (
                                <TextField
                                    {...params}
                                    label="Departments"
                                    variant="standard"
                                />
                            )}
                        />
                    </FormControl>
                </Grid>

                {/* Host and Assignees */}
                <Grid item xs={12} sm={6}>
                    <FormControl fullWidth>
                        <Autocomplete
                            multiple
                            size="small"
                            style={{ width: "100%" }}
                            options={hostOptions}
                            getOptionLabel={(option) => option.label}
                            value={searchCriteria.host}
                            onChange={(_, newValue) => handleHostSelection(newValue)}
                            renderInput={(params) => (
                                <TextField
                                    {...params}
                                    label="Host"
                                    variant="standard"
                                />
                            )}
                        />
                    </FormControl>
                </Grid>
                <Grid item xs={12} sm={6}>
                    <FormControl fullWidth>
                        <Autocomplete
                            multiple
                            size="small"
                            style={{ width: "100%" }}
                            options={assigneeOptions}
                            getOptionLabel={(option) => option.label}
                            value={searchCriteria.assignees}
                            onChange={(_, newValue) => handleAssigneeSelection(newValue)}
                            renderInput={(params) => (
                                <TextField
                                    {...params}
                                    label="Assignees"
                                    variant="standard"
                                />
                            )}
                        />
                    </FormControl>
                </Grid>

                {/* From Date and To Date */}
                <Grid item xs={12} sm={6}>
                    <TextField
                        fullWidth
                        type="date"
                        name="fromDate"
                        label="From Date"
                        value={searchCriteria.fromDate}
                        onChange={handleInputChange}
                        variant="standard"
                        InputLabelProps={{ shrink: true }}
                    />
                </Grid>
                <Grid item xs={12} sm={6}>
                    <TextField
                        fullWidth
                        type="date"
                        name="toDate"
                        label="To Date"
                        value={searchCriteria.toDate}
                        onChange={handleInputChange}
                        variant="standard"
                        InputLabelProps={{ shrink: true }}
                    />
                </Grid>
            </Grid>

            <Box sx={{ textAlign: "right", mt: 5, display: "flex", justifyContent: "space-between", width: "100%" }}>
                <Button
                    variant="contained"
                    color="primary"
                    onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        console.log('Reset triggered');
                        const resetCriteria = {
                            meetingId: "",
                            meetingName: "",
                            hostId: "",
                            hostName: "",
                            fromDate: "",
                            toDate: "",
                            status: [],
                            segments: [],
                            departments: [],
                            host: [],
                            assignees: [],
                        };
                        setSearchCriteria(resetCriteria);
                        if (meetings) {
                            setFilteredMeetings?.(meetings);
                        }
                        setOpen(false);
                    }}
                >
                    Reset
                </Button>
                <Button variant="contained" color="primary" onClick={handleSearch}>
                    Search
                </Button>
            </Box>
        </Box>
    );
};

export default SearchMeetings;