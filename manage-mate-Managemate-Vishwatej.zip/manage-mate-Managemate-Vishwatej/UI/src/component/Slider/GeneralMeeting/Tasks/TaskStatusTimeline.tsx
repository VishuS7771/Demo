import React, { useState, useEffect } from "react";
import { Box, CircularProgress, Table, TableContainer, TableHead, TableBody, TableRow, TableCell, Typography, Pagination } from "@mui/material";
import dayjs from "dayjs";
import { usePageLoader } from "../../../../context/PageLoaderContext";
import { getGeneralMeetingTaskTimelineHistory } from "../../../../Requests/GeneralMeetingRequest";
import { Empty } from "antd";

interface TaskActivityData {
    activity: string;
    completionDate: string;
    markDate: string;
    markedBy: string;
    remarks: string | null;
}

interface TaskStatusTimelineProps {
    generalMeetingTaskId?: number;
}

const TaskStatusTimeline: React.FC<TaskStatusTimelineProps> = ({ generalMeetingTaskId }) => {
    const { showLoader, hideLoader } = usePageLoader();
    const [currentPage, setCurrentPage] = useState(1);
    const [pageSize] = useState(10);
    const [taskActivityData, setTaskActivityData] = useState<TaskActivityData[]>([]);
    const [loading] = useState(false);

    const fetchTimelineHistory = async () => {
        try {
            showLoader();
            const response = await getGeneralMeetingTaskTimelineHistory(generalMeetingTaskId!);
            if (response.httpStatus === "OK") {
                setTaskActivityData(response.data);
            } else {
                console.error(`Error ${response.status}: ${response.statusText}`);
            }
        } catch (error) {
            console.error("Failed to fetch timeline history:", error);
        } finally {
            hideLoader();
        }
    };

    useEffect(() => {
        if (generalMeetingTaskId) fetchTimelineHistory();
    }, [generalMeetingTaskId]);

    const paginatedData = taskActivityData.slice((currentPage - 1) * pageSize, currentPage * pageSize);

    return (
        <Box display="flex" flexDirection="column" alignItems="center" mt={2} px={2}>
            {loading ? (
                <CircularProgress size={60} />
            ) : taskActivityData.length > 0 ? (
                <>
                    <Typography
                        variant="h6"
                        align="center"
                        component="div"
                        gutterBottom
                        sx={{ mb: 2, fontWeight: "bold", color: "rgb(73, 102, 131)" }}
                    >
                        Task Activity Timeline
                    </Typography>
                    <TableContainer sx={{ maxHeight: 600 }}>
                        <Table stickyHeader>
                            <TableHead>
                                <TableRow>
                                    <TableCell sx={{ fontWeight: "bold", width: 90 }}>SR. No</TableCell>
                                    <TableCell sx={{ fontWeight: "bold", width: 200 }}>Activity</TableCell>
                                    <TableCell sx={{ fontWeight: "bold", width: 200 }}>User Expected Date</TableCell>
                                    <TableCell sx={{ fontWeight: "bold", width: 200 }}>Marked Date</TableCell>
                                    <TableCell sx={{ fontWeight: "bold", width: 200 }}>Marked By</TableCell>
                                    <TableCell sx={{ fontWeight: "bold", width: 150 }}>Remarks</TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {paginatedData.map((item, index) => (
                                    <TableRow key={index}>
                                        <TableCell>{(currentPage - 1) * pageSize + index + 1}</TableCell>
                                        <TableCell>{item.activity}</TableCell>
                                        <TableCell>{item.completionDate ? dayjs(item.completionDate).format("DD MMM YYYY") : "-"}</TableCell>
                                        <TableCell>{item.markDate ? dayjs(item.markDate).format("DD MMM YYYY hh:mm A") : "-"}</TableCell>
                                        <TableCell>{item.markedBy}</TableCell>
                                        <TableCell>{item.remarks || "-"}</TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </TableContainer>
                    <Box mt={2} display="flex" justifyContent="center">
                        <Pagination
                            count={Math.ceil(taskActivityData.length / pageSize)}
                            page={currentPage}
                            onChange={(_, page) => setCurrentPage(page)}
                        />
                    </Box>
                </>
            ) : (

                <Box
                    display="flex"
                    justifyContent="center"
                    alignItems="center"
                    minHeight="68vh"
                    width={800}
                >
                    <Empty description="No Task Status Timeline Available" />
                </Box>
            )}
        </Box>
    );
};

export default TaskStatusTimeline;
