import React, { useEffect, useState } from "react";
import {
    Box,
    Grid,
    TextField,
    FormControl,
    Button,
    Typography,
    Autocomplete,
    FormControlLabel,
    Checkbox
} from "@mui/material";
import { employeesType, SearchCriteria, User } from "../../../../Interfaces/Task";
import { DepartmentOption, GeneralMeetingTaskDto, SegmentOption } from "../../../../Interfaces/Generalmeeting";
import { departmentsData, segmentsData, taskStatusOptions } from "../../../../util/constants/generalMeeting";
import { getAllEmployees } from "../../../../Requests/MeetingRequest";
import { useLocation } from "react-router-dom";


// interface SearchCriteria {
//     meetingName: string;
//     taskName: string;
//     assignedDateFrom: string;
//     assignedDateTo: string;
//     targetDateFrom: string;
//     targetDateTo: string;
//     completionDateFrom: string;
//     completionDateTo: string;
//     statuses: StatusOption[];
//     employees: User[];
//     assignees: User[];
//     segments: SegmentOption[];
//     departments: DepartmentOption[];
//     isOverdue: boolean;
// }

interface SearchTasksProps {
    setFilteredTasks?: React.Dispatch<React.SetStateAction<GeneralMeetingTaskDto[]>>;
    tasks?: GeneralMeetingTaskDto[];
    searchCriteria: SearchCriteria;
    setSearchCriteria: React.Dispatch<React.SetStateAction<SearchCriteria>>
    setOpen?: (value: boolean) => void; // Added setOpen prop
}

interface StatusOption {
    value: number;
    label: string;
}

const SearchTasks: React.FC<SearchTasksProps> = ({ setFilteredTasks, tasks, searchCriteria, setSearchCriteria, setOpen }) => {
    const { pathname } = useLocation();
    const pathName = pathname.split("/").filter(Boolean).pop() || "";
    // const [searchCriteria, setSearchCriteria] = useState<SearchCriteria>({
    //     meetingName: "",
    //     taskName: "",
    //     assignedDateFrom: "",
    //     assignedDateTo: "",
    //     targetDateFrom: "",
    //     targetDateTo: "",
    //     completionDateFrom: "",
    //     completionDateTo: "",
    //     statuses: [],
    //     employees: [],
    //     assignees: [],
    //     segments: [],
    //     departments: [],
    //     isOverdue: false,
    // });
    const [allEmployees, setAllEmployees] = useState<employeesType[]>([]);

    const employeeOptions = allEmployees?.map((employee) => ({
        value: employee.employeeId.toString(),
        label: `${employee.employeeName} (${employee.employeeId})`,
    }));

    const handleInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = event.target;
        setSearchCriteria((prev) => ({ ...prev, [name]: value }));
    };

    const handleCheckboxChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const { name, checked } = event.target;
        setSearchCriteria((prev) => ({ ...prev, [name]: checked }));
    };

    const handleSegmentSelection = (newValue: SegmentOption[]) => {
        setSearchCriteria((prev) => ({ ...prev, segments: newValue || [] }));
    };

    const handleDepartmentSelection = (newValue: DepartmentOption[]) => {
        setSearchCriteria((prev) => ({ ...prev, departments: newValue || [] }));
    };

    const handleFilterChange = (
        newValue: { label: string; value: string | number }[] | User[] | StatusOption[] | null,
        filterType: "employee" | "assignee" | "status"
    ) => {
        if (filterType === "employee") {
            const updatedEmployees = Array.isArray(newValue)
                ? newValue.map(val =>
                    typeof val === "object" && "value" in val
                        ? allEmployees.find(emp => emp.employeeId.toString() === val.value.toString())!
                        : (val as User)
                ).filter(Boolean)
                : [];
            setSearchCriteria((prev) => ({ ...prev, employees: updatedEmployees }));
        }

        if (filterType === "assignee") {
            const updatedAssignees = Array.isArray(newValue)
                ? newValue.map(val =>
                    typeof val === "object" && "value" in val
                        ? allEmployees.find(emp => emp.employeeId.toString() === val.value.toString())!
                        : (val as User)
                ).filter(Boolean)
                : [];
            setSearchCriteria((prev) => ({ ...prev, assignees: updatedAssignees }));
        }

        if (filterType === "status") {
            const updatedStatuses = Array.isArray(newValue) && newValue.every(val => "label" in val && "value" in val)
                ? (newValue as StatusOption[])
                : [];
            setSearchCriteria((prev) => ({ ...prev, statuses: updatedStatuses }));
        }
    };

    const handleSearch = () => {
        const filtered = tasks?.filter((task) => {
            const {
                meetingName,
                taskName,
                assignedDateFrom,
                assignedDateTo,
                targetDateFrom,
                targetDateTo,
                completionDateFrom,
                completionDateTo,
                statuses,
                employees,
                assignees,
                segments,
                departments,
                isOverdue,
            } = searchCriteria;

            const taskStatuses = statuses.map(status => status.label);
            const taskEmployees = employees.map(emp => emp.employeeId);
            const taskAssignees = assignees.map(assignee => assignee.employeeId);
            const taskDepartments = departments.map(dep => dep.label);
            const taskSegments = segments.map(seg => seg.label);

            const currentDate = new Date();
            currentDate.setHours(0, 0, 0, 0); // Normalize to start of day

            // Overdue logic: Check if completionDate or targetDate is before current date
            const isTaskOverdue = isOverdue
                ? (() => {
                    const referenceDate = task.completionDate
                        ? new Date(task.completionDate)
                        : task.targetDate
                            ? new Date(task.targetDate)
                            : null;
                    return referenceDate && referenceDate < currentDate;
                })()
                : true;

            // Date range filtering
            const isAssignedDateInRange = assignedDateFrom || assignedDateTo
                ? (() => {
                    const taskDate = task.createdOn ? new Date(task.createdOn) : null;
                    const from = assignedDateFrom ? new Date(assignedDateFrom) : null;
                    const to = assignedDateTo ? new Date(assignedDateTo) : null;
                    if (!taskDate) return false;
                    if (from && taskDate < from) return false;
                    if (to) {
                        to.setHours(23, 59, 59, 999); // Include end of day
                        if (taskDate > to) return false;
                    }
                    return true;
                })()
                : true;

            const isTargetDateInRange = targetDateFrom || targetDateTo
                ? (() => {
                    const taskDate = task.targetDate ? new Date(task.targetDate) : null;
                    const from = targetDateFrom ? new Date(targetDateFrom) : null;
                    const to = targetDateTo ? new Date(targetDateTo) : null;
                    if (!taskDate) return false;
                    if (from && taskDate < from) return false;
                    if (to) {
                        to.setHours(23, 59, 59, 999);
                        if (taskDate > to) return false;
                    }
                    return true;
                })()
                : true;

            const isCompletionDateInRange = completionDateFrom || completionDateTo
                ? (() => {
                    const taskDate = task.completionDate ? new Date(task.completionDate) : null;
                    const from = completionDateFrom ? new Date(completionDateFrom) : null;
                    const to = completionDateTo ? new Date(completionDateTo) : null;
                    if (!taskDate) return false;
                    if (from && taskDate < from) return false;
                    if (to) {
                        to.setHours(23, 59, 59, 999);
                        if (taskDate > to) return false;
                    }
                    return true;
                })()
                : true;

            return (
                (meetingName ? (task as any)?.generalMeetingName?.toLowerCase().includes(meetingName.toLowerCase()) : true) &&
                (taskName ? task.taskName.toLowerCase().includes(taskName.toLowerCase()) : true) &&
                isAssignedDateInRange &&
                isTargetDateInRange &&
                isCompletionDateInRange &&
                (taskStatuses.length > 0 ? taskStatuses.includes(task.status) : true) &&
                (taskEmployees.length > 0
                    ? task.meetingTaskAssigneeDtos?.some(assignee =>
                        taskEmployees.includes(assignee.empId.toString()))
                    : true) &&
                (taskAssignees.length > 0 ? taskAssignees.includes(task.createdBy) : true) &&
                (taskDepartments.length > 0
                    ? task.departmentDtos?.some(dep => taskDepartments.includes(dep.name))
                    : true) &&
                (taskSegments.length > 0
                    ? task.segmentDtos?.some(seg => taskSegments.includes(seg.name))
                    : true) &&
                isTaskOverdue
            );
        });

        if (filtered) {
            setFilteredTasks?.(filtered);
        }
        setOpen?.(false); // Close the slider after search
    };

    const handleReset = () => {
        setSearchCriteria({
            meetingName: "",
            taskName: "",
            assignedDateFrom: "",
            assignedDateTo: "",
            targetDateFrom: "",
            targetDateTo: "",
            completionDateFrom: "",
            completionDateTo: "",
            statuses: [],
            employees: [],
            assignees: [],
            segments: [],
            departments: [],
            isOverdue: false,
        });
        if (tasks) {
            setFilteredTasks?.(tasks);
        }
    };

    useEffect(() => {
        const storedData = localStorage.getItem('employeedata');
        if (storedData) {
            getAllEmployees()
                .then((data) => {
                    if (data) {
                        setAllEmployees(data);
                    }
                }).catch((error) => console.error("Error fetching employees:", error));
        }
    }, []);

    return (
        <Box display="flex" flexDirection="column" mt={3} px={2}>
            <Typography
                variant="h6"
                component="div"
                align="center"
                gutterBottom
                sx={{ fontWeight: "bold", color: "rgb(73, 102, 131)" }}
            >
                Search Tasks
            </Typography>

            <Grid item xs={12}>
                <FormControl sx={{ justifyContent: "end" }}>
                    <FormControlLabel
                        control={
                            <Checkbox
                                name="isOverdue"
                                checked={searchCriteria.isOverdue}
                                onChange={handleCheckboxChange}
                            />
                        }
                        label="Overdue Tasks"
                    />
                </FormControl>
            </Grid>
            <Grid container spacing={3} justifyContent="center">
                {pathName === "MyTasks" && (
                    <Grid item xs={6}>
                        <FormControl variant="standard" fullWidth>
                            <TextField
                                fullWidth
                                name="meetingName"
                                label="Meeting Name"
                                value={searchCriteria.meetingName}
                                onChange={handleInputChange}
                                variant="standard"
                            />
                        </FormControl>
                    </Grid>
                )}
                <Grid item xs={pathName === "MyTasks" ? 6 : 12}>
                    <FormControl variant="standard" fullWidth>
                        <TextField
                            fullWidth
                            name="taskName"
                            label="Task Name"
                            value={searchCriteria.taskName}
                            onChange={handleInputChange}
                            variant="standard"
                        />
                    </FormControl>
                </Grid>

                <Grid item xs={12}>
                    <FormControl variant="standard" fullWidth sx={{ gap: 1 }}>

                        <Grid container spacing={2}>
                            <Grid item xs={6}>
                                <TextField
                                    fullWidth
                                    type="date"
                                    name="assignedDateFrom"
                                    label="From"
                                    value={searchCriteria.assignedDateFrom}
                                    onChange={handleInputChange}
                                    variant="standard"
                                    InputLabelProps={{ shrink: true }}
                                />
                            </Grid>
                            <Grid item xs={6}>
                                <TextField
                                    fullWidth
                                    type="date"
                                    name="assignedDateTo"
                                    label="To"
                                    value={searchCriteria.assignedDateTo}
                                    onChange={handleInputChange}
                                    variant="standard"
                                    InputLabelProps={{ shrink: true }}
                                />
                            </Grid>
                        </Grid>
                    </FormControl>
                </Grid>

                <Grid item xs={12}>
                    <FormControl variant="standard" fullWidth sx={{ gap: 1 }}>
                        <Typography variant="subtitle1" sx={{ fontWeight: "medium" }}>
                            Target Date
                        </Typography>
                        <Grid container spacing={2}>
                            <Grid item xs={6}>
                                <TextField
                                    fullWidth
                                    type="date"
                                    name="targetDateFrom"
                                    label="From"
                                    value={searchCriteria.targetDateFrom}
                                    onChange={handleInputChange}
                                    variant="standard"
                                    InputLabelProps={{ shrink: true }}
                                />
                            </Grid>
                            <Grid item xs={6}>
                                <TextField
                                    fullWidth
                                    type="date"
                                    name="targetDateTo"
                                    label="To"
                                    value={searchCriteria.targetDateTo}
                                    onChange={handleInputChange}
                                    variant="standard"
                                    InputLabelProps={{ shrink: true }}
                                />
                            </Grid>
                        </Grid>
                    </FormControl>
                </Grid>

                <Grid item xs={12}>
                    <FormControl variant="standard" fullWidth sx={{ gap: 1 }}>
                        <Typography variant="subtitle1" sx={{ fontWeight: "medium" }}>
                            Completion Date
                        </Typography>
                        <Grid container spacing={2}>
                            <Grid item xs={6}>
                                <TextField
                                    fullWidth
                                    type="date"
                                    name="completionDateFrom"
                                    label="From"
                                    value={searchCriteria.completionDateFrom}
                                    onChange={handleInputChange}
                                    variant="standard"
                                    InputLabelProps={{ shrink: true }}
                                />
                            </Grid>
                            <Grid item xs={6}>
                                <TextField
                                    fullWidth
                                    type="date"
                                    name="completionDateTo"
                                    label="To"
                                    value={searchCriteria.completionDateTo}
                                    onChange={handleInputChange}
                                    variant="standard"
                                    InputLabelProps={{ shrink: true }}
                                />
                            </Grid>
                        </Grid>
                    </FormControl>
                </Grid>



                <Grid item xs={6}>
                    <FormControl fullWidth>
                        <Autocomplete
                            size="small"
                            multiple
                            style={{ width: "100%" }}
                            loading={true}
                            limitTags={3}
                            options={employeeOptions}
                            getOptionLabel={(option) => option.label}
                            value={
                                searchCriteria.employees.length > 0
                                    ? employeeOptions?.filter(opt =>
                                        searchCriteria.employees.some(emp => emp.employeeId.toString() === opt.value.toString())
                                    )
                                    : []
                            }
                            onChange={(_, newValue) => handleFilterChange(newValue, "employee")}
                            renderInput={(params) => (
                                <TextField
                                    {...params}
                                    label="Employees"
                                    variant="standard"
                                />
                            )}
                            isOptionEqualToValue={(option, value) => option.value === value.value}
                        />
                    </FormControl>
                </Grid>

                <Grid item xs={6}>
                    <FormControl fullWidth>
                        <Autocomplete
                            size="small"
                            style={{ width: "100%" }}
                            loading={true}
                            limitTags={3}
                            multiple
                            options={employeeOptions}
                            getOptionLabel={(option) => option.label}
                            value={
                                searchCriteria.assignees.length > 0
                                    ? employeeOptions?.filter(opt =>
                                        searchCriteria.assignees.some(emp => emp.employeeId.toString() === opt.value.toString())
                                    )
                                    : []
                            }
                            onChange={(_, newValue) => handleFilterChange(newValue, "assignee")}
                            renderInput={(params) => (
                                <TextField
                                    {...params}
                                    label="Assigned By"
                                    variant="standard"
                                />
                            )}
                            isOptionEqualToValue={(option, value) => option.value === value.value}
                        />
                    </FormControl>
                </Grid>

                <Grid item xs={6}>
                    <FormControl fullWidth>
                        <Autocomplete
                            multiple
                            size="small"
                            style={{ width: "100%" }}
                            options={segmentsData}
                            getOptionLabel={(option) => option.label}
                            value={searchCriteria.segments}
                            onChange={(_, newValue) => handleSegmentSelection(newValue)}
                            renderInput={(params) => (
                                <TextField
                                    {...params}
                                    label="Segments"
                                    variant="standard"
                                />
                            )}
                        />
                    </FormControl>
                </Grid>

                <Grid item xs={6}>
                    <FormControl fullWidth>
                        <Autocomplete
                            multiple
                            size="small"
                            style={{ width: "100%" }}
                            options={departmentsData}
                            getOptionLabel={(option) => option.label}
                            value={searchCriteria.departments}
                            onChange={(_, newValue) => handleDepartmentSelection(newValue)}
                            renderInput={(params) => (
                                <TextField
                                    {...params}
                                    label="Departments"
                                    variant="standard"
                                />
                            )}
                        />
                    </FormControl>
                </Grid>

                <Grid item xs={12}>
                    <FormControl fullWidth>
                        <Autocomplete
                            multiple
                            size="small"
                            style={{ width: "100%", background: "#ffffff" }}
                            limitTags={1}
                            options={taskStatusOptions}
                            getOptionLabel={(option) => option.label}
                            value={searchCriteria.statuses}
                            onChange={(_, newValue) => handleFilterChange(newValue, "status")}
                            renderInput={(params) => (
                                <TextField
                                    {...params}
                                    label="Status"
                                    variant="standard"
                                />
                            )}
                        />
                    </FormControl>
                </Grid>


            </Grid>

            <Box sx={{ textAlign: "right", mt: 5, display: "flex", justifyContent: "space-between", width: "100%" }}>
                <Button variant="contained" color="primary" onClick={handleReset}>
                    Reset
                </Button>
                <Button variant="contained" color="primary" onClick={handleSearch}>
                    Search
                </Button>
            </Box>
        </Box>
    );
};

export default SearchTasks;