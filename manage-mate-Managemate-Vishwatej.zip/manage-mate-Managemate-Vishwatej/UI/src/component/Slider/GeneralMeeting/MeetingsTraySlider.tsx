import React from "react";
import { Slide, Paper, IconButton } from "@mui/material";
import { GridCloseIcon } from "@mui/x-data-grid";
import TaskStatusTimeline from "./Tasks/TaskStatusTimeline";
import { GeneralMeetingsDto, GeneralMeetingTaskDto } from "../../../Interfaces/Generalmeeting";
import SearchMeetings from "./Meetings/SearchMeetings";
import SearchTasks from "./Tasks/SearchTasks";
import { SearchCriteria } from "../../../Interfaces/Task";

interface MeetingsTraySliderProps {
    open: boolean;
    setOpen: (value: boolean) => void;
    width?: number | string;
    currentSlider: string;
    generalMeetingTaskId?: number;
    setFilteredMeetings?: React.Dispatch<React.SetStateAction<GeneralMeetingsDto[]>>;
    meetings?: GeneralMeetingsDto[];
    tasks?: GeneralMeetingTaskDto[];
    setFilteredTasks?: React.Dispatch<React.SetStateAction<GeneralMeetingTaskDto[]>>
    searchCriteria: SearchCriteria;
    setSearchCriteria: React.Dispatch<React.SetStateAction<SearchCriteria>>
}

const MeetingsTraySlider: React.FC<MeetingsTraySliderProps> = ({
    open,
    setOpen,
    width = 600,
    currentSlider,
    generalMeetingTaskId,
    setFilteredMeetings,
    setFilteredTasks,
    meetings,
    tasks,
    searchCriteria,
    setSearchCriteria
}) => {

    const widthMap: Record<string, number> = {
        timeline: 900,
        assigneeHistory: 800,
        additional: 500,
        changeAssignee: 450,
        searchTasks: 800
        // searchMeetings:500
    };

    const resolvedWidth = widthMap[currentSlider] ?? width;

    const renderContent = () => {
        switch (currentSlider) {
            case "timeline":
                return <TaskStatusTimeline generalMeetingTaskId={generalMeetingTaskId} />;
            case "searchMeetings":
                return <SearchMeetings meetings={meetings} setFilteredMeetings={setFilteredMeetings} setOpen={setOpen} open={false} />;
            case "searchTasks":
                return <SearchTasks
                    searchCriteria={searchCriteria}
                    setSearchCriteria={setSearchCriteria}
                    tasks={tasks}
                    setFilteredTasks={setFilteredTasks}
                    setOpen={setOpen} // Pass setOpen to SearchTasks
                />;
            default:
                return null;
        }
    };

    return (
        <Slide direction="left" in={open} mountOnEnter unmountOnExit>
            <Paper
                onClick={(e) => e.stopPropagation()}
                sx={{
                    position: "absolute",
                    top: 0,
                    right: 0,
                    width: {
                        sm: '100%',
                        md: '100%',
                        lg: resolvedWidth,
                        xl: resolvedWidth,
                    },
                    height: "100%",
                    px: 1,
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "start",
                    borderRadius: "15px 0 0 15px",
                    boxShadow: 24,
                    zIndex: 1,
                    overflowY: "auto",
                }}
            >
                <IconButton
                    onClick={() => setOpen(false)}
                    sx={{
                        position: "absolute",
                        top: 10,
                        left: 10,
                        color: "grey.500",
                        ":hover": {
                            color: "red",
                        }
                    }}
                >
                    <GridCloseIcon />
                </IconButton>
                {renderContent()}
            </Paper>
        </Slide>
    );
};

export default MeetingsTraySlider;
