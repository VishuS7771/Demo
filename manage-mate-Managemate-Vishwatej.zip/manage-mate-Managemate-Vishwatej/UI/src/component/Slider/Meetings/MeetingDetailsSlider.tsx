import React, { useEffect, useRef } from "react";
import { Slide, Paper, IconButton } from "@mui/material";
import { GridCloseIcon } from "@mui/x-data-grid";
import EditMeetingStatus from "./EditMeetingStatus";

interface MeetingDetailsSliderProps {
    open: boolean;
    setOpen: (value: boolean) => void;
    width?: number | string;
    meetingId: string;
    currentSlider: string;
}

const MeetingDetailsSlider: React.FC<MeetingDetailsSliderProps> = ({
    open,
    setOpen,
    width = 600,
    meetingId,
    currentSlider,
}) => {
    const widthMap: Record<string, number> = {
        timeline: 800,
        assigneeHistory: 800,
        additional: 500,
        changeAssignee: 450,
        editMeetingStatus: 500,
    };

    const resolvedWidth = widthMap[currentSlider] ?? width;
    const sliderRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (sliderRef.current && !sliderRef.current.contains(event.target as Node)) {
                // Ignore clicks on MUI Select dropdowns (rendered in a portal)
                const target = event.target as HTMLElement;
                if (target.closest(".MuiPopover-root") || target.closest(".MuiMenu-root")) {
                    return; // Do not close the slider if clicking in the Select dropdown
                }
                setOpen(false); // Close the slider for other outside clicks
            }
        };

        if (open) {
            document.addEventListener("mousedown", handleClickOutside);
        }

        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [open, setOpen]);

    const renderContent = () => {
        switch (currentSlider) {
            case "editMeetingStatus":
                return <EditMeetingStatus meetingId={meetingId} onClose={() => setOpen(false)} />;
            default:
                return null;
        }
    };

    return (
        <Slide direction="left" in={open} mountOnEnter unmountOnExit>
            <Paper
                ref={sliderRef}
                onClick={(e) => e.stopPropagation()}
                sx={{
                    position: "absolute",
                    top: 0,
                    right: 0,
                    width: {
                        sm: "100%",
                        md: "100%",
                        lg: resolvedWidth,
                        xl: resolvedWidth,
                    },
                    height: "100%",
                    p: 2,
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "start",
                    borderRadius: "15px 0 0 15px",
                    boxShadow: 24,
                    zIndex: 1,
                    overflowY: "auto",
                }}
            >
                <IconButton
                    onClick={() => setOpen(false)}
                    sx={{
                        position: "absolute",
                        top: 10,
                        left: 10,
                        color: "grey.500",
                        ":hover": {
                            color: "red",
                        },
                    }}
                >
                    <GridCloseIcon />
                </IconButton>
                {renderContent()}
            </Paper>
        </Slide>
    );
};

export default MeetingDetailsSlider;