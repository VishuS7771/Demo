import React, { useState, useEffect } from "react";
import SelectMulti, { MultiValue } from "react-select";
import { toast } from "react-toastify";
import { getAllEmployees, getMeetingById, getParticipantsByMeetingId, updateMeetingStatus } from "../../../Requests/MeetingRequest";
import { MeetingParticipantsDto } from "../../../Interfaces/Meeting";
import { Box, Button, FormControl, InputLabel, MenuItem, Select, TextField, Typography } from "@mui/material";

interface EmployeeOption {
    value: number;
    label: string;
}

interface EditMeetingStatusProps {
    meetingId: string;
    onClose: () => void;
}

const EditMeetingStatus: React.FC<EditMeetingStatusProps> = ({ meetingId, onClose }) => {
    const [status, setStatus] = useState<string>("");
    const [reasonForCancellation, setReasonForCancellation] = useState<string>("");
    const [mom, setMom] = useState<string>("");
    const [employees, setEmployees] = useState<EmployeeOption[]>([]);
    const [selEmployee, setSelEmployee] = useState<EmployeeOption[]>([]);
    const [selEmpId, setSelEmpId] = useState<number[]>([]);
    const [id, setId] = useState<any>();
    const [errors, setErrors] = useState<{ reasonForCancellation?: string; mom?: string }>({});

    useEffect(() => {
        const fetchParticipants = async () => {
            try {
                const meetingData = await getMeetingById(meetingId);
                setId(meetingData.id);
                setStatus(meetingData.meetingStatus);
                const participantsData = await getParticipantsByMeetingId(meetingData.id);
                if (Array.isArray(participantsData)) {
                    const employeeOptions = participantsData.map((participant: MeetingParticipantsDto) => ({
                        value: participant.employeeId,
                        label: participant.participantName,
                    }));
                    setSelEmployee(employeeOptions);
                    setSelEmpId(employeeOptions.map((e) => e.value));
                }
            } catch (error) {
                console.error("Error fetching meeting data:", error);
            }
        };
        fetchParticipants();
    }, [meetingId]);

    useEffect(() => {
        if (employees.length === 0) {
            const fetchEmployees = async () => {
                try {
                    const data = await getAllEmployees();
                    const employeeOptions = data.map((employee: { employeeId: number; employeeFullName: string }) => ({
                        value: employee.employeeId,
                        label: employee.employeeFullName,
                    }));
                    setEmployees(employeeOptions);
                } catch (error) {
                    console.error("Error fetching employees:", error);
                }
            };
            fetchEmployees();
        }
    }, [employees]);

    const validateForm = () => {
        let isValid = true;
        const newErrors: { reasonForCancellation?: string; mom?: string } = {};
        if (status === "Cancelled" && !reasonForCancellation) {
            newErrors.reasonForCancellation = "Reason for cancellation is required when the meeting is cancelled.";
            isValid = false;
        }
        if (status === "Completed" && !mom) {
            newErrors.mom = "MOM is required when the meeting is completed.";
            isValid = false;
        }
        setErrors(newErrors);
        return isValid;
    };

    const handleFormSubmit = async () => {
        if (!validateForm()) {
            return;
        }
        const meetingsDto = {
            id,
            meetingId,
            employeeId: selEmpId,
            meetingStatus: status,
            mom,
            reasonForCancellation,
        };
        try {
            const response = await updateMeetingStatus(meetingId, meetingsDto);
            if (response.httpStatus === "OK") {
                toast.success("Meeting Status Updated Successfully!");
                onClose();
            } else {
                toast.error("Failed to update meeting status");
            }
        } catch (error) {
            toast.error("Failed to update meeting status");
        }
    };

    const handleChange = (selectedOptions: MultiValue<EmployeeOption>) => {
        const selectedEmployees = selectedOptions as EmployeeOption[];
        setSelEmployee(selectedEmployees);
        setSelEmpId(selectedEmployees.map((e) => e.value));
    };

    return (
        <Box sx={{ p: 3, width: "100%" }}>
            <Typography variant="h6" component="div" align="center" gutterBottom sx={{ mb: 4, fontWeight: 'bold', color: '#6da0cf' }}>
                Meeting Status
            </Typography>
            <Box component="form" sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
                <FormControl fullWidth>
                    <InputLabel id="status-label">Status</InputLabel>
                    <Select
                        labelId="status-label"
                        id="status"
                        value={status}
                        label="Status"
                        onChange={(e) => setStatus(e.target.value)}
                    >
                        <MenuItem value={status}>{status}</MenuItem>
                        {["Completed", "Cancelled"]
                            .filter((item) => item !== status)
                            .map((item) => (
                                <MenuItem key={item} value={item}>
                                    {item}
                                </MenuItem>
                            ))}
                    </Select>
                </FormControl>

                {status === "Cancelled" && (
                    <TextField
                        fullWidth
                        id="reasonForCancellation"
                        label="Reason for Cancellation"
                        multiline
                        rows={4}
                        value={reasonForCancellation}
                        onChange={(e) => setReasonForCancellation(e.target.value)}
                        error={!!errors.reasonForCancellation}
                        helperText={errors.reasonForCancellation}
                    />
                )}

                {status === "Completed" && (
                    <TextField
                        fullWidth
                        id="mom"
                        label="MOM"
                        multiline
                        rows={6}
                        value={mom}
                        onChange={(e) => setMom(e.target.value)}
                        error={!!errors.mom}
                        helperText={errors.mom}
                    />
                )}

                <FormControl fullWidth>
                    <SelectMulti
                        isMulti
                        options={employees}
                        onChange={handleChange}
                        value={selEmployee}
                        placeholder="Select employees..."
                        id="attendees"
                    />
                </FormControl>

                <Box sx={{ textAlign: "right", mt: 5 }}>
                    <Button variant="contained" color="primary" onClick={handleFormSubmit}>
                        Update
                    </Button>
                </Box>
            </Box>
        </Box>
    );
};

export default EditMeetingStatus;