import React from "react";
import { Slide, Paper, IconButton } from "@mui/material";
import { GridCloseIcon } from "@mui/x-data-grid";
import TaskStatusTimeline from "./TaskStatusTimeline";
import { Task } from "../../../Interfaces/Task";
import TaskAssignHistory from "./TaskAssigneeHistory";
import AdditionalRequirement from "./AdditionalRequirement";
import ChangeAssignee from "./ChangeAssigne";
import SearchProjectDetails from "./SearchProject";

interface BaTraySliderProps {
    open: boolean;
    setOpen: (value: boolean) => void;
    width?: number | string;
    task?: Task | null;
    currentSlider: string;
    setFilteredTasks?: React.Dispatch<React.SetStateAction<Task[]>>;
    tasks?: Task[];
}

const BaTraySlider: React.FC<BaTraySliderProps> = ({
    open,
    setOpen,
    width = 600,
    task,
    currentSlider,
    tasks,
    setFilteredTasks
}) => {

    const widthMap: Record<string, number> = {
        timeline: 950,
        assigneeHistory: 1100,
        additional: 500,
        changeAssignee: 450,
    };

    const resolvedWidth = widthMap[currentSlider] ?? width;

    const renderContent = () => {
        switch (currentSlider) {
            case "searchProjectDetails":
                return <SearchProjectDetails tasks={tasks} setFilteredTasks={setFilteredTasks} setOpen={setOpen}/>;
            case "timeline":
                return task && <TaskStatusTimeline task={task} />;
            case "assigneeHistory":
                return task && <TaskAssignHistory task={task} />;
            case "additional":
                return task && <AdditionalRequirement task={task} />;
            case "changeAssignee":
                return task && <ChangeAssignee task={task}  />;
            default:
                return null;
        }
    };


    return (
        <Slide direction="left" in={open} mountOnEnter unmountOnExit>
            <Paper 
                onClick={(e) => e.stopPropagation()}
                sx={{
                    position: "absolute",
                    top: 0,
                    right: 0,
                    width: {
                        sm: '100%',
                        md: '100%',
                        lg: resolvedWidth,
                        xl: resolvedWidth,
                    },
                    height: "100%",
                    p: 2,
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "start",
                    borderRadius: "15px 0 0 15px",
                    boxShadow: 24,
                    zIndex: 1,
                    overflowY: "auto",
                }}
            >
                <IconButton
                    onClick={() => setOpen(false)}
                    sx={{
                        position: "absolute",
                        top: 10,
                        left: 10,
                        color: "grey.500",
                        ":hover": {
                            color: "red",
                        }
                    }}
                >
                    <GridCloseIcon />
                </IconButton>
                {renderContent()}
            </Paper>
        </Slide>
    );
};

export default BaTraySlider;
