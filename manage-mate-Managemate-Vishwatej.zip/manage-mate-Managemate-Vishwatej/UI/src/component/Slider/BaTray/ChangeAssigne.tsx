import React, { useState, useEffect, useRef } from "react";
import {
    Autocomplete,
    TextField,
    Button,
    Grid,
    Typography,
    Box,
    FormControl,
    InputAdornment,
    IconButton,
} from "@mui/material";
import SaveIcon from "@mui/icons-material/Save";
import ClearIcon from "@mui/icons-material/Clear";
import UploadIcon from "@mui/icons-material/Upload";
import { styled } from "@mui/material/styles";
import { Task, TaskAssignmentHistoryDto, Tray, User } from "../../../Interfaces/Task";
import { EmployeeData } from "../../../Interfaces/Login";
import { assignTask, getTrayList, getUserList } from "../../../Requests/TaskRequest";
import { DescriptionOutlined, Person2Outlined, Refresh, TableRowsOutlined } from "@mui/icons-material";
import { toast } from "react-toastify";

const FormContainer = styled(Box)(({ theme }) => ({
    padding: theme.spacing(3),
    maxWidth: 600,
    margin: "auto",
    [theme.breakpoints.down("sm")]: {
        padding: theme.spacing(2),
    },
}));

const StyledFormControl = styled(FormControl)(({ theme }) => ({
    marginBottom: theme.spacing(2),
    width: "100%",
}));

const StyledButton = styled(Button)(({ theme }) => ({
    marginRight: theme.spacing(1),
}));

interface ChangeAssigneeProps {
    task?: Task | null;
   
}

const ChangeAssignee: React.FC<ChangeAssigneeProps> = ({ task }) => {
    const [trayList, setTrayList] = useState<Tray[]>([]);
    const [userList, setUserList] = useState<User[]>([]);
    const [selectedTray, setSelectedTray] = useState<string>("");
    const [selectedUser, setSelectedUser] = useState<string>("");
    const [remarks, setRemarks] = useState<string>("");
    const [employee, setEmployee] = useState<EmployeeData | null>(null);
    const [file, setFile] = useState<File | null>(null);
    const [fileName, setFileName] = useState<string>("");
    const [errors, setErrors] = useState<{ tray?: string; user?: string; remarks?: string }>({});
    const fileInputRef = useRef<HTMLInputElement | null>(null);

    useEffect(() => {
        const storedData = localStorage.getItem("employeedata");
        if (storedData) {
            const parsedData = JSON.parse(storedData);
            setEmployee(parsedData);
        }
        getTrayList()
            .then((response) => setTrayList(response.data))
            .catch((error) => console.error("Error fetching tray list:", error));
    }, []);

    const handleTrayChange = async (_: React.ChangeEvent<{}>, value: Tray | null) => {
        const trayName = value?.trayName || "";
        setSelectedTray(trayName);
        setSelectedUser("");
        setErrors((prev) => ({ ...prev, tray: "" }));

        if (trayName) {
            try {
                const response = await getUserList(trayName);
                setUserList(response.data);
            } catch (error) {
                console.error("Error fetching user list:", error);
            }
        } else {
            setUserList([]);
        }
    };

    const handleUserChange = (_: React.ChangeEvent<{}>, value: User | null) => {
        setSelectedUser(value?.employeeId?.toString() || "");
        setErrors((prev) => ({ ...prev, user: "" }));
    };

    const handleRemarksChange = (event: React.ChangeEvent<HTMLTextAreaElement>) => {
        setRemarks(event.target.value);
        setErrors((prev) => ({ ...prev, remarks: "" }));
    };

    const handleAttachment = (e: React.ChangeEvent<HTMLInputElement>) => {
        const selectedFile = e.target.files?.[0];
        if (selectedFile) {
            setFile(selectedFile);
            setFileName(selectedFile.name);
        }
    };

    const handleClearFile = () => {
        setFile(null);
        setFileName("");
        if (fileInputRef.current) {
            fileInputRef.current.value = "";
        }
    };

    const handleClear = () => {
        setSelectedTray("");
        setSelectedUser("");
        setRemarks("");
        setFile(null);
        setFileName("");
        setErrors({});
        if (fileInputRef.current) {
            fileInputRef.current.value = "";
        }
    };

    const validateForm = () => {
        const newErrors: { tray?: string; user?: string; remarks?: string } = {};
        if (!selectedTray) newErrors.tray = "Tray is required";
        if (!selectedUser) newErrors.user = "User is required";
        if (!remarks.trim()) newErrors.remarks = "Remarks are required";
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async () => {
        if (!validateForm()) return;

        const employeeIdNumber = selectedUser ? parseInt(selectedUser, 10) : NaN;
        const assignId = employee?.EmployeeNo ? parseInt(employee.EmployeeNo, 10) : NaN;

        const newTaskAssignment: TaskAssignmentHistoryDto = {
            task: task!,
            employeeId: employeeIdNumber,
            remarks: remarks,
            assignedBy: assignId,
            assignTaskId: 0,
            employeeNameAndId: "",
            assignDate: new Date(),
            assignedByNameAndId: "",
            isAssigned: 1,
            attachmentPath: "",
        };

        try {
            const response = await assignTask(newTaskAssignment, file);
            if (response.httpStatus === "CREATED") {
                toast.success("Assignee changed successfully");
            } else {
                toast.error("Assignee change failed");
            }
        } catch (error) {
            console.error("Error assigning task:", error);
            toast.error("Error assigning task");
        }
    };

    return (
        <FormContainer>
            <Box
                sx={{
                    position: "relative",
                    top: "15%",
                    left: "50%",
                    transform: "translate(-50%, -50%)",
                }}
            >
                <Typography
                    variant="h5"
                    fontWeight={600}
                    mb={3}
                    sx={{ paddingLeft: 2 }}
                >
                    Assign Project
                </Typography>
                <Grid container spacing={2}>
                    <Grid item xs={12}>
                        <StyledFormControl error={!!errors.tray} required>
                            <Autocomplete
                                options={trayList}
                                getOptionLabel={(option) => option.trayName}
                                value={trayList.find((tray) => tray.trayName === selectedTray) || null}
                                onChange={handleTrayChange}
                                renderInput={(params) => (
                                    <TextField
                                        {...params}
                                        label="Tray"
                                        variant="outlined"
                                        error={!!errors.tray}
                                        helperText={errors.tray}
                                        InputProps={{
                                            ...params.InputProps,
                                            startAdornment: (
                                                <InputAdornment position="start">
                                                    <TableRowsOutlined />
                                                </InputAdornment>
                                            ),
                                        }}
                                    />
                                )}
                            />
                        </StyledFormControl>
                    </Grid>

                    <Grid item xs={12}>
                        <StyledFormControl error={!!errors.user} required>
                            <Autocomplete
                                options={userList}
                                getOptionLabel={(option) => option.employeeName}
                                value={userList.find((user) => user.employeeId.toString() === selectedUser) || null}
                                onChange={handleUserChange}
                                disabled={!selectedTray}
                                renderInput={(params) => (
                                    <TextField
                                        {...params}
                                        label="User"
                                        variant="outlined"
                                        error={!!errors.user}
                                        helperText={errors.user}
                                        InputProps={{
                                            ...params.InputProps,
                                            startAdornment: (
                                                <InputAdornment position="start">
                                                    <Person2Outlined />
                                                </InputAdornment>
                                            ),
                                        }}
                                    />
                                )}
                            />
                        </StyledFormControl>
                    </Grid>

                    <Grid item xs={12}>
                        <StyledFormControl error={!!errors.remarks} required>
                            <TextField
                                label="Remarks"
                                variant="outlined"
                                placeholder="Remarks"
                                multiline
                                maxRows={5}
                                value={remarks}
                                onChange={handleRemarksChange}
                                error={!!errors.remarks}
                                helperText={errors.remarks}
                                fullWidth
                                InputProps={{
                                    startAdornment: (
                                        <InputAdornment position="start">
                                            <DescriptionOutlined />
                                        </InputAdornment>
                                    ),
                                }}
                            />
                        </StyledFormControl>
                    </Grid>

                    <Grid item xs={12}>
                        <Typography
                            variant="subtitle2"
                            sx={{
                                color: "text.secondary",
                                fontSize: { xs: "0.75rem", sm: "0.875rem" },
                                mt: -2
                            }}
                        >
                            Add Attachment
                        </Typography>
                        <Box display="flex" alignItems="center" gap={2} mb={2}>
                            <Button
                                variant="outlined"
                                color="primary"
                                startIcon={<UploadIcon />}
                                onClick={() => fileInputRef.current?.click()}
                                sx={{ borderRadius: "8px", textTransform: "none" }}
                            >
                                Choose File
                            </Button>
                            <Typography
                                variant="body2"
                                color={fileName ? "textPrimary" : "textSecondary"}
                            >
                                {fileName || "No file chosen"}
                            </Typography>
                            {fileName && (
                                <IconButton
                                    onClick={handleClearFile}
                                    sx={{ color: "grey.600" }}
                                    title="Clear File"
                                >
                                    <ClearIcon />
                                </IconButton>
                            )}
                            <input
                                type="file"
                                id="attachment-input"
                                onChange={handleAttachment}
                                ref={fileInputRef}
                                style={{ display: "none" }}
                            />
                        </Box>
                    </Grid>

                    <Grid item xs={12}>
                        <Box
                            sx={{
                                display: "flex",
                                justifyContent: { xs: "center", sm: "flex-end" },
                                gap: 2,
                                flexWrap: "wrap",
                            }}
                        >
                            <StyledButton
                                variant="contained"
                                color="primary"
                                startIcon={<SaveIcon />}
                                onClick={handleSubmit}
                            >
                                Submit
                            </StyledButton>
                            <StyledButton
                                variant="outlined"
                                color="error"
                                startIcon={<Refresh />}
                                onClick={handleClear}
                            >
                                Clear
                            </StyledButton>
                        </Box>
                    </Grid>
                </Grid>
            </Box>
        </FormContainer>
    );
};

export default ChangeAssignee;