import React, { useState, useEffect } from "react";
import dayjs from "dayjs";
import { Task, TaskTimeLineData, TaskTimelineDto } from "../../../Interfaces/Task";
import { getTaskTimeLine } from "../../../Requests/TaskRequest";
import {
  Box,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Pagination,
  Typography,
  Tooltip,
} from "@mui/material";
import { Empty } from "antd";
import TableSkeleton from "../../Skeletons/Skeleton";
import { StatusChip } from "../../Chip/StatusChip";
import { tooltipProps } from "../../../util/constants/commonStyles";

interface TaskStatusTimelineProps {
  task?: Task | null;
}

const TaskStatusTimeline: React.FC<TaskStatusTimelineProps> = ({ task }) => {
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize] = useState(10);
  const [taskTimeLineData, setTaskTimeLineData] = useState<TaskTimeLineData[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (task?.id) {
      setLoading(true);
      getTaskTimeLine(task.id)
        .then((response) => {
          const data = response.data || [];
          const mappedData: TaskTimeLineData[] = data.map(
            (taskTimeline: TaskTimelineDto) => ({
              taskTimeLineId: taskTimeline.taskTimeLineId,
              status: taskTimeline.statusDefinitionsDto.status,
              subStatus: taskTimeline.subStatusDefinitionsDto.subStatus,
              dateAndTime: taskTimeline.dateAndTime,
              statusMarkedBy: taskTimeline.statusMarkedBy,
              proprietorName: taskTimeline.proprietorAssignmentsDto.proprietorMasterDto.proprietorName,
            })
          );
          setTaskTimeLineData(mappedData || []);
        })
        .catch((error) => {
          console.error("Error fetching task status timeline:", error);
        })
        .finally(() => {
            setLoading(false);
        });
    }
  }, [task?.id]);

  const paginatedData = taskTimeLineData.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize
  );

  const totalPages = Math.ceil(taskTimeLineData.length / pageSize);

  const handlePageChange = (_event: React.ChangeEvent<unknown>, pageNumber: number) => {
    setCurrentPage(pageNumber);
  };

  return (
    <Box alignItems="left" flexDirection="column" mt={2}>
      <Box px={5} mb={3}>
        <Typography variant="h5" sx={{ fontWeight: 600 }}>
          Project Status Timeline
        </Typography>
      </Box>

      <TableContainer sx={{ minHeight: "65vh", mt: 2 }}>
        {loading ? (
            <TableSkeleton column={5} />
        ) : paginatedData.length > 0 ? (
          <Table size="small">
            <TableHead>
              <TableRow sx={{ height: 60 }}>
                <TableCell sx={{ fontWeight: "bold", width: 50, textAlign: "center" }}>
                  SR.NO
                </TableCell>
                <TableCell sx={{ fontWeight: "bold", width: 200, textAlign: "center" }}>
                  STATUS
                </TableCell>
                <TableCell sx={{ fontWeight: "bold", width: 200, whiteSpace: "nowrap" }}>
                  SUB-STATUS
                </TableCell>
                <TableCell sx={{ fontWeight: "bold", width: 200, whiteSpace: "nowrap" }}>
                  PROPRIETOR
                </TableCell>
                <TableCell sx={{ fontWeight: "bold", width: 200, whiteSpace: "nowrap" }}>
                  DATE & TIME
                </TableCell>
                <TableCell sx={{ fontWeight: "bold", width: 200, whiteSpace: "nowrap" }}>
                  STATUS MARKED BY
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {paginatedData.map((record, index) => (
                <TableRow key={record.taskTimeLineId} sx={{ height: 55 }}>
                  <TableCell align="center">
                    {(currentPage - 1) * pageSize + index + 1}
                  </TableCell>
                  <TableCell
                    sx={{
                      maxWidth: 200,
                      whiteSpace: "nowrap",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                      textAlign: "center",
                    }}
                  >

                    <Tooltip title={record.status} {...tooltipProps} disableHoverListener={record.status.length <= 10} >
                      <span>
                        <StatusChip status={record.status} />
                      </span>
                    </Tooltip>
                  </TableCell>
                  <TableCell
                    sx={{
                      maxWidth: 200,
                      whiteSpace: "nowrap",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                    }}
                  >
                    {record.subStatus}
                  </TableCell>
                  <TableCell
                    sx={{
                      maxWidth: 200,
                      whiteSpace: "nowrap",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                    }}
                  >
                    {record.proprietorName}
                  </TableCell>
                  <TableCell
                    sx={{
                      maxWidth: 200,
                      whiteSpace: "nowrap",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                    }}
                  >
                    {dayjs(record.dateAndTime).format("DD MMM YYYY hh:mm A")}
                  </TableCell>
                  <TableCell
                    sx={{
                      maxWidth: 300,
                      whiteSpace: "nowrap",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                    }}
                  >
                    {record.statusMarkedBy}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        ) : (
          <Box
            display="flex"
            justifyContent="center"
            alignItems="center"
            minHeight="68vh"
          >
            <Empty description="No Task Status Timeline Available" />
          </Box>
        )}
      </TableContainer>

      <Box display="flex" justifyContent="center" mt={1}>
        <Pagination
          count={totalPages}
          page={currentPage}
          sx={{
            "& .MuiPaginationItem-root": {
              color: "rgb(73, 102, 131) !important",
              borderColor: "rgb(73, 102, 131) !important",
            },
            "& .MuiPaginationItem-root.Mui-selected": {
              backgroundColor: "rgb(73, 102, 131) !important",
              color: "#fff !important",
            },
          }}
          onChange={handlePageChange}
        />
      </Box>
    </Box>
  );
};

export default TaskStatusTimeline;