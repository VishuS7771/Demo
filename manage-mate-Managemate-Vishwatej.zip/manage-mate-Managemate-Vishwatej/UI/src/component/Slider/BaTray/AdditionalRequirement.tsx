import React, { useState, useEffect, useRef } from "react";
import {
    Box,
    Grid,
    Typography,
    TextField,
    Button,
    FormControl,
    InputAdornment,
    IconButton,
} from "@mui/material";
import { styled } from "@mui/material/styles";
import SaveIcon from "@mui/icons-material/Save";
import ClearIcon from "@mui/icons-material/Clear";
import UploadIcon from "@mui/icons-material/Upload";
import DescriptionOutlined from "@mui/icons-material/DescriptionOutlined";
import { AdditonalRequirement, Task } from "../../../Interfaces/Task";
import { toast, ToastContainer } from "react-toastify";
import { additionalRequirementReq } from "../../../Requests/TaskRequest";

const StyledFormControl = styled(FormControl)(({ theme }) => ({
    marginBottom: theme.spacing(2),
    width: "100%",
}));

const StyledButton = styled(Button)(({ theme }) => ({
    marginRight: theme.spacing(1),
}));

interface AdditionalRequirementProps {
    task?: Task | null;
}

const AdditionalRequirement: React.FC<AdditionalRequirementProps> = ({ task }) => {
    const [additionalRequirement, setAdditionalRequirement] = useState<AdditonalRequirement>({
        additionalRequirementId: 0,
        tasksDto: task!,
        requirement: "",
        dateAndTime: "",
        attachment: "",
    });
    const [file, setFile] = useState<File | null>(null);
    const [fileName, setFileName] = useState<string>("");
    const [errors, setErrors] = useState<{ requirement?: string }>({});
    const fileInputRef = useRef<HTMLInputElement | null>(null);

    useEffect(() => {
        if (task) {
            setAdditionalRequirement((prev) => ({
                ...prev,
                tasksDto: task,
            }));
        }
    }, [task]);

    const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setAdditionalRequirement((prev) => ({
            ...prev,
            [name]: value,
        }));
        setErrors((prev) => ({ ...prev, requirement: "" }));
    };

    const handleAttachment = (e: React.ChangeEvent<HTMLInputElement>) => {
        const selectedFile = e.target.files?.[0];
        if (selectedFile) {
            setFile(selectedFile);
            setFileName(selectedFile.name);
        }
    };

    const handleClearFile = () => {
        setFile(null);
        setFileName("");
        if (fileInputRef.current) {
            fileInputRef.current.value = "";
        }
    };

    const handleClear = () => {
        setAdditionalRequirement({
            additionalRequirementId: 0,
            tasksDto: task!,
            requirement: "",
            dateAndTime: "",
            attachment: "",
        });
        setFile(null);
        setFileName("");
        setErrors({});
        if (fileInputRef.current) {
            fileInputRef.current.value = "";
        }
    };

    const validateForm = () => {
        const newErrors: { requirement?: string } = {};
        if (!additionalRequirement.requirement.trim()) {
            newErrors.requirement = "Requirement is required";
        }
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!validateForm()) return;

        try {
            const response = await additionalRequirementReq(additionalRequirement, file);
            if (response.httpStatus === "CREATED") {
                toast.success("Additional Requirement added successfully!");
                handleClear();
            } else {
                toast.error("Additional Requirement adding failed");
            }
        } catch (error) {
            console.error("Error adding requirement:", error);
            toast.error("Error adding requirement");
        }
    };

    return (
        <Box display="flex" flexDirection="column" alignItems="center" mt={1} px={2}>
            <Typography
                variant="h5"
                fontWeight={600}
                mb={5}
                sx={{ paddingLeft: 2 }}
            >
                Add New Requirement
            </Typography>
            <form onSubmit={handleSubmit}>
                <Grid container spacing={2}>
                    <Grid item xs={12}>
                        <StyledFormControl error={!!errors.requirement} required>
                            <TextField
                                label="Requirement"
                                variant="outlined"
                                placeholder="Enter requirement"
                                multiline
                                maxRows={5}
                                name="requirement"
                                value={additionalRequirement.requirement}
                                onChange={handleChange}
                                error={!!errors.requirement}
                                helperText={errors.requirement}
                                fullWidth
                                InputProps={{
                                    startAdornment: (
                                        <InputAdornment position="start">
                                            <DescriptionOutlined />
                                        </InputAdornment>
                                    ),
                                }}
                            />
                        </StyledFormControl>
                    </Grid>

                    <Grid item xs={12}>
                        <Typography
                            variant="subtitle2"
                            sx={{
                                color: "text.secondary",
                                fontSize: { xs: "0.75rem", sm: "0.875rem" },
                                mt: -2,
                            }}
                        >
                            Add Attachment
                        </Typography>
                        <Box display="flex" alignItems="center" gap={2} mb={2}>
                            <Button
                                variant="outlined"
                                color="primary"
                                startIcon={<UploadIcon />}
                                onClick={() => fileInputRef.current?.click()}
                                sx={{ borderRadius: "8px", textTransform: "none" }}
                            >
                                Choose File
                            </Button>
                            <Typography
                                variant="body2"
                                color={fileName ? "textPrimary" : "textSecondary"}
                            >
                                {fileName || "No file chosen"}
                            </Typography>
                            {fileName && (
                                <IconButton
                                    onClick={handleClearFile}
                                    sx={{ color: "grey.600" }}
                                    title="Clear File"
                                >
                                    <ClearIcon />
                                </IconButton>
                            )}
                            <input
                                type="file"
                                id="attachment-input"
                                onChange={handleAttachment}
                                ref={fileInputRef}
                                style={{ display: "none" }}
                            />
                        </Box>
                    </Grid>

                    <Grid item xs={12}>
                        <Box
                            sx={{
                                display: "flex",
                                justifyContent: { xs: "center", sm: "flex-end" },
                                gap: 2,
                                flexWrap: "wrap",
                            }}
                        >
                            <StyledButton
                                variant="contained"
                                color="primary"
                                startIcon={<SaveIcon />}
                                type="submit"
                            >
                                Submit
                            </StyledButton>
                            <StyledButton
                                variant="outlined"
                                color="error"
                                startIcon={<ClearIcon />}
                                onClick={handleClear}
                            >
                                Clear
                            </StyledButton>
                        </Box>
                    </Grid>
                </Grid>

            </form>
            <ToastContainer />

        </Box>
    );
};

export default AdditionalRequirement;