import React, { useState, useEffect } from "react";
import dayjs from "dayjs";
import { Task, TaskAssignmentHistoryDto } from "../../../Interfaces/Task";
import { downLoadDocument, getTaskAssignmetHistory } from "../../../Requests/TaskRequest";
import {
  Box,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Pagination,
  Typography,
  IconButton,
} from "@mui/material";
import { Empty } from "antd";
import TableSkeleton from "../../Skeletons/Skeleton";
import { DownloadOutlined } from "@ant-design/icons";

interface TaskAssignHistoryProps {
  task?: Task | null;
}

const TaskAssignHistory: React.FC<TaskAssignHistoryProps> = ({ task }) => {
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize] = useState(10);
  const [taskAssignmentHistoryDto, setTaskAssignmentHistoryDto] = useState<TaskAssignmentHistoryDto[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (task?.id) {
      setLoading(true);
      getTaskAssignmetHistory(task.id)
        .then((response) => {
          setTaskAssignmentHistoryDto(response.data || []);
        })
        .catch((error) => {
          console.error("Error fetching task assignment history:", error);
        })
        .finally(() => {
          setLoading(false);
        });
    }
  }, [task?.id]);

  const paginatedData = taskAssignmentHistoryDto.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize
  );

  const totalPages = Math.ceil(taskAssignmentHistoryDto.length / pageSize);

  const handlePageChange = (_event: React.ChangeEvent<unknown>, pageNumber: number) => {
    setCurrentPage(pageNumber);
  };

  const handleDownload = (filePath: string) => {
    downLoadDocument(filePath);
  };

  return (
    <Box alignItems="left" flexDirection="column" mt={2}>
      <Box px={5} mb={3}>
        <Typography variant="h5" sx={{ fontWeight: 600 }}>
          Assignee History
        </Typography>
      </Box>

      <TableContainer sx={{ minHeight: "65vh", mt: 2 }}>
        {loading ? (
          <TableSkeleton column={6} />
        ) : paginatedData.length > 0 ? (
          <Table size="small">
            <TableHead>
              <TableRow sx={{ height: 60 }}>
                <TableCell sx={{ fontWeight: "bold", width: 50, textAlign: "center" }}>
                  SR.NO
                </TableCell>
                <TableCell sx={{ fontWeight: "bold", width: 400, whiteSpace: "nowrap" }}>
                  ASSIGNED TO
                </TableCell>
                <TableCell sx={{ fontWeight: "bold", width: 150, whiteSpace: "nowrap" }}>
                  REMARKS
                </TableCell>
                <TableCell sx={{ fontWeight: "bold", width: 400, whiteSpace: "nowrap" }}>
                  ASSIGNED BY
                </TableCell>
                <TableCell sx={{ fontWeight: "bold", width: 150, whiteSpace: "nowrap" }}>
                  ASSIGNED DATE
                </TableCell>
                <TableCell sx={{ fontWeight: "bold", width: 100, textAlign: "center" }}>
                  ATTACHMENT
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {paginatedData.map((record, index) => (
                <TableRow key={record.assignTaskId} sx={{ height: 55 }}>
                  <TableCell align="center">
                    {(currentPage - 1) * pageSize + index + 1}
                  </TableCell>
                  <TableCell
                    sx={{
                      maxWidth: 200,
                      whiteSpace: "nowrap",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                    }}
                  >
                    {record.employeeNameAndId}
                  </TableCell>
                  <TableCell
                    sx={{
                      maxWidth: 200,
                      whiteSpace: "nowrap",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                    }}
                  >
                    {record.remarks || "N/A"}
                  </TableCell>
                  <TableCell
                    sx={{
                      maxWidth: 200,
                      whiteSpace: "nowrap",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                    }}
                  >
                    {record.assignedByNameAndId}
                  </TableCell>
                  <TableCell
                    sx={{
                      maxWidth: 200,
                      whiteSpace: "nowrap",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                    }}
                  >
                    {dayjs(record.assignDate).format("DD MMM YYYY hh:mm A")}
                  </TableCell>
                  <TableCell align="center"
                    sx={{
                      maxWidth: 200,
                      whiteSpace: "nowrap",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                    }}
                  >
                    {record.attachmentPath ? (
                      <IconButton onClick={() => handleDownload(record.attachmentPath)}>
                        <DownloadOutlined style={{ fontSize: "18px", color: "#1890ff" }} />
                      </IconButton>
                    ) : (
                      "No Attachment"
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        ) : (
          <Box
            display="flex"
            justifyContent="center"
            alignItems="center"
            minHeight="68vh"
          >
            <Empty description="No Task Assignment History Available" />
          </Box>
        )}
      </TableContainer>

      <Box display="flex" justifyContent="center" mt={1}>
        <Pagination
          count={totalPages}
          page={currentPage}
          sx={{
            "& .MuiPaginationItem-root": {
              color: "rgb(73, 102, 131) !important",
              borderColor: "rgb(73, 102, 131) !important",
            },
            "& .MuiPaginationItem-root.Mui-selected": {
              backgroundColor: "rgb(73, 102, 131) !important",
              color: "#fff !important",
            },
          }}
          onChange={handlePageChange}
        />
      </Box>
    </Box>
  );
};

export default TaskAssignHistory;