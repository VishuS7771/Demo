import React, { useEffect, useState } from "react";
import {
    Box,
    Grid,
    TextField,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    Chip,
    Button,
    Typography
} from "@mui/material";
import { StatusDefinitionsDto, SubStatusDefinitionsDto, Task } from "../../../Interfaces/Task";
import { getAllStatus } from "../../../Requests/StatusMappingRequest";
import { getAllSubStatus } from "../../../Requests/SubStatusRequest";
import { EmployeeData } from "../../../Interfaces/Login";
import { GridDeleteForeverIcon } from "@mui/x-data-grid";

interface SearchProjectDetailsProps {
    setFilteredTasks?: React.Dispatch<React.SetStateAction<Task[]>>;
    tasks?: Task[];
    setOpen: (value: boolean) => void;
}

const SearchProjectDetails: React.FC<SearchProjectDetailsProps> = ({ setFilteredTasks, tasks }) => {

    const [subStatuses, setSubStatuses] = useState<SubStatusDefinitionsDto[]>([]);
    const [filteredStatusMappings, setFilteredStatusMappings] = useState<StatusDefinitionsDto[]>([]);
    const [employee, setEmployee] = useState<EmployeeData | null>(null);

    const [searchCriteria, setSearchCriteria] = useState<{
        taskId: string;
        taskName: string;
        fromDate: string;
        toDate: string;
        status: string[];
        subStatus: string[];
        employeeId: number | null;
    }>({
        taskId: "",
        taskName: "",
        fromDate: "",
        toDate: "",
        status: [],
        subStatus: [],
        employeeId: null,
    })

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setSearchCriteria((prev) => ({ ...prev, [name]: value }));
    };

    const handleSearchStatus = (statuses: string[]) => {
        const empId = localStorage.getItem('employeeNo');
        const employeeId = Number(empId) || null;
        setSearchCriteria((prevCriteria) => ({
            ...prevCriteria,
            status: statuses,
            employeeId: employeeId,
        }));
    };

    const handleSearchSubStatus = (subStatuses: string[]) => {
        const empId = localStorage.getItem('employeeNo');
        const employeeId = Number(empId) || null;
        setSearchCriteria((prevCriteria) => ({
            ...prevCriteria,
            subStatus: subStatuses,
            employeeId: employeeId,
        }));
    };

    const fetchSubStatuses = async () => {
        try {
            const data = await getAllSubStatus();
            setSubStatuses(data.data);

        } catch (err) {
            console.log("Failed to fetch sub-status data.");
        } 
    };

    const fetchAllStatusMappings = async () => {
        try {
            const response = await getAllStatus();
            setFilteredStatusMappings(Array.isArray(response.data) ? response.data : []);
        } catch (error) {
            console.error("Error fetching all status mappings:", error);
            setFilteredStatusMappings([]);
        } 
    };

    const handleSearch = () => {
        const parseCustomDate = (dateString: string) => {
            const [day, month, year] = dateString.split("-");
            return new Date(`${year}-${month}-${day}`);
        };

        const filtered = tasks?.filter((task) => {
            if (!task.dateAndTime) return false; // Prevent null errors
            const taskDate = parseCustomDate(task.dateAndTime);
            const fromDate = searchCriteria.fromDate ? new Date(searchCriteria.fromDate) : null;
            const toDate = searchCriteria.toDate ? new Date(searchCriteria.toDate) : null;

            const currentDate = new Date();
            let closestTimeline =
                task.taskTimelineDto.length > 0
                    ? task.taskTimelineDto.reduce((closest, timeline) => {
                        const timelineDate = new Date(timeline.dateAndTime);
                        const currentDiff = Math.abs(currentDate.getTime() - timelineDate.getTime());
                        const closestDiff = Math.abs(currentDate.getTime() - new Date(closest.dateAndTime).getTime());

                        return currentDiff < closestDiff ? timeline : closest;
                    }, task.taskTimelineDto[0])
                    : null;

            if (!closestTimeline) {
                return false;
            }

            return (
                (searchCriteria.taskId
                    ? task.taskId.toString().includes(searchCriteria.taskId)
                    : true) &&
                (searchCriteria.taskName
                    ? task.taskName.toLowerCase().includes(searchCriteria.taskName.toLowerCase())
                    : true) &&
                (fromDate ? taskDate >= fromDate : true) &&
                (toDate ? taskDate <= toDate : true) &&
                (Array.isArray(searchCriteria.status) && searchCriteria.status.length > 0
                    ? searchCriteria.status.some(
                        (status) =>
                            status &&
                            typeof status === "string" &&
                            closestTimeline.statusDefinitionsDto?.status.toLowerCase() === status.toLowerCase()
                    )
                    : true) &&
                (Array.isArray(searchCriteria.subStatus) && searchCriteria.subStatus.length > 0
                    ? searchCriteria.subStatus.some(
                        (subStatus) =>
                            subStatus &&
                            typeof subStatus === "string" &&
                            closestTimeline.subStatusDefinitionsDto?.subStatus.toLowerCase() === subStatus.toLowerCase()
                    )
                    : true)
            );
        });

        if (filtered) {
            setFilteredTasks?.(filtered);
        }


    };

    useEffect(() => {
        const storedData = localStorage.getItem('employeedata');
        if (storedData) {
            const parsedData = JSON.parse(storedData);
            setEmployee(parsedData);

            if (parsedData?.DesignationId) {
                fetchAllStatusMappings();
                fetchSubStatuses();
            }

            setSearchCriteria({
                taskId: "",
                taskName: "",
                fromDate: "",
                toDate: "",
                status: [],
                subStatus: [],
                employeeId: Number(parsedData?.EmployeeNo) || null,
            });
        }
    }, []);


    return (
        <Box display="flex" flexDirection="column" alignItems="center" mt={1} px={2}>



            <Typography
                variant="h6"
                align="center"
                component="div"
                gutterBottom
                sx={{ fontWeight: "bold", color: "rgb(73, 102, 131)" }}
            >
                Search Project
            </Typography>

            <Grid container gap={2}>
                <TextField
                    fullWidth
                    label="Project ID"
                    name="taskId"
                    placeholder="Project ID"
                    value={searchCriteria.taskId}
                    onChange={handleInputChange}
                    variant="standard"
                />
                <TextField
                    fullWidth
                    label="Project Name"
                    name="taskName"
                    placeholder="Project Name"
                    value={searchCriteria.taskName}
                    onChange={handleInputChange}
                    variant="standard"
                />
                <FormControl variant="standard" sx={{ mb: 2 }} fullWidth>
                    <InputLabel>Status</InputLabel>
                    <Select
                        multiple
                        name="status"
                        value={searchCriteria.status || []}
                        onChange={(event) => handleSearchStatus(event.target.value as string[])}
                        renderValue={(selected) => (
                            <div>
                                {selected.map((value) => (
                                    <Chip
                                        key={value}
                                        label={value}
                                        // onDelete={() => handleRemoveStatus(value)}
                                        deleteIcon={<GridDeleteForeverIcon />}
                                        sx={{ margin: 0.5 }}
                                    />
                                ))}
                            </div>
                        )}
                        MenuProps={{
                            PaperProps: {
                                style: {
                                    maxHeight: 200,
                                    maxWidth: 300, // Set a reasonable width
                                    overflow: 'auto',
                                },
                            },
                        }}
                    >
                        {filteredStatusMappings.map((status) => (
                            <MenuItem key={status.status} value={status.status}>
                                {status.status}
                            </MenuItem>
                        ))}
                    </Select>
                </FormControl>

                <FormControl variant="standard" sx={{ gap: 3 }} fullWidth>

                    <TextField
                        fullWidth
                        type="date"
                        name="fromDate"
                        label="From Date"
                        value={searchCriteria.fromDate}
                        onChange={handleInputChange}
                        variant="standard"
                        InputLabelProps={{ shrink: true }}
                    />

                    <TextField
                        fullWidth
                        type="date"
                        name="toDate"
                        label="To Date"
                        value={searchCriteria.toDate}
                        onChange={handleInputChange}
                        variant="standard"
                        InputLabelProps={{ shrink: true }}
                    />

                </FormControl>

                <FormControl variant="standard" fullWidth>
                    <InputLabel>Sub-Status</InputLabel>
                    <Select
                        multiple
                        name="subStatus"
                        value={searchCriteria.subStatus || []}
                        onChange={(event) => handleSearchSubStatus(event.target.value as string[])}
                        renderValue={(selected) => (
                            <div>
                                {selected.map((value) => (
                                    <Chip key={value} label={value} style={{ margin: 2 }} />
                                ))}
                            </div>
                        )}

                        MenuProps={{
                            PaperProps: {
                                style: {
                                    maxHeight: 200,
                                    maxWidth: 300, // Set a reasonable width
                                    overflow: 'auto',
                                },
                            },
                        }}
                    >
                        {subStatuses.map((subStatus) => (
                            <MenuItem key={subStatus.subStatus} value={subStatus.subStatus}>
                                {subStatus.subStatus}
                            </MenuItem>
                        ))}
                    </Select>

                </FormControl>
            </Grid>

            <Box sx={{ textAlign: "right", mt: 5, display: "flex", justifyContent: "space-between",width:"100%" }}>


                <Button variant="contained" color="primary" onClick={() => {
                    setSearchCriteria({
                        taskId: "",
                        taskName: "",
                        fromDate: "",
                        toDate: "",
                        status: [],
                        subStatus: [],
                        employeeId: Number(employee?.EmployeeNo) || null,
                    });
                    if (tasks) {
                        setFilteredTasks?.(tasks);
                    }

                }

                }>
                    Reset
                </Button>
                <Button variant="contained" color="primary" onClick={handleSearch}>
                    Search
                </Button>
            </Box>
        </Box>
    );
};

export default SearchProjectDetails;
