import { Navigate } from 'react-router-dom';
import { useContext } from 'react';
import { AuthContext } from '../component/Auth/AuthContext';

const ProtectedRoute = ({ children }: { children: JSX.Element }) => {
  const { isAuthenticated } = useContext(AuthContext);

  if (!localStorage.getItem('token')) {
    return <Navigate to="/ui/login" replace />;
  }

  return isAuthenticated ? children : null;
};


export default ProtectedRoute;
