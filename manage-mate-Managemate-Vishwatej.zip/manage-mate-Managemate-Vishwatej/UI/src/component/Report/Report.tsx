import React, { useEffect, useState } from "react";
import { toast, ToastContainer } from "react-toastify";
import { getAllSubStatus } from "../../Requests/SubStatusRequest";
import { getAllStatus } from "../../Requests/StatusMappingRequest";
import { getTaskList } from "../../Requests/TaskRequest";
import { downloadReport } from "../../Requests/MenuPermission";
import { ReportState, StatusDefinitionsDto, SubStatusDefinitionsDto, TaskList } from "../../Interfaces/Task";
import {
  Box,
  Button,
  Grid,
  TextField,
  MenuItem,
  Typography,
  Paper,
  InputAdornment,
  IconButton,
  Autocomplete
} from "@mui/material";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import {
  DateRange,
  Download,
  Refresh,
  AssessmentOutlined,
  AssignmentIndOutlined,
  DescriptionOutlined,
  FilterList,
} from "@mui/icons-material";

interface StatusOption {
  value: number;
  label: string;
}

interface SubStatusOption {
  value: number;
  label: string;
}

const ReportComponent: React.FC = () => {
  const [report, setReport] = useState<ReportState>({
    reportType: "",
    taskId: "",
    statusId: [],
    subStatusId: [],
    dateFrom: null,
    dateTo: null,
  });

  const [projects, setProjects] = useState<TaskList[]>([]);
  const [statusOptions, setStatusOptions] = useState<StatusOption[]>([]);
  const [subStatusOptions, setSubStatusOptions] = useState<SubStatusOption[]>([]);
  const [selectedStatuses, setSelectedStatuses] = useState<StatusOption[]>([]);
  const [selectedSubStatuses, setSelectedSubStatuses] = useState<SubStatusOption[]>([]);
  const [errors, setErrors] = useState<Partial<Record<keyof ReportState, string>>>({});
  const [openDateFrom, setOpenDateFrom] = useState(false);
  const [openDateTo, setOpenDateTo] = useState(false);

  useEffect(() => {
    const fetchStatusAndSubStatus = async () => {
      try {
        const statusResponse = await getAllStatus();
        const statusData = statusResponse.data;
        const statusOptions = statusData.map((status: StatusDefinitionsDto) => ({
          value: status.statusId,
          label: status.status,
        }));
        setStatusOptions(statusOptions);

        const subStatusResponse = await getAllSubStatus();
        const subStatusData = subStatusResponse.data;
        const subStatusOptions = subStatusData.map((subStatus: SubStatusDefinitionsDto) => ({
          value: subStatus.subStatusId,
          label: subStatus.subStatus,
        }));
        setSubStatusOptions(subStatusOptions);
      } catch (error) {
        console.error("Error fetching data:", error);
        setStatusOptions([]);
        setSubStatusOptions([]);
      }
    };
    fetchStatusAndSubStatus();
  }, []);

  useEffect(() => {
    const fetchTaskList = async () => {
      try {
        const response = await getTaskList();
        setProjects(response.data);
      } catch (error) {
        console.error("Error fetching task list:", error);
      }
    };
    fetchTaskList();
  }, []);

  const validateForm = (): boolean => {
    const newErrors: Partial<Record<keyof ReportState, string>> = {};

    if (!report.reportType) {
      newErrors.reportType = "Report Type is required";
    }

    if (!report.taskId) {
      if (!report.dateFrom) {
        newErrors.dateFrom = "From Date is required when Project is not selected";
      }
      if (!report.dateTo) {
        newErrors.dateTo = "To Date is required when Project is not selected";
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (field: keyof ReportState, value: any) => {
    setReport((prev) => ({ ...prev, [field]: value }));
    setErrors((prev) => ({ ...prev, [field]: "" }));
  };

  const handleStatusSelection = (newValue: StatusOption[] | null) => {
    const selectedOptions = newValue || [];
    setSelectedStatuses(selectedOptions);
    const selectedStatusIds = selectedOptions.map((option) => option.value);
    handleChange("statusId", selectedStatusIds);
  };

  const handleSubStatusSelection = (newValue: SubStatusOption[] | null) => {
    const selectedOptions = newValue || [];
    setSelectedSubStatuses(selectedOptions);
    const selectedSubStatusIds = selectedOptions.map((option) => option.value);
    handleChange("subStatusId", selectedSubStatusIds);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) {
      return;
    }
    try {
      await downloadReport(report);
      toast.success("Report downloaded successfully!");
      handleReset();
    } catch (error) {
      console.error("Error in downloading report:", error);
      toast.error("Error downloading report.");
    }
  };

  const handleReset = () => {
    setReport({
      reportType: "",
      taskId: "",
      statusId: [],
      subStatusId: [],
      dateFrom: null,
      dateTo: null,
    });
    setSelectedStatuses([]);
    setSelectedSubStatuses([]);
    setErrors({});
    setOpenDateFrom(false);
    setOpenDateTo(false);
  };

  const reportTypes = [{ value: "Project Tracker", label: "Project Tracker" }];

  return (
      <Paper elevation={3} sx={{ borderRadius: 2, minHeight: "84vh", boxShadow: "", overflow: "hidden", }} >
        <Typography variant="h5" align="left" sx={{ ml: 14, mt: 5, mb: 3, fontWeight: "bold" }}>
          Generate Report
        </Typography>

        <Box component="form" onSubmit={handleSubmit}>
          <Grid container spacing={{ xs: 2, sm: 3, md: 4, lg: 5 }} sx={{ padding: "20px 110px 40px 110px" }}>
            <Grid item xs={12} sm={12} lg={6} minWidth={"400px"}>
              <TextField
                select
                fullWidth
                label="Report Type"
                name="reportType"
                value={report.reportType}
                onChange={(e) => handleChange("reportType", e.target.value)}
                variant="outlined"
                error={!!errors.reportType}
                helperText={errors.reportType}
                slotProps={{
                  input: {
                    startAdornment: (
                      <InputAdornment position="start">
                        <DescriptionOutlined />
                      </InputAdornment>
                    ),
                  }
                }}
                sx={{
                  "& .MuiInputBase-root": {
                    fontSize: { xs: "0.875rem", sm: "1rem" },
                  },
                }}
              >
                <MenuItem value="">Select Report Type</MenuItem>
                {reportTypes.map((type) => (
                  <MenuItem key={type.value} value={type.value}>
                    {type.label}
                  </MenuItem>
                ))}
              </TextField>
            </Grid>
            <Grid item xs={12} sm={12} lg={6} minWidth={"400px"}>
              <TextField
                select
                fullWidth
                label="Project"
                name="taskId"
                value={report.taskId}
                onChange={(e) => handleChange("taskId", e.target.value)}
                variant="outlined"
                slotProps={{
                  input: {
                    startAdornment: (
                      <InputAdornment position="start">
                        <AssignmentIndOutlined />
                      </InputAdornment>
                    ),
                  }
                }}
                SelectProps={{
                  MenuProps: {
                    disablePortal: false,
                    PaperProps: {
                      sx: {
                        maxHeight: 400,
                        maxWidth: 400,
                      },
                    },
                  },
                }}
                sx={{
                  "& .MuiInputBase-root": {
                    fontSize: { xs: "0.875rem", sm: "1rem" },
                  },
                }}
              >
                <MenuItem value="">Select a project</MenuItem>
                {projects.map((task) => (
                  <MenuItem key={task.taskId} value={task.taskId}>
                    {task.taskName}
                  </MenuItem>
                ))}
              </TextField>
            </Grid>
            <Grid item xs={12} sm={12} lg={6} minWidth={"400px"}>
              <Autocomplete
                multiple
                options={statusOptions}
                getOptionLabel={(option) => option.label}
                value={selectedStatuses}
                onChange={(_, newValue) => handleStatusSelection(newValue)}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Status"
                    variant="outlined"
                    slotProps={{
                      input: {
                        ...params.InputProps,
                        startAdornment: (
                          <>
                            <InputAdornment position="start">
                              <AssessmentOutlined />
                            </InputAdornment>
                            {params.InputProps.startAdornment}
                          </>
                        ),
                      },
                    }}
                    sx={{
                      "& .MuiInputBase-root": {
                        fontSize: { xs: "0.875rem", sm: "1rem" },
                      },
                    }}
                  />
                )}
              />
            </Grid>
            <Grid item xs={12} sm={12} lg={6} minWidth={"400px"}>
              <Autocomplete
                multiple
                options={subStatusOptions}
                getOptionLabel={(option) => option.label}
                value={selectedSubStatuses}
                onChange={(_, newValue) => handleSubStatusSelection(newValue)}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Sub-Status"
                    variant="outlined"
                    slotProps={{
                      input: {
                        ...params.InputProps,
                        startAdornment: (
                          <>
                            <InputAdornment position="start">
                              <FilterList />
                            </InputAdornment>
                            {params.InputProps.startAdornment}
                          </>
                        ),
                      },
                    }}
                    sx={{
                      "& .MuiInputBase-root": {
                        fontSize: { xs: "0.875rem", sm: "1rem" },
                      },
                    }}
                  />
                )}
              />
            </Grid>
            {!report.taskId && (
              <>
                <Grid item xs={12} sm={12} lg={6} minWidth={"400px"}>
                  <DatePicker
                    open={openDateFrom}
                    onOpen={() => setOpenDateFrom(true)}
                    onClose={() => setOpenDateFrom(false)}
                    label="From Date"
                    value={report.dateFrom ? new Date(report.dateFrom) : null}
                    onChange={(date) => handleChange("dateFrom", date ? date.toISOString() : null)}
                    format="dd/MM/yyyy"
                    slotProps={{
                      textField: {
                        fullWidth: true,
                        variant: "outlined",
                        error: !!errors.dateFrom,
                        helperText: errors.dateFrom,
                        onClick:() => setOpenDateFrom(true),
                        InputProps: {
                          startAdornment: (
                            <InputAdornment position="start">
                              <IconButton>
                                <DateRange />
                              </IconButton>
                            </InputAdornment>
                          ),
                          endAdornment: <></>,
                        },
                        sx: {
                          "& .MuiInputBase-root": {
                            fontSize: { xs: "0.875rem", sm: "1rem" },
                          },
                        },
                      },
                    }}
                  />
                </Grid>
                <Grid item xs={12} sm={12} lg={6} minWidth={"400px"}>
                  <DatePicker
                    open={openDateTo}
                    onOpen={() => setOpenDateTo(true)}
                    onClose={() => setOpenDateTo(false)}
                    label="To Date"
                    value={report.dateTo ? new Date(report.dateTo) : null}
                    onChange={(date) => handleChange("dateTo", date ? date.toISOString() : null)}
                    format="dd/MM/yyyy"
                    slotProps={{
                      textField: {
                        fullWidth: true,
                        variant: "outlined",
                        error: !!errors.dateTo,
                        helperText: errors.dateTo,
                        onClick:()=>setOpenDateTo(true),
                        InputProps: {
                          startAdornment: (
                            <InputAdornment position="start">
                              <IconButton>
                                <DateRange />
                              </IconButton>
                            </InputAdornment>
                          ),
                          endAdornment: <></>,
                        },
                        sx: {
                          "& .MuiInputBase-root": {
                            fontSize: { xs: "0.875rem", sm: "1rem" },
                          },
                        },
                      },
                    }}
                  />
                </Grid>
              </>
            )}
            <Grid item xs={12} minWidth={"400px"}>
              <Box sx={{ display: "flex", justifyContent: { xs: "center", sm: "flex-end" }, gap: 2, flexWrap: "wrap", }}>
                <Button
                  type="submit"
                  variant="contained"
                  color="primary"
                  startIcon={<Download />}
                  sx={{
                    px: { xs: 2, sm: 3 },
                    py: 1,
                    fontSize: { xs: "0.75rem", sm: "0.875rem" },
                    textTransform: "none",
                    minWidth: { xs: "120px", sm: "140px" },
                  }}
                >
                  Download
                </Button>
                <Button
                  type="button"
                  variant="outlined"
                  color="secondary"
                  startIcon={<Refresh />}
                  onClick={handleReset}
                  sx={{ px: { xs: 2, sm: 3 }, py: 1, fontSize: { xs: "0.75rem", sm: "0.875rem" }, textTransform: "none", minWidth: { xs: "120px", sm: "140px" }, }}>
                  Reset
                </Button>
              </Box>
            </Grid>
          </Grid>
        </Box>
        <ToastContainer />
      </Paper>
  );
};

export default ReportComponent;
