import { useEffect, useState } from "react";
import { EmployeeData } from "../Interfaces/Login";
import { useNavigate } from "react-router-dom";
import ProfilePopup from "./PopUp/ProfilePopUp";
import { AppBar, Toolbar, Typography, IconButton, Menu, MenuItem, Box } from "@mui/material";

const Header = () => {
  const [employee, setEmployee] = useState<EmployeeData | null>(null);
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [isProfileOpen, setProfileOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const storedData = localStorage.getItem("employeedata");
    if (storedData) {
      setEmployee(JSON.parse(storedData));
    }
  }, []);

  const handleMenuOpen = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleLogOut = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("employeedata");
    navigate("/ui/login");
  };

  const openProfile = () => {
    setProfileOpen(true);
    handleMenuClose();
  };

  const handleLogoClick = () => {
    navigate("/ui/dashboard");
  };

  return (
    <AppBar position="relative" sx={{ backgroundColor: "rgb(73, 102, 131)", boxShadow: '0px 4px 8px rgba(0, 0, 0, 0.1)', padding: '7px', borderRadius: '10px', mb: 2,zIndex:0}}>
      <Toolbar sx={{ display: "flex", justifyContent: "space-between" }}>
        <Typography
          variant="h4"
          sx={{ cursor: "pointer", fontFamily: "serif", color: "white" }}
          onClick={handleLogoClick}
        >
          Manage-Mate
        </Typography>
        <Box display="flex" alignItems="center">
          <Box textAlign="right" mr={1} sx={{ display: { xs: 'none', md: 'block' } }}>
            <Typography
              variant="h6"
              component="div"
              fontWeight="bold"
              color="white "
              sx={{
                fontFamily: "'Montserrat', sans-serif",
                fontSize: "18px",
                textTransform: "uppercase",
              }}
            >
              {employee?.EmployeeFullName || "Employee Name"}
            </Typography>

            <Typography
              variant="body2"
              color="white"
              sx={{
                fontFamily: "'Lato', sans-serif",
                fontSize: "13px",
                fontWeight: "500",
              }}
            >
              {employee?.Designation || "Designation"}
            </Typography>

          </Box>
          <IconButton onClick={handleMenuOpen}>
            <img
              src={employee?.ImageUrl || "/default-avatar.png"}
              alt="User Avatar"
              style={{ width: "50px", height: "50px", cursor: "pointer", borderRadius:"50%" }}
            />
          </IconButton>
          <Menu
            anchorEl={anchorEl}
            open={Boolean(anchorEl)}
            onClose={handleMenuClose}
            anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
            transformOrigin={{ vertical: "top", horizontal: "right" }}
          >
            <MenuItem onClick={openProfile}>Profile</MenuItem>
            <MenuItem onClick={handleLogOut}>Logout</MenuItem>
          </Menu>
        </Box>
      </Toolbar>
      <ProfilePopup employee={employee} isVisible={isProfileOpen} onClose={() => setProfileOpen(false)} />
    </AppBar>
  );
};

export default Header;