import {
  Box,
  Button,
  Card,
  CardContent,
  Checkbox,
  FormControlLabel,
  IconButton,
  InputAdornment,
  TextField,
  Typography,
} from '@mui/material';
import illustrationImg from '../assets/loginBg.jpg';
import logo from '../images/mas_logo.png';
import { useState, FormEvent, ChangeEvent, useContext } from 'react';
import { LoginDto } from '../Interfaces/Login';
import { logIn } from '../Requests/Request';
import { useNavigate, useLocation } from 'react-router-dom';
import { AuthContext } from '../component/Auth/AuthContext';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import CryptoJS from "crypto-js";
import { Visibility, VisibilityOff } from '@mui/icons-material';

const backgroundImageUrl = logo;
const secretKey = CryptoJS.enc.Utf8.parse("M@S-MFSL-SECURE1"); // 16-byte key
const iv = CryptoJS.enc.Utf8.parse("1234567890123456"); // 16-byte IV

function Login() {

  const [login, setLogin] = useState<LoginDto>({
    username: '',
    password: '',
  });
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const { setIsAuthenticated, setEmployee } = useContext(AuthContext);
  const navigate = useNavigate();
  const location = useLocation();

  const encryptPassword = (password: string): string => {
    const encrypted = CryptoJS.AES.encrypt(password, secretKey, {
      iv: iv,
      mode: CryptoJS.mode.CBC, // Ensure the mode is CBC
      padding: CryptoJS.pad.Pkcs7,
    });
    return encrypted.toString();
  };

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    // Validation for empty fields
    if (!login.username.trim()) {
      toast.warning(' Please enter username!');
      return;
    }

    if (!login.password.trim()) {
      toast.warning(' Please enter password!');
      return;
    }

    try {
      const encryptedPassword = encryptPassword(login.password); // Encrypt before sending
      const loginData = { ...login, password: encryptedPassword };

      const data = await logIn(loginData);
      if (data.login) {
        const firstEmployee = data.employeeData;
        setEmployee(firstEmployee);
        setIsAuthenticated(true);
        sessionStorage.setItem("employeedata", JSON.stringify(data.employeeData));
        localStorage.setItem('employeedata', JSON.stringify(firstEmployee));
        // toast.success('Login successful!');
        const from = location.state?.from?.pathname || '/ui/dashboard';//navigate to dashboard
        navigate(from);
        // navigate('/ui/task');
      } else {
        toast.error(data.message);
      }
    } catch (error) {
      console.error('Login failed:', error);
      toast.error('Invalid credentials. Please try again!');
    }
  };

  const handleUsernameChange = (e: ChangeEvent<HTMLInputElement>) => {
    setLogin((prevLogin) => ({
      ...prevLogin,
      username: e.target.value,
    }));
  };

  const handlePasswordChange = (e: ChangeEvent<HTMLInputElement>) => {
    setLogin((prevLogin) => ({
      ...prevLogin,
      password: e.target.value,
    }));
  };

  const togglePasswordVisibility = () => {
    setShowPassword((prev) => !prev);
  };

  return (
    <Box
      sx={{
        position: 'fixed',
        top: 0,
        left: 0,
        width: '100vw',
        height: '100vh',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        overflow: 'hidden',
        zIndex: 9999,

      }}
    >
      {/* Background Image Layer */}
      <Box
        sx={{
          position: 'absolute',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.4)), url(${illustrationImg})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          zIndex: 0,
        }}
      />

      <Card
        sx={{
          width: { lg: 1100 },
          p: 3,
          boxShadow: 10,
          borderRadius: 4,
          zIndex: 1,
          opacity: 0.85,
          // height: "500px"
        }}
      >
        <CardContent>
          <Box
            sx={{
              display: 'flex',
              minHeight: { xs: 'auto', md: '400px' },
              flexDirection: { xs: 'column', md: 'row' },
              gap: 4,
              padding: 1,
            }}
          >
            {/* Left Box (Image) */}
            <Box
              sx={{
                flex: { xs: 'none', md: 1 },
                margin: 3,
                borderRadius: 2,
                height: { xs: 170, md: 'auto' },
                backgroundImage: `url(${backgroundImageUrl})`,
                backgroundSize: 'cover',
                backgroundPosition: 'center',
              }}
            />

            {/* Right Box (Form) */}
            <Box sx={{ maxWidth: 400, width: '100%', margin: '0 auto' }}>
              <Typography
                variant="h5"
                fontWeight={600}
                sx={{ color: '#03498f', textAlign: 'start' }}
              >
                Welcome to{' '}
                <Box component="span" sx={{ fontWeight: 'bold', color: '#f39122' }}>
                  MANAGE-MATE
                </Box>
              </Typography>

              <Typography
                variant="body2"
                sx={{ color: '#6c757d', mt: 1, mb: 3 }}
              >
                <em>Please sign-in to your account and start the adventure</em>
              </Typography>

              <Box
                component="form"
                onSubmit={handleSubmit}
                noValidate
                sx={{
                  display: 'flex',
                  flexDirection: 'column',
                  gap: 3,
                  paddingRight: { xs: 0, md: 4 },
                }}
              >
                <TextField
                  label="User Name"
                  variant="outlined"
                  fullWidth
                  value={login.username}
                  onChange={handleUsernameChange}
                  autoComplete="current-username"
                  size="medium"
                />

                <TextField
                  label="Password"
                  variant="outlined"
                  fullWidth
                  type={showPassword ? 'text' : 'password'}
                  value={login.password}
                  onChange={handlePasswordChange}
                  autoComplete="current-password"
                  size="medium"
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        <IconButton onClick={togglePasswordVisibility} edge="end">
                          {showPassword ? <Visibility /> : <VisibilityOff />}
                        </IconButton>
                      </InputAdornment>
                    )
                  }}
                />


                {/* <TextField
                  placeholder="Captcher Code"
                  variant="outlined"
                  fullWidth
                  type="text"
                  value={inputValue}
                  onChange={handleCaptchaChange}
                  autoComplete="off"
                  size="small"
                
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start" >
                        <Box
                          sx={{
                            height: '35px',
                            display: 'flex',
                            alignItems: 'center',
                            backgroundColor: 'transparent',
                            borderTopLeftRadius: '6px',
                            borderBottomLeftRadius: '4px',
                            // fontFamily: 'revert-layer',
                            fontSize: '1.5rem',
                            minWidth: '80px',
                            color: '#03498f',
                            textTransform: 'uppercase',
                            paddingRight:1,
                            borderRight:"1px solid gray"
                          }}
                        >
                          {captcha}
                        </Box>
                      </InputAdornment>


                    ),
                    endAdornment: (
                      <InputAdornment position="end">
                        <IconButton onClick={generateCaptcha} edge="end">
                          <RefreshRounded />
                        </IconButton>
                      </InputAdornment>
                    )
                  }}
                /> */}
                <FormControlLabel
                  control={<Checkbox size="small" style={{ height: "10px" }} />}
                  label={<Typography variant='body2'>Remember Me</Typography>}
                  sx={{ justifyContent: 'flex-start' }}
                />

                <Button
                  type="submit"
                  variant="contained"
                  fullWidth
                  size='large'
                  sx={{
                    mt: 1,
                    backgroundColor: '#03498f',
                    fontWeight: 500,
                    '&:hover': {
                      backgroundColor: '#063d74'
                    }
                  }}
                >
                  Sign In
                </Button>
              </Box>
            </Box>
          </Box>
        </CardContent>
      </Card>
      <ToastContainer position="top-center" autoClose={3000} />
    </Box>

  );
}

export default Login;