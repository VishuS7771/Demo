import { Skeleton, Table, TableBody, TableCell, TableHead, TableRow } from "@mui/material";
import React from "react";

interface TableSkeletonProps {
  column: number;
}

const TableSkeleton: React.FC<TableSkeletonProps> = ({ column }) => {
  return (
    <Table sx={{ minWidth: 650 }} aria-label="skeleton table">
      <TableHead></TableHead>
      <TableBody>
        {Array.from({ length: 10 }).map((_, rowIndex) => (
          <TableRow key={rowIndex}>
            {Array.from({ length: column }).map((_, colIndex) => (
              <TableCell key={colIndex} colSpan={column} sx={{ border: "none" }} >
                <Skeleton
                  variant="rounded"
                  width={130}
                  height={25}
                  animation="wave"
                />
              </TableCell>
            ))}
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
};

export default TableSkeleton;
