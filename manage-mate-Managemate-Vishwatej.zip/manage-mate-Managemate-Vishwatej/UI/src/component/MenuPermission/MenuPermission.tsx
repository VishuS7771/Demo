import React, { useEffect, useState } from "react";
import { User } from "../../Interfaces/Task";
import { getAllEmployees } from "../../Requests/MeetingRequest";
import { MenuPermission } from "../../Interfaces/MenuPermission";
import { addMenuPermission, getMenuPermission } from "../../Requests/MenuPermission";
import { toast, ToastContainer } from "react-toastify";
import {
  Autocomplete,
  Box,
  Button,
  Divider,
  Paper,
  Switch,
  TextField,
  Typography,
  useTheme,
  useMediaQuery,
} from "@mui/material";
import {
  Dashboard as DashboardIcon,
  People as PeopleIcon,
  Assignment as AssignmentIcon,
  Storage as StorageIcon,
  DocumentScannerRounded,
} from "@mui/icons-material";
import { menuPermissionCardStyles } from "../../util/constants/commonStyles";

interface PermissionGroup {
  groupName: string;
  icon: React.ReactNode;
  permissions: { name: string; checked: boolean }[];
}

const permissions: PermissionGroup[] = [
  {
    groupName: "Masters",
    icon: <StorageIcon />,
    permissions: [
      { name: "Status", checked: false },
      { name: "Sub-status", checked: false },
      { name: "Proprietor", checked: false },
      { name: "Assign", checked: false },
      { name: "User", checked: false },
      { name: "Module", checked: false },

    ],
  },
  {
    groupName: "Dashboard",
    icon: <DashboardIcon />,
    permissions: [{ name: "Dashboard", checked: false }],
  },
  {
    groupName: "General Meeting",
    icon: <PeopleIcon />,
    permissions: [{ name: "General Meeting", checked: false }],
  },
  {
    groupName: "Project",
    icon: <AssignmentIcon />,
    permissions: [
      { name: "Add Project", checked: false },
      { name: "Project", checked: false },
    ],
  },
  {
    groupName: "Report",
    icon: <DocumentScannerRounded/>,
    permissions: [
      { name: "Report", checked: false },
    ],
  },
];

const initialMenuPermissions: MenuPermission = {
  menuPermissionId: 0,
  employeeId: 0,
  isStatus: false,
  isSubStatus: false,
  isProprietor: false,
  isAssign: false,
  isUser: false,
  isDashboard: false,
  isTask: false,
  isProject: false,
  isReport: false,
  isModule: false,
  isGeneralMeeting: false,
};

const MenuPermissionManagement: React.FC = () => {
  const theme = useTheme();
  const [employees, setEmployees] = useState<User[]>([]);
  const [selectedEmployee, setSelectedEmployee] = useState<User | null>(null);
  const [menuPermission, setMenuPermission] = useState<MenuPermission>(initialMenuPermissions);
  const [permissionGroups, setPermissionGroups] = useState<PermissionGroup[]>(permissions);
  const [btnLoading, setBtnLoading] = useState(false);

  const isXs = useMediaQuery(theme.breakpoints.down("sm"));
  const isSm = useMediaQuery(theme.breakpoints.between("sm", "md"));

  const getGridColumns = () => {
    if (isXs) return "repeat(1, 1fr)";
    if (isSm) return "repeat(2, 1fr)";
    return "repeat(3, 1fr)";
  };

  useEffect(() => {
    const fetchEmployees = async () => {
      setBtnLoading(true);
      try {
        const data = await getAllEmployees();
        setEmployees(data);
      } catch (error) {
        toast.error("Failed to fetch employees. Please try again.");
      } finally {
        setBtnLoading(false);
      }
    };
    fetchEmployees();
  }, []);

  const getMenuPermissionByuser = async (empId: number) => {
    if (!empId) return;
    try {
      const response = await getMenuPermission(empId);
      setMenuPermission(response.data);
      setMenuPermission((prev) => ({ ...prev, employeeId: empId}));
      setPermissionGroups((prevGroups) =>
        prevGroups.map((group) => ({
          ...group,
          permissions: group.permissions.map((permission) => {
            const permissionNameToKey: Record<string, keyof MenuPermission> = {
              Status: "isStatus",
              "Sub-status": "isSubStatus",
              Proprietor: "isProprietor",
              Assign: "isAssign",
              User: "isUser",
              Module: "isModule",
              Dashboard: "isDashboard",
              "General Meeting": "isGeneralMeeting",
              "Add Project": "isTask",
              Project: "isProject",
              Report: "isReport",
            };
            const permissionKey = permissionNameToKey[permission.name];
            return { ...permission, checked: permissionKey ? response.data[permissionKey] : permission.checked };
          }),
        }))
      );
    } catch (error) {
      toast.error("Failed to fetch menu permissions. Please try again.");
    }
  };

  const handleEmployeeSelect = async (employeeId: string) => {
    const employee = employees.find((e) => String(e.employeeId) === employeeId);
    if (employee) {
      setSelectedEmployee(employee);
      setMenuPermission((prev) => ({ ...prev, employeeId: Number(employee.employeeId) }));
      await getMenuPermissionByuser(Number(employee.employeeId));
    } else {
      setSelectedEmployee(null);
      clearPermissions();
    }
  };

  const handleToggleChange = (groupIndex: number, permissionIndex: number) => {
    setPermissionGroups((prevGroups) =>
      prevGroups.map((group, gIndex) => {
        if (gIndex !== groupIndex) return group;
        const updatedPermissions = group.permissions.map((permission, pIndex) => {
          if (pIndex !== permissionIndex) return permission;
          const updatedPermission = { ...permission, checked: !permission.checked };
          const permissionNameToKey: Partial<Record<string, keyof Pick<MenuPermission,
            'isStatus' | 'isSubStatus' | 'isProprietor' | 'isAssign' | 'isModule' | 'isUser' |
            'isDashboard' | 'isGeneralMeeting' | 'isTask' | 'isProject' | 'isReport'>>> = {
            Status: 'isStatus',
            'Sub-status': 'isSubStatus',
            Proprietor: 'isProprietor',
            Assign: 'isAssign',
            User: "isUser",
            Module: "isModule",
            Dashboard: 'isDashboard',
            'General Meeting': 'isGeneralMeeting',
            'Add Project': 'isTask',
            Project: 'isProject',
            Report: "isReport",
          };
          const permissionKey = permissionNameToKey[updatedPermission.name];
          if (permissionKey) {
            setMenuPermission((prev) => ({ ...prev, [permissionKey]: updatedPermission.checked }));
          }
          return updatedPermission;
        });
        return { ...group, permissions: updatedPermissions };
      })
    );
  };

  const handleSelectAll = () => {
    const allChecked = permissionGroups.every((group) => group.permissions.every((p) => p.checked));
    const newCheckedState = !allChecked;
    const updatedGroups = permissionGroups.map((group) => ({
      ...group,
      permissions: group.permissions.map((permission) => ({
        ...permission,
        checked: newCheckedState,
      })),
    }));

    setPermissionGroups(updatedGroups);

    const permissionNameToKey: Partial<Record<string, keyof Pick<MenuPermission,
      'isStatus' | 'isSubStatus' | 'isProprietor' | 'isAssign' | 'isModule' | 'isUser' |
      'isDashboard' | 'isGeneralMeeting' | 'isTask' | 'isProject' | 'isReport'>>> = {
      Status: 'isStatus',
      'Sub-status': 'isSubStatus',
      Proprietor: 'isProprietor',
      Assign: 'isAssign',
      User: "isUser",
      Module: "isModule",
      Dashboard: 'isDashboard',
      'General Meeting': 'isGeneralMeeting',
      'Add Project': 'isTask',
      Project: 'isProject',
      Report: 'isReport',
    };

    const updatedMenuPermission: MenuPermission = { ...menuPermission };
    updatedGroups.forEach((group) => {
      group.permissions.forEach((permission) => {
        const permissionKey = permissionNameToKey[permission.name];
        if (permissionKey) {
          updatedMenuPermission[permissionKey] = newCheckedState;
        }
      });
    });
    setMenuPermission(updatedMenuPermission);
  };

  const clearPermissions = () => {
    setPermissionGroups((prevGroups) =>
      prevGroups.map((group) => ({
        ...group,
        permissions: group.permissions.map((permission) => ({
          ...permission,
          checked: false,
        })),
      }))
    );
    setMenuPermission(initialMenuPermissions);
  };

  const handleSubmit = async () => {debugger
    if (!selectedEmployee) {
      toast.error("Please select an employee first");
      return;
    }
    try {
      await addMenuPermission(menuPermission);
      toast.success("Menu permissions saved successfully");
    } catch (error) {
      console.error("Failed to submit menu permission:", error);
      toast.error("Failed to save menu permissions. Please try again.");
    } finally {
    }
  };

  return (
    <>
      <Paper elevation={3} sx={{ borderRadius: 2, minHeight: "84vh", boxShadow: "", overflow: "hidden", pl: 14, pt: 5, pb: 3, pr: 14 }}>
        <Typography variant="h5" align="left" sx={{ fontWeight: "bold" }}>
          Menu Permissions
        </Typography>
        <Typography sx={{ mb: 3 }}>Select an employee to manage their permissions</Typography>
        <Autocomplete
          fullWidth
          loading={btnLoading}
          options={employees}
          getOptionLabel={(option) => `${option.employeeName} - ${option.employeeId}`}
          value={selectedEmployee || null}
          onChange={(_, newValue) => handleEmployeeSelect(newValue?.employeeId ?? "")}
          renderInput={(params) => (
            <TextField
              {...params}
              variant="outlined"
              placeholder="Select Employee"
              sx={{ mb: 4 }}
            />
          )}
          isOptionEqualToValue={(option, value) => option.employeeId === value.employeeId}
        />
        <Box sx={menuPermissionCardStyles.selectAllBox}>
          <Typography sx={menuPermissionCardStyles.selectAllText}>Allow all Permissions for selected Employee</Typography>
          <Switch
            checked={permissionGroups.every((group) => group.permissions.every((p) => p.checked))}
            onChange={handleSelectAll}
            disabled={selectedEmployee === null}
            sx={menuPermissionCardStyles.switch}
          />
        </Box>
        <Box sx={{ display: "flex", flexDirection: "column" }}>
          {permissionGroups.map((group, groupIndex) => (
            <Box key={groupIndex}>
              <Box sx={menuPermissionCardStyles.groupTitle}>
                {group.icon}
                <Typography>{group.groupName}</Typography>
              </Box>
              <Box
                sx={{
                  display: "grid",
                  gridTemplateColumns: getGridColumns(),
                  gap: { xs: 1.5, sm: 2 },
                  mb: 2,
                }}
              >
                {group.permissions.map((permission, permissionIndex) => (
                  <Box key={permissionIndex} sx={menuPermissionCardStyles.permissionCard}>
                    <Typography sx={menuPermissionCardStyles.permissionText}>{permission.name}</Typography>
                    <Switch
                      checked={permission.checked}
                      onChange={() => handleToggleChange(groupIndex, permissionIndex)}
                      disabled={selectedEmployee === null}
                      sx={menuPermissionCardStyles.switch}
                    />
                  </Box>
                ))}
              </Box>
              <Divider sx={menuPermissionCardStyles.divider} />
            </Box>
          ))}
        </Box>
        <Box sx={menuPermissionCardStyles.buttonContainer}>
          <Button
            variant="contained"
            onClick={handleSubmit}
            sx={{ ...menuPermissionCardStyles.button, ...menuPermissionCardStyles.saveButton }}
          >
            Save
          </Button>
          <Button
            variant="outlined"
            onClick={clearPermissions}
            sx={{ ...menuPermissionCardStyles.button, ...menuPermissionCardStyles.clearButton }}
          >
            Clear
          </Button>
        </Box>
      </Paper>
      <ToastContainer position="top-right" autoClose={3000} />
    </>
  );
};

export default MenuPermissionManagement;