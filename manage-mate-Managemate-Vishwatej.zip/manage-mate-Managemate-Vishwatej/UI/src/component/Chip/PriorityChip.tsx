import React from 'react';
import { Chip } from '@mui/material';
import { getChipStyles } from '../../util/constants/commonStyles';

interface PriorityChipProps {
  status: string;
}

export const PriorityChip: React.FC<PriorityChipProps> = ({ status }) => {
  return (
    <Chip
      label={status}
      sx={{
        height: '25px',
        width: '100%',
        textAlign: 'center',
        borderRadius: '999px',
        ...getChipStyles(status),
      }}
    />
  );
};
