import React from 'react';
import { Chip } from '@mui/material';
import { getStatusChipStyles } from '../../util/constants/commonStyles';

interface StatusChipProps {
  status: string;
}

export const StatusChip: React.FC<StatusChipProps> = ({ status }) => {
  return (
    <Chip
      label={status}
      sx={{
        height: '25px',
        width: '100px',
        textAlign: 'center',
        borderRadius: '999px',
        ...getStatusChipStyles(status),
      }}
    />
  );
};
