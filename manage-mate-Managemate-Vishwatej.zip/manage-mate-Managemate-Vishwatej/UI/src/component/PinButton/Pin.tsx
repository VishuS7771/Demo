import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPause, faPlay } from "@fortawesome/free-solid-svg-icons";

interface PauseResumeButtonProps {
  isPaused: boolean;
  togglePause: () => void;
}

const PauseResumeButton: React.FC<PauseResumeButtonProps> = ({ isPaused, togglePause }) => {
  return (
    <div
      onClick={togglePause}
      style={{
        cursor: "pointer",
        marginLeft: "auto", // Pushes to the rightmost side
        color: "gray",
        fontSize: "20px",
      }}
    >
      <FontAwesomeIcon icon={isPaused ? faPlay : faPause} />
    </div>
  );
};

export default PauseResumeButton;
