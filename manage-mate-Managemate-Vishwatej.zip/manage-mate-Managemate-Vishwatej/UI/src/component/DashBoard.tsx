import React, { useEffect, useState } from "react";
import { getProprietorAndStatus, getStakeHolderProprietorAndStatus } from "../Requests/TaskRequest";
import { EmployeeData } from "../Interfaces/Login";
import { getAllStakeholders } from "../Requests/MenuPermission";
import { Box, Card, CardContent, Divider, Grid, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography } from "@mui/material";
import { HourglassTop, PendingActions, StopCircleOutlined, FactCheck, PauseCircleFilled, AssignmentTurnedIn } from "@mui/icons-material";
import { motion } from 'framer-motion';
interface StatusProprietorResultDto {
  statusMap: { [key: string]: number };
  proprietorMap: { [key: string]: number };
  stringMapMap: {
    [status: string]: {
      [proprietor: string]: number;
    };
  };
}

export interface StakeHolders {
  id: number;
  stakeHolderId: number;
}

interface StatusItem {
  label: string;
  value: number;
  icon: JSX.Element;
  footerColor: string;
  footerText: string;
  valueColor: string
}

const statusMetadata: Record<string, { icon: JSX.Element; footerText: string }> = {
  'In-Process': {
    icon: <HourglassTop />,
    footerText: 'Items currently processing',
  },
  'Stopped': {
    icon: <StopCircleOutlined />,
    footerText: 'Items stopped due to error',
  },
  'Completed': {
    icon: <FactCheck />,
    footerText: 'Successfully completed items',
  },
  'Not-Started': {
    icon: <PendingActions />,
    footerText: 'Items yet to be started',
  },
  'Hold': {
    icon: <PauseCircleFilled />,
    footerText: 'Items currently on hold',
  },
  'Sign-Off': {
    icon: <AssignmentTurnedIn />,
    footerText: 'Items awaiting final sign-off',
  },
};

const DashBoard: React.FC = () => {
  const [data, setData] = useState<StatusProprietorResultDto | null>(null);
  const [employee, setEmployee] = useState<EmployeeData | null>(null);
  const [designation, setDesignation] = useState<string>("");
  const [stakeholders, setStakeholders] = useState<StakeHolders[]>([]);
  const [totalRow, setTotalRow] = useState<{ [key: string]: number }>({});

  useEffect(() => {
    const storedData = localStorage.getItem("employeedata");
    if (storedData) {
      const parsedData = JSON.parse(storedData);
      setEmployee(parsedData);
    }
  }, []);

  useEffect(() => {
    const fetchStakeholders = async () => {
      const data = await getAllStakeholders();
      setStakeholders(data);
    };

    fetchStakeholders();
  }, []);

  useEffect(() => {
    const fetchData = async () => {
      if (!employee) return;

      const empNo = Number(employee.EmployeeNo);
      const isEmployeeInStakeholders = stakeholders.some(
        (stakeholder) => stakeholder.stakeHolderId === empNo
      );

      if (isEmployeeInStakeholders) {
        const response = await getStakeHolderProprietorAndStatus(empNo, "Stakeholder");
        setData(response);
      } else {
        const departmentArray: string[] = employee.Department?.split(" -> ") ?? [];
        try {
          if (departmentArray.includes("Software Development")) {
            setDesignation("Developer Team");
          } else if (departmentArray.includes("Project Management")) {
            setDesignation("BA Team");
          } else if (departmentArray.includes("Legal")) {
            setDesignation("Legal");
          } else if (departmentArray.includes("Management")) {
            setDesignation("Management");
          } else if (departmentArray.includes("Stakeholder")) {
            setDesignation("Stakeholder");
          }
          if (employee.Designation === "CHIEF TECHNOLOGY OFFICER") {
            setDesignation("CHIEF TECHNOLOGY OFFICER");
          }
          if (designation) {
            const response = await getProprietorAndStatus(empNo, designation);
            setData(response);
          }
        } catch (error) {
          console.error("Error fetching data:", error);
        }
      }
    };

    fetchData();
  }, [employee, designation, stakeholders]);

  useEffect(() => {
    if (!data) return;

    const statusColumns = Object.keys(data.statusMap);
    const newTotalRow: { [key: string]: number } = {};

    // Initialize totals to zero.
    statusColumns.forEach((status) => {
      newTotalRow[status] = 0;
    });

    // Update totals for existing combinations.
    Object.keys(data.stringMapMap).forEach((status) => {
      Object.values(data.stringMapMap[status]).forEach((count) => {
        if (!isNaN(count)) {
          newTotalRow[status] = (newTotalRow[status] || 0) + count;
        }
      });
    });

    // Calculate the grand total.
    newTotalRow["Total"] = statusColumns.reduce(
      (sum, status) => sum + (newTotalRow[status] || 0),
      0
    );

    setTotalRow((prev) => ({
      ...prev, // Preserve previous totals for non-updated combinations.
      ...newTotalRow, // Update only with newly calculated totals.
    }));
  }, [data]);

  if (!data) {
    return <div></div>;
  }

  const { statusMap, proprietorMap, stringMapMap } = data;

  const statusColumns = Object.keys(statusMap);

  const statusItems: StatusItem[] = Object.entries(statusMap).map(([label, value]) => ({
    label,
    value,
    icon: statusMetadata[label]?.icon || <PendingActions />,
    valueColor: 'rgb(73, 102, 131)',
    footerColor: 'rgb(208 215 223)',
    footerText: statusMetadata[label]?.footerText || 'No status description available',
  }));


  return (
    <>

      <Grid item xs={12} mb={2} mt={2}>
        <Grid container spacing={3} justifyContent="space-evenly" alignItems="flex-start" wrap="wrap">
          {statusItems.map((item, index) => (
            <Grid item key={index} lg={3} sm={4} xs={12} minWidth="400px">
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.3, ease: 'easeOut' }}

              >
                <Card
                  sx={{
                    borderRadius: 2,
                    height: '100%',
                    position: 'relative',
                    overflow: 'hidden',
                    transition: 'transform 0.2s, box-shadow 0.2s',
                    '&:hover': {
                      transform: 'scale(1.02)',
                      boxShadow: '0px 8px 30px rgba(0,0,0,0.15)'
                    },
                    '&::after': {
                      content: '""',
                      position: 'absolute',
                      top: 0,
                      left: 0,
                      width: '100%',
                      height: '100%',
                      borderRadius: 2,
                      opacity: 0,
                      transition: 'opacity 0.2s',
                    },
                    '&:hover::after': {
                      opacity: 1,
                    }
                  }}
                >
                  <CardContent>
                    <Grid container justifyContent="space-between" alignItems="center">
                      <Grid item>
                        <Typography
                          sx={{
                            color: item.valueColor,
                            fontWeight: 800,
                            fontSize: '1.2rem',
                            mb: 0.5
                          }}
                        >
                          {item.value}
                        </Typography>
                        <Typography
                          variant="inherit"
                          sx={{ color: '#666', mb: 0.5 }}
                        >
                          {item.label}
                        </Typography>
                      </Grid>
                      <Grid item>
                        <Box
                          sx={{
                            width: 50,
                            height: 50,
                            borderRadius: '50%',
                            backgroundColor: item.valueColor,
                            color: 'white',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            fontSize: '24px',
                            mb: 1
                          }}
                        >
                          {item.icon}
                        </Box>
                      </Grid>
                    </Grid>
                  </CardContent>
                  <Divider sx={{ background: '#bababa' }} />
                  <Box
                    sx={{
                      px: 2.5,
                      py: 2,
                      background: `linear-gradient(135deg, ${item.footerColor} 30%, #ffffff 100%)`,
                      color: 'white',
                      borderBottomLeftRadius: 8,
                      borderBottomRightRadius: 8
                    }}
                  >
                    <Typography
                      variant="body2"
                      sx={{ fontSize: '15px', fontWeight: 500, color: item.valueColor }}
                    >
                      {item.footerText}
                    </Typography>
                  </Box>
                </Card>
              </motion.div>
            </Grid>
          ))}
        </Grid>
      </Grid>


      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.3, ease: 'easeOut' }}

      >
        <TableContainer
          component={Paper}
          sx={{
            borderRadius: 2,
            boxShadow: 3,
            overflowX: "auto",
            minHeight: "60vh",
            mt:8
          }}
        >
          <Table>
            <TableHead>

              <TableRow sx={{ background: "rgb(246, 247, 251)", height: 60 }}>
                <TableCell
                  rowSpan={2}
                  sx={{ fontWeight: "bold", textTransform: "uppercase", verticalAlign: "middle", borderRight: "1px solid rgba(224, 224, 224, 1)", color: "slategray" }}
                >
                  Proprietor
                </TableCell>
                <TableCell
                  colSpan={statusColumns.length}
                  align="center"
                  sx={{ fontWeight: "bold", textTransform: "uppercase", color: "slategray" }}
                >
                  Status
                </TableCell>
                <TableCell
                  rowSpan={2}
                  align="center"
                  sx={{ fontWeight: "bold", textTransform: "uppercase", verticalAlign: "middle", borderLeft: "1px solid rgba(224, 224, 224, 1)", color: "slategray" }}
                >
                  Total
                </TableCell>
              </TableRow>
              <TableRow sx={{ height: "50px", background: "rgb(246, 247, 251)", }}>
                {statusColumns.map((status) => (
                  <TableCell
                    key={status}
                    align="center"
                    sx={{ fontWeight: "bold", textTransform: "uppercase", color: "slategray" }}
                  >
                    {status}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {Object.keys(proprietorMap).map((proprietor) => {
                const proprietorTotal = statusColumns.reduce(
                  (sum, status) => sum + (stringMapMap[status]?.[proprietor] || 0),
                  0
                );
                return (
                  <TableRow
                    key={proprietor}
                    sx={{
                      "&:hover": { backgroundColor: "#fafafa" },
                    }}
                  >
                    <TableCell>{proprietor}</TableCell>
                    {statusColumns.map((status) => (
                      <TableCell key={status} align="center">
                        {stringMapMap[status]?.[proprietor] || 0}
                      </TableCell>
                    ))}
                    <TableCell align="center">{proprietorTotal}</TableCell>
                  </TableRow>
                );
              })}
              <TableRow sx={{ backgroundColor: "rgb(246, 247, 251)" }}>
                <TableCell sx={{ fontWeight: "bold" }}>Total</TableCell>
                {statusColumns.map((status) => (
                  <TableCell
                    key={status}
                    align="center"
                    sx={{ fontWeight: "bold" }}
                  >
                    {totalRow[status] || 0}
                  </TableCell>
                ))}
                <TableCell align="center" sx={{ fontWeight: "bold" }}>
                  {totalRow["Total"] || 0}
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </TableContainer>
      </motion.div>
    </>
  );
};

export default DashBoard;
