import { useEffect, useState } from 'react';
import {
  getAllProprietorAssignments,
  updateProprietorAssignment
} from '../../Requests/ProprietorRequest';
import {
  ProprietorAssignmentsDto
} from '../../Interfaces/Proprietor';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import "../../css/Proprietor.css";
import { Box, Button, Pagination, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography } from '@mui/material';
import { usePageLoader } from '../../context/PageLoaderContext';
import { FaPlusCircle } from 'react-icons/fa';
import MappingModal from '../Modal/Mapping/MappingModal';
import ProprietorMapping from '../Modal/Mapping/ProprietorMapping';

const Proprietor: React.FC = () => {
  const { showLoader, hideLoader } = usePageLoader();
  const [tableLoading, setTableLoading] = useState(false);
  const [editMode, setEditMode] = useState<boolean>(false);
  const [assignments, setAssignments] = useState<ProprietorAssignmentsDto[]>([]);
  const [selectedAssignment, setSelectedAssignment] = useState<ProprietorAssignmentsDto | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 8;
  const [showModal, setShowModal] = useState(false);

  const fetchData = async () => {
    showLoader();
    setTableLoading(true);
    try {
      const assignmentResponse = await getAllProprietorAssignments();
      setAssignments(assignmentResponse.data);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setTableLoading(false);
      hideLoader();
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleShowModal = () => {
    if (showModal) {
      setEditMode(false);
      setSelectedAssignment(null);
    }
    setShowModal(!showModal);
  };

  const handlePageChange = (pageNumber: number) => {
    setCurrentPage(pageNumber);
  };

  const currentAssignments = assignments.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );
  const totalPages = Math.ceil(assignments.length / itemsPerPage);

  const handleEdit = async (id: number) => {
    const assignmentToEdit = assignments.find((assignment) => assignment.proprietorMappingId === id);
    if (assignmentToEdit) {
      setSelectedAssignment(assignmentToEdit);
      setEditMode(true);
      setShowModal(true);
    }
  };

  const handleSave = async (updatedAssignment: ProprietorAssignmentsDto | null, isNew: boolean) => {
    if (updatedAssignment) {
      if (isNew) {
        // Create new assignment
        setAssignments([...assignments, updatedAssignment]);
        toast.success("Proprietor Assignment saved successfully!");
      } else {
        // Update existing assignment
        setAssignments(prevAssignments =>
          prevAssignments.map(assignment =>
            assignment.proprietorMappingId === updatedAssignment.proprietorMappingId
              ? updatedAssignment
              : assignment
          )
        );
        toast.success("Proprietor updated successfully!");
      }
      // Refresh assignments to ensure data consistency
      try {
        const response = await getAllProprietorAssignments();
        setAssignments(response.data);
      } catch (error) {
        console.error("Error refreshing assignments:", error);
      }
    }
  };

  const handleInactive = async (id: number) => {
    showLoader();
    const assignmentToUpdate = assignments.find((assignment) => assignment.proprietorMappingId === id);

    if (assignmentToUpdate) {
      const updatedAssignment = { ...assignmentToUpdate, isActive: assignmentToUpdate.isActive === 1 ? 0 : 1 };
      try {
        await updateProprietorAssignment(id, updatedAssignment);
        setAssignments(assignments.map((assignment) =>
          assignment.proprietorMappingId === id ? updatedAssignment : assignment
        ));
        toast.success(
          `Proprietor Assignment ${updatedAssignment.isActive === 1 ? 'Active' : 'De-Activate'} successfully!`);
      } catch (error) {
        console.error("Error updating assignment:", error);
        toast.error("Failed to update Proprietor Assignment. Please try again.");
      } finally {
        hideLoader();
      }
    }
  };

  return (
    <>
      <Box display="flex" justifyContent="end" mr={4}>
        <Button
          size="small"
          variant="contained"
          startIcon={<FaPlusCircle fontSize="small" />}
          onClick={handleShowModal}
          sx={{
            backgroundColor: 'rgba(73, 102, 131, 0.15)',
            backdropFilter: 'blur(6px)',
            color: 'rgb(73, 102, 131)',
            border: '1px solid rgba(73, 102, 131, 0.3)',
            textTransform: 'none',
            fontWeight: 500,
            fontSize: '0.75rem',
            boxShadow: '0 1px 4px rgba(0,0,0,0.1)',
            m: 3,
            py: 1,
            '&:hover': {
              backgroundColor: 'rgba(73, 102, 131, 0.25)',
              color: 'rgb(73, 102, 131)',
            },
          }}
        >
          Add Proprietor Mapping
        </Button>
      </Box>
      <TableContainer sx={{ minHeight: "50vh", overflowX: { xs: 'auto', xl: 'hidden' } }}>
        {!tableLoading ? (
          Array.isArray(currentAssignments) && currentAssignments.length > 0 ? (
            <Table sx={{ tableLayout: "fixed", width: "100%" }} size="small">
              <TableHead>
                <TableRow sx={{ background: "rgb(246, 247, 251)", height: 60 }}>
                  <TableCell sx={{ fontWeight: "bold", textAlign: "center", width: 150 }}>SR. No.</TableCell>
                  <TableCell sx={{ fontWeight: "bold" }}>TRAY</TableCell>
                  <TableCell sx={{ fontWeight: "bold" }}>STATUS</TableCell>
                  <TableCell sx={{ fontWeight: "bold" }}>SUB-STATUS</TableCell>
                  <TableCell sx={{ fontWeight: "bold" }}>PROPRIETOR</TableCell>
                  <TableCell sx={{ fontWeight: "bold", textAlign: "center" }}>ACTION</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {currentAssignments.map((assignment, index) => (
                  <TableRow key={assignment.proprietorMappingId} sx={{ height: 50 }}>
                    <TableCell align="center">
                      {(currentPage - 1) * itemsPerPage + index + 1}
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2" noWrap>
                        {assignment.trayMasterDto?.trayName}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2" noWrap>
                        {assignment.statusDefinitionsDto?.status}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2" noWrap>
                        {assignment.subStatusDefinitionsDto?.subStatus}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2" noWrap>
                        {assignment.proprietorMasterDto?.proprietorName}
                      </Typography>
                    </TableCell>
                    <TableCell align='center'>
                      <Box display="flex" gap={1} justifyContent="center">
                        <Button
                          size="small"
                          variant="contained"
                          onClick={() => handleEdit(assignment.proprietorMappingId)}
                          sx={{
                            minWidth: "50px",
                            fontWeight: "600",
                            fontSize: "0.6rem",
                            padding: "2px 6px",
                            height: "25px",
                            lineHeight: "1",
                          }}
                        >
                          Edit
                        </Button>
                        <Button
                          size="small"
                          variant="contained"
                          color={assignment.isActive === 1 ? "error" : "success"}
                          onClick={() => handleInactive(assignment.proprietorMappingId)}
                          sx={{
                            minWidth: "80px",
                            fontWeight: "600",
                            fontSize: "0.6rem",
                            padding: "2px 6px",
                            height: "25px",
                            lineHeight: "1",
                            backgroundColor: (theme) =>
                              assignment.isActive === 1 ? theme.palette.error.main : theme.palette.success.main,
                            '&:hover': {
                              backgroundColor: (theme) =>
                                assignment.isActive === 1 ? theme.palette.error.dark : theme.palette.success.dark,
                            },
                          }}
                        >
                          {assignment.isActive === 1 ? "Deactivate" : "Activate"}
                        </Button>
                      </Box>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <Box display="flex" justifyContent="center" alignItems="center" minHeight="50vh">
              <Typography variant="body2" color="textSecondary">
                No assignments available.
              </Typography>
            </Box>
          )
        ) : (
          <></>
        )}
      </TableContainer>
      {!tableLoading && totalPages > 0 && (
        <Box display="flex" justifyContent="center" mt={2}>
          <Pagination
            count={totalPages}
            page={currentPage}
            onChange={(_, page) => handlePageChange(page)}
            sx={{
              '& .MuiPaginationItem-root': {
                color: 'rgb(73, 102, 131) !important',
                borderColor: 'rgb(73, 102, 131) !important',
              },
              '& .MuiPaginationItem-root.Mui-selected': {
                backgroundColor: 'rgb(73, 102, 131) !important',
                color: '#fff !important',
              },
            }}
          />
        </Box>
      )}
      <ToastContainer autoClose={2000} position="top-right" />
      <MappingModal
        title={"Proprietor Mapping"}
        isVisible={showModal}
        onClose={handleShowModal}
      >
        <ProprietorMapping
          editData={selectedAssignment}
          mode={editMode ? "edit" : "add"}
          isOpen={showModal}
          onClose={handleShowModal}
          onSave={handleSave}
        />
      </MappingModal>
    </>
  );
};

export default Proprietor;
