import React, { useEffect, useState } from "react";
import {
  SubStatusDefinitionsDto,
} from "../../Interfaces/Task";
import { toast, ToastContainer } from "react-toastify";
import { getAllSubStatus, updateSubStatus } from "../../Requests/SubStatusRequest";
import { Box, Button, Pagination, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography } from "@mui/material";
import { Empty } from "antd";
import { usePageLoader } from "../../context/PageLoaderContext";
import { FaPlusCircle } from "react-icons/fa";
import MappingModal from "../Modal/Mapping/MappingModal";
import SubStatusMappingModalForm from "../Modal/Mapping/SubStatusMapping";
import { actionButtonStyle } from "../../util/constants/commonStyles";

const SubStatusMapping: React.FC = () => {

  const { showLoader, hideLoader } = usePageLoader();
  const [tableLoading, setTableLoading] = useState(false);
  const [subStatus, setSubStatus] = useState<SubStatusDefinitionsDto>();
  const [subStatuses, setSubStatuses] = useState<SubStatusDefinitionsDto[]>([]);
  const [editMode, setEditMode] = useState<boolean>(false);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 8;
  const [showModal, setShowModal] = useState(false);
  const handleShowModal = () => {
    setShowModal(!showModal);
  }

  const handleEdit = (subStatus: SubStatusDefinitionsDto) => {
    setEditMode(true);
    setSubStatus(subStatus);
    setShowModal(!showModal);
  };

  const handleToggleActive = async (subStatus: SubStatusDefinitionsDto) => {
    try {
      showLoader();
      const updatedSubStatus = {
        ...subStatus,
        isActive: subStatus.isActive === 1 ? 0 : 1,
      };
      await updateSubStatus(subStatus.subStatusId, updatedSubStatus);
      toast.success(
        `Sub-Status "${subStatus.subStatus}" is now ${updatedSubStatus.isActive === 1 ? "Active" : "De-Activate"}`
      );
      const data = await getAllSubStatus();
      setSubStatuses(data.data);
    } catch (error) {
      toast.error("Failed to update active status.");
    } finally {
      hideLoader();
    }
  };

  const handlePageChange = (page: number) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
    }
  };

  const currentItems = subStatuses.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const totalPages = Math.ceil(subStatuses.length / itemsPerPage);


  const fetchSubStatuses = async () => {
    showLoader();
    setTableLoading(true);
    try {
      const data = await getAllSubStatus();
      setSubStatuses(data.data);
    } catch (err) {
      console.error(err);
    } finally {
      setTableLoading(false);
      hideLoader();
    }
  };

  useEffect(() => {
    fetchSubStatuses();
  }, []);


  return (
    <>
      <Box display="flex" justifyContent="end" mr={4}>
        <Button
          size="small"
          variant="contained"
          startIcon={<FaPlusCircle fontSize="small" />}
          sx={{
            ...actionButtonStyle, m: 3,
            py: 1
          }}

          onClick={() => { handleShowModal(); setEditMode(false) }}
        >
          Add Sub Status Mapping
        </Button>
      </Box>
      <TableContainer sx={{ minHeight: "50vh", mt: 0, overflowX: { xs: 'auto', xl: 'hidden' } }}>
        {!tableLoading ? (
          currentItems.length > 0 ? (
            <Table sx={{ tableLayout: "fixed", width: "100%" }} size="small">
              <TableHead>
                <TableRow sx={{ background: "rgb(246, 247, 251)", height: 60 }}>
                  <TableCell sx={{ fontWeight: "bold", width: 100, textAlign: "center" }}>SR.NO</TableCell>
                  <TableCell sx={{ fontWeight: "bold", width: 250 }}>SUB-STATUS</TableCell>
                  <TableCell sx={{ fontWeight: "bold", width: 200 }}>STATUS</TableCell>
                  <TableCell sx={{ fontWeight: "bold", width: 200 }}>TRAY</TableCell>
                  <TableCell sx={{ fontWeight: "bold", width: 200, textAlign: "center" }}>ACTION</TableCell>
                </TableRow>
              </TableHead>

              <TableBody>
                {currentItems.map((subStatus, index) => (
                  <TableRow key={subStatus.subStatusId} sx={{ height: 50 }}>
                    <TableCell align="center">
                      {(currentPage - 1) * itemsPerPage + index + 1}
                    </TableCell>

                    <TableCell>
                      <Typography variant="body2" noWrap>
                        {subStatus.subStatus}
                      </Typography>
                    </TableCell>

                    <TableCell>
                      <Typography variant="body2" noWrap>
                        {subStatus.statusDefinitionsDto?.status}
                      </Typography>
                    </TableCell>

                    <TableCell>
                      <Typography variant="body2" noWrap>
                        {subStatus.trayMasterDto?.trayName}
                      </Typography>
                    </TableCell>

                    <TableCell align="center">
                      <Box display="flex" gap={1} justifyContent="center">
                        <Button
                          size="small"
                          variant="contained"
                          onClick={() => handleEdit(subStatus)}
                          sx={{
                            minWidth: "50px",
                            fontWeight: "600",
                            fontSize: "0.6rem",
                            padding: "2px 6px",
                            height: "25px",
                            lineHeight: "1",
                          }}
                        >
                          Edit
                        </Button>

                        <Button
                          size="small"
                          variant="contained"
                          color={subStatus.isActive === 1 ? "error" : "success"}
                          onClick={() => handleToggleActive(subStatus)}
                          sx={{
                            minWidth: "80px",
                            fontWeight: "600",
                            fontSize: "0.6rem",
                            padding: "2px 6px",
                            height: "25px",
                            lineHeight: "1",
                            backgroundColor: (theme) =>
                              subStatus.isActive === 1 ? theme.palette.error.main : theme.palette.success.main,
                            '&:hover': {
                              backgroundColor: (theme) =>
                                subStatus.isActive === 1 ? theme.palette.error.dark : theme.palette.success.dark,
                            },
                          }}
                        >
                          {subStatus.isActive === 1 ? "Deactivate" : "Activate"}
                        </Button>
                      </Box>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <Box display="flex" justifyContent="center" alignItems="center" minHeight="50vh">
              <Empty description="No Sub-Status available. Please add Sub-Status first or adjust the search term." />
            </Box>
          )
        ) : (
          <></>
        )}
      </TableContainer>

      {!tableLoading && totalPages > 0 && (
        <Box display="flex" justifyContent="center" mt={2}>
          <Pagination
            count={totalPages}
            page={currentPage}
            onChange={(_, page) => handlePageChange(page)}
            sx={{
              '& .MuiPaginationItem-root': {
                color: 'rgb(73, 102, 131) !important',
                borderColor: 'rgb(73, 102, 131) !important',
              },
              '& .MuiPaginationItem-root.Mui-selected': {
                backgroundColor: 'rgb(73, 102, 131) !important',
                color: '#fff !important',
              },
            }}
          />
        </Box>
      )}

      <MappingModal
        title={"Sub Status Mapping"}
        isVisible={showModal}
        onClose={handleShowModal}
      >
        <SubStatusMappingModalForm
          editData={subStatus}
          mode={editMode ? "edit" : "add"}
          isOpen={showModal}
          onClose={handleShowModal}
        />
      </MappingModal>
      <ToastContainer />
    </>
  );
};

export default SubStatusMapping;