import React, { useState, useEffect } from "react";
import {
  createMeeting, editMeeting, getAllEmployees, getAllMeetings,
  getParticipantsByMeetingId, getTaskByEmployee
} from "../../Requests/MeetingRequest";
import { MeetingParticipantsDto, MeetingsDto } from "../../Interfaces/Meeting";
import { EmployeeData } from "../../Interfaces/Login";
import { Task } from "../../Interfaces/Task";
import Select, { MultiValue, components } from "react-select";
import { ToastContainer, toast } from 'react-toastify';
import moment from 'moment';
import { useLocation } from "react-router-dom";
import {
  Box, Button, Grid, TextField, Typography, FormControl,
  InputLabel, Select as MuiSelect, MenuItem, FormHelperText,
  CardContent, SelectChangeEvent, InputAdornment, IconButton,
  Paper
} from '@mui/material';
import CalendarTodayIcon from '@mui/icons-material/CalendarToday';
import DescriptionIcon from '@mui/icons-material/Description';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import LinkIcon from '@mui/icons-material/Link';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { TimePicker } from '@mui/x-date-pickers/TimePicker';
import { AdapterMoment } from '@mui/x-date-pickers/AdapterMoment';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AccessTime, Groups, RateReview, Assignment, People } from "@mui/icons-material";
import { parse } from "date-fns";

interface EmployeeOption {
  value: number;
  label: string;
  employeeDesignation: string;
  employeeDepartmentName: string;
}

// Custom Control component for react-select to add icon
const CustomControl = ({ children, ...props }: any) => (
  <components.Control {...props}>
    <People style={{ marginLeft: '10px', color: '#757575', fontSize: '20px' }} />
    {children}
  </components.Control>
);

const Meeting: React.FC = () => {
  const location = useLocation();
  const [meetingDetails, setMeetingDetails] = useState<MeetingsDto | null>(null);
  const [employees, setEmployees] = useState<EmployeeOption[]>([]);
  const [selectedEmployees, setSelectedEmployees] = useState<EmployeeOption[]>([]);
  const [employee, setEmployee] = useState<EmployeeData | null>(null);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  const [tasks, setTasks] = useState<Task[]>([]);
  const [selectedTaskId, setSelectedTaskId] = useState<string>("");
  const [isEditMode, setIsEditMode] = useState(false);
  const [open, setOpen] = useState(false);
  const [fromTimeOpen, setFromTimeOpen] = useState(false);
  const [toTimeOpen, setToTimeOpen] = useState(false);

  useEffect(() => {
    const storedData = localStorage.getItem("employeedata");
    if (storedData) {
      const parsedData = JSON.parse(storedData);
      setEmployee(parsedData);
    }
  }, []);

  useEffect(() => {
    if (employee) {
      const fetchTasks = async () => {
        try {
          const tasksData = await getTaskByEmployee(Number(employee?.EmployeeNo));
          if (Array.isArray(tasksData)) {
            setTasks(tasksData);
          } else {
            setTasks([]);
          }
        } catch (error) {
          console.error("Error fetching tasks:", error);
        }
      };
      fetchTasks();
    }
  }, [employee]);

  useEffect(() => {
    console.log("Tasks state updated:", tasks);
  }, [tasks]);

  const fetchEmployees = async () => {
    try {
      const fetchedEmployees = await getAllEmployees();
      const employeeOptions: EmployeeOption[] = fetchedEmployees.map((employee: any) => ({
        value: Number(employee.employeeId),
        label: employee.employeeFullName,
        employeeDesignation: employee.designation,
        employeeDepartmentName: employee.departmentName,
      }));
      setEmployees(employeeOptions);
    } catch (error) {
      toast.error("Failed to load employees. Please try again later.");
    }
  };

  useEffect(() => {
    fetchEmployees();
  }, []);

  useEffect(() => {
    const fetchMeetingDetails = async () => {
      if (location.state?.meeting) {
        const meeting = location.state.meeting;
        setMeetingDetails(meeting);
        setSelectedTaskId(meeting.tasksDto?.id.toString() || "");
        const formattedDate = meeting.date ? moment(meeting.date).format("YYYY-MM-DD") : "";
        try {
          const participantsData = await getParticipantsByMeetingId(meeting.id);
          if (Array.isArray(participantsData)) {
            const employeeOptions = participantsData.map((participant: MeetingParticipantsDto) => ({
              value: participant.employeeId,
              label: participant.participantName,
              employeeDesignation: participant.designation,
              employeeDepartmentName: participant.departmentName,
            }));
            setSelectedEmployees(employeeOptions);
            setMeetingDetails({ ...meeting, date: formattedDate });
            setSelectedTaskId(meeting.tasksDto?.id.toString() || "");
          }
        } catch (error) {
          console.error("Error fetching participants:", error);
        }
        setIsEditMode(true);
      }
    };
    fetchMeetingDetails();
  }, [location.state]);


  const parseTimeString = (timeString: string | undefined): Date | null => {
    if (!timeString) return null;
    // Try parsing common time formats
    const formats = ["h:mm a", "h:mm:ss a", "HH:mm", "HH:mm:ss"];
    for (const formatString of formats) {
      try {
        const parsed = parse(timeString, formatString, new Date());
        if (!isNaN(parsed.getTime())) {
          return parsed;
        }
      } catch (error) {
        // Continue to next format
      }
    }
    console.warn(`Failed to parse time string: ${timeString}`);
    return null;
  };


  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setMeetingDetails((prevDetails) => ({ ...prevDetails, [name]: value } as MeetingsDto));
    // Clear error for the field when user starts typing
    setErrors((prevErrors) => ({ ...prevErrors, [name]: "" }));
  };

  const handleEmployeeSelection = (selectedOptions: MultiValue<EmployeeOption>) => {
    setSelectedEmployees(selectedOptions as EmployeeOption[]);
    const selectedEmployeeIds = selectedOptions.map((option) => option.value);
    setMeetingDetails((prevDetails) => {
      if (!prevDetails) return null;
      return { ...prevDetails, employeeId: selectedEmployeeIds };
    });
    // Clear attendees error when selection changes
    setErrors((prevErrors) => ({ ...prevErrors, attendees: "" }));
  };

  const handleTaskChange = (e: SelectChangeEvent<string>) => {
    const selectedTaskId = e.target.value;
    setSelectedTaskId(selectedTaskId);
    const selectedTaskObject = tasks.find((task) => task.id === Number(selectedTaskId));
    if (selectedTaskObject) {
      setMeetingDetails((prevMeeting) => ({
        ...prevMeeting,
        tasksDto: selectedTaskObject,
        id: prevMeeting?.id ?? 0,
        meetingId: prevMeeting?.meetingId ?? "",
        meetingName: prevMeeting?.meetingName ?? "",
        agenda: prevMeeting?.agenda ?? "",
        employeeId: prevMeeting?.employeeId ?? [],
        date: prevMeeting?.date ?? "",
        fromTime: prevMeeting?.fromTime ?? "",
        toTime: prevMeeting?.toTime ?? "",
        location: prevMeeting?.location ?? "",
        link: prevMeeting?.link ?? "",
        remarks: prevMeeting?.remarks ?? "",
        createdBy: Number(employee?.EmployeeNo) ?? 0,
        meetingStatus: prevMeeting?.meetingStatus ?? "",
        reasonForCancellation: prevMeeting?.reasonForCancellation ?? "",
        mom: prevMeeting?.mom ?? "",
        meetingParticipantsDtoList: prevMeeting?.meetingParticipantsDtoList ?? [],
        createdOn: prevMeeting?.createdOn ?? "",
        hostIdName: prevMeeting?.hostIdName ?? "",
        departmentName: prevMeeting?.departmentName ?? "",
        designation: prevMeeting?.designation ?? "",
      }));
    }
    // Clear task error when selection changes
    setErrors((prevErrors) => ({ ...prevErrors, task: "" }));
  };

  const handleDateChange = (date: any) => {
    setMeetingDetails((prevDetails) => ({
      ...prevDetails,
      date: date ? date.format("YYYY-MM-DD") : "",
    } as MeetingsDto));
    setErrors((prevErrors) => ({ ...prevErrors, date: "" }));
  };

  const handleTimeChange = (time: Date | moment.Moment | null, field: string) => {
    setMeetingDetails((prevDetails) => ({
      ...prevDetails,
      [field]: time ? moment(time).format("hh:mm A") : "",
    } as MeetingsDto));
    setErrors((prevErrors) => ({ ...prevErrors, [field]: "" }));
  };

  const validateMeetingName = () => {
    if (!meetingDetails?.meetingName) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        meetingName: "Meeting Name is required.",
      }));
      return false;
    }
    setErrors((prevErrors) => ({ ...prevErrors, meetingName: "" }));
    return true;
  };

  const validateAgenda = () => {
    if (!meetingDetails?.agenda) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        agenda: "Agenda is required.",
      }));
      return false;
    }
    setErrors((prevErrors) => ({ ...prevErrors, agenda: "" }));
    return true;
  };

  const validateAttendees = () => {
    if (selectedEmployees.length === 0) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        attendees: "Please select at least one attendee.",
      }));
      return false;
    }
    setErrors((prevErrors) => ({ ...prevErrors, attendees: "" }));
    return true;
  };

  const validateDate = () => {
    if (!meetingDetails?.date) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        date: "Meeting Date is required.",
      }));
      return false;
    }
    if (moment(meetingDetails?.date).isBefore(moment().startOf('day'))) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        date: "Past date is not allowed.",
      }));
      return false;
    }
    setErrors((prevErrors) => ({ ...prevErrors, date: "" }));
    return true;
  };

  const validateTime = () => {
    let isValid = true;
    setErrors((prevErrors) => ({
      ...prevErrors,
      fromTime: "",
      toTime: "",
    }));
    if (!meetingDetails?.fromTime) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        fromTime: "From Time is required.",
      }));
      isValid = false;
    }
    if (!meetingDetails?.toTime) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        toTime: "To Time is required.",
      }));
      isValid = false;
    }
    if (
      meetingDetails?.fromTime &&
      meetingDetails?.toTime
    ) {
      const fromTime = parseTimeString(meetingDetails.fromTime);
      const toTime = parseTimeString(meetingDetails.toTime);
      if (fromTime && toTime && fromTime >= toTime) {
        setErrors((prevErrors) => ({
          ...prevErrors,
          toTime: "To Time cannot be earlier than or equal to From Time.",
        }));
        isValid = false;
      }
    }
    return isValid;
  };

  const validateTask = () => {
    if (!selectedTaskId) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        task: "Project is required.",
      }));
      return false;
    }
    setErrors((prevErrors) => ({ ...prevErrors, task: "" }));
    return true;
  };

  const validateLocationOrLink = () => {
    if (!meetingDetails?.location && !meetingDetails?.link) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        locationOrLink: "Either Location or Link must be provided.",
      }));
      return false;
    }
    setErrors((prevErrors) => ({ ...prevErrors, locationOrLink: "" }));
    return true;
  };

  const handleResetForm = () => {
    setMeetingDetails(null);
    setSelectedTaskId("");
    setErrors({});
    setEmployees([]);
    setSelectedEmployees([]);
    setIsEditMode(false);
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    // Run all validations
    const isValid = [
      validateMeetingName(),
      validateAgenda(),
      validateAttendees(),
      validateDate(),
      validateTime(),
      validateTask(),
      validateLocationOrLink(),
    ].every(Boolean);

    if (!isValid) {
      return;
    }

    try {
      if (isEditMode) {
        const response = await editMeeting(meetingDetails?.meetingId || "", meetingDetails);
        if (response.httpStatus === "OK") {
          toast.success("Meeting Updated Successfully!");
        } else {
          toast.error("Meeting Failed To Update");
        }
      } else {
        const response = await createMeeting(meetingDetails);
        if (response.httpStatus === "CREATED") {
          toast.success("Meeting Created Successfully!");
        } else {
          toast.error("Meeting Failed To Create");
        }
      }
      await getAllMeetings();
    } catch (error) {
      toast.error("Failed to Create Meeting. Please try again.");
    } finally {
      handleResetForm();
    }
  };

  return (
    <Paper elevation={3} sx={{ borderRadius: 2, overflow: "hidden", position: "relative", boxShadow: "" }}
    >

      <Typography variant="h5" align="left" sx={{ ml: 5, mt: 4, fontWeight: "bold" }}>
        {isEditMode ? "Update Meeting" : "Create Meeting"}
      </Typography>
      <LocalizationProvider dateAdapter={AdapterMoment}>
        <Box sx={{ p: 4, bgcolor: 'background.default', minHeight: '77vh' }}>
          <ToastContainer />
          <CardContent>


            <form onSubmit={handleSubmit}>
              <Grid container spacing={3}>
                <Grid item xs={12} md={6}>
                  <TextField
                    fullWidth
                    label="Meeting Name*"
                    name="meetingName"
                    value={meetingDetails?.meetingName || ""}
                    onChange={handleInputChange}
                    error={!!errors.meetingName}
                    helperText={errors.meetingName}
                    variant="outlined"
                    sx={{ mb: 2 }}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <Groups />
                        </InputAdornment>
                      ),
                    }}
                  />
                </Grid>
                <Grid item xs={12} md={6}>
                  <TextField
                    fullWidth
                    label="Agenda"
                    name="agenda"
                    value={meetingDetails?.agenda || ""}
                    onChange={handleInputChange}
                    multiline
                    error={!!errors.agenda}
                    helperText={errors.agenda}
                    variant="outlined"
                    sx={{ mb: 2 }}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <DescriptionIcon />
                        </InputAdornment>
                      ),
                    }}
                  />
                </Grid>
                <Grid item xs={12} md={6}>
                  <FormControl fullWidth error={!!errors.attendees}>
                    <Select
                      options={employees}
                      isMulti
                      value={selectedEmployees}
                      onChange={handleEmployeeSelection}
                      placeholder="Select Employee Attendees"
                      components={{ Control: CustomControl }}
                      styles={{
                        control: (base) => ({
                          ...base,
                          height: '56px',
                          borderRadius: '4px',
                          border: errors.attendees ? '1px solid #d32f2f' : '1px solid #c4c4c4',
                          '&:hover': {
                            borderColor: errors.attendees ? '#d32f2f' : '#000',
                          },
                        }),
                        valueContainer: (base) => ({
                          ...base,
                          padding: '0 8px',
                          maxHeight: '50px',
                          overflowY: 'auto',
                          scrollbarWidth: 'none',
                          msOverflowStyle: 'none',
                          '&::-webkit-scrollbar': {
                            display: 'none',
                          },
                        }),
                        menu: (base) => ({
                          ...base,
                          zIndex: 1300,
                        }),
                        option: (base, { isFocused, isSelected }) => ({
                          ...base,
                          backgroundColor: isSelected
                            ? '#e0f7fa'
                            : isFocused
                              ? '#f5f5f5'
                              : '#fff',
                          color: '#000',
                        }),
                      }}
                    />

                    <FormHelperText>{errors.attendees}</FormHelperText>
                  </FormControl>
                </Grid>
                <Grid item xs={12} md={6}>
                  <DatePicker
                    label="Meeting Date"
                    value={meetingDetails?.date ? moment(meetingDetails.date) : null}
                    onChange={handleDateChange}
                    disabled={isEditMode}
                    minDate={moment()}
                    open={open}
                    onOpen={() => setOpen(true)}
                    onClose={() => setOpen(false)}
                    slots={{
                      openPickerIcon: CalendarTodayIcon,
                    }}
                    slotProps={{
                      textField: {
                        fullWidth: true,
                        error: !!errors.date,
                        helperText: errors.date,
                        InputProps: {
                          startAdornment: (
                            <InputAdornment position="start">
                              <IconButton
                                edge="start"
                                onClick={() => setOpen(true)}
                              >
                                <CalendarTodayIcon />
                              </IconButton>
                            </InputAdornment>
                          ),
                          endAdornment: null,
                        },
                        sx: {
                          '& .MuiInputAdornment-root.MuiInputAdornment-positionEnd': {
                            display: 'none',
                          },
                        },
                      },
                    }}
                  />
                </Grid>
                <Grid item xs={12} md={6}>
                  <TimePicker
                    label="From Time"
                    value={meetingDetails?.fromTime ? moment(meetingDetails.fromTime, 'HH:mm A') : null}
                    onChange={(time) => handleTimeChange(time, 'fromTime')}
                    disabled={isEditMode}
                    open={fromTimeOpen}
                    onOpen={() => setFromTimeOpen(true)}
                    onClose={() => setFromTimeOpen(false)}
                    slots={{
                      openPickerIcon: AccessTime,
                    }}
                    slotProps={{
                      textField: {
                        fullWidth: true,
                        error: !!errors.fromTime,
                        helperText: errors.fromTime,
                        InputProps: {
                          startAdornment: (
                            <InputAdornment position="start">
                              <IconButton
                                edge="start"
                                onClick={() => setFromTimeOpen(true)}
                              >
                                <AccessTime />
                              </IconButton>
                            </InputAdornment>
                          ),
                          endAdornment: null,
                        },
                        sx: {
                          '& .MuiInputAdornment-root.MuiInputAdornment-positionEnd': {
                            display: 'none',
                          },
                        },
                      },
                    }}
                  />
                </Grid>
                <Grid item xs={12} md={6}>
                  <TimePicker
                    label="To Time"
                    value={meetingDetails?.toTime ? moment(meetingDetails.toTime, 'HH:mm A') : null}
                    onChange={(time) => handleTimeChange(time, 'toTime')}
                    disabled={isEditMode}
                    open={toTimeOpen}
                    onOpen={() => setToTimeOpen(true)}
                    onClose={() => setToTimeOpen(false)}
                    slots={{
                      openPickerIcon: AccessTime,
                    }}
                    slotProps={{
                      textField: {
                        fullWidth: true,
                        error: !!errors.toTime,
                        helperText: errors.toTime,
                        InputProps: {
                          startAdornment: (
                            <InputAdornment position="start">
                              <IconButton
                                edge="start"
                                onClick={() => setToTimeOpen(true)}
                              >
                                <AccessTime />
                              </IconButton>
                            </InputAdornment>
                          ),
                          endAdornment: null,
                        },
                        sx: {
                          '& .MuiInputAdornment-root.MuiInputAdornment-positionEnd': {
                            display: 'none',
                          },
                        },
                      },
                    }}
                  />
                </Grid>
                <Grid item xs={12} md={6}>
                  <FormControl fullWidth error={!!errors.task}>
                    <InputLabel>Project</InputLabel>
                    <MuiSelect
                      value={selectedTaskId}
                      onChange={handleTaskChange}
                      label="Project"
                      variant="outlined"
                      startAdornment={
                        <InputAdornment position="start">
                          <Assignment />
                        </InputAdornment>
                      }
                    >
                      <MenuItem value="">Select Project</MenuItem>
                      {tasks.length > 0 ? (
                        tasks.map((task) => (
                          <MenuItem key={task.id} value={task.id}>
                            {task.taskId} - {task.taskName}
                          </MenuItem>
                        ))
                      ) : (
                        <MenuItem disabled>No projects available</MenuItem>
                      )}
                    </MuiSelect>
                    <FormHelperText>{errors.task}</FormHelperText>
                  </FormControl>
                </Grid>
                <Grid item xs={12} md={6}>
                  <TextField
                    fullWidth
                    label="Location"
                    name="location"
                    value={meetingDetails?.location || ""}
                    onChange={handleInputChange}
                    error={!!errors.locationOrLink}
                    helperText={errors.locationOrLink}
                    variant="outlined"
                    sx={{ mb: 2 }}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <LocationOnIcon />
                        </InputAdornment>
                      ),
                    }}
                  />
                </Grid>
                <Grid item xs={12} md={6}>
                  <TextField
                    fullWidth
                    label="Link"
                    name="link"
                    value={meetingDetails?.link || ""}
                    onChange={handleInputChange}
                    type="url"
                    error={!!errors.locationOrLink}
                    helperText={errors.locationOrLink}
                    variant="outlined"
                    sx={{ mb: 2 }}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <LinkIcon />
                        </InputAdornment>
                      ),
                    }}
                  />
                </Grid>
                <Grid item xs={12} md={6}>
                  <TextField
                    fullWidth
                    label="Remarks"
                    name="remarks"
                    value={meetingDetails?.remarks || ""}
                    onChange={handleInputChange}
                    multiline
                    variant="outlined"
                    sx={{ mb: 2 }}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <RateReview />
                        </InputAdornment>
                      ),
                    }}
                  />
                </Grid>
                <Grid item xs={12}>
                  <Box
                    sx={{
                      display: 'flex',
                      gap: 2,
                      justifyContent: 'flex-end', // Aligns buttons to the right
                      mt: 3
                    }}
                  >
                    <Button
                      type="submit"
                      variant="contained"
                      color="primary"
                      size="large"
                      sx={{ minWidth: 200 }}
                    >
                      {isEditMode ? "Update Meeting" : "Create Meeting"}
                    </Button>
                    <Button
                      type="button"
                      variant="outlined"
                      color="error"
                      size="large"
                      onClick={handleResetForm}
                      sx={{ minWidth: 200 }}
                    >
                      Clear
                    </Button>
                  </Box>
                </Grid>
              </Grid>
            </form>
          </CardContent>
        </Box>
      </LocalizationProvider>
    </Paper>
  );
};

export default Meeting;