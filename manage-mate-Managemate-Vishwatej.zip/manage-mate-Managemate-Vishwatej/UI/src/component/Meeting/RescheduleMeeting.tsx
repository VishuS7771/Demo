import React, { useEffect, useState } from "react";
import {
    TextField, Button, InputAdornment, Dialog, DialogContent, DialogTitle, IconButton, Box, Grid, Typography, CircularProgress,
    Divider
} from "@mui/material";
import { getAllEmployees, getMeetingById, getParticipantsByMeetingId, updateMeetingStatus } from "../../Requests/MeetingRequest";
import SelectMulti, { components, MultiValue } from "react-select";
import { MeetingParticipantsDto, MeetingsDto } from "../../Interfaces/Meeting";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import moment from "moment";
import PersonIcon from '@mui/icons-material/Person';
import EventIcon from '@mui/icons-material/Event';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import LinkIcon from '@mui/icons-material/Link';
import NotesIcon from '@mui/icons-material/Notes';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { TimePicker } from '@mui/x-date-pickers/TimePicker';
import { Clear } from "@mui/icons-material";

interface EmployeeOption {
    value: number;
    label: string;
}

// Custom Control component for react-select to add icon
const CustomControl = ({ children, ...props }: any) => (
    <components.Control {...props}>
        <PersonIcon style={{ marginLeft: '10px', color: '#757575', fontSize: '20px' }} />
        {children}
    </components.Control>
);

const RescheduleMeeting: React.FC<{ meetingId: string, onClose: () => void }> = ({ meetingId, onClose }) => {
    const [formData, setFormData] = useState<Partial<MeetingsDto>>({
        employeeId: [],
        date: "",
        fromTime: "",
        toTime: "",
        location: "",
        link: "",
        remarks: "",
        meetingStatus: "Re-Schedule",
    });

    const [meetingData, setMeetingData] = useState<Partial<MeetingsDto>>({});
    const [employees, setEmployees] = useState<EmployeeOption[]>([]);
    const [selEmployee, setSelEmployee] = useState<EmployeeOption[]>([]);
    const [loading, setLoading] = useState(false);
    const [dateOpen, setDateOpen] = useState(false);
    const [fromTimeOpen, setFromTimeOpen] = useState(false);
    const [toTimeOpen, setToTimeOpen] = useState(false);

    useEffect(() => {
        if (employees.length === 0) {
            const fetchEmployees = async () => {
                try {
                    setLoading(true);
                    const data = await getAllEmployees();
                    const employeeOptions = data.map((employee: { employeeId: number; employeeFullName: string }) => ({
                        value: employee.employeeId,
                        label: employee.employeeFullName,
                    }));
                    setEmployees(employeeOptions);
                } catch (error) {
                    console.error("Error fetching employees:", error);
                    toast.error("Failed to load employees.");
                } finally {
                    setLoading(false);
                }
            };
            fetchEmployees();
        }
    }, [employees]);

    useEffect(() => {
        const fetchParticipants = async () => {
            setLoading(true);
            try {
                const meetingData = await getMeetingById(meetingId);
                const participantsData = await getParticipantsByMeetingId(meetingData.id);
                let employeeOptions: EmployeeOption[] = []
                if (Array.isArray(participantsData)) {
                    employeeOptions = participantsData.map((participant: MeetingParticipantsDto) => ({
                        value: participant.employeeId,
                        label: participant.participantName,
                    }));
                    setSelEmployee(employeeOptions);
                }
                const formattedDate = meetingData.date ? moment(meetingData.date).format("YYYY-MM-DD") : "";
                if (meetingData) {
                    setMeetingData(meetingData);
                    setFormData({
                        employeeId: employeeOptions.map((e) => e.value),
                        date: formattedDate,
                        fromTime: meetingData.fromTime || "",
                        toTime: meetingData.toTime || "",
                        location: meetingData.location || "",
                        link: meetingData.link || "",
                        remarks: meetingData.remarks || "",
                        meetingStatus: formData.meetingStatus || "",
                    });
                }
            } catch (error) {
                console.error("Error fetching meeting data:", error);
                toast.error("Failed to load meeting data.");
            } finally {
                setLoading(false);
            }
        };
        fetchParticipants();
    }, [meetingId]);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData((prev) => ({ ...prev, [name]: value }));
    };

    const handleChange = (selectedOptions: MultiValue<EmployeeOption>) => {
        const selectedEmployees = selectedOptions as EmployeeOption[];
        setSelEmployee(selectedEmployees);
        const updatedSelEmpId = selectedEmployees.map((e) => e.value);
        setFormData((prev) => ({
            ...prev,
            employeeId: updatedSelEmpId,
        }));
    };

    const handleDateChange = (date: any) => {
        console.log("Selected date:", date ? date.format("YYYY-MM-DD") : null);
        setFormData((prev) => ({
            ...prev,
            date: date ? moment(date).format("YYYY-MM-DD") : "",
        }));
    };

    const handleTimeChange = (time:Date | moment.Moment | null, field: string) => {
        console.log(`Selected ${field}:`, time ? moment(time).format("HH:mm") : null);
        setFormData((prev) => ({
            ...prev,
            [field]: time ? moment(time).format("HH:mm") : "",
        }));
    };
    
    const handleSubmit = async () => {
        console.log("Form Data on Submit:", formData);
        const currentDateTime = moment(); // Current date and time: May 15, 2025, 04:03 PM IST
        const selectedDateTime = moment(`${formData.date} ${formData.fromTime}`, "YYYY-MM-DD HH:mm");

        // Validate that attendees are selected
        if (!formData.employeeId || formData.employeeId.length === 0) {
            toast.warning("Please select at least one attendee.");
            return;
        }

        // Validate that the selected date and time are not in the past
        if (selectedDateTime.isBefore(currentDateTime)) {
            console.log("Validation failed: Selected date/time is in the past.");
            toast.warning("Cannot reschedule to a past date or time.");
            return;
        }

        // Validate that no changes were made to date or time
        const originalDate = moment(meetingData.date).format("YYYY-MM-DD");
        if (
            formData.date === originalDate &&
            formData.fromTime === meetingData.fromTime &&
            formData.toTime === meetingData.toTime
        ) {
            console.log("Validation failed: No changes detected in date or time.");
            toast.warning("No changes detected in date or time. Reschedule not allowed.");
            return;
        }

        // Validate mandatory fields
        if (!formData.date || !formData.fromTime || !formData.toTime) {
            console.log("Validation failed: Missing mandatory fields.");
            toast.warning("Date and Time are mandatory fields.");
            return;
        }

        // Validate that toTime is after fromTime
        const fromTime = moment(formData.fromTime, "HH:mm");
        const toTime = moment(formData.toTime, "HH:mm");
        if (toTime.isSameOrBefore(fromTime)) {
            console.log("Validation failed: To Time is not later than From Time.");
            toast.warning("To Time must be later than From Time.");
            return;
        }

        try {
            setLoading(true);
            const response = await updateMeetingStatus(meetingId, formData);
            console.log("API Response:", response);
            if (response.httpStatus === "OK") {
                toast.success("Meeting rescheduled successfully!");
            } else {
                toast.error("Failed to reschedule meeting.");
            }
            onClose();
        } catch (error) {
            console.error("Error rescheduling meeting:", error);
            toast.error("Failed to reschedule meeting.");
        } finally {
            setLoading(false);
        }
    };

    const handleResetForm = () => {
        setFormData({
            employeeId: [],
            date: "",
            fromTime: "",
            toTime: "",
            location: "",
            link: "",
            remarks: "",
            meetingStatus: "Re-Schedule",
        });
        setSelEmployee([]);
    };

    return (
        <Dialog
            open={true}
            onClose={onClose}
            maxWidth="md"
            fullWidth
            sx={{ '& .MuiDialog-paper': { borderRadius: 2, boxShadow: 3 } }}
        >
            <DialogTitle
                sx={{
                    bgcolor: 'grey.50',
                    p: 0, // Remove default padding from DialogTitle
                    display: 'flex',
                    flexDirection: 'column',
                }}
            >
                <Box
                    sx={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        px: 2, // Add padding only to this row for content spacing
                        py: 1,
                    }}
                >
                    <Typography
                        variant="h5"
                        component="h2"
                        fontWeight="bold"
                        color="rgb(73, 102, 131)"
                    >
                        Reschedule Meeting
                    </Typography>
                    <IconButton onClick={onClose} aria-label="close" sx={{
                        color: "grey.500",
                        ":hover": { color: "red" },
                    }}>
                        <Clear />
                    </IconButton>
                </Box>
                <Divider
                    sx={{
                        borderBottom: 1,
                        borderColor: 'rgb(73, 102, 131)',
                        width: '100%', // Ensure full width
                        mx: 0, // Remove any horizontal margin
                    }}
                />
            </DialogTitle>

            <DialogContent sx={{ p: 3 }}>
                <ToastContainer />
                    {loading ? (
                        <Box display="flex" justifyContent="center" alignItems="center" minHeight={200}>
                            <CircularProgress />
                        </Box>
                    ) : (
                        <Grid container spacing={3}>
                            {/* Left Column */}
                            <Grid item xs={12} md={6}>
                                <Box mb={2} mt={3}>
                                    <SelectMulti
                                        isMulti
                                        options={employees}
                                        onChange={handleChange}
                                        value={selEmployee}
                                        placeholder="Select employees..."
                                        id="attendees"
                                        components={{ Control: CustomControl }}
                                        classNames={{
                                            control: () => "border-gray-300 rounded-md",
                                            menu: () => "bg-white border border-gray-300 rounded-md",
                                        }}
                                        styles={{
                                            control: (base) => ({
                                                ...base,
                                                height: '56px',
                                                borderRadius: '4px',
                                                border: '1px solid #c4c4c4',
                                                '&:hover': {
                                                    borderColor: '#000',
                                                },
                                            }),
                                            valueContainer: (base) => ({
                                                ...base,
                                                padding: '0 8px',
                                                maxHeight: '50px',
                                                overflowY: 'auto',
                                                scrollbarWidth: 'none',
                                                msOverflowStyle: 'none',
                                                '&::-webkit-scrollbar': {
                                                    display: 'none',
                                                },
                                            }),
                                            menu: (base) => ({
                                                ...base,
                                                zIndex: 1300,
                                            }),
                                            option: (base, { isFocused, isSelected }) => ({
                                                ...base,
                                                backgroundColor: isSelected
                                                    ? '#e0f7fa'
                                                    : isFocused
                                                        ? '#f5f5f5'
                                                        : '#fff',
                                                color: '#000',
                                            }),
                                        }}
                                    />
                                </Box>
                                <Box mb={2}>
                                    <TimePicker
                                        label="From Time"
                                        value={formData.fromTime ? moment(formData.fromTime, 'HH:mm') : null}
                                        onChange={(time) => handleTimeChange(time, 'fromTime')}
                                        open={fromTimeOpen}
                                        onOpen={() => setFromTimeOpen(true)}
                                        onClose={() => setFromTimeOpen(false)}
                                        slotProps={{
                                            textField: {
                                                fullWidth: true,
                                                InputProps: {
                                                    startAdornment: (
                                                        <InputAdornment position="start">
                                                            <IconButton
                                                                edge="start"
                                                                onClick={() => setFromTimeOpen(true)}
                                                            >
                                                                <AccessTimeIcon color="action" />
                                                            </IconButton>
                                                        </InputAdornment>
                                                    ),
                                                    endAdornment: null,
                                                },
                                                sx: {
                                                    '& .MuiInputAdornment-root.MuiInputAdornment-positionEnd': {
                                                        display: 'none',
                                                    },
                                                },
                                            },
                                        }}
                                    />
                                </Box>
                                <Box mb={2}>
                                    <TextField
                                        fullWidth
                                        name="location"
                                        label="Location"
                                        inputProps={{ maxLength: 100 }}
                                        value={formData.location || ""}
                                        onChange={handleInputChange}
                                        InputProps={{
                                            startAdornment: (
                                                <InputAdornment position="start">
                                                    <IconButton edge="start">
                                                        <LocationOnIcon color="action" />
                                                    </IconButton>
                                                </InputAdornment>
                                            ),
                                        }}
                                    />
                                </Box>
                            </Grid>

                            {/* Right Column */}
                            <Grid item xs={12} md={6} mt={3}>
                                <Box mb={2}>
                                    <DatePicker
                                        label="Meeting Date"
                                        value={formData.date ? moment(formData.date) : null}
                                        onChange={handleDateChange}
                                        open={dateOpen}
                                        onOpen={() => setDateOpen(true)}
                                        onClose={() => setDateOpen(false)}
                                        slotProps={{
                                            textField: {
                                                fullWidth: true,
                                                InputProps: {
                                                    startAdornment: (
                                                        <InputAdornment position="start">
                                                            <IconButton
                                                                edge="start"
                                                                onClick={() => setDateOpen(true)}
                                                            >
                                                                <EventIcon color="action" />
                                                            </IconButton>
                                                        </InputAdornment>
                                                    ),
                                                    endAdornment: null,
                                                },
                                                sx: {
                                                    '& .MuiInputAdornment-root.MuiInputAdornment-positionEnd': {
                                                        display: 'none',
                                                    },
                                                },
                                            },
                                        }}
                                    />
                                </Box>
                                <Box mb={2}>
                                    <TimePicker
                                        label="To Time"
                                        value={formData.toTime ? moment(formData.toTime, 'HH:mm') : null}
                                        onChange={(time) => handleTimeChange(time, 'toTime')}
                                        open={toTimeOpen}
                                        onOpen={() => setToTimeOpen(true)}
                                        onClose={() => setToTimeOpen(false)}
                                        slotProps={{
                                            textField: {
                                                fullWidth: true,
                                                InputProps: {
                                                    startAdornment: (
                                                        <InputAdornment position="start">
                                                            <IconButton
                                                                edge="start"
                                                                onClick={() => setToTimeOpen(true)}
                                                            >
                                                                <AccessTimeIcon color="action" />
                                                            </IconButton>
                                                        </InputAdornment>
                                                    ),
                                                    endAdornment: null,
                                                },
                                                sx: {
                                                    '& .MuiInputAdornment-root.MuiInputAdornment-positionEnd': {
                                                        display: 'none',
                                                    },
                                                },
                                            },
                                        }}
                                    />
                                </Box>
                                <Box mb={2}>
                                    <TextField
                                        fullWidth
                                        name="link"
                                        label="Link"
                                        value={formData.link || ""}
                                        onChange={handleInputChange}
                                        InputProps={{
                                            startAdornment: (
                                                <InputAdornment position="start">
                                                    <IconButton edge="start">
                                                        <LinkIcon color="action" />
                                                    </IconButton>
                                                </InputAdornment>
                                            ),
                                        }}
                                    />
                                </Box>
                            </Grid>

                            {/* Remarks - Centered at the Bottom */}
                            <Grid item xs={12}>
                                <Box sx={{ display: 'flex', mb: 2 }}>
                                    <TextField
                                        fullWidth
                                        name="remarks"
                                        label="Remarks"
                                        multiline
                                        rows={3}
                                        inputProps={{ maxLength: 5000 }}
                                        value={formData.remarks || ""}
                                        onChange={handleInputChange}
                                        InputProps={{
                                            startAdornment: (
                                                <InputAdornment position="start">
                                                    <IconButton edge="start">
                                                        <NotesIcon color="action" />
                                                    </IconButton>
                                                </InputAdornment>
                                            ),
                                        }}
                                    />
                                </Box>
                            </Grid>

                            {/* Buttons */}
                            <Grid item xs={12}>
                                <Box sx={{ display: 'flex', gap: 2, justifyContent: 'flex-end', mt: 3 }}>
                                    <Button
                                        variant="contained"
                                        color="primary"
                                        onClick={handleSubmit}
                                        size="small" // ← smaller button
                                        sx={{ minWidth: 150, py: 1, fontWeight: 'medium', borderRadius: 1 }}
                                    >
                                        Reschedule Meeting
                                    </Button>
                                    <Button
                                        variant="outlined"
                                        color="error"
                                        onClick={handleResetForm}
                                        size="small" // ← smaller button
                                        sx={{ minWidth: 150, py: 1, fontWeight: 'medium', borderRadius: 1 }}
                                    >
                                        Clear
                                    </Button>
                                </Box>
                            </Grid>
                        </Grid>
                    )}
            </DialogContent>
        </Dialog>
    );
};

export default RescheduleMeeting;