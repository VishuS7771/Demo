import React, { useState, useEffect } from "react";
import { getMeetingByTaskId, getMeetingsByEmployee } from "../../Requests/MeetingRequest";
import { MeetingsDto } from "../../Interfaces/Meeting";
import { ToastContainer } from 'react-toastify';
import moment from 'moment';
import { FaCalendarAlt, FaCommentDots, FaEdit, FaFileAlt, FaFlag, FaLink, FaEllipsisH, FaPlusCircle, FaSearch } from "react-icons/fa";
import MomLink from "../PopUp/MomPopUp";
import LinkPopUp from "../PopUp/LinkPopUp";
import RemarksPopUp from "../PopUp/RemarksPopUp";
import { useNavigate, useParams } from "react-router-dom";
import { EmployeeData } from "../../Interfaces/Login";
import RescheduleMeeting from "./RescheduleMeeting";
import { Box, Button, IconButton, Pagination, Paper, Popover, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Tooltip, Typography } from "@mui/material";
import { Empty } from "antd";
import MeetingDetailsSlider from "../Slider/Meetings/MeetingDetailsSlider";
import TableSkeleton from "../Skeletons/Skeleton";
import { getIconButtonStyle } from "../../util/constants/commonStyles";
import { CancelOutlined } from "@mui/icons-material";
import { meetingSearchCriteriaProps } from "../../Interfaces/Task";
import { actionButtonStyle, Search, SearchIconWrapper, StyledInputBase, tooltipProps } from "../../util/constants/commonStyles";
import { StatusChip } from "../Chip/StatusChip";
import dayjs from "dayjs";

interface ActionButton {
  title: string;
  icon: React.ReactNode;
  color: string;
  handler: () => void;
  disabled?: boolean;
}

const MeetingDetails: React.FC = () => {

  const navigate = useNavigate();
  const [tableLoading, setTableLoading] = useState(false);
  const [employee, setEmployee] = useState<EmployeeData | null>(null);
  const [meetingsList, setMeetingsList] = useState<MeetingsDto[]>([]);
  const [showMomLinkModal, setShowMomLinkModal] = useState(false);
  const [showLinkModal, setShowLinkModal] = useState(false);
  const [showRemarksModal, setShowRemarksModal] = useState(false);
  const [showRescheduleModal, setShowRescheduleModal] = useState(false);
  const [selectedMeetingId, setSelectedMeetingId] = useState<string | null>(null);
  const { taskId } = useParams<{ taskId: string }>();
  const [currentPage, setCurrentPage] = useState(1);
  const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null);
  const [selectedMeeting, setSelectedMeeting] = useState<MeetingsDto | null>(null);
  const itemsPerPage = 10;
  const [sliderOpen, setSliderOpen] = useState(false);
  const [currentSlider, setCurrentSlider] = useState<string>("");
  const [filteredMeetings, setFilteredMeetings] = useState<MeetingsDto[]>([]);
  const [searchCriteria, setSearchCriteria] = useState<meetingSearchCriteriaProps>({
    meetingId: "",
    meetingName: "",
    hostId: "",
    hostName: "",
    fromDate: "",
    toDate: "",
    status: [],
  })

  useEffect(() => {
    const storedData = localStorage.getItem("employeedata");
    if (storedData) {
      const parsedData = JSON.parse(storedData);
      setEmployee(parsedData);
    }
  }, []);

  const fetchMeetings = async () => {
    if (employee && employee.EmployeeNo) {
      setTableLoading(true);
      try {
        let meetings;
        if (taskId && taskId !== "0") {
          meetings = await getMeetingByTaskId(Number(taskId));
        } else {
          meetings = await getMeetingsByEmployee(Number(employee.EmployeeNo));
        }

        const sortedResponse = (meetings || []).sort((a: MeetingsDto, b: MeetingsDto) =>
          dayjs(b.createdOn, 'YYYY-DD-MM HH:mm:ss').valueOf() - dayjs(a.createdOn, 'YYYY-DD-MM HH:mm:ss').valueOf()
        );

        setMeetingsList(sortedResponse);
        setFilteredMeetings(sortedResponse);

      } catch (error) {
        console.error("Error fetching meetings:", error);
        setMeetingsList([]);
        setFilteredMeetings([]);

      } finally {
        setTableLoading(false);
      }
    }
  };

  useEffect(() => {
    fetchMeetings();
  }, [employee]);

  useEffect(() => {
    handleSearch();
  }, [searchCriteria]);

  const handlePageChange = (_: React.ChangeEvent<unknown>, pageNumber: number) => {
    setCurrentPage(pageNumber);
  };

  const handleSearch = () => {
    const meetings = meetingsList.filter((meeting) => {
      const searchValue = searchCriteria.meetingName?.toLowerCase();

      if (!searchValue) return true;

      const nameMatch = meeting.meetingName?.toLowerCase().includes(searchValue);
      const idMatch = meeting.meetingId?.toLowerCase().includes(searchValue);

      return nameMatch || idMatch;
    });

    setFilteredMeetings(meetings);
    setCurrentPage(1);
  };


  const currentMeetings = filteredMeetings.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const totalPages = Math.ceil(filteredMeetings.length / itemsPerPage);

  const handleMomLinkClick = (meetingId: string) => {
    setSelectedMeetingId(meetingId);
    setShowMomLinkModal(true);
  };

  const handleCloseMomLinkModal = () => {
    setShowMomLinkModal(false);
    setSelectedMeetingId(null);
  };

  const handleLinkClick = (meetingId: string) => {
    setSelectedMeetingId(meetingId);
    setShowLinkModal(true);
  };

  const handleCloseLinkModal = () => {
    setShowLinkModal(false);
    setSelectedMeetingId(null);
  };

  const handleRemarksClick = (meetingId: string) => {
    setSelectedMeetingId(meetingId);
    setShowRemarksModal(true);
  };

  const handleCloseRemarksModal = () => {
    setShowRemarksModal(false);
    setSelectedMeetingId(null);
  };

  const handleMeetingStatusClick = (meetingId: string) => {
    setSelectedMeetingId(meetingId);
    setCurrentSlider("editMeetingStatus");
    setSliderOpen(true);
  };

  const handleRescheduleClick = (meetingId: string) => {
    setSelectedMeetingId(meetingId);
    setShowRescheduleModal(true);
  };

  const handleCloseRescheduleModal = () => {
    setShowRescheduleModal(false);
    setSelectedMeetingId(null);
    fetchMeetings();
  };

  const handleEditMeeting = (meeting: MeetingsDto) => {
    navigate("/ui/Meeting", { state: { meeting } });
  };

  const handleOpenPopover = (event: React.MouseEvent<HTMLButtonElement>, meeting: MeetingsDto) => {
    setSelectedMeeting(meeting);
    setAnchorEl(event.currentTarget);
  };

  const handleClosePopover = () => {
    setAnchorEl(null);
    setSelectedMeeting(null);
  };

  const actionButtons = (meeting: MeetingsDto): ActionButton[] => [
    {
      title: "Edit",
      icon: <FaEdit />,
      color: "primary",
      handler: () => handleEditMeeting(meeting),
      disabled: meeting.meetingStatus === 'Completed' || meeting.meetingStatus === 'Cancelled' || String(meeting.createdBy) !== employee?.EmployeeNo,
    },
    {
      title: "Status",
      icon: <FaFlag />,
      color: "warning",
      handler: () => handleMeetingStatusClick(meeting.meetingId),
      disabled: meeting.meetingStatus === 'Completed' || meeting.meetingStatus === 'Cancelled' || String(meeting.createdBy) !== employee?.EmployeeNo,
    },
    {
      title: "Reschedule",
      icon: <FaCalendarAlt />,
      color: "secondary",
      handler: () => handleRescheduleClick(meeting.meetingId),
      disabled: meeting.meetingStatus === 'Completed' || meeting.meetingStatus === 'Cancelled' || String(meeting.createdBy) !== employee?.EmployeeNo,
    },
    {
      title: "Remarks",
      icon: <FaCommentDots />,
      color: "info",
      handler: () => handleRemarksClick(meeting.meetingId),
    },
    {
      title: "Meeting Link",
      icon: <FaLink />,
      color: "success",
      handler: () => handleLinkClick(meeting.meetingId),
    },
    {
      title: "MOM",
      icon: <FaFileAlt />,
      color: "default",
      handler: () => handleMomLinkClick(meeting.meetingId),
      disabled: meeting.meetingStatus !== 'Completed',
    },
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setSearchCriteria((prev) => ({ ...prev, [name]: value }));
  };

  const handleClear = () => {
    setSearchCriteria({
      meetingId: "",
      meetingName: "",
      hostId: "",
      hostName: "",
      fromDate: "",
      toDate: "",
      status: [],
    });
    setFilteredMeetings(meetingsList);
    setCurrentPage(1);

  };


  return (
    <Paper
      elevation={3}
      sx={{ pb: 2, borderRadius: 2, overflow: "hidden", position: "relative", boxShadow: "" }}
    >
      <ToastContainer />


      <Box display="flex" justifyContent="space-between" flexWrap="wrap" gap={2} px={5} mt={4} mb={3}>
        <Typography variant="h5" sx={{ fontWeight: 600 }} >Meeting Details </Typography>
        <Button
          size="small"
          variant="contained"
          startIcon={<FaPlusCircle fontSize="small" />}
          sx={actionButtonStyle}
          onClick={() => (navigate('/ui/Meeting'))}
        >
          SCHEDULE NEW MEETING
        </Button>
      </Box>
      <Box mt={2}>
        <Box display="flex" flexDirection={"row"} justifyContent="end" px={3} mb={2} mt={1}>
          <Search>
            <SearchIconWrapper>
              <IconButton></IconButton>
              <FaSearch color="#9d9d9d" />
            </SearchIconWrapper>
            <StyledInputBase
              placeholder="Search meeting name or id"
              name="meetingName"
              value={searchCriteria.meetingName}
              onChange={handleInputChange}
              inputProps={{ 'aria-label': 'search' }}
            />
            {
              <IconButton
                sx={{
                  position: 'absolute',
                  right: 4,
                  top: '50%',
                  transform: 'translateY(-50%)',
                  padding: '4px',
                  color: "lightgray"
                }}
                onClick={handleClear}
              >
                <CancelOutlined fontSize="medium" />
              </IconButton>
            }

          </Search>
          {/* <Tooltip title="Filter list" {...tooltipProps}>
            <IconButton sx={{ height: 35 }}>
              <GridFilterListIcon fontSize="medium" color="action" />
            </IconButton>
          </Tooltip> */}
        </Box>

        <TableContainer sx={{ minHeight: "63vh" }}>
          {!tableLoading ? (
            currentMeetings.length > 0 ? (
              <Table sx={{ minWidth: 1200 }}>
                <TableHead>
                  <TableRow sx={{ background: "rgb(246, 247, 251)", height: 60 }}>
                    <TableCell sx={{ fontWeight: "bold", width: 100, textAlign: "center" }}>SR. NO</TableCell>
                    <TableCell sx={{ fontWeight: "bold", width: 200 }}>MEETING ID & NAME</TableCell>
                    <TableCell sx={{ fontWeight: "bold", width: 200 }}>PROJECT ID & NAME</TableCell>
                    <TableCell sx={{ fontWeight: "bold", width: 150 }}>HOST ID & NAME</TableCell>
                    <TableCell sx={{ fontWeight: "bold", width: 250 }}>DESIGNATION & DEPARTMENT</TableCell>
                    <TableCell sx={{ fontWeight: "bold", width: 160 }}>DATE & TIME</TableCell>
                    <TableCell sx={{ fontWeight: "bold", width: 150 }}>LOCATION</TableCell>
                    <TableCell sx={{ fontWeight: "bold", width: 150, textAlign: "center" }}>STATUS</TableCell>
                    <TableCell sx={{ fontWeight: "bold", width: 100 }}>AGENDA</TableCell>
                    <TableCell sx={{ fontWeight: "bold", width: 100 }}>ACTION</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {currentMeetings.map((meeting, index) => (
                    <TableRow key={meeting.id}>
                      <TableCell sx={{ textAlign: "center", whiteSpace: "nowrap" }}>
                        {(currentPage - 1) * itemsPerPage + index + 1}
                      </TableCell>
                      <TableCell sx={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", maxWidth: 200 }}>
                        <Tooltip title={`${meeting.meetingId} - ${meeting.meetingName}`} {...tooltipProps}>
                          <span>{`${meeting.meetingId} - ${meeting.meetingName}`}</span>
                        </Tooltip>
                      </TableCell>
                      <TableCell sx={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", maxWidth: 200 }}>
                        <Tooltip title={`${meeting.tasksDto?.taskId || 'N/A'} - ${meeting.tasksDto?.taskName || 'N/A'}`} {...tooltipProps}>
                          <span>{`${meeting.tasksDto?.taskId || 'N/A'} - ${meeting.tasksDto?.taskName || 'N/A'}`}</span>
                        </Tooltip>
                      </TableCell>
                      <TableCell sx={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", maxWidth: 150 }}>
                        <Tooltip title={meeting.hostIdName || 'N/A'} {...tooltipProps}>
                          <span>{meeting.hostIdName || 'N/A'}</span>
                        </Tooltip>
                      </TableCell>
                      <TableCell sx={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", maxWidth: 200 }}>
                        <Tooltip title={`${meeting.designation || 'N/A'} - ${meeting.departmentName || 'N/A'}`} {...tooltipProps}>
                          <span>{`${meeting.designation || 'N/A'} - ${meeting.departmentName || 'N/A'}`}</span>
                        </Tooltip>
                      </TableCell>
                      <TableCell sx={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", maxWidth: 200 }}>
                        <div>{moment(meeting.date).format('DD MMM YYYY')}</div>
                        <div>
                          {meeting.fromTime} -{' '}
                          {meeting.toTime}
                        </div>
                      </TableCell>
                      <TableCell sx={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", maxWidth: 150 }}>
                        <Tooltip title={meeting.location || 'N/A'} {...tooltipProps}>
                          <span>{meeting.location || 'N/A'}</span>
                        </Tooltip>
                      </TableCell>
                      <TableCell sx={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", maxWidth: 100 }}>
                        <Tooltip title={meeting.meetingStatus} {...tooltipProps} disableHoverListener={meeting.meetingStatus.length <= 10} >
                          <span><StatusChip status={meeting.meetingStatus} /></span>
                        </Tooltip>
                      </TableCell>
                      <TableCell sx={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", maxWidth: 200 }}>
                        <Tooltip title={meeting.agenda || 'N/A'} {...tooltipProps}>
                          <span>{meeting.agenda || 'N/A'}</span>
                        </Tooltip>
                      </TableCell>
                      <TableCell>
                        <Box display="flex" gap={1}>
                          <Tooltip title="More Actions" {...tooltipProps}>
                            <IconButton
                              color="default"
                              onClick={(e) => handleOpenPopover(e, meeting)}
                              sx={getIconButtonStyle("#bbbbbb")}
                            >
                              <FaEllipsisH color="#bbbbbb" />
                            </IconButton>
                          </Tooltip>
                          <Popover
                            open={Boolean(anchorEl && selectedMeeting?.id === meeting.id)}
                            anchorEl={anchorEl}
                            onClose={handleClosePopover}
                            anchorOrigin={{
                              vertical: "bottom",
                              horizontal: "left",
                            }}
                            transformOrigin={{
                              vertical: "top",
                              horizontal: "right",
                            }}
                          >
                            <Box display="grid" gridTemplateColumns="repeat(3, 1fr)" gap={1} p={2} width={180}>
                              {actionButtons(meeting).map(({ title, icon, color, handler, disabled }, index) => (
                                <Tooltip key={title} title={title} {...tooltipProps} placement={index < 3 ? "top" : "bottom"}>
                                  <span>
                                    <IconButton
                                      color={color as any}
                                      sx={getIconButtonStyle(color || 'default')}
                                      onClick={() => {
                                        handler();
                                        handleClosePopover();
                                      }}
                                      disabled={disabled}
                                    >
                                      {icon}
                                    </IconButton>
                                  </span>
                                </Tooltip>
                              ))}
                            </Box>
                          </Popover>
                        </Box>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <Box
                display="flex"
                justifyContent="center"
                alignItems="center"
                minHeight="50vh"
              >
                <Empty description="No meetings found. Please create meetings first or change the search term." />
              </Box>
            )
          ) : (
            <TableSkeleton column={10} />
          )}
        </TableContainer>


        <Box display="flex" justifyContent="center" mt={1}>
          <Pagination
            count={totalPages}
            page={currentPage}
            sx={{
              '& .MuiPaginationItem-root': {
                color: 'rgb(73, 102, 131) !important',
                borderColor: 'rgb(73, 102, 131) !important',
              },
              '& .MuiPaginationItem-root.Mui-selected': {
                backgroundColor: 'rgb(73, 102, 131) !important',
                color: '#fff !important',
              },
            }}
            onChange={handlePageChange}
          />
        </Box>
      </Box>

      {
        showMomLinkModal && selectedMeetingId && (
          <MomLink meetingId={selectedMeetingId} onClose={handleCloseMomLinkModal} />
        )
      }
      {
        showLinkModal && selectedMeetingId && (
          <LinkPopUp meetingId={selectedMeetingId} onClose={handleCloseLinkModal} />
        )
      }
      {
        showRemarksModal && selectedMeetingId && (
          <RemarksPopUp meetingId={selectedMeetingId} onClose={handleCloseRemarksModal} />
        )
      }
      {
        showRescheduleModal && selectedMeetingId && (
          <RescheduleMeeting meetingId={selectedMeetingId} onClose={handleCloseRescheduleModal} />
        )
      }
      {
        sliderOpen && selectedMeetingId && (
          <MeetingDetailsSlider
            open={sliderOpen}
            setOpen={setSliderOpen}
            meetingId={selectedMeetingId}
            currentSlider={currentSlider}
          />
        )
      }
    </Paper >
  );
};

export default MeetingDetails;