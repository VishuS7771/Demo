import React, { useEffect, useState } from "react";
import {
    Box,
    Stack,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    TextField,
    Button,
    SelectChangeEvent,
    InputAdornment,
} from "@mui/material";
import { TableRows, Label, SubdirectoryArrowRight } from "@mui/icons-material";
import { StatusDefinitionsDto, SubStatusDefinitionsDto, Tray } from "../../../Interfaces/Task";
import { getstatus } from "../../../Requests/StatusMappingRequest";
import { EmployeeData } from "../../../Interfaces/Login";
import { toast } from "react-toastify";
import {
    createSubStatusMapping,
    getAllSubStatus,
    getAllTrays,
    updateSubStatus,
} from "../../../Requests/SubStatusRequest";

interface SubStatusMappingProps {
    isOpen: boolean;
    editData?: SubStatusDefinitionsDto;
    mode?: "add" | "edit";
    onClose: () => void;
}

const SubStatusMappingModalForm: React.FC<SubStatusMappingProps> = ({
    isOpen,
    editData,
    mode = "add",
    onClose,
}) => {
    const [trays, setTrays] = useState<Tray[]>([]);
    const [statuses, setStatuses] = useState<StatusDefinitionsDto[]>([]);
    const [selectedTrayName, setSelectedTrayName] = useState<string>("");
    const [selectedStatus, setSelectedStatus] = useState<string>("");
    const [manualSubStatus, setManualSubStatus] = useState<string>("");
    const [employee, setEmployee] = useState<EmployeeData | null>(null);
    const [subStatuses, setSubStatuses] = useState<SubStatusDefinitionsDto[]>([]);
    const [editSubStatusId, setEditSubStatusId] = useState<number | null>(null);

    // 🟡 Fetch trays and employee on mount
    useEffect(() => {
        const init = async () => {
            const employeeData = localStorage.getItem("employee");
            if (employeeData) {
                setEmployee(JSON.parse(employeeData));
            }
            try {
                const trayResponse = await getAllTrays();
                setTrays(trayResponse.data);
                const subStatusResponse = await getAllSubStatus();
                setSubStatuses(subStatusResponse.data);
            } catch (error) {
                toast.error("Error loading initial data.");
            }
        };

        if (isOpen) init();
    }, [isOpen]);

    // 🟡 Populate form in edit mode
    useEffect(() => {
        if (mode === "edit" && editData) {
            setEditSubStatusId(editData.subStatusId);
            setManualSubStatus(editData.subStatus);
            setSelectedTrayName(editData.trayMasterDto.trayName);
            setSelectedStatus(editData.statusDefinitionsDto.status);
        }
    }, [editData, mode]);

    useEffect(() => {
        const fetchStatuses = async () => {
            if (selectedTrayName) {
                try {
                    const response = await getstatus(selectedTrayName);
                    setStatuses(response.data);
                } catch (error) {
                    toast.error("Error fetching statuses.");
                }
            }
        };

        fetchStatuses();
    }, [selectedTrayName]);

    const handleTrayChange = async (trayName: string) => {
        setSelectedTrayName(trayName);
        setSelectedStatus("");
    };

    const handleClear = () => {
        setSelectedTrayName("");
        setSelectedStatus("");
        setManualSubStatus("");
        setEditSubStatusId(null);
        setStatuses([]);
    };

    const handleSubmit = async () => {
        if (!selectedTrayName || !selectedStatus || !manualSubStatus) {
            toast.error("Please select tray, status, and enter sub-status.");
            return;
        }

        if (!/^[a-zA-Z]+(?:[\s-][a-zA-Z]+)*$/.test(manualSubStatus)) {
            toast.error("Only alphabets, spaces, and hyphens allowed.");
            return;
        }

        const isDuplicate = subStatuses.some(
            (subStatus) =>
                subStatus.statusDefinitionsDto.status === selectedStatus &&
                subStatus.subStatus.toLowerCase() === manualSubStatus.toLowerCase() &&
                (mode === "edit" ? subStatus.subStatusId !== editSubStatusId : true)
        );
        if (isDuplicate) {
            toast.error("This combination already exists.");
            return;
        }

        const tray = trays.find((t) => t.trayName === selectedTrayName);
        const status = statuses.find((s) => s.status === selectedStatus);

        if (!tray || !status || !employee) {
            toast.error("Invalid tray, status or employee.");
            return;
        }

        const subStatusPayload: SubStatusDefinitionsDto = {
            subStatusId: editSubStatusId ?? 0,
            subStatus: manualSubStatus,
            statusDefinitionsDto: {
                ...status,
                createdBy: Number(employee.EmployeeNo),
            },
            createdBy: Number(employee.EmployeeNo),
            createdOn: "",
            isActive: 1,
            trayMasterDto: {
                ...tray,
                createdBy: Number(employee.EmployeeNo),
                isActive: 1,
                createdOn: "",
            },
        };

        try {
            if (mode === "edit" && editSubStatusId) {
                const response = await updateSubStatus(editSubStatusId, subStatusPayload);
                response.httpStatus === "OK"
                    ? toast.success("Updated Successfully!")
                    : toast.error("Update Failed.");
            } else {
                const response = await createSubStatusMapping(subStatusPayload);
                response.httpStatus === "CREATED"
                    ? toast.success("Created Successfully!")
                    : toast.error("Creation Failed.");
            }

            const data = await getAllSubStatus();
            setSubStatuses(data.data);
            handleClear();
            onClose();
        } catch (error) {
            toast.error("Failed to save sub-status.");
        }
    };

    return (
        <Box>
            <Stack spacing={3} mt={1} p={2}>
                <FormControl fullWidth variant="outlined" size="small">
                    <InputLabel id="tray-label">Tray</InputLabel>
                    <Select
                        labelId="tray-label"
                        label="Tray"
                        value={selectedTrayName}
                        onChange={(e: SelectChangeEvent) => handleTrayChange(e.target.value)}
                        startAdornment={
                            <InputAdornment position="start">
                                <TableRows />
                            </InputAdornment>
                        }
                    >
                        <MenuItem value="">
                            <em>Select Tray</em>
                        </MenuItem>
                        {trays.map((tray) => (
                            <MenuItem key={tray.trayId} value={tray.trayName}>
                                {tray.trayName}
                            </MenuItem>
                        ))}
                    </Select>
                </FormControl>

                <FormControl fullWidth variant="outlined" size="small" disabled={!selectedTrayName}>
                    <InputLabel id="status-label">Status</InputLabel>
                    <Select
                        labelId="status-label"
                        label="Status"
                        value={selectedStatus || ""}
                        onChange={(e) => setSelectedStatus(e.target.value)}
                        startAdornment={
                            <InputAdornment position="start">
                                <Label />
                            </InputAdornment>
                        }
                    >
                        <MenuItem value="">
                            <em>Select Status</em>
                        </MenuItem>
                        {statuses.map((status) => (
                            <MenuItem key={status.statusId} value={status.status}>
                                {status.status}
                            </MenuItem>
                        ))}
                    </Select>
                </FormControl>

                <TextField
                    fullWidth
                    label="Sub-Status"
                    value={manualSubStatus}
                    onChange={(e) => setManualSubStatus(e.target.value)}
                    inputProps={{ maxLength: 50 }}
                    variant="outlined"
                    size="small"
                    InputProps={{
                        startAdornment: (
                            <InputAdornment position="start">
                                <SubdirectoryArrowRight />
                            </InputAdornment>
                        ),
                    }}
                />
            </Stack>

            <Box sx={{ display: "flex", justifyContent: "flex-end", mt: 1, gap: 1.5 }}>
                <Button variant="contained" onClick={handleSubmit}>
                    {mode === "edit" ? "Update" : "Save"}
                </Button>
                <Button variant="outlined" color="warning" onClick={handleClear}>
                    Clear
                </Button>
            </Box>
        </Box>
    );
};

export default SubStatusMappingModalForm;