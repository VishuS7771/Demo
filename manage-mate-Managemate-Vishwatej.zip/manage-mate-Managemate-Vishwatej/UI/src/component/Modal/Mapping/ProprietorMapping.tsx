import { useEffect, useState } from 'react';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import "../../../css/Proprietor.css";
import { Box, Button, Grid, MenuItem, Select, InputLabel, FormControl, SelectChangeEvent, InputAdornment } from '@mui/material';
import SubdirectoryArrowRightIcon from '@mui/icons-material/SubdirectoryArrowRight';
import PersonIcon from '@mui/icons-material/Person';
import { usePageLoader } from '../../../context/PageLoaderContext';
import { PropriotorDto, StatusDefinitionsDto, SubStatusDefinitionsDto, TrayMasterDto } from '../../../Interfaces/Task';
import { ProprietorAssignmentsDto } from '../../../Interfaces/Proprietor';
import { EmployeeData } from '../../../Interfaces/Login';
import { getstatus, getSubStatus, getTrayList } from '../../../Requests/TaskRequest';
import { createProprietorAssignment, getAllProprietorMaster, updateProprietorAssignment } from '../../../Requests/ProprietorRequest';
import { Label, TableRows } from '@mui/icons-material';

interface ProprietorMappingProps {
    isOpen: boolean;
    editData?: ProprietorAssignmentsDto | null;
    mode?: "add" | "edit";
    onClose: () => void;
    onSave: (updatedAssignment: ProprietorAssignmentsDto | null, isNew: boolean) => void;
}

const ProprietorMapping: React.FC<ProprietorMappingProps> = ({ isOpen, editData, mode = "add", onClose }) => {
    const { showLoader, hideLoader } = usePageLoader();
    const [status, setStatus] = useState<string>("");
    const [subStatus, setSubStatus] = useState<string>("");
    const [proprietor, setProprietor] = useState<string>("");
    const [trayList, setTrayList] = useState<TrayMasterDto[]>([]);
    const [proprietorList, setProprietorList] = useState<PropriotorDto[]>([]);
    const [statusList, setStatusList] = useState<StatusDefinitionsDto[]>([]);
    const [subStatusList, setSubStatusList] = useState<SubStatusDefinitionsDto[]>([]);
    const [selectedTray, setSelectedTray] = useState<string | null>(null);
    const [selectedStatus, setSelectedStatus] = useState<number | null>(null);
    const [selectedSubStatus, setSelectedSubStatus] = useState<number | null>(null);
    const [selectedAssignment, setSelectedAssignment] = useState<ProprietorAssignmentsDto | null>(null);
    const [employee, setEmployee] = useState<EmployeeData | null>(null);

    useEffect(() => {
        const storedData = localStorage.getItem("employeedata");
        if (storedData) {
            const parsedData = JSON.parse(storedData);
            setEmployee(parsedData);
        }
    }, []);

    useEffect(() => {
        if (isOpen) {
            const fetchTrays = async () => {
                try {
                    showLoader();
                    const trayResponse = await getTrayList();
                    setTrayList(trayResponse.data);
                } catch (error) {
                    console.error("Error fetching tray list:", error);
                } finally {
                    hideLoader();
                }
            };
            fetchTrays();
        }
    }, [isOpen]);

    useEffect(() => {
        if (editData && mode === "edit") {
            setSelectedAssignment(editData);
            setSelectedTray(String(editData.trayMasterDto.trayName));

            // Fetch and pre-fill Status dropdown
            const fetchStatus = async () => {
                try {
                    showLoader();
                    const statusResponse = await getstatus(String(editData.trayMasterDto.trayName));
                    setStatusList(statusResponse.data);
                    setSelectedStatus(editData.statusDefinitionsDto.statusId);
                    setStatus(String(editData.statusDefinitionsDto.statusId));
                } catch (error) {
                    console.error("Error fetching Status for Tray:", error);
                } finally {
                    hideLoader();
                }
            };
            fetchStatus();

            // Fetch and pre-fill Sub-Status dropdown
            const fetchSubStatus = async () => {
                try {
                    showLoader();
                    const subStatusResponse = await getSubStatus(editData.statusDefinitionsDto.statusId);
                    setSubStatusList(subStatusResponse.data);
                    setSelectedSubStatus(editData.subStatusDefinitionsDto.subStatusId);
                    setSubStatus(String(editData.subStatusDefinitionsDto.subStatusId));
                } catch (error) {
                    console.error("Error fetching Sub-Status for Status:", error);
                } finally {
                    hideLoader();
                }
            };
            fetchSubStatus();

            // Fetch and pre-fill Proprietor dropdown
            const fetchProprietors = async () => {
                try {
                    showLoader();
                    const proprietorResponse = await getAllProprietorMaster();
                    setProprietorList(proprietorResponse.data);
                    setProprietor(String(editData.proprietorMasterDto.proprietorId));
                } catch (error) {
                    console.error("Error fetching Proprietor List:", error);
                } finally {
                    hideLoader();
                }
            };
            fetchProprietors();
        }
    }, [editData, mode, isOpen]);

    const handleTrayChange = (event: SelectChangeEvent<string>) => {
        const trayName = event.target.value;
        setSelectedTray(trayName);

        if (trayName) {
            const fetchStatus = async () => {
                try {
                    showLoader();
                    const response = await getstatus(trayName);
                    setStatusList(response.data);
                    setStatus("");
                    setSubStatusList([]);
                    setSelectedStatus(null);
                    setSelectedSubStatus(null);
                } catch (error) {
                    console.error("Error fetching Status list:", error);
                } finally {
                    hideLoader();
                }
            };
            fetchStatus();
        }
    };

    const handleStatusChange = (event: SelectChangeEvent<string>) => {
        const statusName = Number(event.target.value);
        setSelectedStatus(statusName);
        setStatus(event.target.value);

        if (statusName) {
            const fetchSubStatus = async () => {
                try {
                    showLoader();
                    const response = await getSubStatus(statusName);
                    setSubStatusList(response.data);
                    setSubStatus("");
                    setSelectedSubStatus(null);
                } catch (error) {
                    console.error("Error fetching Sub-Status list:", error);
                } finally {
                    hideLoader();
                }
            };
            fetchSubStatus();
        }
    };

    const handleSubStatusChange = (event: SelectChangeEvent<string>) => {
        const subStatusName = Number(event.target.value);
        setSelectedSubStatus(subStatusName);
        setSubStatus(event.target.value);

        if (subStatusName) {
            const fetchProprietors = async () => {
                try {
                    showLoader();
                    const response = await getAllProprietorMaster();
                    setProprietorList(response.data);
                } catch (error) {
                    console.error("Error fetching Proprietor list:", error);
                } finally {
                    hideLoader();
                }
            };
            fetchProprietors();
        } else {
            setProprietorList([]);
        }
    };

    const handleSave = async (event: React.MouseEvent<HTMLButtonElement>) => {
        event.preventDefault();

        if (selectedAssignment) {
            // Update existing assignment
            const selectedTrayId = trayList.find(tray => tray.trayName === selectedTray)?.trayId;
            const updatedAssignment: ProprietorAssignmentsDto = {
                ...selectedAssignment,
                trayMasterDto: {
                    ...selectedAssignment.trayMasterDto,
                    trayId: Number(selectedTrayId),
                },
                statusDefinitionsDto: {
                    ...selectedAssignment.statusDefinitionsDto,
                    statusId: Number(status),
                },
                subStatusDefinitionsDto: {
                    ...selectedAssignment.subStatusDefinitionsDto,
                    subStatusId: Number(subStatus),
                },
                proprietorMasterDto: {
                    ...selectedAssignment.proprietorMasterDto,
                    proprietorId: Number(proprietor),
                },
            };

            try {
                const response = await updateProprietorAssignment(selectedAssignment.proprietorMappingId, updatedAssignment);
                if (response.httpStatus === "OK") {
                    setStatus(""); setSubStatus(""); setProprietor("");
                    setSelectedTray(null);
                    setSelectedAssignment(null);
                    toast.success("Proprietor updated successfully!");
                    onClose()
                } else {
                    toast.error("Failed to update Proprietor.");
                }
            } catch (error) {
                toast.error("Failed to update Proprietor.");
            }
        } else {
            // Create new assignment
            if (status && subStatus && proprietor) {
                const selectedTrayId = trayList.find(tray => tray.trayName === selectedTray)?.trayId;
                const newAssignment = {
                    trayMasterDto: { trayId: selectedTrayId },
                    statusDefinitionsDto: { statusId: status },
                    subStatusDefinitionsDto: { subStatusId: subStatus },
                    proprietorMasterDto: { proprietorId: proprietor },
                    createdBy: Number(employee?.EmployeeNo),
                    isActive: 1,
                };

                try {
                    const savedRecord = await createProprietorAssignment(newAssignment);
                    if (savedRecord.httpStatus === "CREATED") {
                        toast.success("Proprietor Assignment saved successfully!");
                        setStatus(""); setSubStatus(""); setProprietor(""); setSelectedTray(null);
                        onClose()
                    } else {
                        toast.error("Error saving Proprietor Assignment Please try again!");
                    }
                } catch (error) {
                    toast.error("Error saving Proprietor Assignment Please try again!");
                }
            }
        }
    };

    const handleClear = () => {
        setSelectedTray(null);
        setSelectedStatus(null);
        setSelectedSubStatus(null);
        setProprietor("");
        setStatus("");
        setSubStatus("");
        setStatusList([]);
        setSubStatusList([]);
        setProprietorList([]);
        setSelectedAssignment(null);
    };

    if (!isOpen) return null;

    return (
        <Box sx={{ p: 3 }}>
            <Grid spacing={2}>
                <Grid item xs={12} md={4}>
                    <FormControl fullWidth sx={{ mb: 3 }}>
                        <InputLabel htmlFor="tray" shrink sx={{ fontSize: '0.875rem' }}>
                            Tray
                        </InputLabel>
                        <Select
                            labelId="tray-label"
                            label="Tray"
                            value={selectedTray || ''}
                            onChange={handleTrayChange}
                            name="trayMasterDto.trayId"
                            startAdornment={
                                <InputAdornment position="start">
                                    <TableRows />
                                </InputAdornment>
                            }
                            sx={{
                                '.MuiSelect-select': { py: 1.5, pl: 1 },
                                '.MuiOutlinedInput-notchedOutline': { borderColor: '#ced4da' },
                                '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: '#80bdff' },
                                '&.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#007bff', borderWidth: 2 },
                            }}
                        >
                            {Array.isArray(trayList) &&
                                trayList.map((tray) => (
                                    <MenuItem key={tray.trayId} value={tray.trayName}>
                                        {tray.trayName}
                                    </MenuItem>
                                ))}
                        </Select>
                    </FormControl>
                </Grid>

                <Grid item xs={12} md={4}>
                    <FormControl fullWidth sx={{ mb: 3 }}>
                        <InputLabel htmlFor="status" shrink sx={{ fontSize: '0.875rem' }}>
                            Status
                        </InputLabel>
                        <Select
                            labelId="status-label"
                            label="Status"
                            value={status || ''}
                            onChange={handleStatusChange}
                            name="statusDefinitionsDto.statusId"
                            disabled={!selectedTray}
                            startAdornment={
                                <InputAdornment position="start">
                                    <Label />
                                </InputAdornment>
                            }
                            sx={{
                                '.MuiSelect-select': { py: 1.5, pl: 1 },
                                '.MuiOutlinedInput-notchedOutline': { borderColor: '#ced4da' },
                                '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: '#80bdff' },
                                '&.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#007bff', borderWidth: 2 },
                            }}
                        >
                            {Array.isArray(statusList) &&
                                statusList.map((status) => (
                                    <MenuItem key={status.statusId} value={status.statusId}>
                                        {status.status}
                                    </MenuItem>
                                ))}
                        </Select>
                    </FormControl>
                </Grid>

                <Grid item xs={12} md={4}>
                    <FormControl fullWidth sx={{ mb: 3 }}>
                        <InputLabel htmlFor="subStatus" shrink sx={{ fontSize: '0.875rem' }}>
                            Sub-Status
                        </InputLabel>
                        <Select
                            labelId="substatus-label"
                            label="Sub-Status"
                            value={subStatus || ''}
                            onChange={handleSubStatusChange}
                            name="subStatusDefinitionsDto.subStatusId"
                            disabled={!selectedTray || !selectedStatus}
                            startAdornment={
                                <InputAdornment position="start">
                                    <SubdirectoryArrowRightIcon />
                                </InputAdornment>
                            }
                            sx={{
                                '.MuiSelect-select': { py: 1.5, pl: 1 },
                                '.MuiOutlinedInput-notchedOutline': { borderColor: '#ced4da' },
                                '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: '#80bdff' },
                                '&.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#007bff', borderWidth: 2 },
                            }}
                        >
                            {Array.isArray(subStatusList) &&
                                subStatusList.map((subStatus) => (
                                    <MenuItem key={subStatus.subStatusId} value={subStatus.subStatusId}>
                                        {subStatus.subStatus}
                                    </MenuItem>
                                ))}
                        </Select>
                    </FormControl>
                </Grid>

                <Grid item xs={12} md={4}>
                    <FormControl fullWidth sx={{ mb: 3 }}>
                        <InputLabel htmlFor="proprietor" shrink sx={{ fontSize: '0.875rem' }}>
                            Proprietor
                        </InputLabel>
                        <Select
                            labelId="proprietor-label"
                            label="Proprietor"
                            value={proprietor || ''}
                            onChange={(event: SelectChangeEvent<string>) => setProprietor(event.target.value)}
                            name="proprietorMasterDto.proprietorId"
                            disabled={!selectedTray || !selectedStatus || !selectedSubStatus}
                            startAdornment={
                                <InputAdornment position="start">
                                    <PersonIcon />
                                </InputAdornment>
                            }
                            sx={{
                                '.MuiSelect-select': { py: 1.5, pl: 1 },
                                '.MuiOutlinedInput-notchedOutline': { borderColor: '#ced4da' },
                                '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: '#80bdff' },
                                '&.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#007bff', borderWidth: 2 },
                            }}
                        >
                            {Array.isArray(proprietorList) &&
                                proprietorList.map((proprietor) => (
                                    <MenuItem key={proprietor.proprietorId} value={proprietor.proprietorId}>
                                        {proprietor.proprietorName}
                                    </MenuItem>
                                ))}
                        </Select>
                    </FormControl>
                </Grid>
            </Grid>

            <Box sx={{ display: "flex", justifyContent: "flex-end", mt: 1, gap: 1.5 }}>
                <Button variant="contained" onClick={handleSave}>
                    {mode === 'edit' ? 'Update' : 'Save'}
                </Button>
                <Button variant="outlined" color="warning" onClick={handleClear}>
                    Clear
                </Button>
            </Box>
            <ToastContainer />
        </Box>
    );
};

export default ProprietorMapping;