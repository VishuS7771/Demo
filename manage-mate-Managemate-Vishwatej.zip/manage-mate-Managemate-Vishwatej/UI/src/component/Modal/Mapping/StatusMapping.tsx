import React, { useEffect, useState } from "react";
import { toast } from "react-toastify";
import { addStatus, updateStatusMapping } from "../../../Requests/StatusMappingRequest";
import { getTrayList } from "../../../Requests/TaskRequest";
import { EmployeeData } from "../../../Interfaces/Login";
import { StatusDefinitionsDto, TrayMasterDto } from "../../../Interfaces/Task";
import {
    Box,
    Button,
    FormControl,
    InputLabel,
    MenuItem,
    Select,
    SelectChangeEvent,
    Stack,
    TextField,
    InputAdornment,
} from "@mui/material";
import { TableRows, Label } from "@mui/icons-material";

interface StatusMappingProps {
    isOpen: boolean;
    editData?: StatusDefinitionsDto;
    mode?: "add" | "edit";
    onClose: () => void;
}

const StatusMapping: React.FC<StatusMappingProps> = ({ isOpen, editData, mode = "add", onClose }) => {
    const [employee, setEmployee] = useState<EmployeeData | null>(null);
    const [trays, setTrayList] = useState<TrayMasterDto[]>([]);
    const [editMode, setEditMode] = useState<boolean>(false);
    const [status, setStatus] = useState<StatusDefinitionsDto>({
        statusId: 0,
        status: "",
        createdBy: 0,
        trayMasterDto: { trayId: 0, trayName: "", isActive: 1, createdBy: 0, createdOn: "" },
        createdOn: "",
        isActive: 1,
    });

    useEffect(() => {
        const storedData = localStorage.getItem("employeedata");
        if (storedData) {
            try {
                const parsedData = JSON.parse(storedData);
                setEmployee(parsedData);
                setStatus((prev) => ({
                    ...prev,
                    createdBy: parsedData.EmployeeNo,
                    isActive: parsedData.isActive || 1,
                }));
            } catch (error) {
                console.error("Error parsing employee data from localStorage:", error);
            }
        }
    }, []);

    useEffect(() => {
        if (isOpen) {
            getTrayList()
                .then((response) => {
                    setTrayList(response.data);
                })
                .catch((error) => console.error("Error fetching tray list:", error));
        }
    }, [isOpen]);

    useEffect(() => {
        if (mode === "edit" && editData) {
            setEditMode(true);
            setStatus(editData);
        } else {
            setEditMode(false);
        }
    }, [editData, mode]);

    const handleTrayChange = (event: SelectChangeEvent<number>) => {
        const trayId = Number(event.target.value);
        const selectedTray = trays.find((tray) => tray.trayId === trayId);
        if (selectedTray) {
            setStatus({
                ...status,
                trayMasterDto: selectedTray,
            });
        }
    };

    const onSave = async () => {
        if (!status.trayMasterDto.trayId) {
            toast.error("Please select a tray.");
            return;
        }

        const statusValue = status.status.trim();
        if (!statusValue) {
            toast.error("Status cannot be empty.");
            return;
        }

        if (/[^a-zA-Z\- ]/.test(statusValue)) {
            toast.error("Status can only contain letters, hyphens, and spaces.");
            return;
        }

        try {
            if (editMode && status.statusId) {
                const response = await updateStatusMapping(status.statusId, status);
                if (response.httpStatus === "OK") {
                    toast.success("Status Updated Successfully!");
                    setEditMode(false);
                    onClose();
                }
                else toast.error("Failed to Update Status");

            } else {
                const response = await addStatus(status);
                if (response.httpStatus === "OK") {
                    toast.success("Status Mapped Successfully!");
                    onClose();
                }
                else toast.error("Failed to Map Status");
            }

            handleClear();
        } catch {
            toast.error("Failed to save status. Please try again.");
        }
    };

    const handleClear = () => {
        setStatus({
            statusId: 0,
            status: "",
            createdBy: Number(employee?.EmployeeNo),
            trayMasterDto: { trayId: 0, trayName: "", isActive: 1, createdBy: 0, createdOn: "" },
            createdOn: "",
            isActive: 1,
        });
        setEditMode(false);
    };

    return (
        <Box>
            <Stack spacing={3} mt={1} p={2}>
                <FormControl fullWidth variant="outlined" size="small">
                    <InputLabel id="tray-label">Tray</InputLabel>
                    <Select
                        labelId="tray-label"
                        label="Tray"
                        value={status.trayMasterDto?.trayId || ""}
                        onChange={handleTrayChange}
                        startAdornment={
                            <InputAdornment position="start">
                                <TableRows />
                            </InputAdornment>
                        }
                    >
                        <MenuItem value="" disabled>
                            Select a Tray
                        </MenuItem>
                        {trays.map((tray) => (
                            <MenuItem key={tray.trayId} value={tray.trayId}>
                                {tray.trayName}
                            </MenuItem>
                        ))}
                    </Select>
                </FormControl>

                <TextField
                    fullWidth
                    label="Status"
                    value={status.status}
                    onChange={(e) => setStatus({ ...status, status: e.target.value })}
                    inputProps={{ maxLength: 50 }}
                    variant="outlined"
                    size="small"
                    InputProps={{
                        startAdornment: (
                            <InputAdornment position="start">
                                <Label />
                            </InputAdornment>
                        ),
                    }}
                />
            </Stack>

            <Box sx={{ display: "flex", justifyContent: "flex-end", mt: 1, gap: 1.5 }}>
                <Button variant="contained" onClick={onSave}>
                    {editMode ? "Update" : "Save"}
                </Button>
                <Button variant="outlined" color="warning" onClick={handleClear}>
                    Clear
                </Button>
            </Box>
        </Box>
    );
};

export default StatusMapping;