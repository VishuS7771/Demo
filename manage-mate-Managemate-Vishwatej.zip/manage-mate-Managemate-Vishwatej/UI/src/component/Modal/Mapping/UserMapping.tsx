import React, { useEffect, useState } from "react";
import { toast } from "react-toastify";
import {
    Autocomplete,
    Box,
    Button,
    FormControl,
    InputLabel,
    MenuItem,
    Select,
    Stack,
    TextField,
    InputAdornment,
} from "@mui/material";
import { Person, Group } from "@mui/icons-material";
import { getAllEmployees } from "../../../Requests/MeetingRequest";
import { StakeHolderManagementUser, StatusDefinitionsDto, User } from "../../../Interfaces/Task";
import { checkIfUserExists, createStakeholderManagementUser } from "../../../Requests/MenuPermission";

interface StatusMappingProps {
    isOpen: boolean;
    editData?: StatusDefinitionsDto;
    mode?: "add" | "edit";
    onClose: () => void;
}

const UserMappingModalForm: React.FC<StatusMappingProps> = ({ onClose }) => {
    const [btnLoading,setBtnLoading] = useState(false);
    const [employees, setEmployees] = useState<User[]>([]);
    const [selectedEmployee, setSelectedEmployee] = useState<User | null>(null);
    const [userType, setUserType] = useState<string>("");

    useEffect(() => {
        const fetchEmployees = async () => {
            setBtnLoading(true);
            try {
                const data = await getAllEmployees();
                setEmployees(data);
                setBtnLoading(false);
            } catch (error) {
                console.error("Error fetching employees:", error);
            }finally{
                setBtnLoading(false);
            }
        };
        fetchEmployees();
    }, []);

    const employeeOptions = employees.map((employee) => ({
        value: employee.employeeId.toString(),
        label: `${employee.employeeName} (${employee.employeeId})`,
    }));

    const userTypeOptions = [
        { value: "STAKEHOLDER", label: "STAKEHOLDER" },
        { value: "MANAGEMENT-USER", label: "MANAGEMENT" },
    ];

    const handleSave = async () => {
        if (!selectedEmployee || !userType) {
            toast.error("Please select an employee and user type.");
            return;
        }

        const newUser: StakeHolderManagementUser = {
            userId: Number(selectedEmployee.employeeId),
            userType,
            empName: selectedEmployee.employeeName,
            id: 0,
        };

        try {
            // Check if the user already exists
            const userExists = await checkIfUserExists(newUser);

            if (userExists.data.exists) {
                toast.error(`${userType} with userId ${newUser.userId} already exists.`);
                return; // Stop further processing if user exists
            } else {
                // Proceed with creating the new user if it doesn't exist
                if (userType === "STAKEHOLDER") {
                    await createStakeholderManagementUser(newUser);
                    toast.success("Stakeholder mapped successfully.");
                    onClose();
                } else if (userType === "MANAGEMENT-USER") {
                    await createStakeholderManagementUser(newUser);
                    toast.success("Management User mapped successfully.");
                    onClose();
                } else {
                    toast.error("Invalid user type.");
                    return;
                }
            }
            setUserType("");
            setSelectedEmployee(null);
        } catch (error) {
            console.error("Error mapping user:", error);
            toast.error("Failed to map user.");
        }
    };

    const handleClear = () => {
        setUserType("");
        setSelectedEmployee(null);
    };

    return (
        <Box>
            <Stack spacing={3} mt={1} p={2}>
                <FormControl fullWidth size="small" sx={{ mb: 2 }}>
                    <Autocomplete
                        size="small"
                        fullWidth
                        loading={btnLoading}
                        options={employeeOptions}
                        getOptionLabel={(option) => option.label}
                        value={
                            selectedEmployee
                                ? employeeOptions.find((opt) => opt.value === selectedEmployee.employeeId.toString())
                                : null
                        }
                        onChange={(_, newValue) => {
                            const selected = employees.find((emp) => emp.employeeId.toString() === newValue?.value);
                            setSelectedEmployee(selected || null);
                        }}
                        renderInput={(params) => (
                            <TextField
                                {...params}
                                label="Employee"
                                InputProps={{
                                    ...params.InputProps,
                                    startAdornment: (
                                        <>
                                            <InputAdornment position="start">
                                                <Person />
                                            </InputAdornment>
                                            {params.InputProps.startAdornment}
                                        </>
                                    ),
                                }}
                            />
                        )}
                        isOptionEqualToValue={(option, value) => option.value === value.value}
                    />
                </FormControl>

                <FormControl fullWidth size="small">
                    <InputLabel id="user-type-label">User Type</InputLabel>
                    <Select
                        labelId="user-type-label"
                        value={userType}
                        label="User Type"
                        onChange={(e) => setUserType(e.target.value)}
                        startAdornment={
                            <InputAdornment position="start">
                                <Group />
                            </InputAdornment>
                        }
                    >
                        {userTypeOptions.map((opt) => (
                            <MenuItem key={opt.value} value={opt.value}>
                                {opt.label}
                            </MenuItem>
                        ))}
                    </Select>
                </FormControl>
            </Stack>

            <Box sx={{ display: "flex", justifyContent: "flex-end", mt: 1, gap: 1.5 }}>
                <Button variant="contained" color="primary" onClick={handleSave}>
                    Save
                </Button>
                <Button variant="outlined" color="warning" onClick={handleClear}>
                    Clear
                </Button>
            </Box>
        </Box>
    );
};

export default UserMappingModalForm;