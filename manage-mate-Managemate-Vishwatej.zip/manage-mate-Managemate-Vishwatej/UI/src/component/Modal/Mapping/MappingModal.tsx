import React from "react";
import {
    Dialog,
    DialogTitle,
    DialogContent,
    IconButton,
    Divider,
} from "@mui/material";
import { Clear } from "@mui/icons-material";

interface MappingModalProps {
    isVisible: boolean;
    onClose: () => void;
    children?: React.ReactNode;
    title: String
}

const MappingModal: React.FC<MappingModalProps> = ({
    isVisible,
    onClose,
    children,
    title
}) => {
    return (
        <Dialog
            open={isVisible}
            onClose={onClose}
            maxWidth="sm"
            fullWidth
            PaperProps={{
                style: { borderRadius: "10px" },
            }}
        >
            <DialogTitle
                sx={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    padding: "16px 24px",
                }}
            >
              {title}
                <IconButton onClick={onClose}
                    sx={{
                        color: "grey.500",
                        ":hover": {
                            color: "red",
                        }
                    }}
                >
                    <Clear fontSize="inherit" />
                </IconButton>
            </DialogTitle>
            <Divider sx={{ height: 1, backgroundColor: '#4a4848'}}/>
            <DialogContent sx={{ backgroundColor: "", padding: "0px 32px 32px 32px" }}>
                {children}
                
            </DialogContent>
        </Dialog>
    );
};

export default MappingModal;
