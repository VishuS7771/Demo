import React, { useEffect, useState } from "react";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { Box, Button, FormControl, InputLabel, MenuItem, Select as MuiSelect, InputAdornment, TextField, Autocomplete } from "@mui/material";
import { SelectChangeEvent } from "@mui/material";
import InventoryIcon from '@mui/icons-material/Inventory';
import PersonIcon from '@mui/icons-material/Person';
import { usePageLoader } from "../../../context/PageLoaderContext";
import { ModuleAssignmentDto } from "../../../Interfaces/Module";
import { Modules, User } from "../../../Interfaces/Task";
import { addModule, updateModuleMapping } from "../../../Requests/TaskRequest";

interface ModuleMappingFormProps {
    isOpen: boolean;
    editData?: ModuleAssignmentDto | null;
    mode?: "add" | "edit";
    onClose: () => void;
    onSave: (updatedAssignment: ModuleAssignmentDto | null, isNew: boolean) => void;
    modules: Modules[];
    employees: User[];
    empId: number | null;
}

const ModuleMapping: React.FC<ModuleMappingFormProps> = ({
    isOpen,
    editData,
    mode = "add",
    onClose,
    onSave,
    modules,
    employees,
    empId,
}) => {
    const { showLoader, hideLoader } = usePageLoader();
    const [selectedModule, setSelectedModule] = useState<number | "">("");
    const [selectedEmployee, setSelectedEmployee] = useState<User | null>(null);

    const employeeOptions = employees.map((employee) => ({
        value: employee.employeeId.toString(),
        label: `${employee.employeeName} (${employee.employeeId})`,
    }));

    useEffect(() => {
        if (editData && mode === "edit") {
            setSelectedModule(editData.moduleId);
            setSelectedEmployee(employees.find((e) => Number(e.employeeId) === editData.employeeId) || null);
        } else {
            setSelectedModule("");
            setSelectedEmployee(null);
        }
    }, [editData, mode, employees]);

    const handleModuleChange = (e: SelectChangeEvent<number>) => {
        setSelectedModule(Number(e.target.value));
    };

    const handleEmployeeSelect = (_: React.SyntheticEvent, newValue: { value: string; label: string } | null) => {
        const employee = employees.find((e) => Number(e.employeeId) === Number(newValue?.value)) || null;
        setSelectedEmployee(employee);
    };

    const handleSave = async (event: React.MouseEvent<HTMLButtonElement>) => {
        event.preventDefault();

        if (!selectedModule || !selectedEmployee) {
            if (!selectedModule) {
                toast.error("Please select a module.");
            }
            if (!selectedEmployee) {
                toast.error("Please select an employee.");
            }
            return;
        }

        const selectedModuleData = modules.find((module) => module.id === selectedModule);
        if (!selectedModuleData) {
            toast.error("Invalid module selected.");
            return;
        }

        const moduleAssignmentDto: ModuleAssignmentDto = {
            moduleMappingId: editData?.moduleMappingId || 0,
            module: selectedModuleData.moduleName,
            moduleId: selectedModuleData.id,
            employeeId: Number(selectedEmployee.employeeId),
            isActive: 1,
            createdBy: Number(empId),
            createdOn: "",
            mappedEmployee: selectedEmployee.employeeName,
        };

        try {
            if (mode === "edit" && moduleAssignmentDto.moduleMappingId) {
                showLoader();
                const response = await updateModuleMapping(moduleAssignmentDto.moduleMappingId, moduleAssignmentDto);
                if (response.httpStatus === "OK") {
                    onSave(moduleAssignmentDto, false);
                    toast.success("Module mapping updated successfully.");
                    onClose()
                } else {
                    toast.error("Failed to update module mapping.");
                }
            } else {
                showLoader();
                const response = await addModule(moduleAssignmentDto);
                if (response.httpStatus === "CREATED") {
                    onSave(response.data, true);
                    toast.success("Module mapping saved successfully.");
                    onClose()
                } else {
                    toast.error("Failed to save module mapping.");
                }
            }
            setSelectedModule("");
            setSelectedEmployee(null);
        } catch (error) {
            console.error("Error saving module mapping:", error);
            toast.error("An error occurred while saving module mapping.");
        } finally {
            hideLoader();
        }
    };

    const handleClear = () => {
        setSelectedModule("");
        setSelectedEmployee(null);
    };

    if (!isOpen) return null;

    return (
        <Box sx={{ p: 3 }}>
            <Box>
                <FormControl fullWidth sx={{ mb: 2 }}>
                    <InputLabel htmlFor="module" shrink sx={{ fontSize: "0.875rem" }}>
                        Module
                    </InputLabel>
                    <MuiSelect
                        labelId="module-label"
                        label="Module"
                        value={selectedModule}
                        onChange={handleModuleChange}
                        name="moduleId"
                        startAdornment={
                            <InputAdornment position="start">
                                <InventoryIcon />
                            </InputAdornment>
                        }
                        MenuProps={{
                            disablePortal: true, 
                            PaperProps: {
                                style: {
                                    maxHeight: 300,
                                    overflowY: 'auto',
                                },
                            },
                        }}
                        sx={{
                            ".MuiSelect-select": { py: 1.5, pl: 4 },
                            ".MuiOutlinedInput-notchedOutline": { borderColor: "#ced4da" },
                            "&:hover .MuiOutlinedInput-notchedOutline": { borderColor: "#80bdff" },
                            "&.Mui-focused .MuiOutlinedInput-notchedOutline": { borderColor: "#007bff", borderWidth: 2 },
                        }}
                    >
                        <MenuItem value="">
                            <em>Select Module</em>
                        </MenuItem>
                        {modules.map((module) => (
                            <MenuItem key={module.id} value={module.id}>
                                {module.moduleName}
                            </MenuItem>
                        ))}
                    </MuiSelect>
                </FormControl>
                <FormControl fullWidth size="small" sx={{ mb: 2 }}>
                    <Autocomplete
                        size="small"
                        fullWidth
                        options={employeeOptions}
                        getOptionLabel={(option) => option.label}
                        value={
                            selectedEmployee
                                ? employeeOptions.find((opt) => opt.value === selectedEmployee.employeeId.toString())
                                : null
                        }
                        onChange={handleEmployeeSelect}
                        renderInput={(params) => (
                            <TextField
                                {...params}
                                label="Employee"
                                InputProps={{
                                    ...params.InputProps,
                                    startAdornment: (
                                        <>
                                            <InputAdornment position="start">
                                                <PersonIcon />
                                            </InputAdornment>
                                            {params.InputProps.startAdornment}
                                        </>
                                    ),
                                }}
                            />
                        )}
                        isOptionEqualToValue={(option, value) => option.value === value.value}
                    />
                </FormControl>
            </Box>
            <Box sx={{ display: "flex", justifyContent: "flex-end", mt: 1, gap: 1.5 }}>
                <Button variant="contained" onClick={handleSave}>
                    {mode === 'edit' ? 'Update' : 'Save'}
                </Button>
                <Button variant="outlined" color="warning" onClick={handleClear}>
                    Clear
                </Button>
            </Box>
        </Box>
    );
};

export default ModuleMapping;