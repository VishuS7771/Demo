import React, { useState, useRef, FormEvent, useEffect } from "react";
import { addSubTask, updateSubTask } from "../../../Requests/TaskRequest";
import { Task, User, createTask } from "../../../Interfaces/Task";
import { EmployeeData } from "../../../Interfaces/Login";
import {
    Box,
    Button,
    Grid,
    TextField,
    MenuItem,
    Typography,
    Modal,
    InputAdornment,
    IconButton,
} from "@mui/material";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import {
    DateRange,
    Save,
    Refresh,
    LowPriorityOutlined,
    DescriptionOutlined,
    Person2Outlined,
    AssignmentIndOutlined,
    Upload,
    Clear,
} from "@mui/icons-material";
import { toast } from "react-toastify";

interface SubTaskModalProps {
    isVisible: boolean;
    onClose: () => void;
    task: Partial<Task>;
    setTask: React.Dispatch<React.SetStateAction<Partial<Task>>>;
    userList: User[];
    employee: EmployeeData | null;
    parentTaskId: string | undefined;
    fetchTasks: () => Promise<void>;
}

const SubTaskModal: React.FC<SubTaskModalProps> = ({
    isVisible,
    onClose,
    task,
    setTask,
    userList,
    employee,
    parentTaskId,
    fetchTasks,
}) => {
    const [selectedUser, setSelectedUser] = useState<string>("");
    const fileInputRef = useRef<HTMLInputElement | null>(null);
    const [file, setFile] = useState<File | null>(null);
    const [fileName, setFileName] = useState<string>("");
    const [errors, setErrors] = useState<{ [key: string]: string }>({});
    const [openDatePicker, setOpenDatePicker] = useState(false);

    useEffect(() => {
        if (task.assignedTo) {
            setSelectedUser(task.assignedTo.toString());
        } else {
            setSelectedUser("");
        }
    }, [task.assignedTo]);

    const handleChange = (
        e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
    ) => {
        const { name, value } = e.target;
        setTask((prevTask) => ({ ...prevTask, [name]: value }));
        setErrors((prevErrors) => ({ ...prevErrors, [name]: "" }));
    };

    const handleDateChange = (date: any) => {
        if (date) {
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            if (date < today) {
                setErrors((prevErrors) => ({
                    ...prevErrors,
                    date: "Past Date is not allowed.",
                }));
                return;
            }
            setTask((prevTask) => ({
                ...prevTask,
                tentativeEndDate: date,
            }));
            setErrors((prevErrors) => ({ ...prevErrors, date: "" }));
        } else {
            setTask((prevTask) => ({
                ...prevTask,
                tentativeEndDate: null,
            }));
        }
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files.length > 0) {
            const selectedFile = e.target.files[0];
            setFile(selectedFile);
            setFileName(selectedFile.name);
        }
    };

    const handleClearFile = () => {
        setFile(null);
        setFileName("");
        if (fileInputRef.current) {
            fileInputRef.current.value = "";
        }
    };

    const handleUserSelection = (empId: string) => {
        setSelectedUser(empId);
        setTask((prevTask) => ({ ...prevTask, assignedTo: Number(empId) }));
        setErrors((prevErrors) => ({ ...prevErrors, assignedTo: "" }));
    };

    const validateForm = (): boolean => {
        const newErrors: { [key: string]: string } = {};

        if (!task.taskName?.trim()) {
            newErrors.taskName = "Sub Task Name is required";
        }
        if (!task.description?.trim()) {
            newErrors.description = "Description is required";
        }
        if (!task.taskPriority) {
            newErrors.taskPriority = "Sub-Task Priority is required";
        }
        if (!selectedUser) {
            newErrors.assignedTo = "Assign To is required";
        }

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e: FormEvent) => {
        e.preventDefault();
        if (!validateForm()) {
            toast.info("Please fill all required fields.");
            return;
        }
        const numericParentTaskId = parentTaskId ? parseInt(parentTaskId, 10) : 0;
        try {
            if (task.id) {
                const response = await updateSubTask(task, task.id);
                if (response.data.httpStatus === "OK") {
                    toast.success("Sub Task updated successfully!");
                    setSelectedUser("");
                    if (employee) setTask(createTask(employee));
                    fetchTasks();
                } else {
                    toast.error(`${response.data.message}`);
                }
            } else {
                const response = await addSubTask(task, file, numericParentTaskId);
                if (response.data.httpStatus === "OK") {
                    toast.success("Sub Task added successfully!");
                    if (employee) setTask(createTask(employee));
                    setSelectedUser("");
                    fetchTasks();
                } else {
                    toast.error(`Error: ${response.data.message}`);
                }
            }
            handleClearFile();
            onClose();
        } catch (error) {
            console.error("Error adding/updating task:", error);
            toast.error(`Error: ${error}`);
        }
    };

    const handleReset = () => {
        if (employee) setTask(createTask(employee));
        setSelectedUser("");
        handleClearFile();
        setErrors({});
        setOpenDatePicker(false);
    };

    return (
        <Modal
            open={isVisible}
            onClose={onClose}
            aria-labelledby="subtask-modal-title"
            aria-describedby="subtask-modal-description"
        >
            <Box
                sx={{
                    position: "absolute",
                    top: "50%",
                    left: "50%",
                    transform: "translate(-50%, -50%)",
                    width: { xs: "90%", sm: "80%", md: "70%", lg: 1000 },
                    maxWidth: "95vw",
                    bgcolor: "background.paper",
                    boxShadow: 24,
                    borderRadius: "10px",
                    maxHeight: "90vh",
                    overflowY: "auto",
                }}
            >
                <Box
                    sx={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        p: { xs: 2, sm: 2 },
                        borderBottom: 1,
                        borderColor: 'rgb(73, 102, 131)',
                    }}
                >
                    <Typography
                        id="subtask-modal-title"
                        variant="h5"
                        sx={{
                            fontWeight: "bold",
                        }}
                    >
                        {task.id ? "Edit Sub-Task" : "Add Sub-Task"}
                    </Typography>

                    <IconButton
                        onClick={onClose}
                        sx={{
                            color: "grey.500",
                            ":hover": {
                                color: "red",
                            },
                        }}
                    >
                        <Clear />
                    </IconButton>
                </Box>
                    <Box
                        component="form"
                        onSubmit={handleSubmit}
                        sx={{ padding: "40px 110px 40px 110px" }}
                        mt={2}
                    >
                        <Grid container spacing={{ xs: 2, sm: 3, md: 4, lg: 5 }}>
                            <Grid item xs={12} sm={6} minWidth={"400px"}>
                                <TextField
                                    fullWidth
                                    label="Sub Task Name"
                                    name="taskName"
                                    placeholder="SubTask Name"
                                    value={task.taskName || ""}
                                    onChange={handleChange}
                                    variant="outlined"
                                    error={!!errors.taskName}
                                    helperText={
                                        errors.taskName ||
                                        `${task.taskName?.length || 0} / 100 characters used`
                                    }
                                    slotProps={{
                                        input: {
                                            startAdornment: (
                                                <InputAdornment position="start">
                                                    <AssignmentIndOutlined />
                                                </InputAdornment>
                                            ),
                                            inputProps: { maxLength: 100 },
                                        },
                                    }}
                                    sx={{
                                        "& .MuiInputBase-root": {
                                            fontSize: { xs: "0.875rem", sm: "1rem" },
                                        },
                                    }}
                                />
                            </Grid>
                            <Grid item xs={12} sm={6} minWidth={"400px"}>
                                <TextField
                                    select
                                    fullWidth
                                    label="Sub-Task Priority"
                                    name="taskPriority"
                                    value={task.taskPriority || ""}
                                    onChange={handleChange}
                                    variant="outlined"
                                    error={!!errors.taskPriority}
                                    helperText={errors.taskPriority}
                                    slotProps={{
                                        input: {
                                            startAdornment: (
                                                <InputAdornment position="start">
                                                    <LowPriorityOutlined />
                                                </InputAdornment>
                                            ),
                                        },
                                    }}
                                    sx={{
                                        "& .MuiInputBase-root": {
                                            fontSize: { xs: "0.875rem", sm: "1rem" },
                                        },
                                    }}
                                >
                                    <MenuItem value="">
                                        <em>Select Sub-Task Priority</em>
                                    </MenuItem>
                                    <MenuItem value="High">High</MenuItem>
                                    <MenuItem value="Medium">Medium</MenuItem>
                                    <MenuItem value="Low">Low</MenuItem>
                                    <MenuItem value="Critical">Critical</MenuItem>
                                </TextField>
                            </Grid>
                            <Grid item xs={12} sm={6} minWidth={"400px"}>
                                <TextField
                                    select
                                    fullWidth
                                    label="Assign To"
                                    value={selectedUser}
                                    onChange={(e) => handleUserSelection(e.target.value)}
                                    variant="outlined"
                                    error={!!errors.assignedTo}
                                    helperText={errors.assignedTo}
                                    slotProps={{
                                        input: {
                                            startAdornment: (
                                                <InputAdornment position="start">
                                                    <Person2Outlined />
                                                </InputAdornment>
                                            ),
                                        },
                                    }}
                                    SelectProps={{
                                        MenuProps: {
                                            disablePortal: false,
                                            PaperProps: {
                                                sx: {
                                                    maxHeight: 300,
                                                    maxWidth: "90vw",
                                                },
                                            },
                                        },
                                    }}
                                    sx={{
                                        "& .MuiInputBase-root": {
                                            fontSize: { xs: "0.875rem", sm: "1rem" },
                                        },
                                    }}
                                >
                                    <MenuItem value="" disabled>
                                        Select a User
                                    </MenuItem>
                                    {userList.map((user) => (
                                        <MenuItem key={user.employeeId} value={user.employeeId}>
                                            {user.employeeName}
                                        </MenuItem>
                                    ))}
                                </TextField>
                            </Grid>
                            <Grid item xs={12} sm={6} minWidth={"400px"}>
                                <DatePicker
                                    open={openDatePicker}
                                    onOpen={() => setOpenDatePicker(true)}
                                    onClose={() => setOpenDatePicker(false)}
                                    label="Tentative End Date"
                                    value={task.tentativeEndDate ? new Date(task.tentativeEndDate) : null}
                                    onChange={handleDateChange}
                                    format="dd/MM/yyyy"
                                    slotProps={{
                                        textField: {
                                            fullWidth: true,
                                            variant: "outlined",
                                            error: !!errors.date,
                                            helperText: errors.date,
                                            InputProps: {
                                                startAdornment: (
                                                    <InputAdornment position="start">
                                                        <IconButton onClick={() => setOpenDatePicker(true)}>
                                                            <DateRange />
                                                        </IconButton>
                                                    </InputAdornment>
                                                ),
                                                endAdornment: <></>,
                                            },
                                            sx: {
                                                "& .MuiInputBase-root": {
                                                    fontSize: { xs: "0.875rem", sm: "1rem" },
                                                },
                                            },
                                        },
                                    }}
                                    minDate={new Date()}
                                />
                            </Grid>
                            <Grid item xs={12} sm={6} minWidth={"400px"} mt={-2}>
                                <Typography
                                    variant="subtitle2"
                                    sx={{
                                        color: "text.secondary",
                                        fontSize: { xs: "0.75rem", sm: "0.875rem" },
                                        mb: 1,
                                    }}
                                >
                                    Add Attachment
                                </Typography>
                                <Box display="flex" alignItems="center" gap={2}>
                                    <Button
                                        variant="outlined"
                                        color="primary"
                                        startIcon={<Upload />}
                                        onClick={() => fileInputRef.current?.click()}
                                        sx={{ borderRadius: "8px", textTransform: "none" }}
                                    >
                                        Choose File
                                    </Button>
                                    <Typography
                                        variant="body2"
                                        color={fileName ? "textPrimary" : "textSecondary"}
                                    >
                                        {fileName || "No file chosen"}
                                    </Typography>
                                    {fileName && (
                                        <IconButton
                                            onClick={handleClearFile}
                                            sx={{ color: "grey.600" }}
                                            title="Clear File"
                                        >
                                            <Clear />
                                        </IconButton>
                                    )}
                                    <input
                                        type="file"
                                        name="attachmentPath"
                                        onChange={handleFileChange}
                                        ref={fileInputRef}
                                        style={{ display: "none" }}
                                    />
                                </Box>
                            </Grid>
                            <Grid item xs={12} sm={6} minWidth={"400px"}>
                                <TextField
                                    fullWidth
                                    label="Description"
                                    name="description"
                                    placeholder="Description"
                                    value={task.description || ""}
                                    onChange={handleChange}
                                    variant="outlined"
                                    multiline
                                    maxRows={5}
                                    error={!!errors.description}
                                    helperText={
                                        errors.description ||
                                        `${task.description?.length || 0} / 5000 characters used`
                                    }
                                    slotProps={{
                                        input: {
                                            startAdornment: (
                                                <InputAdornment position="start">
                                                    <DescriptionOutlined />
                                                </InputAdornment>
                                            ),
                                            inputProps: { maxLength: 5000 },
                                        },
                                    }}
                                    sx={{
                                        "& .MuiInputBase-root": {
                                            fontSize: { xs: "0.875rem", sm: "1rem" },
                                            resize: "vertical",
                                            minHeight: "56px",
                                        },
                                        "& .MuiInputBase-input": {
                                            overflow: "auto",
                                        },
                                    }}
                                />
                            </Grid>
                            <Grid item xs={12} sm={12} minWidth={"400px"} mt={-2}>
                                <Box
                                    sx={{
                                        display: "flex",
                                        justifyContent: { xs: "center", sm: "flex-end" },
                                        gap: 2,
                                        flexWrap: "wrap",
                                    }}
                                >
                                    <Button
                                        type="submit"
                                        variant="contained"
                                        color="primary"
                                        startIcon={<Save />}
                                        sx={{
                                            px: { xs: 2, sm: 3 },
                                            py: 1,
                                            fontSize: { xs: "0.75rem", sm: "0.875rem" },
                                            textTransform: "none",
                                            minWidth: { xs: "120px", sm: "140px" },
                                        }}
                                    >
                                        {task.id ? "Update Sub-Task" : "Add Sub-Task"}
                                    </Button>
                                    <Button
                                        type="button"
                                        variant="outlined"
                                        color="error"
                                        startIcon={<Refresh />}
                                        onClick={handleReset}
                                        sx={{
                                            px: { xs: 2, sm: 3 },
                                            py: 1,
                                            fontSize: { xs: "0.75rem", sm: "0.875rem" },
                                            textTransform: "none",
                                            minWidth: { xs: "120px", sm: "140px" },
                                        }}
                                    >
                                        Clear
                                    </Button>
                                </Box>
                            </Grid>
                        </Grid>
                    </Box>
            </Box>
        </Modal>
    );
};

export default SubTaskModal;