import React, { useState, useEffect, useRef } from "react";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import {
  Box, Button, Grid, TextField, Typography, Modal, InputAdornment, IconButton, Autocomplete, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Tooltip, Paper, MenuItem,
} from "@mui/material";
import {
  Save,
  Clear,
  DescriptionOutlined,
  PeopleOutline,
  Upload,
  Edit,
  Delete,
  EventOutlined,
} from "@mui/icons-material";
import { DatePicker } from "@mui/x-date-pickers";
import { getAllEmployees } from "../../../Requests/MeetingRequest";
import { getGeneralMeetingTasks, markStatus } from "../../../Requests/GeneralMeetingRequest";
import { EmployeeOption, GeneralMeetingsDto, GeneralMeetingTaskDto, TaskValidationError, ValidationError } from "../../../Interfaces/Generalmeeting";
import { validateForm, validateTask } from "../../../util/validations/generalMeeting";
import { cancelledtaskStatuses, closedtaskStatuses, completedtaskStatuses, defaultTask, statuses } from "../../../util/constants/generalMeeting";
import moment from "moment";

interface MeetingStatusUIPopupProps {
  onClose: () => void;
  meetingData: GeneralMeetingsDto | null;
  toast: typeof toast;
}

const GeneralMeetingStatusUI: React.FC<MeetingStatusUIPopupProps> = ({ onClose, meetingData, toast }) => {
  const [taskStatuses, setTaskStatuses] = useState<string[]>([]);
  const employeeNo = localStorage.getItem("employeeNo") || "";
  const [status, setStatus] = useState<string>(meetingData?.meetingStatus || "Pending");
  const [statusWarning, setStatusWarning] = useState<string>("");
  const [reasonForCancellation, setReasonForCancellation] = useState<string>(meetingData?.reasonForCancellation || "");
  const [mom, setMom] = useState<string>(meetingData?.mom || "");
  const [employees, setEmployees] = useState<EmployeeOption[]>([]);
  const [selectedEmployees, setSelectedEmployees] = useState<EmployeeOption[]>([]);
  const [errors, setErrors] = useState<ValidationError>({});
  const [taskErrors, setTaskErrors] = useState<TaskValidationError>({});
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const [fileName, setFileName] = useState<string>("");
  const [tasks, setTasks] = useState<GeneralMeetingTaskDto[]>([]);
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [attendiesLoading, setAttendiesLoading] = useState<boolean>(false);
  const [task, setTask] = useState<GeneralMeetingTaskDto>({ ...defaultTask, createdBy: employeeNo });
  const [tasksData, setTasksData] = useState<GeneralMeetingTaskDto[]>([]);
  const [openDatePicker, setOpenDatePicker] = useState(false);

  const handleEmployeeSelection = (newValue: EmployeeOption[]) => {
    setTask({ ...task, employeeIds: newValue.map(option => option.value) });
    setTaskErrors((prev) => ({ ...prev, employeeIds: "" }));
  };

  const handleTaskChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTask({ ...task, [e.target.name]: e.target.value });
    setTaskErrors((prev) => ({ ...prev, [e.target.name]: "" }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const selectedFile = e.target.files[0];
      setFile(selectedFile);
      setFileName(selectedFile.name);
    }
  };

  const handleClearFile = () => {
    setFile(null);
    setFileName("");
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleAttendeesChange = (newValue: EmployeeOption[]) => {
    setSelectedEmployees(newValue);
    setErrors((prev) => ({ ...prev, participants: "" }));
  };

  const handleAddOrUpdateTask = () => {
    const isValid = validateTask(task, setTaskErrors);
    if (!isValid) return;
    setTasks((prevTasks) => {
      if (editingIndex !== null) {
        const updatedTasks = [...prevTasks];
        updatedTasks[editingIndex] = task;
        return updatedTasks;
      } else {
        return [...prevTasks, task];
      }
    });
    setTask({ ...defaultTask, createdBy: employeeNo });
    setEditingIndex(null);
    setTaskErrors({});
  };

  const handleEditTask = (index: number) => {
    setTask(tasks[index]);
    setEditingIndex(index);
  };

  const handleDeleteTask = (index: number) => {
    setTasks(tasks.filter((_, i) => i !== index));
  };

  const getEmployeeLabels = (employeeIds: number[]): string => {
    const employeeMap = new Map(employees.map(emp => [emp.value, emp.label]));
    return employeeIds.map(id => employeeMap.get(id) || id).join(", ");
  };

  const handleDateChange = (date: any) => {
    if (date) {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      if (date < today) {
        setTaskErrors((prev) => ({
          ...prev,
          targetDate: "Past dates are not allowed.",
        }));
        return;
      }
      const formattedDate = moment(date).format("YYYY-MM-DD");
      setTask({ ...task, targetDate: formattedDate });
      setTaskErrors((prev) => ({ ...prev, targetDate: "" }));
    } else {
      setTask({ ...task, targetDate: "" });
    }
  };

  useEffect(() => {
    const fetchMeetingTasks = async () => {
      if (meetingData?.id) {
        try {
          const data = await getGeneralMeetingTasks(meetingData.id);
          setTasksData(data || []);
        } catch (error) {
          console.error("Error fetching tasks:", error);
        }
      }
    };
    fetchMeetingTasks();
  }, [meetingData?.id]);

  const handleSubmit = async () => {
    if (meetingData?.meetingStatus && status === meetingData.meetingStatus) {
      setStatusWarning(`"${status}" status is already marked`);
      return;
    }

    if (status === "Closed") {
      const incompleteTasks = tasksData.filter(task => task.status !== "Completed");
      if (incompleteTasks.length > 0) {
        toast.error("Cannot mark meeting as 'Closed' until all tasks are marked 'Completed'.");
        return;
      }
    }

    if (!validateForm({ status, selectedEmployees, reasonForCancellation, mom, setErrors })) {
      return;
    }

    try {
      const employeeIdNumbers = selectedEmployees.map(emp => Number(emp.value));
      const taskEmployeeIds = tasks.map(task => ({
        ...task,
        employeeIds: task.employeeIds,
        targetDate: task.targetDate ? moment(task.targetDate).format("YYYY-MM-DD") : "",
      }));
      const meetingStatusObj = {
        status,
        generalMeetingId: meetingData?.id || 0,
        mom,
        reasonForCancellation,
        employeeIds: employeeIdNumbers,
        markedBy: employeeNo || 0,
        generalMeetingTaskDto: taskEmployeeIds,
      };
      const response = await markStatus(meetingStatusObj, file);
      if (response.httpStatus === "OK") {
        toast.success("Meeting Status Updated Successfully!");
        setTask({ ...defaultTask, createdBy: employeeNo });
        setEditingIndex(null);
        setTasks([]);
        setFile(null);
        setFileName("");
        setMom("");
        setStatus("");
        setSelectedEmployees([]);
        setStatusWarning("");
        onClose();
      } else {
        toast.error("Failed to update meeting status");
      }
    } catch (error) {
      toast.error("Failed to update meeting status");
    }
    setSelectedEmployees([]);
  };

  useEffect(() => {
    if (employees.length === 0) {
      const fetchEmployees = async () => {
        try {
          setAttendiesLoading(true);
          const data = await getAllEmployees();
          const employeeOptions = data.map((employee: { employeeId: number; employeeFullName: string }) => ({
            value: employee.employeeId,
            label: employee.employeeFullName,
          }));

          const selectedEmployeeOptions = data
            .filter((employee: { employeeId: number }) =>
              meetingData?.meetingParticipantsDtoList?.some(
                (participant: { employeeId: number }) => participant.employeeId == employee.employeeId
              )
            )
            .map((employee: { employeeId: number; employeeFullName: string }) => ({
              value: employee.employeeId,
              label: employee.employeeFullName,
            }));
          setEmployees(employeeOptions);
          setSelectedEmployees(selectedEmployeeOptions);
        } catch (error) {
          console.error("Error fetching employees:", error);
        } finally {
          setAttendiesLoading(false);
        }
      };
      fetchEmployees();
    }
    if (meetingData?.meetingStatus === "Completed") {
      setTaskStatuses(completedtaskStatuses);
    } else if (meetingData?.meetingStatus === "Closed") {
      setTaskStatuses(closedtaskStatuses);
    } else if (meetingData?.meetingStatus === "Cancelled") {
      setTaskStatuses(cancelledtaskStatuses);
    } else {
      setTaskStatuses(statuses);
    }
  }, [employees.length, meetingData]);

  const isCompleted = meetingData?.meetingStatus === "Completed";

  return (
    <>
      <ToastContainer />
      <Modal
        open={true}
        onClose={onClose}
        aria-labelledby="meeting-status-modal-title"
        aria-describedby="meeting-status-modal-description"
      >
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            width: { xs: "90%", sm: "80%", md: "70%", lg: 1000 },
            maxWidth: "95vw",
            bgcolor: "background.paper",
            boxShadow: 24,
            borderRadius: "10px",
            maxHeight: "90vh",
            overflowY: "auto",
          }}
        >
          <Box
            sx={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              p: { xs: 2, sm: 2 },
              borderBottom: 1,
              borderColor: 'rgb(73, 102, 131)',
              position: "sticky",
              top: 0,
              zIndex: 1000,
              bgcolor: "background.paper",
            }}
          >
            <Typography
              id="meeting-status-modal-title"
              variant="h5"
              sx={{ fontWeight: "bold" }}
            >
              General Meeting Status
            </Typography>
            <IconButton
              onClick={onClose}
              sx={{
                color: "grey.500",
                ":hover": { color: "red" },
              }}
            >
              <Clear />
            </IconButton>
          </Box>
          <Box
            component="form"
            sx={{ padding: { xs: "20px", sm: "30px 50px" } }}
            mt={2}
          >
            <Grid container spacing={{ xs: 2, sm: 3, md: 4, lg: 5 }}>
              <Grid item xs={12} minWidth="400px">
                <TextField
                  select
                  fullWidth
                  label="Status"
                  value={status}
                  onChange={(e) => {
                    setStatus(e.target.value);
                    setErrors((prev) => ({ ...prev, status: "" }));
                    setStatusWarning("");
                  }}
                  variant="outlined"
                  error={!!errors.status || !!statusWarning}
                  helperText={errors.status || statusWarning}
                  slotProps={{
                    input: {
                      startAdornment: (
                        <InputAdornment position="start">
                          <DescriptionOutlined />
                        </InputAdornment>
                      ),
                    }
                  }}
                  sx={{
                    "& .MuiInputBase-root": {
                      fontSize: { xs: "0.875rem", sm: "1rem" },
                    },
                  }}
                >
                  <MenuItem value="" disabled>
                    Select status
                  </MenuItem>
                  {taskStatuses.map((item) => (
                    <MenuItem key={item} value={item}>
                      {item}
                    </MenuItem>
                  ))}
                </TextField>
              </Grid>
              {status === "Cancelled" && (
                <Grid item xs={12} minWidth="400px">
                  <TextField
                    fullWidth
                    label="Reason For Cancellation"
                    value={reasonForCancellation}
                    onChange={(e) => {
                      setReasonForCancellation(e.target.value);
                      setErrors((prev) => ({ ...prev, reasonForCancellation: "" }));
                    }}
                    variant="outlined"
                    multiline
                    maxRows={4}
                    error={!!errors.reasonForCancellation}
                    helperText={
                      errors.reasonForCancellation ||
                      `${reasonForCancellation.length} / 5000 characters used`
                    }
                    slotProps={{
                      input: {
                        startAdornment: (
                          <InputAdornment position="start">
                            <DescriptionOutlined />
                          </InputAdornment>
                        ),
                        inputProps: { maxLength: 5000 },
                      },
                    }}
                    sx={{
                      "& .MuiInputBase-root": {
                        fontSize: { xs: "0.875rem", sm: "1rem" },
                        resize: "vertical",
                        minHeight: "56px",
                      },
                      "& .MuiInputBase-input": {
                        overflow: "auto",
                      },
                    }}
                  />
                </Grid>
              )}
              {status === "Completed" && (
                <>
                  <Grid item xs={12} minWidth="400px">
                    <TextField
                      fullWidth
                      label="MOM (Minutes of Meeting)"
                      value={mom}
                      onChange={(e) => {
                        setMom(e.target.value);
                        setErrors((prev) => ({ ...prev, mom: "" }));
                      }}
                      variant="outlined"
                      multiline
                      maxRows={6}
                      disabled={isCompleted}
                      error={!!errors.mom}
                      helperText={
                        errors.mom ||
                        `${mom.length} / 5000 characters used`
                      }
                      slotProps={{
                        input: {
                          startAdornment: (
                            <InputAdornment position="start">
                              <DescriptionOutlined />
                            </InputAdornment>
                          ),
                          inputProps: { maxLength: 5000 },
                        },
                      }}
                      sx={{
                        "& .MuiInputBase-root": {
                          fontSize: { xs: "0.875rem", sm: "1rem" },
                          resize: "vertical",
                          minHeight: "56px",
                        },
                        "& .MuiInputBase-input": {
                          overflow: "auto",
                        },
                      }}
                    />
                  </Grid>
                  <Grid item xs={12} minWidth="400px" mt={-2}>
                    <TableContainer component={Paper} sx={{ maxHeight: "400px" }}>
                      <Table stickyHeader sx={{ tableLayout: "fixed", width: "160%" }}>
                        <TableHead>
                          <TableRow>
                            <TableCell sx={{ width: "5%", fontWeight: "bold", background: "rgb(233 235 241)" }}>SR.NO</TableCell>
                            <TableCell sx={{ width: "20%", fontWeight: "bold", background: "rgb(233 235 241)" }}>TASK NAME</TableCell>
                            <TableCell sx={{ width: "20%", fontWeight: "bold", background: "rgb(233 235 241)" }}>REMARKS</TableCell>
                            <TableCell sx={{ width: "25%", fontWeight: "bold", background: "rgb(233 235 241)" }}>EMPLOYEE NAME</TableCell>
                            <TableCell sx={{ width: "30%", fontWeight: "bold", background: "rgb(233 235 241)" }}>TARGET DATE</TableCell>
                            <TableCell sx={{ width: "15%", fontWeight: "bold", background: "rgb(233 235 241)" }}>ACTION</TableCell>
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {tasks.map((t, index) => (
                            <TableRow key={index}>
                              <TableCell sx={{ fontSize: { xs: "0.75rem", sm: "0.875rem" } }}>{index + 1}</TableCell>
                              <TableCell sx={{ fontSize: { xs: "0.75rem", sm: "0.875rem" } }}>{t.taskName}</TableCell>
                              <TableCell sx={{ fontSize: { xs: "0.75rem", sm: "0.875rem" } }}>{t.remark}</TableCell>
                              <TableCell>{getEmployeeLabels(t.employeeIds)}</TableCell>
                              <TableCell>
                                {moment(t.targetDate).format("DD MMMM YYYY")}
                              </TableCell>
                              <TableCell>
                                <Tooltip title="Edit">
                                  <IconButton
                                    size="small"
                                    onClick={() => handleEditTask(index)}
                                    disabled={isCompleted}
                                  >
                                    <Edit />
                                  </IconButton>
                                </Tooltip>
                                <Tooltip title="Delete">
                                  <IconButton
                                    size="small"
                                    onClick={() => handleDeleteTask(index)}
                                    disabled={isCompleted}
                                  >
                                    <Delete />
                                  </IconButton>
                                </Tooltip>
                              </TableCell>
                            </TableRow>
                          ))}
                          <TableRow>
                            <TableCell sx={{ fontSize: { xs: "0.75rem", sm: "0.875rem" } }}>{tasks.length + 1}</TableCell>
                            <TableCell>
                              <TextField
                                fullWidth
                                placeholder="Task name"
                                name="taskName"
                                value={task.taskName}
                                onChange={handleTaskChange}
                                variant="outlined"
                                disabled={isCompleted}
                                error={!!taskErrors.taskName}
                                helperText={taskErrors.taskName}
                                slotProps={{
                                  input: {
                                    inputProps: { maxLength: 50 }
                                  }
                                }}
                                sx={{
                                  "& .MuiInputBase-root": {
                                    fontSize: { xs: "0.75rem", sm: "0.875rem" },
                                  },
                                  "& .MuiInputBase-input": {
                                    padding: "16px 14px",
                                  },
                                }}
                              />
                            </TableCell>
                            <TableCell>
                              <TextField
                                fullWidth
                                placeholder="Remark"
                                name="remark"
                                value={task.remark}
                                onChange={handleTaskChange}
                                variant="outlined"
                                disabled={isCompleted}
                                error={!!taskErrors.remark}
                                helperText={taskErrors.remark}
                                slotProps={{
                                  input: {
                                    inputProps: { maxLength: 200 }
                                  }
                                }}
                                sx={{
                                  "& .MuiInputBase-root": {
                                    fontSize: { xs: "0.75rem", sm: "0.875rem" },
                                  },
                                  "& .MuiInputBase-input": {
                                    padding: "16px 14px",
                                  },
                                }}
                              />
                            </TableCell>
                            <TableCell>
                              <Autocomplete
                                multiple
                                limitTags={1}
                                options={employees}
                                getOptionLabel={(option) => option.label}
                                value={employees.filter(emp => task.employeeIds.includes(emp.value))}
                                onChange={(_, newValue) => handleEmployeeSelection(newValue)}
                                disabled={isCompleted}
                                renderInput={(params) => (
                                  <TextField
                                    {...params}
                                    placeholder="Select Employee"
                                    variant="outlined"
                                    error={!!taskErrors.employeeIds}
                                    helperText={taskErrors.employeeIds}
                                    sx={{
                                      "& .MuiInputBase-root": {
                                        fontSize: { xs: "0.75rem", sm: "0.875rem" },
                                      },
                                      "& .MuiInputBase-input": {
                                        padding: "8px 14px",
                                      },
                                    }}
                                  />
                                )}
                                sx={{ width: "100%" }}
                              />
                            </TableCell>
                            <TableCell>
                              <DatePicker
                                open={openDatePicker}
                                onClose={() => setOpenDatePicker(false)}
                                value={task.targetDate ? new Date(task.targetDate) : null}
                                onChange={handleDateChange}
                                format="dd/MM/yyyy"
                                disabled={isCompleted}
                                slotProps={{
                                  textField: {
                                    fullWidth: true,
                                    variant: "outlined",
                                    error: !!taskErrors.targetDate,
                                    helperText: taskErrors.targetDate,
                                    InputProps: {
                                      startAdornment: (
                                        <InputAdornment position="start">
                                          <IconButton onClick={() => setOpenDatePicker(true)}>
                                            <EventOutlined />
                                          </IconButton>
                                        </InputAdornment>
                                      ),
                                      endAdornment: <></>,
                                    },
                                    sx: {
                                      "& .MuiInputBase-root": {
                                        fontSize: { xs: "0.75rem", sm: "0.875rem" },
                                      },
                                      "& .MuiInputBase-input": {
                                        padding: "8px 14px",
                                      },
                                    },
                                  },
                                }}
                                minDate={new Date()}
                              />
                            </TableCell>
                            <TableCell>
                              <Tooltip title="Save">
                                <IconButton
                                  size="small"
                                  onClick={handleAddOrUpdateTask}
                                  disabled={isCompleted}
                                >
                                  <Save />
                                </IconButton>
                              </Tooltip>
                            </TableCell>
                          </TableRow>
                        </TableBody>
                      </Table>
                    </TableContainer>
                  </Grid>
                </>
              )}
              <Grid item xs={12} minWidth="400px">
                <Autocomplete
                  multiple
                  options={employees}
                  getOptionLabel={(option) => option.label}
                  value={selectedEmployees}
                  onChange={(_, newValue) => handleAttendeesChange(newValue)}
                  disabled={isCompleted}
                  loading={attendiesLoading}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label="Attendees"
                      variant="outlined"
                      error={!!errors.participants}
                      helperText={errors.participants}
                      slotProps={{
                        input: {
                          ...params.InputProps,
                          startAdornment: (
                            <>
                              <InputAdornment position="start">
                                <PeopleOutline />
                              </InputAdornment>
                              {params.InputProps.startAdornment}
                            </>
                          ),
                        },
                      }}
                      sx={{
                        "& .MuiInputBase-root": {
                          fontSize: { xs: "0.875rem", sm: "1rem" },
                        },
                      }}
                    />
                  )}
                  sx={{ width: "100%" }}
                  isOptionEqualToValue={(option, value) => option.value === value.value}
                />
              </Grid>
              <Grid item xs={12} minWidth="400px" mt={-2}>
                <Typography
                  variant="subtitle2"
                  sx={{
                    color: "text.secondary",
                    fontSize: { xs: "0.75rem", sm: "0.875rem" },
                    mb: 1,
                  }}
                >
                  Add Attachment
                </Typography>
                <Box display="flex" alignItems="center" gap={2}>
                  <Button
                    variant="outlined"
                    color="primary"
                    startIcon={<Upload />}
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isCompleted}
                    sx={{ borderRadius: "8px", textTransform: "none" }}
                  >
                    Choose File
                  </Button>
                  <Typography
                    variant="body2"
                    color={fileName ? "textPrimary" : "textSecondary"}
                  >
                    {fileName || "No file chosen"}
                  </Typography>
                  {fileName && (
                    <IconButton
                      onClick={handleClearFile}
                      sx={{ color: "grey.600" }}
                      title="Clear File"
                    >
                      <Clear />
                    </IconButton>
                  )}
                  <input
                    type="file"
                    name="attachment"
                    onChange={handleFileChange}
                    ref={fileInputRef}
                    style={{ display: "none" }}
                    disabled={isCompleted}
                  />
                </Box>
              </Grid>
              <Grid item xs={12} minWidth="400px">
                <Box
                  sx={{
                    display: "flex",
                    justifyContent: { xs: "center", sm: "flex-end" },
                    gap: 2,
                    flexWrap: "wrap",
                  }}
                >
                  <Button
                    type="button"
                    variant="contained"
                    color="primary"
                    startIcon={<Save />}
                    onClick={handleSubmit}
                    sx={{
                      px: { xs: 2, sm: 3 },
                      py: 1,
                      fontSize: { xs: "0.75rem", sm: "0.875rem" },
                      textTransform: "none",
                      minWidth: { xs: "120px", sm: "140px" },
                    }}
                  >
                    Submit
                  </Button>
                  <Button
                    variant="outlined"
                    color="error"
                    onClick={() => {
                      setTask({ ...defaultTask, createdBy: employeeNo });
                      setEditingIndex(null);
                      setTasks([]);
                      setFile(null);
                      setFileName("");
                      setMom("");
                      setStatus("");
                      setSelectedEmployees([]);
                      setStatusWarning("");
                      setErrors({});
                      setTaskErrors({});
                    }}
                    sx={{
                      px: { xs: 2, sm: 3 },
                      py: 1,
                      fontSize: { xs: "0.75rem", sm: "0.875rem" },
                      textTransform: "none",
                      minWidth: { xs: "120px", sm: "140px" },
                    }}
                  >
                    Clear
                  </Button>
                </Box>
              </Grid>
            </Grid>
          </Box>
        </Box>
      </Modal>
    </>
  );
};

export default GeneralMeetingStatusUI;