import React, { useState, useEffect } from "react";
import { MultiValue } from "react-select";
import { getAllEmployees } from "../../../Requests/MeetingRequest";
import Select from "react-select";
import { AddGeneralMeetingTask } from "../../../Requests/GeneralMeetingRequest";
import { DepartmentOption, EmployeeOption, GeneralMeetingTaskDto, SegmentOption, TaskValidationError } from "../../../Interfaces/Generalmeeting";
import { toast, ToastContainer } from "react-toastify";
import { validateTask } from "../../../util/validations/generalMeeting";
import { defaultTask, departmentsData, segmentsData } from "../../../util/constants/generalMeeting";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Typography,
  IconButton,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  TableContainer,
  TextField,
  Button,
  Box,
  Autocomplete,
  InputAdornment,
} from "@mui/material";
import { Close, Edit, Delete, CategoryOutlined, ApartmentOutlined } from "@mui/icons-material";
import { usePageLoader } from "../../../context/PageLoaderContext";

interface MeetingStatusUIPopupProps {
  handleAddTaskModal: () => void;
  meetingId?: string;
  toast: typeof toast;
  refreshTasks: () => void;
}

const AddTaskPopup: React.FC<MeetingStatusUIPopupProps> = ({ handleAddTaskModal, toast, meetingId, refreshTasks }) => {
  const employeeNo = localStorage.getItem("employeeNo") || "";
  const [employees, setEmployees] = useState<EmployeeOption[]>([]);
  const [taskErrors, setTaskErrors] = useState<TaskValidationError>({});
  const [tasks, setTasks] = useState<GeneralMeetingTaskDto[]>([]);
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [task, setTask] = useState<GeneralMeetingTaskDto>({
    ...defaultTask,
    generalMeetingId: meetingId ?? '',
    completionDate: "",
    createdBy: employeeNo,
    departmentDtos: [],
    segmentDtos: []
  });
  const [selectedEmployees, setSelectedEmployees] = useState<EmployeeOption[]>([]);
  const [getEmployeeStatus, setGetEmployeeStatus] = useState(false);
  const { showLoader, hideLoader } = usePageLoader();
  const [selectedSegment, setSelectedSegment] = useState<SegmentOption[]>([]);
  const [selectedDepartment, setSelectedDepartment] = useState<DepartmentOption[]>([]);

  const handleSegmentSelection = (newValue: SegmentOption[]) => {
    if (!newValue) {
      setSelectedSegment([]);
      return;
    }
    setSelectedSegment(newValue);

    console.log("newValue ", newValue)
    const selectedSegments = newValue.map((option) => ({
      id: option.value,
      name: option.label,
    }));
    setTask({ ...task, segmentDtos: selectedSegments });

    // setMeetingDetails((prevDetails) => {
    //   if (!prevDetails) return null;
    //   return { ...prevDetails, segmentDtos: selectedSegments };
    // });
    // setErrors((prevErrors) => ({ ...prevErrors, segment: "" }));
  };

  const handleDepartmentSelection = (newValue: DepartmentOption[]) => {
    setSelectedDepartment(newValue);
    const selectedDepartmentDtos = newValue.map((option) => ({
      id: option.value,
      name: option.label,
    }));

    setTask({ ...task, departmentDtos: selectedDepartmentDtos });

    // setMeetingDetails((prevDetails) => {
    //   if (!prevDetails) return null;
    //   return { ...prevDetails, departmentDtos: selectedDepartmentDtos };
    // });
    // setErrors((prevErrors) => ({ ...prevErrors, department: "" }));
  };

  const handleEmployeeSelection = (selectedOptions: MultiValue<EmployeeOption>): void => {
    const employeeIds = selectedOptions.map(option => option.value);
    setTask({ ...task, employeeIds });
  };

  const handleTaskChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    if (name === "remark") {
      if (value.length <= 200) {
        setTask({ ...task, [name]: value });
      }
    } else {
      setTask({ ...task, [name]: value });
    }

  };

  const handleAddOrUpdateTask = async () => {
    const isValid = validateTask(task, setTaskErrors);
    if (!isValid) return;
    showLoader();
    try {
      const taskToAdd = { ...task };
      const response = await AddGeneralMeetingTask([taskToAdd]);
      if (response.httpStatus === "OK") {
        toast.success("Task added successfully!");
        setTasks((prevTasks) => {
          if (editingIndex !== null) {
            const updatedTasks = [...prevTasks];
            updatedTasks[editingIndex] = task;
            return updatedTasks;
          } else {
            return [...prevTasks, task];
          }
        });
        const resetTask = {
          ...defaultTask,
          generalMeetingId: meetingId ?? '',
          employeeIds: [],
          completionDate: "",
          createdBy: employeeNo,
          departmentDtos: [],
          segmentDtos: []
        };
        setTask(resetTask);
        setEditingIndex(null);
        refreshTasks();
      } else {
        toast.error("Failed to add task");
      }
    } catch (error) {
      toast.error("Failed to add task");
    } finally {
      hideLoader();
    }
  };

  const handleEditTask = (index: number) => {
    setTask(tasks[index]);
    setEditingIndex(index);
  };

  const handleDeleteTask = (index: number) => {
    setTasks(tasks.filter((_, i) => i !== index));
  };

  const getEmployeeLabels = (employeeIds: number[]): string => {
    const employeeMap = new Map(employees.map(emp => [emp.value, emp.label]));
    return employeeIds.map(id => employeeMap.get(id) || id).join(", ");
  };

  useEffect(() => {
    const fetchEmployees = async () => {
      try {
        setGetEmployeeStatus(true);
        const employeeData = await getAllEmployees();
        const allEmployeeOptions = employeeData.map((employee: { employeeId: number; employeeFullName: string }) => ({
          value: employee.employeeId,
          label: employee.employeeFullName,
        }));
        setEmployees(allEmployeeOptions);
        setSelectedEmployees(allEmployeeOptions);
        setGetEmployeeStatus(false);
      } catch (error) {
        console.error("Error fetching employees:", error);
      }
    };
    fetchEmployees();
  }, []);

  return (
    <Dialog
      open={true}
      onClose={handleAddTaskModal}
      maxWidth="lg"
      fullWidth
      sx={{
        '& .MuiDialog-paper': {
          borderRadius: '8px',
          padding: '16px',
          boxShadow: '0px 4px 20px rgba(0, 0, 0, 0.1)',
        },
      }}
    >
      <DialogTitle sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', pb: 1 }}>
        <Typography variant="h6" component="div" fontWeight="bold" color="rgb(73, 102, 131)">
          Add Tasks
        </Typography>
        <IconButton
          onClick={handleAddTaskModal}
          sx={{
            color: "grey.600",
            ":hover": { color: "red" },
          }}
          title="Close"
        >
          <Close />
        </IconButton>
      </DialogTitle>

      <DialogContent dividers sx={{ py: 2, borderBlockEnd: "none" }}>
        <Box sx={{ display: 'flex', gap: 4, mb: 3 }}>
          <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 4 }}>
            <Box>
              <TextField
                fullWidth
                name="taskName"
                value={task.taskName}
                error={!!taskErrors.taskName}
                helperText={taskErrors.taskName}
                onChange={handleTaskChange}
                placeholder="Task"
                variant="outlined"
                label="Task Name*"
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />

            </Box>

            <Box>
              <TextField
                fullWidth
                multiline
                name="remark"
                value={task.remark}
                error={!!taskErrors.remark}
                helperText={taskErrors.remark ? taskErrors.remark : 
                  task.remark &&
                  <Typography variant="caption" color={task.remark.length >= 200 ? "error" : "textSecondary"}>
                  {200 - task.remark.length} / 200
                </Typography>
                }
                onChange={handleTaskChange}
                placeholder="Task"
                variant="outlined"
                label="Task*"
                maxRows={3}
                inputProps={{ maxLength: 200 }}
                sx={{
                  '& .MuiOutlinedInput-root': {
                    borderRadius: '8px',
                  },
                }}
              />
            </Box>

          {
          !meetingId &&
          <Box>


              <Autocomplete
                multiple
                options={segmentsData}
                getOptionLabel={(option) => option.label}
                value={selectedSegment}
                onChange={(_, newValue) => handleSegmentSelection(newValue)}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Segments*"
                    variant="outlined"
                    error={!!taskErrors.segment}
                    helperText={taskErrors.segment}
                    slotProps={{
                      input: {
                        ...params.InputProps,
                        startAdornment: (
                          <>
                            <InputAdornment position="start">
                              <CategoryOutlined />
                            </InputAdornment>
                            {params.InputProps.startAdornment}
                          </>
                        ),
                      },
                    }}
                    sx={{
                      "& .MuiInputBase-root": {
                        fontSize: { xs: "0.875rem", sm: "1rem", borderRadius: "8px" },
                      },
                    }}
                  />
                )}

              />

            </Box>
}

          </Box>

          {/* Right Side: Employee Name and Target Date */}
          <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 4 }}>
            <Box>
              <Select
                isMulti
                options={selectedEmployees}
                value={selectedEmployees.filter((emp) => task.employeeIds.includes(emp.value))}
                onChange={handleEmployeeSelection}
                placeholder="Select Employee"
                menuPortalTarget={document.body}
                styles={{
                  control: (base) => ({
                    ...base,
                    borderRadius: '8px',
                    border: '1px solid rgba(0, 0, 0, 0.23)',
                    minHeight: '56px',
                    maxHeight: '100px',
                    overflowY: 'auto',
                    padding: '0 8px',
                  }),
                  valueContainer: (base) => ({
                    ...base,
                    overflowY: 'auto',
                    maxHeight: '90px',
                    padding: '2px 8px',
                  }),
                  menuPortal: (base) => ({ ...base, zIndex: 9999 }),
                }}
                isLoading={getEmployeeStatus}
              />
              {taskErrors.employeeIds && (
                <Typography variant="caption" color="error">
                  {taskErrors.employeeIds}
                </Typography>
              )}
            </Box>

            <Box>
              <TextField
                fullWidth
                name="targetDate"
                type="date"
                value={task.targetDate}
                error={!!taskErrors.targetDate}
                helperText={taskErrors.targetDate}
                onChange={handleTaskChange}
                variant="outlined"
                label="Target Date*"
                InputLabelProps={{ shrink: true }}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
              />
             
            </Box>

            {
              
               
          !meetingId &&
              <Box>

              <Autocomplete
                multiple
                options={departmentsData}
                getOptionLabel={(option) => option.label}
                value={selectedDepartment}
                onChange={(_, newValue) => handleDepartmentSelection(newValue)}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Departments*"
                    variant="outlined"
                    error={!!taskErrors.department}
                    helperText={taskErrors.department}
                    slotProps={{
                      input: {
                        ...params.InputProps,
                        startAdornment: (
                          <>
                            <InputAdornment position="start">
                              <ApartmentOutlined />
                            </InputAdornment>
                            {params.InputProps.startAdornment}
                          </>
                        ),
                      },
                    }}
                    sx={{
                      "& .MuiInputBase-root": {
                        fontSize: { xs: "0.875rem", sm: "1rem", borderRadius: "8px" },
                      },
                    }}
                  />
                )}
              />

            </Box>}
          </Box>
        </Box>

        {/* Add Task Button */}
        <Box sx={{ display: 'flex', justifyContent: 'end', mb: 2 }}>
          <Button
            variant="contained"
            color="primary"
            onClick={handleAddOrUpdateTask}
            sx={{ borderRadius: '8px', textTransform: 'none' }}
          >
            {editingIndex !== null ? "Update Task" : "Add Task"}
          </Button>
        </Box>

        {/* Table to display tasks */}
        <TableContainer sx={{ maxHeight: "400px", overflowY: "auto" }}>
          <Table sx={{ tableLayout: "fixed", width: "100%" }}>
            <TableHead>
              <TableRow sx={{ backgroundColor: 'rgb(246, 247, 251)'}}>
                <TableCell sx={{ fontWeight: 'bold', textAlign: 'center', width: '80px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  SR. NO
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', textAlign: 'center', width: '150px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  TASK NAME
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', textAlign: 'center', width: '250px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  TASK
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', textAlign: 'center', width: '150px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  EMPLOYEE NAME
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', textAlign: 'center', width: '150px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  TARGET DATE
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', textAlign: 'center', width: '80px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  ACTION
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {tasks.length > 0 ? (
                tasks.map((t: GeneralMeetingTaskDto, index) => (
                  <TableRow key={index} >
                    <TableCell sx={{ textAlign: 'center', whiteSpace: 'normal', wordBreak: 'break-word' }}>
                      {index + 1}
                    </TableCell>
                    <TableCell sx={{ textAlign: 'center', whiteSpace: 'normal', wordBreak: 'break-word' }}>
                      {t.taskName}
                    </TableCell>
                    <TableCell sx={{ textAlign: 'center', whiteSpace: 'normal', wordBreak: 'break-word' }}>
                      {t.remark}
                    </TableCell>
                    <TableCell sx={{ textAlign: 'center', whiteSpace: 'normal', wordBreak: 'break-word' }}>
                      {getEmployeeLabels(t.employeeIds)}
                    </TableCell>
                    <TableCell sx={{ textAlign: 'center', whiteSpace: 'normal', wordBreak: 'break-word' }}>
                      {t.targetDate}
                    </TableCell>
                    <TableCell sx={{  gap: 1 }}>
                      <IconButton onClick={() => handleEditTask(index)} title="Edit">
                        <Edit />
                      </IconButton>
                      <IconButton onClick={() => handleDeleteTask(index)} title="Delete">
                        <Delete />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={6} sx={{ textAlign: 'center' }}>
                    No tasks added yet.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </DialogContent>

      <DialogActions sx={{ p: 2, pt: 1 }}>
        <Button
          variant="outlined"
          color="primary"
          onClick={handleAddTaskModal}
          sx={{ borderRadius: '8px', textTransform: 'none' }}
        >
          Close
        </Button>
      </DialogActions>

      <ToastContainer />
    </Dialog>
  );
};

export default AddTaskPopup;