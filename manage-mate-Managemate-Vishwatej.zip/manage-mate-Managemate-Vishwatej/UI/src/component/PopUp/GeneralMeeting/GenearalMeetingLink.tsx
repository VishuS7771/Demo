import React, { useEffect, useState } from "react";
import { Box, IconButton, Modal, Typography, Grid, Button } from "@mui/material";
import { Clear } from "@mui/icons-material";
import { toast, ToastContainer } from "react-toastify";
import { GeneralMeetingsDto } from "../../../Interfaces/Generalmeeting";
import { resendMeetingLink } from "../../../Requests/GeneralMeetingRequest";

interface LinkPopUpProps {
  meeting: GeneralMeetingsDto;
  onClose: () => void;
}

const GeneralMeetingLinkPopUp: React.FC<LinkPopUpProps> = ({ meeting, onClose }) => {
  const [link, setLink] = useState<string | null>(null);

  useEffect(() => {
    if (meeting) {
      setLink(meeting.link);
    }
  }, [meeting]);

  const sendMeetingLink = async () => {
    const response = await resendMeetingLink(meeting.id);
    if (response.httpStatus === "OK") {
      toast.success("Meeting link sent successfully!");
    }
  };

  return (
    <Modal
      open={true}
      onClose={onClose}
      aria-labelledby="link-modal-title"
      aria-describedby="link-modal-description"
    >
      <Box
        sx={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          width: { xs: "90%", sm: "80%", md: "70%", lg: 800 },
          maxWidth: "95vw",
          bgcolor: "background.paper",
          boxShadow: 24,
          borderRadius: "10px",
          maxHeight: "90vh",
          overflow: "auto",
        }}
      >
        <Box
          sx={{
            display: "flex",
            justifyContent: "end",
            p: { xs: 1, sm: 1 },
          }}
        >
          <IconButton
            onClick={onClose}
            sx={{
              color: "grey.500",
              ":hover": { color: "red" },
            }}
          >
            <Clear />
          </IconButton>
        </Box>
        <Box
          sx={{
            p: { xs: 1, sm: 2 },
            minWidth: { xs: 300, sm: 400 },
            minHeight: { xs: 100, sm: 100 },
            width: { xs: "100%", sm: 780 },
            height: { xs: "auto", sm: 200 },
            boxSizing: "border-box",
            
            mt: -5,
          }}
        >
          <ToastContainer position="top-center" autoClose={3000} />
          <Grid container spacing={3}>
            <Grid item xs={12} ml={2}>
              <Typography
                variant="subtitle1"
                sx={{
                  fontWeight: "bold",
                  color: "text.primary",
                  fontSize: { sm: "1.3rem" },
                }}
              >
                Meeting Link :
              </Typography>
              <Typography
                variant="body1"
                sx={{
                  fontSize: { xs: "0.875rem", sm: "1.1rem" },
                  color: "text.primary",
                  whiteSpace: "pre-wrap",
                  wordBreak: "break-word",
                  ml: 3,
                  mt: 1,
                }}
              >
                {link ? (
                  <a href={link} target="_blank" rel="noopener noreferrer">
                    {link}
                  </a>
                ) : (
                  "No link available"
                )}
              </Typography>
            </Grid>
            {link && (
              <Grid item xs={12} sx={{ textAlign: "end", mt: 4, ml: 2 }}>
                <Button
                  variant="contained"
                  color="primary"
                  onClick={sendMeetingLink}
                >
                  Send Link
                </Button>
              </Grid>
            )}
          </Grid>
        </Box>
      </Box>
    </Modal>
  );
};

export default GeneralMeetingLinkPopUp;
