import React, { useState } from "react";
import {
  Modal,
  Box,
  IconButton,
  Typography,
  Grid,
  Divider,
  Button,
} from "@mui/material";
import {
  Clear,
  EventOutlined,
  ScheduleOutlined,
  PeopleOutlined,
  LinkOutlined,
  NotesOutlined,
  LocationOnOutlined,
  BusinessOutlined,
  AssignmentOutlined,
} from "@mui/icons-material";
import moment from "moment";
import { GeneralMeetingsDto } from "../../../Interfaces/Generalmeeting";

interface ViewMeetingProps {
  meeting: GeneralMeetingsDto;
  onClose: () => void;
}

const ViewMeeting: React.FC<ViewMeetingProps> = ({ meeting, onClose }) => {
  const [expandedFields, setExpandedFields] = useState<{ [key: string]: boolean }>({});

  const toggleExpand = (field: string) => {
    setExpandedFields((prev) => ({
      ...prev,
      [field]: !prev[field],
    }));
  };

  const renderValue = (value: string | JSX.Element, field: string) => {
    if (typeof value === "string" && value.length > 50 && !expandedFields[field]) {
      return (
        <>
          {value.substring(0, 50)}...
          <Button
            size="small"
            onClick={() => toggleExpand(field)}
            sx={{
              textTransform: "none",
              ml: 1,
              '&:hover': {
                backgroundColor: 'transparent',
              }
            }}
          >
            Show More
          </Button>
        </>
      );
    }
    if (typeof value === "string" && expandedFields[field]) {
      return (
        <>
          {value}
          <Button
            size="small"
            onClick={() => toggleExpand(field)}
            sx={{
              textTransform: "none",
              ml: 1,
              '&:hover': {
                backgroundColor: 'transparent',
              }
            }}
          >
            Show Less
          </Button>
        </>
      );
    }
    return value;
  };

  return (
    <Modal
      open={true}
      onClose={onClose}
      aria-labelledby="meeting-details-modal-title"
      aria-describedby="meeting-details-modal-description"
    >
      <Box
        sx={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          width: { xs: "95%", sm: 600, md: 800, lg: 1000 },
          minHeight: { xs: "90vh", sm: 600, md: 700, lg: 700 },
          bgcolor: "background.paper",
          boxShadow: 24,
          borderRadius: 2,
          overflow: "auto",
          display: "flex",
          flexDirection: "column",
        }}
      >
        <Box
          sx={{
            display: "flex",
            justifyContent: "end",
            p: { xs: 1, sm: 2 },
          }}
        >
          <IconButton
            onClick={onClose}
            sx={{
              color: "grey.500",
              ":hover": { color: "red" },
            }}
          >
            <Clear />
          </IconButton>
        </Box>
        <Box sx={{ p: { xs: 2, sm: 3, md: 4 }, flexGrow: 1, overflow: "auto", boxSizing: "border-box", mt: -10, }}>
          <Typography variant="h5" sx={{ fontWeight: "bold", textAlign: "left", }} >
            Meeting Detail - {meeting?.meetingId}
          </Typography>

          <Box sx={{ mt: 4, mb: 2 }}>
            <Grid container spacing={2} justifyContent="space-between" alignContent="center">
              {[
                {
                  label: "Meeting Name",
                  value: meeting?.meetingName || "N/A",
                  icon: <AssignmentOutlined fontSize="small" />,
                },
                {
                  label: "Agenda",
                  value: meeting?.agenda || "N/A",
                  icon: <NotesOutlined fontSize="small" />,
                },
                {
                  label: "Meeting Date",
                  value: meeting?.meetingDate
                    ? moment(meeting.meetingDate).format("DD MMM YYYY")
                    : "N/A",
                  icon: <EventOutlined fontSize="small" />,
                },
                {
                  label: "From Time",
                  value: meeting?.fromTime || "N/A",
                  icon: <ScheduleOutlined fontSize="small" />,
                },
                {
                  label: "To Time",
                  value: meeting?.toTime || "N/A",
                  icon: <ScheduleOutlined fontSize="small" />,
                },
                {
                  label: "Location",
                  value: meeting?.location || "N/A",
                  icon: <LocationOnOutlined fontSize="small" />,
                },
                {
                  label: "Attendees",
                  value:
                    meeting?.meetingParticipantsDtoList?.length > 0
                      ? meeting.meetingParticipantsDtoList
                        .map(
                          (participant) =>
                            participant.participantName ||
                            `ID: ${participant.employeeId || "Unknown"}`
                        )
                        .join(", ")
                      : "N/A",
                  icon: <PeopleOutlined fontSize="small" />,
                },
                {
                  label: "Scheduled By",
                  value: meeting?.hostIdName?.split(" - ")[1] || "N/A",
                  icon: <PeopleOutlined fontSize="small" />,
                },
                {
                  label: "Segments",
                  value:
                    meeting?.segmentDtos?.map((s) => s.name).join(", ") || "N/A",
                  icon: <BusinessOutlined fontSize="small" />,
                },
                {
                  label: "Department",
                  value:
                    meeting?.departmentDtos?.map((d) => d.name).join(", ") ||
                    "N/A",
                  icon: <BusinessOutlined fontSize="small" />,
                },
                {
                  label: "Link",
                  value: meeting?.link ? (
                    <a
                      href={meeting.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      style={{ color: "#1976d2", textDecoration: "underline" }}
                    >
                      {meeting.link}
                    </a>
                  ) : (
                    "N/A"
                  ),
                  icon: <LinkOutlined fontSize="small" />,
                },
                {
                  label: "Remarks",
                  value: meeting?.remarks || "N/A",
                  icon: <NotesOutlined fontSize="small" />,
                },
                {
                  label: "MOM (Minutes of Meeting)",
                  value: meeting?.mom || "N/A",
                  icon: <NotesOutlined fontSize="small" />,
                  visible:
                    meeting.meetingStatus === "Completed" ||
                    meeting.meetingStatus === "Closed",
                },
              ]
                .filter((item) => item.visible !== false)
                .map((item, index) => (
                  <Grid
                    item
                    xs={item.label === "MOM (Minutes of Meeting)" ? 12 : 12}
                    sm={item.label === "MOM (Minutes of Meeting)" ? 12 : 6}
                    md={item.label === "MOM (Minutes of Meeting)" ? 12 : 4}
                    key={index}
                    sx={{ minWidth: 0 }}
                  >
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        gap: 1,
                        width: "100%",
                        overflow: "hidden",
                      }}
                    >
                      <Typography
                        variant="subtitle1"
                        sx={{
                          display: "flex",
                          alignItems: "center",
                          gap: 1,
                          fontWeight: 500,
                          color: "text.primary",
                          whiteSpace: "nowrap",
                          overflow: "hidden",
                          textOverflow: "ellipsis",
                          textAlign: "left",
                        }}
                      >
                        {item.icon}
                        {item.label}
                      </Typography>
                      <Typography
                        variant="body2"
                        color="text.secondary"
                        sx={{
                          pl: 3,
                          overflow: "hidden",
                          textOverflow: "ellipsis",
                          display: "-webkit-box",
                          WebkitLineClamp: expandedFields[item.label]
                            ? "unset"
                            : 2,
                          WebkitBoxOrient: "vertical",
                          textAlign: "left",
                        }}
                      >
                        {renderValue(item.value, item.label)}
                      </Typography>
                      <Divider sx={{ mt: 1 }} />
                    </Box>
                  </Grid>
                ))}
            </Grid>
          </Box>
        </Box>
      </Box>
    </Modal>
  );
};

export default ViewMeeting;