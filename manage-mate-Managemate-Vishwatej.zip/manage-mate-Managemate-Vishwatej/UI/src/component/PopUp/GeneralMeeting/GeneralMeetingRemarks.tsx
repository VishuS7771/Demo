import React, { useEffect, useState } from "react";
import {
    Box,
    IconButton,
    Modal,
    Typography,
    Grid,
} from "@mui/material";
import { Clear } from "@mui/icons-material";
import { GeneralMeetingsDto } from "../../../Interfaces/Generalmeeting";

interface RemarksPopUp {
    meeting: GeneralMeetingsDto;
    onClose: () => void;
}

const GeneralMeetingRemarksPopUp: React.FC<RemarksPopUp> = ({ meeting, onClose }) => {
    const [description, setDescription] = useState<string | null>(null);

    useEffect(() => {
        if (meeting) {
            setDescription(meeting.remarks);
        }
    }, [meeting]);

    return (
        <Modal
            open={true}
            onClose={onClose}
            aria-labelledby="remarks-modal-title"
            aria-describedby="remarks-modal-description"
        >
            <Box
                sx={{
                    position: "absolute",
                    top: "50%",
                    left: "50%",
                    transform: "translate(-50%, -50%)",
                    width: { xs: "90%", sm: "80%", md: "70%", lg: 800 },
                    maxWidth: "95vw",
                    bgcolor: "background.paper",
                    boxShadow: 24,
                    borderRadius: "10px",
                    maxHeight: "90vh",
                    overflow: "auto",
                }}
            >
                <Box
                    sx={{
                        display: "flex",
                        justifyContent: "end",
                        p: { xs: 1, sm: 1 },
                    }}
                >
                    <IconButton
                        onClick={onClose}
                        sx={{
                            color: "grey.500",
                            ":hover": { color: "red" },
                        }}
                    >
                        <Clear />
                    </IconButton>
                </Box>
                <Box
                    sx={{
                        p: { xs: 1, sm: 3 },
                        minWidth: { xs: 300, sm: 400 },
                        minHeight: { xs: 100, sm: 300 },
                        width: { xs: "100%", sm: 780 },
                        height: { xs: "auto", sm: 200 },
                        boxSizing: "border-box",
                        mb: 4, mt: -5
                    }}
                >
                    <Grid container spacing={2}>
                        <Grid item xs={12}>
                            <Typography
                                variant="subtitle1"
                                sx={{
                                    fontWeight: "bold",
                                    color: "text.primary",
                                    fontSize: { sm: "1.3rem" },
                                }}
                            >
                                Remarks :
                            </Typography>
                            <Typography
                                variant="body1"  
                                sx={{
                                    fontSize: { xs: "0.875rem", sm: "1rem" },
                                    color: "text.primary",
                                    whiteSpace: "pre-wrap",
                                    wordBreak: "break-word",
                                    ml: 3,
                                    mt: 1,
                                }}
                            >
                                {description || "N/A"}
                            </Typography>
                        </Grid>
                    </Grid>
                </Box>
            </Box>
        </Modal>
    );
};

export default GeneralMeetingRemarksPopUp;