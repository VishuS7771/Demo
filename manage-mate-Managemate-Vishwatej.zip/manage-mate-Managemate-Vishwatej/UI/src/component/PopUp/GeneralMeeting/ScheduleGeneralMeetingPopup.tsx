import React, { useEffect, useState } from "react";
import { toast } from "react-toastify";
import {
  Box,
  Button,
  Grid,
  TextField,
  InputAdornment,
  IconButton,
  Autocomplete,
} from "@mui/material";
import {
  Save,
  Refresh,
  DescriptionOutlined,
  LocationOnOutlined,
  EventOutlined,
  LinkOutlined,
  NotesOutlined,
  AccessTime,
  EventNoteOutlined,
  PeopleOutline,
  AssignmentIndOutlined,
  CategoryOutlined,
  ApartmentOutlined,
} from "@mui/icons-material";
import { DatePicker, TimePicker } from "@mui/x-date-pickers";
import { parse } from "date-fns";
import { GeneralMeetingsDto, SegmentOption } from "../../../Interfaces/Generalmeeting";
import { createMeeting, updateMeeting, resheduleMeetings } from "../../../Requests/GeneralMeetingRequest";
import { getAllEmployees } from "../../../Requests/MeetingRequest";
import moment from "moment";
import CustomModal from "../../Modal/CustomModal/CustomModal";
import { departmentsData, segmentsData } from "../../../util/constants/generalMeeting";

interface EmployeeOption {
  value: number;
  label: string;
}

interface DepartmentOption {
  value: number;
  label: string;
}

const ScheduleGeneralMeeting: React.FC<{
  onClose: () => void;
  meetingDetail?: GeneralMeetingsDto | null;
  meetingMode: string;
  fetchMeetings: () => void;
}> = ({ onClose, meetingDetail, meetingMode, fetchMeetings }) => {
  const [meetingDetails, setMeetingDetails] = useState<GeneralMeetingsDto | null>(null);
  const [employees, setEmployees] = useState<EmployeeOption[]>([]);
  const [selectedEmployees, setSelectedEmployees] = useState<EmployeeOption[]>([]);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  const [departmentOptions, setDepartmentOptions] = useState<DepartmentOption[]>([]);
  const [segmentOptions, setSegmentOptions] = useState<SegmentOption[]>([]);
  const [selectedEmployeesSchedule, setSelectedScheduleEmployees] = useState<EmployeeOption[]>([]);
  const [selectedDepartment, setSelectedDepartment] = useState<DepartmentOption[]>([]);
  const [selectedSegment, setSelectedSegment] = useState<SegmentOption[]>([]);
  const [openDatePicker, setOpenDatePicker] = useState(false);
  const [openTimePicker, setOpenTimePicker] = useState("");

  const employeeId = localStorage.getItem("employeeNo");

  const fetchEmployees = async () => {
    try {
      const fetchedEmployees = await getAllEmployees();
      const employeeOptions: EmployeeOption[] = fetchedEmployees.map((employee: any) => ({
        value: Number(employee.employeeId),
        label: employee.employeeFullName,
      }));
      setEmployees(employeeOptions);

      if ((meetingMode === "Edit" || meetingMode === "Reschedule") && meetingDetail) {
        setSelectedScheduleEmployees(
          employeeOptions
            .filter((e) => e.value === Number(meetingDetail?.hostIdName?.split(" - ")[0]))
            .map((participant) => ({
              value: participant.value,
              label: participant.label,
            }))
        );
      } else {
        setSelectedScheduleEmployees([]);
      }
    } catch (error) {
      toast.error("Failed to load employees. Please try again later.");
    }
  };

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setMeetingDetails((prevDetails) => ({
      ...prevDetails,
      [name]: value,
    } as GeneralMeetingsDto));
    setErrors((prevErrors) => ({ ...prevErrors, [name]: "" }));
  };

  const handleEmployeeSelection = (newValue: EmployeeOption[]) => {
    setSelectedEmployees(newValue);
    const selectedEmployeeIds = newValue.map((option) => option.value);
    setMeetingDetails((prevDetails) => {
      if (!prevDetails) return null;
      return { ...prevDetails, employeeId: selectedEmployeeIds };
    });
    setErrors((prevErrors) => ({ ...prevErrors, attendees: "" }));
  };

  const handleDepartmentSelection = (newValue: DepartmentOption[]) => {
    setSelectedDepartment(newValue);
    const selectedDepartmentDtos = newValue.map((option) => ({
      id: option.value,
      name: option.label,
    }));
    setMeetingDetails((prevDetails) => {
      if (!prevDetails) return null;
      return { ...prevDetails, departmentDtos: selectedDepartmentDtos };
    });
    setErrors((prevErrors) => ({ ...prevErrors, department: "" }));
  };

  const handleSegmentSelection = (newValue: SegmentOption[]) => {
    if (!newValue) {
      setSelectedSegment([]);
      return;
    }
    setSelectedSegment(newValue);

    console.log("newValue ",newValue)
    const selectedSegments = newValue.map((option) => ({
      id: option.value,
      name: option.label,
    }));
    setMeetingDetails((prevDetails) => {
      if (!prevDetails) return null;
      return { ...prevDetails, segmentDtos: selectedSegments };
    });
    setErrors((prevErrors) => ({ ...prevErrors, segment: "" }));
  };

  const handleScheduledBySelection = (newValue: EmployeeOption | null) => {
    const selected = newValue ? [newValue] : [];
    setSelectedScheduleEmployees(selected);
    setMeetingDetails((prevDetails) => ({
      ...prevDetails,
      scheduledBy: newValue ? newValue.value : null,
    } as GeneralMeetingsDto));
    setErrors((prevErrors) => ({ ...prevErrors, scheduledBy: "" }));
  };

  const handleDateChange = (date: any) => {
    if (date) {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      setMeetingDetails((prevDetails) => ({
        ...prevDetails,
        meetingDate: date,
      } as GeneralMeetingsDto));
      setErrors((prevErrors) => ({ ...prevErrors, date: "" }));
    }
  };

  const parseTimeString = (timeString: string | undefined): Date | null => {
    if (!timeString) return null;
    // Try parsing common time formats
    const formats = ["h:mm a", "h:mm:ss a", "HH:mm", "HH:mm:ss"];
    for (const formatString of formats) {
      try {
        const parsed = parse(timeString, formatString, new Date());
        if (!isNaN(parsed.getTime())) {
          return parsed;
        }
      } catch (error) {
        // Continue to next format
      }
    }
    console.warn(`Failed to parse time string: ${timeString}`);
    return null;
  };

  const handleTimeChange = (field: string, time: Date | moment.Moment | null,) => {
    setMeetingDetails((prevDetails) => ({
      ...prevDetails,
      [field]: time ? moment(time).format("hh:mm A") : "",
    } as GeneralMeetingsDto));
    setErrors((prevErrors) => ({ ...prevErrors, [field]: "" }));
  };

  useEffect(() => {
    if (!(meetingMode === "Edit" || meetingMode === "Reschedule")) {
      handleResetForm();
    }
    fetchEmployees();
    setDepartmentOptions(departmentsData);
    setSegmentOptions(segmentsData);
    setMeetingDetails((prevDetails) => ({
      ...prevDetails,
      createdBy: Number(employeeId),
    } as GeneralMeetingsDto));
  }, []);

  useEffect(() => {
    if ((meetingMode === "Edit" || meetingMode === "Reschedule") && meetingDetail) {
      const selected = meetingDetail.meetingParticipantsDtoList.map((participant) => ({
        value: participant.employeeId,
        label: participant.participantName,
      }));
      const departmentDto = meetingDetail.departmentDtos.map((d) => ({
        value: d.id,
        label: d.name,
      }));
      const segmentDto = meetingDetail.segmentDtos.map((s) => ({
        value: s.id,
        label: s.name,
      }));
      setSelectedEmployees(selected);
      setSelectedDepartment(departmentDto);
      setSelectedSegment(segmentDto);
      setMeetingDetails({
        ...meetingDetail,
        employeeId: selected.map((s) => s.value),
        departmentDtos: departmentDto.map((d) => ({ id: d.value, name: d.label })),
        segmentDtos: segmentDto.map((s) => ({ id: s.value, name: s.label })),

      });
    }
  }, [meetingMode, meetingDetail]);

  const validateMeetingName = () => {
    if (!meetingDetails?.meetingName) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        meetingName: "Meeting Name is required.",
      }));
      return false;
    }
    setErrors((prevErrors) => ({ ...prevErrors, meetingName: "" }));
    return true;
  };

  const validateAgenda = () => {
    if (!meetingDetails?.agenda) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        agenda: "Agenda is required.",
      }));
      return false;
    }
    setErrors((prevErrors) => ({ ...prevErrors, agenda: "" }));
    return true;
  };

  const validateAttendees = () => {
    if (selectedEmployees.length === 0) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        attendees: "Please select at least one attendee.",
      }));
      return false;
    }
    setErrors((prevErrors) => ({ ...prevErrors, attendees: "" }));
    return true;
  };

  const validateSegment = () => {
    if (selectedSegment.length === 0) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        segment: "Please select at least one segment.",
      }));
      return false;
    }
    setErrors((prevErrors) => ({ ...prevErrors, segment: "" }));
    return true;
  };

  const validateDepartment = () => {
    if (selectedDepartment.length === 0) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        department: "Please select at least one department.",
      }));
      return false;
    }
    setErrors((prevErrors) => ({ ...prevErrors, department: "" }));
    return true;
  };

  const validateScheduledBy = () => {
    if (selectedEmployeesSchedule.length === 0) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        scheduledBy: "Please select Scheduled By.",
      }));
      return false;
    }
    setErrors((prevErrors) => ({ ...prevErrors, scheduledBy: "" }));
    return true;
  };

  const validateDate = () => {
    if (!meetingDetails?.meetingDate) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        date: "Meeting Date is required.",
      }));
      return false;
    }
    setErrors((prevErrors) => ({ ...prevErrors, date: "" }));
    return true;
  };

  const validateTime = () => {
    let isValid = true;
    setErrors((prevErrors) => ({
      ...prevErrors,
      fromTime: "",
      toTime: "",
    }));
    if (!meetingDetails?.fromTime) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        fromTime: "From Time is required.",
      }));
      isValid = false;
    }
    if (!meetingDetails?.toTime) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        toTime: "To Time is required.",
      }));
      isValid = false;
    }
    if (
      meetingDetails?.fromTime &&
      meetingDetails?.toTime
    ) {
      const fromTime = parseTimeString(meetingDetails.fromTime);
      const toTime = parseTimeString(meetingDetails.toTime);
      if (fromTime && toTime && fromTime >= toTime) {
        setErrors((prevErrors) => ({
          ...prevErrors,
          toTime: "To Time cannot be earlier than or equal to From Time.",
        }));
        isValid = false;
      }
    }
    return isValid;
  };

  const validateLocationOrLink = () => {
    if (!meetingDetails?.location && !meetingDetails?.link) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        locationOrLink: "Either Location or Link must be provided.",
      }));
      return false;
    }
    setErrors((prevErrors) => ({ ...prevErrors, locationOrLink: "" }));
    return true;
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    if (!validateMeetingName() || !validateScheduledBy() || !validateLocationOrLink() || !validateDate() || !validateTime() || !validateSegment() || !validateAttendees() || !validateDepartment() || !validateAgenda()) { return; }

    try {
      if (meetingMode === "Edit") {
        const response = await updateMeeting(meetingDetails?.id, meetingDetails);
        if (response.httpStatus === "OK") {
          toast.success("Meeting Saved Successfully!");
          fetchMeetings();
        } else {
          toast.error("Meeting Failed To Save");
        }
      } else if (meetingMode === "Reschedule") {
        const response = await resheduleMeetings(meetingDetails?.id, meetingDetails);
        if (response.httpStatus === "OK") {
          toast.success("Meeting Rescheduled Successfully!");
          fetchMeetings();
        } else {
          toast.error("Meeting Failed To Reschedule");
        }
      } else {
        const response = await createMeeting(meetingDetails);
        if (response.httpStatus === "CREATED") {
          toast.success("Meeting Created Successfully!");
          fetchMeetings();
        } else {
          toast.error("Meeting Failed To Create");
        }
      }
      handleResetForm();
      onClose();
    } catch (error) {
      console.error("Error handling meeting:", error);
      toast.error(`Error: ${error}`);
    }
  };

  const handleResetForm = () => {
    setMeetingDetails(null);
    setErrors({});
    setSelectedEmployees([]);
    setSelectedSegment([]);
    setSelectedDepartment([]);
    setSelectedScheduleEmployees([]);
    setOpenDatePicker(false);
    setOpenTimePicker("");
  };

  const handleClose = () => {
    setMeetingDetails(null);
    setErrors({});
    setSelectedEmployees([]);
    setSelectedSegment([]);
    setSelectedDepartment([]);
    setSelectedScheduleEmployees([]);
    setOpenDatePicker(false);
    setOpenTimePicker("");
    onClose();
  };

  return (
    <CustomModal
      open={true}
      onClose={handleClose}
      maxWidth="lg"
      title={meetingMode === "Edit"
        ? "Edit General Meeting"
        : meetingMode === "Reschedule"
          ? "Reschedule General Meeting"
          : "Schedule General Meeting"}
      actions={
        <form onSubmit={handleSubmit}>
          <Box
            sx={{
              display: "flex",
              justifyContent: { xs: "center", sm: "flex-end" },
              gap: 2,
              flexWrap: "wrap",
            }}
          >
            <Button
              variant="contained"
              color="primary"
              type="submit"
              startIcon={<Save />}
              sx={{
                px: { xs: 2, sm: 3 },
                py: 1,
                fontSize: { xs: "0.75rem", sm: "0.875rem" },
                textTransform: "none",
                minWidth: { xs: "120px", sm: "140px" },
              }}
            >
              {meetingMode === "Edit"
                ? "Save Meeting"
                : meetingMode === "Reschedule"
                  ? "Reschedule Meeting"
                  : "Schedule Meeting"}
            </Button>
            {meetingMode !== "Edit" && meetingMode !== "Reschedule" && (
              <Button
                type="button"
                variant="outlined"
                color="error"
                startIcon={<Refresh />}
                onClick={handleResetForm}
                sx={{
                  px: { xs: 2, sm: 3 },
                  py: 1,
                  fontSize: { xs: "0.75rem", sm: "0.875rem" },
                  textTransform: "none",
                  minWidth: { xs: "120px", sm: "140px" },
                }}
              >
                Clear
              </Button>
            )}
          </Box>
        </form>
      }
    >
      <Box
        sx={{ padding: { xs: "20px", sm: "40px 50px" } }}
      >
        <Grid container spacing={{ xs: 2, sm: 3, md: 4, lg: 5 }}>
          <Grid item xs={12} sm={12} lg={6} minWidth="400px">
            <TextField
              fullWidth
              label="Meeting Name*"
              name="meetingName"
              placeholder="Meeting Name"
              helperText={errors.meetingName}
              value={meetingDetails?.meetingName || ""}
              onChange={handleInputChange}
              variant="outlined"
              error={!!errors.meetingName}
              disabled={meetingMode === "Reschedule"}
              slotProps={{
                input: {
                  startAdornment: (
                    <InputAdornment position="start">
                      <EventNoteOutlined />
                    </InputAdornment>
                  ),
                },
              }}
              sx={{
                "& .MuiInputBase-root": {
                  fontSize: { xs: "0.875rem", sm: "1rem" },
                },
              }}
            />
          </Grid>
          <Grid item xs={12} sm={12} lg={6} minWidth="400px">
            <Autocomplete
              options={employees}
              loading={true}
              getOptionLabel={(option) => option.label}
              value={selectedEmployeesSchedule[0] || null}
              onChange={(_, newValue) => handleScheduledBySelection(newValue)}
              disabled={meetingMode === "Reschedule"}
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="Scheduled By*"
                  variant="outlined"
                  error={!!errors.scheduledBy}
                  helperText={errors.scheduledBy}
                  slotProps={{
                    input: {
                      ...params.InputProps,
                      startAdornment: (
                        <InputAdornment position="start">
                          <AssignmentIndOutlined />
                        </InputAdornment>
                      ),
                    },
                  }}
                  sx={{
                    "& .MuiInputBase-root": {
                      fontSize: { xs: "0.875rem", sm: "1rem" },
                    },
                  }}
                />
              )}
            />
          </Grid>
          <Grid item xs={12} sm={12} lg={6} minWidth="400px">
            <TextField
              fullWidth
              label="Location"
              name="location"
              placeholder="Location"
              value={meetingDetails?.location || ""}
              onChange={handleInputChange}
              variant="outlined"
              error={!!errors.locationOrLink}
              helperText={errors.locationOrLink}
              disabled={meetingMode === "Reschedule"}
              slotProps={{
                input: {
                  startAdornment: (
                    <InputAdornment position="start">
                      <LocationOnOutlined />
                    </InputAdornment>
                  ),
                },
              }}
              sx={{
                "& .MuiInputBase-root": {
                  fontSize: { xs: "0.875rem", sm: "1rem" },
                },
              }}
            />
          </Grid>
          <Grid item xs={12} sm={12} lg={6} minWidth="400px">
            <DatePicker
              open={openDatePicker}
              onOpen={() => setOpenDatePicker(true)}
              onClose={() => setOpenDatePicker(false)}
              label="Meeting Date*"
              value={
                meetingDetails?.meetingDate
                  ? new Date(meetingDetails.meetingDate)
                  : null
              }
              onChange={handleDateChange}
              format="dd/MM/yyyy"
              slotProps={{
                textField: {
                  fullWidth: true,
                  variant: "outlined",
                  error: !!errors.date,
                  helperText: errors.date,
                  disabled: meetingMode === "Edit",
                  InputProps: {
                    startAdornment: (
                      <InputAdornment position="start">
                        <IconButton onClick={() => setOpenDatePicker(true)}>
                          <EventOutlined />
                        </IconButton>
                      </InputAdornment>
                    ),
                    endAdornment: <></>,
                  },
                  sx: {
                    "& .MuiInputBase-root": {
                      fontSize: { xs: "0.875rem", sm: "1rem" },
                    },
                  },
                },
              }}
            // minDate={new Date()}
            />
          </Grid>
          <Grid item xs={12} sm={12} lg={6} minWidth="400px">
            <TimePicker
              label="From Time*"
              value={parseTimeString(meetingDetails?.fromTime)}
              onChange={(time) => handleTimeChange("fromTime", time)}
              disabled={meetingMode === "Edit"}
              open={openTimePicker === "from"}
              onOpen={() => setOpenTimePicker("from")}
              onClose={() => setOpenTimePicker("")}
              slots={{
                openPickerIcon: AccessTime,
              }}
              slotProps={{
                textField: {
                  fullWidth: true,
                  variant: "outlined",
                  error: !!errors.fromTime,
                  helperText: errors.fromTime,
                  InputProps: {
                    startAdornment: (
                      <InputAdornment position="start">
                        <IconButton
                          edge="start"
                          onClick={() => setOpenTimePicker("from")}
                        >
                          <AccessTime />
                        </IconButton>
                      </InputAdornment>
                    ),
                    endAdornment: null,
                  },
                  sx: {
                    "& .MuiInputBase-root": {
                      fontSize: { xs: "0.875rem", sm: "1rem" },
                    },
                    "& .MuiInputAdornment-root.MuiInputAdornment-positionEnd": {
                      display: "none",
                    },
                  },
                },
              }}
            />
          </Grid>
          <Grid item xs={12} sm={12} lg={6} minWidth="400px">
            <TimePicker
              label="To Time*"
              value={parseTimeString(meetingDetails?.toTime)}
              onChange={(time) => handleTimeChange("toTime", time)}
              disabled={meetingMode === "Edit"}
              open={openTimePicker === "to"}
              onOpen={() => setOpenTimePicker("to")}
              onClose={() => setOpenTimePicker("")}
              slots={{
                openPickerIcon: AccessTime,
              }}
              slotProps={{
                textField: {
                  fullWidth: true,
                  variant: "outlined",
                  error: !!errors.toTime,
                  helperText: errors.toTime,
                  InputProps: {
                    startAdornment: (
                      <InputAdornment position="start">
                        <IconButton
                          edge="start"
                          onClick={() => setOpenTimePicker("to")}
                        >
                          <AccessTime />
                        </IconButton>
                      </InputAdornment>
                    ),
                    endAdornment: null,
                  },
                  sx: {
                    "& .MuiInputBase-root": {
                      fontSize: { xs: "0.875rem", sm: "1rem" },
                    },
                    "& .MuiInputAdornment-root.MuiInputAdornment-positionEnd": {
                      display: "none",
                    },
                  },
                },
              }}
            />
          </Grid>

          <Grid item xs={12} sm={12} lg={6} minWidth="400px">
            <Autocomplete
              multiple
              options={segmentOptions}
              getOptionLabel={(option) => option.label}
              value={selectedSegment}
              onChange={(_, newValue) => handleSegmentSelection(newValue)}
              disabled={meetingMode === "Reschedule"}
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="Segments*"
                  variant="outlined"
                  error={!!errors.segment}
                  helperText={errors.segment}
                  slotProps={{
                    input: {
                      ...params.InputProps,
                      startAdornment: (
                        <>
                          <InputAdornment position="start">
                            <CategoryOutlined />
                          </InputAdornment>
                          {params.InputProps.startAdornment}
                        </>
                      ),
                    },
                  }}
                  sx={{
                    "& .MuiInputBase-root": {
                      fontSize: { xs: "0.875rem", sm: "1rem" },
                    },
                  }}
                />
              )}

            />
          </Grid>
          <Grid item xs={12} sm={12} lg={6} minWidth="400px">
            <TextField
              fullWidth
              label="Link"
              name="link"
              placeholder="Meeting Link"
              value={meetingDetails?.link || ""}
              onChange={handleInputChange}
              variant="outlined"
              error={!!errors.locationOrLink}
              helperText={errors.locationOrLink}
              disabled={meetingMode === "Reschedule"}
              slotProps={{
                input: {
                  startAdornment: (
                    <InputAdornment position="start">
                      <LinkOutlined />
                    </InputAdornment>
                  ),
                },
              }}
              sx={{
                "& .MuiInputBase-root": {
                  fontSize: { xs: "0.875rem", sm: "1rem" },
                },
              }}
            />
          </Grid>
          <Grid item xs={12} sm={12} lg={6} minWidth="400px">
            <Autocomplete
              multiple
              options={employees}
              loading={true}
              getOptionLabel={(option) => option.label}
              value={selectedEmployees}
              onChange={(_, newValue) => handleEmployeeSelection(newValue)}
              disabled={meetingMode === "Reschedule"}
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="Attendees*"
                  variant="outlined"
                  error={!!errors.attendees}
                  helperText={errors.attendees}
                  slotProps={{
                    input: {
                      ...params.InputProps,
                      startAdornment: (
                        <>
                          <InputAdornment position="start">
                            <PeopleOutline />
                          </InputAdornment>
                          {params.InputProps.startAdornment}
                        </>
                      ),
                    },
                  }}
                  sx={{
                    "& .MuiInputBase-root": {
                      fontSize: { xs: "0.875rem", sm: "1rem" },
                    },
                  }}
                />
              )}
            />
          </Grid>
          <Grid item xs={12} sm={12} lg={6} minWidth="400px">
            <Autocomplete
              multiple
              options={departmentOptions}
              getOptionLabel={(option) => option.label}
              value={selectedDepartment}
              onChange={(_, newValue) => handleDepartmentSelection(newValue)}
              disabled={meetingMode === "Reschedule"}
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="Departments*"
                  variant="outlined"
                  error={!!errors.department}
                  helperText={errors.department}
                  slotProps={{
                    input: {
                      ...params.InputProps,
                      startAdornment: (
                        <>
                          <InputAdornment position="start">
                            <ApartmentOutlined />
                          </InputAdornment>
                          {params.InputProps.startAdornment}
                        </>
                      ),
                    },
                  }}
                  sx={{
                    "& .MuiInputBase-root": {
                      fontSize: { xs: "0.875rem", sm: "1rem" },
                    },
                  }}
                />
              )}
            />
          </Grid>
          <Grid item xs={12} sm={12} lg={6} minWidth="400px">
            <TextField
              fullWidth
              label="Agenda*"
              name="agenda"
              placeholder="Agenda"
              value={meetingDetails?.agenda || ""}
              onChange={handleInputChange}
              variant="outlined"
              multiline
              maxRows={3}
              error={!!errors.agenda}
              helperText={
                errors.agenda ||
                `${meetingDetails?.agenda?.length || 0} / 5000 characters used`
              }
              disabled={meetingMode === "Reschedule"}
              slotProps={{
                input: {
                  startAdornment: (
                    <InputAdornment position="start">
                      <DescriptionOutlined />
                    </InputAdornment>
                  ),
                  inputProps: { maxLength: 5000 },
                },
              }}
              sx={{
                "& .MuiInputBase-root": {
                  fontSize: { xs: "0.875rem", sm: "1rem" },
                  resize: "vertical",
                  minHeight: "56px",
                },
                "& .MuiInputBase-input": {
                  overflow: "auto",
                },
              }}
            />
          </Grid>
          <Grid item xs={12} sm={12} lg={6} minWidth="400px">
            <TextField
              fullWidth
              label="Remarks"
              name="remarks"
              placeholder="Remarks"
              value={meetingDetails?.remarks || ""}
              onChange={handleInputChange}
              variant="outlined"
              multiline
              maxRows={3}
              helperText={
                errors.remarks ||
                `${meetingDetails?.remarks?.length || 0} / 5000 characters used`
              }
              disabled={meetingMode === "Reschedule"}
              slotProps={{
                input: {
                  startAdornment: (
                    <InputAdornment position="start">
                      <NotesOutlined />
                    </InputAdornment>
                  ),
                  inputProps: { maxLength: 5000 },
                },
              }}
              sx={{
                "& .MuiInputBase-root": {
                  fontSize: { xs: "0.875rem", sm: "1rem" },
                  resize: "vertical",
                  minHeight: "56px",
                },
                "& .MuiInputBase-input": {
                  overflow: "auto",
                },
              }}
            />
          </Grid>

        </Grid>
      </Box>
    </CustomModal>
  );
};

export default ScheduleGeneralMeeting;
