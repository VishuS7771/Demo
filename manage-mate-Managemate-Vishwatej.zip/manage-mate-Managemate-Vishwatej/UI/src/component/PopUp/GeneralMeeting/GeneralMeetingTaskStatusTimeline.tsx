import React, { useState, useEffect, useRef } from "react";
import {
  Slide,
  Paper,
  IconButton,
  Box,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Pagination,
  Tooltip,
} from "@mui/material";
import { GridCloseIcon } from "@mui/x-data-grid";
import dayjs from "dayjs";
import { Empty } from "antd";
import { getGeneralMeetingTimeline } from "../../../Requests/GeneralMeetingRequest";
import { MeetingTimelineData } from "../../../Interfaces/Generalmeeting";
import { StatusChip } from "../../Chip/StatusChip";
import { tooltipProps } from "../../../util/constants/commonStyles";

interface TaskStatusTimelineProps {
  open: boolean;
  setOpen: (value: boolean) => void;
  generalMeetingId: number | undefined;
}

interface TimelineRow {
  key: string;
  status: string;
  name: string;
  markedBy: string;
  markedOn: string;
  meetingTaskSubStatus?: string;
  meetingName?: string;
}

const GeneralMeetingTaskStatusTimeline: React.FC<TaskStatusTimelineProps> = ({
  open,
  setOpen,
  generalMeetingId,
}) => {
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize] = useState(8);
  const [timelineData, setTimelineData] = useState<TimelineRow[]>([]);
  const [loading, setLoading] = useState(false);
  const sliderRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open || generalMeetingId === undefined) return;

    setLoading(true);
    getGeneralMeetingTimeline(generalMeetingId)
      .then((response: MeetingTimelineData) => {
        const flatData: TimelineRow[] = [];

        response.meetingStatusMark.forEach((mark, index) => {
          flatData.push({
            key: `statusMark-${index}-${mark.markedOn}`,
            name: mark.meetingName,
            status: mark.status,
            markedBy: mark.markedBy,
            markedOn: mark.markedOn,
          });
        });

        response.generalMeetingTask.forEach((taskGroup, groupIndex) => {
          const taskStatuses = taskGroup.meetingTaskStatus ?? [];
          taskStatuses.forEach((task, taskIndex) => {
            flatData.push({
              key: `taskStatus-${groupIndex}-${taskIndex}-${task.markedOn}`,
              name: task.taskStatus,
              status: task.meetingTaskSubStatus || "-",
              meetingTaskSubStatus: task.meetingTaskSubStatus,
              markedBy: task.markedBy,
              markedOn: task.markedOn,
            });
          });
        });

        flatData.sort((a, b) => new Date(a.markedOn).getTime() - new Date(b.markedOn).getTime());

        setTimelineData(flatData);
      })
      .catch((error) => {
        console.error("Error fetching general meeting timeline:", error);
        setTimelineData([]);
      })
      .finally(() => {
        setLoading(false);
      });
  }, [open, generalMeetingId]);

  const paginatedData = timelineData.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize
  );


  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (sliderRef.current && !sliderRef.current.contains(event.target as Node)) {
        setOpen(false);
      }
    };

    if (open) {
      document.addEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [open, setOpen]);

  return (
    <Slide direction="left" in={open} mountOnEnter unmountOnExit>
      <Paper
        ref={sliderRef}
        onClick={(e) => e.stopPropagation()}
        sx={{
          position: "absolute",
          top: 0,
          right: 0,
          width: { sm: "100%", md: "100%", lg: 900, xl: 900 },
          height: "100%",
          display: "flex",
          flexDirection: "column",
          alignItems: "start",
          borderRadius: "15px 0 0 15px",
          boxShadow: 24,
          zIndex: 1,
          overflowY: "auto",
        }}
      >
        <IconButton
          onClick={() => setOpen(false)}
          sx={{
            position: "absolute",
            top: 10,
            left: 10,
            color: "grey.500",
            ":hover": {
              color: "red",
            },
          }}
        >
          <GridCloseIcon />
        </IconButton>
        <Box sx={{ p: 3, width: "100%" }}>
          <Typography
            variant="h6"
            component="div"
            align="center"
            gutterBottom
            sx={{ mb: 2, fontWeight: "bold", color: "rgb(73, 102, 131)" }}
          >
            General Meeting Task Status Timeline
          </Typography>

          {loading ? (
            <Typography variant="body1" align="center">Loading...</Typography>
          ) : timelineData.length > 0 ? (
            <>
              <TableContainer>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell sx={{ fontWeight: "bold", width: 90 }}>SR. NO</TableCell>
                      <TableCell sx={{ fontWeight: "bold", width: 150 }}>MEETING NAME</TableCell>
                      <TableCell sx={{ fontWeight: "bold", width: 100 }} align="center">STATUS</TableCell>
                      <TableCell sx={{ fontWeight: "bold", width: 200 }}>MARKED BY</TableCell>
                      <TableCell sx={{ fontWeight: "bold", width: 150 }}>DATE AND TIME</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {paginatedData.map((record, index) => (
                      <TableRow key={record.key}>
                        <TableCell align="center">{(currentPage - 1) * pageSize + index + 1}</TableCell>
                        <TableCell>{record.name || record.meetingName}</TableCell>
                        <TableCell align="center" sx={{ maxWidth: 120 }}>
                          <Tooltip title={record.status} {...tooltipProps} disableHoverListener={record.status.length <= 9} >
                            <span>
                              <StatusChip status={record.status} />
                            </span>
                          </Tooltip>
                        </TableCell>
                        <TableCell>{record.markedBy}</TableCell>
                        <TableCell>{dayjs(record.markedOn).format("DD MMM YYYY hh:mm A")}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
              <Box sx={{ display: "flex", justifyContent: "center", mt: 2 }}>
                <Pagination
                  count={Math.ceil(timelineData.length / pageSize)}
                  page={currentPage}
                  onChange={(_, page) => setCurrentPage(page)}
                  color="primary"
                />
              </Box>
            </>
          ) : (
            <Empty description="No Task Status Timeline Available" />
          )}
        </Box>
      </Paper>
    </Slide>
  );
};

export default GeneralMeetingTaskStatusTimeline;
