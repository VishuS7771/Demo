import React, { useState, useEffect } from "react";
import { MultiValue } from "react-select";
import { getAllEmployees } from "../../../Requests/MeetingRequest";
import Select, { components } from "react-select";
import { EmployeeOption, GeneralMeetingTaskDto, SegmentOption, TaskValidationError } from "../../../Interfaces/Generalmeeting";
import { toast, ToastContainer } from "react-toastify";
import { validateTask } from "../../../util/validations/generalMeeting";
import { EditGeneralMeetingTask } from "../../../Requests/GeneralMeetingRequest";
import { defaultTask, departmentsData, segmentsData } from "../../../util/constants/generalMeeting";
import {
    Box,
    TextField,
    Typography,
    Button,
    IconButton,
    CircularProgress,
    InputAdornment,
    Grid,
    Autocomplete,
} from "@mui/material";
import { ApartmentOutlined, CategoryOutlined } from "@mui/icons-material";
import PersonIcon from '@mui/icons-material/Person';
import DescriptionIcon from '@mui/icons-material/Description';
import NotesIcon from '@mui/icons-material/Notes';
import EventIcon from '@mui/icons-material/Event';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import moment from "moment";
import { LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterMoment } from "@mui/x-date-pickers/AdapterMoment";
import CustomModal from "../../Modal/CustomModal/CustomModal";

// Custom Control component for react-select to add icon
const CustomControl = ({ children, ...props }: any) => (
    <components.Control {...props}>
        <PersonIcon style={{ marginLeft: '10px', color: '#757575', fontSize: '20px' }} />
        {children}
    </components.Control>
);

interface MeetingStatusUIPopupProps {
    handleEditTaskModal: () => void;
    selectedTask: GeneralMeetingTaskDto | null;
    toast: typeof toast;
    meetingId?: string;
    refreshTasks: () => void;

}


interface DepartmentOption {
    value: number;
    label: string;
}


const EditGeneralTaskModal: React.FC<MeetingStatusUIPopupProps> = ({ selectedTask, meetingId, handleEditTaskModal, toast, refreshTasks }) => {
    const employeeNo = localStorage.getItem("employeeNo") || "";
    const [employees, setEmployees] = useState<EmployeeOption[]>([]);
    const [taskErrors, setTaskErrors] = useState<TaskValidationError>({});
    const [task, setTask] = useState<GeneralMeetingTaskDto>({ ...defaultTask, completionDate: "", createdBy: employeeNo });
    const [isRemarkFocused, setIsRemarkFocused] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [dateOpen, setDateOpen] = useState(false);
    const [selectedSegment, setSelectedSegment] = useState<SegmentOption[]>([]);
    const [selectedDepartment, setSelectedDepartment] = useState<DepartmentOption[]>([]);

    const handleEmployeeSelection = (selectedOptions: MultiValue<EmployeeOption>): void => {
        const employeeIds = selectedOptions.map(option => option.value);
        setTask({ ...task, employeeIds });
    };

    const handleTaskChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        if (name === "remark") {
            if (value.length <= 200) {
                setTask({ ...task, [name]: value });
            }
        } else {
            setTask({ ...task, [name]: value });
        }
    };

    const handleDateChange = (date: any) => {
        setTask((prev) => ({
            ...prev,
            targetDate: date ? moment(date).format("YYYY-MM-DD") : "",
        }));
    };

    const handleSubmit = async () => {
        const isValid = validateTask(task, setTaskErrors);
        if (!isValid) return;

        setIsLoading(true);
        try {
            const response = await EditGeneralMeetingTask(task);
            if (response.httpStatus === "OK") {
                setTask({ ...defaultTask, completionDate: "", createdBy: employeeNo });
                toast.success(response?.message || "Task updated successfully");
                handleEditTaskModal();
                refreshTasks();
            } else {
                toast.error("Failed to update task");
            }
        } catch (error) {
            toast.error("An error occurred while updating the task");
        } finally {
            setIsLoading(false);
        }
    };

    const formatDate = (dateString: string): string => {
        return new Date(dateString).toISOString().split("T")[0];
    };

    const handleSegmentSelection = (newValue: SegmentOption[]) => {
        if (!newValue) {
            setSelectedSegment([]);
            return;
        }
        setSelectedSegment(newValue);

        console.log("newValue ", newValue)
        const selectedSegments = newValue.map((option) => ({
            id: option.value,
            name: option.label,
        }));
        setTask({ ...task, segmentDtos: selectedSegments });

        // setMeetingDetails((prevDetails) => {
        //   if (!prevDetails) return null;
        //   return { ...prevDetails, segmentDtos: selectedSegments };
        // });
        // setErrors((prevErrors) => ({ ...prevErrors, segment: "" }));
    };

    const handleDepartmentSelection = (newValue: DepartmentOption[]) => {
        setSelectedDepartment(newValue);
        const selectedDepartmentDtos = newValue.map((option) => ({
            id: option.value,
            name: option.label,
        }));

        setTask({ ...task, departmentDtos: selectedDepartmentDtos });

        // setMeetingDetails((prevDetails) => {
        //   if (!prevDetails) return null;
        //   return { ...prevDetails, departmentDtos: selectedDepartmentDtos };
        // });
        // setErrors((prevErrors) => ({ ...prevErrors, department: "" }));
    };

    useEffect(() => {
        if (employees.length === 0) {
            const fetchEmployees = async () => {
                setIsLoading(true);
                try {
                    const data = await getAllEmployees();
                    const employeeOptions = data.map((employee: { employeeId: number; employeeFullName: string }) => ({
                        value: employee.employeeId,
                        label: employee.employeeFullName,
                    }));
                    setEmployees(employeeOptions);

                    const selectedEmployeeOptions = data
                        .filter((employee: { employeeId: number }) =>
                            selectedTask?.meetingTaskAssigneeDtos?.some(
                                (participant: { empId: number }) => participant.empId == employee.employeeId
                            )
                        )
                        .map((employee: { employeeId: number; employeeFullName: string }) => employee.employeeId);

                    if (selectedTask) {

                        const departmentDto = selectedTask?.departmentDtos?.map((d) => ({
                            value: d.id,
                            label: d.name,
                        }));
                        const segmentDto = selectedTask?.segmentDtos?.map((s) => ({
                            value: s.id,
                            label: s.name,
                        }));
                        setSelectedDepartment(departmentDto);
                        setSelectedSegment(segmentDto);

                        const updatedTask: GeneralMeetingTaskDto = {
                            generalMeetingTaskId: selectedTask.generalMeetingTaskId,
                            generalMeetingName:"",
                            taskName: selectedTask.taskName,
                            remark: selectedTask.remark,
                            targetDate: formatDate(selectedTask.targetDate),
                            createdOn: formatDate(selectedTask.createdOn),
                            status: selectedTask.status,
                            createdBy: selectedTask.createdBy,
                            generalMeetingId: selectedTask.generalMeetingId,
                            meetingTaskAssigneeDtos: selectedTask.meetingTaskAssigneeDtos,
                            employeeIds: selectedEmployeeOptions,
                            completionDate: selectedTask.completionDate,
                            departmentDtos: departmentDto?.map((d) => ({ id: d.value, name: d.label })),
                            segmentDtos: segmentDto?.map((s) => ({ id: s.value, name: s.label })),

                        };

                        setTask(updatedTask);
                    }
                } catch (error) {
                    console.error("Error fetching employees:", error);
                    toast.error("Failed to load employees");
                } finally {
                    setIsLoading(false);
                }
            };

            fetchEmployees();
        }
    }, []);


    return (
        <CustomModal open={true} onClose={handleEditTaskModal} title="Edit Tasks" actions={
            <Button
                variant="contained"
                color="primary"
                onClick={handleSubmit}
                sx={{ borderRadius: '8px', textTransform: 'none', minWidth: '150px', py: 1 }}
                disabled={isLoading}
                loading={isLoading}
            >
                 Submit
            </Button>
        }>
            {isLoading ? (
                <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '300px' }}>
                    <CircularProgress />
                </Box>
            ) : (
                <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', pt: 2 }}>
                    <Grid container spacing={5}>
                        {/* Left Side: Task Name and Remark */}
                        <Grid item xs={12} md={6}>
                            <Box mb={5}>
                                <TextField
                                    fullWidth
                                    name="taskName"
                                    value={task.taskName}
                                    onChange={handleTaskChange}
                                    placeholder="Enter task name"
                                    variant="outlined"
                                    label="Task Name*"
                                    InputProps={{
                                        startAdornment: (
                                            <InputAdornment position="start">
                                                <IconButton edge="start">
                                                    <DescriptionIcon color="action" />
                                                </IconButton>
                                            </InputAdornment>
                                        ),
                                    }}
                                    sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
                                    error={!!taskErrors?.taskName}
                                    helperText={taskErrors.taskName}
                                />

                            </Box>

                            <Box mb={5}>
                                <TextField
                                    fullWidth
                                    multiline
                                    name="remark"
                                    value={task.remark}
                                    onChange={handleTaskChange}
                                    onFocus={() => setIsRemarkFocused(true)}
                                    onBlur={() => setIsRemarkFocused(false)}
                                    placeholder="Enter remarks*"
                                    maxRows={3}
                                    variant="outlined"
                                    label="Remarks*"
                                    inputProps={{ maxLength: 200 }}
                                    error={!!taskErrors.remark || task.remark.length >= 200}
                                    helperText={
                                        taskErrors.remark
                                            ? taskErrors.remark
                                            : isRemarkFocused && `${task.remark.length} / 200`
                                    }
                                    InputProps={{
                                        startAdornment: (
                                            <InputAdornment position="start">
                                                <IconButton edge="start">
                                                    <NotesIcon color="action" />
                                                </IconButton>
                                            </InputAdornment>
                                        ),
                                    }}
                                    sx={{
                                        '& .MuiOutlinedInput-root': {
                                            borderRadius: '8px',
                                            maxHeight: '100px',
                                            overflow: 'hidden',
                                            '& textarea': {
                                                height: '80px',
                                                overflowY: 'auto',
                                                resize: 'none',
                                            },
                                        },
                                    }}
                                />

                            </Box>

                            {
                                !meetingId &&
                                <Box>


                                    <Autocomplete
                                        multiple
                                        options={segmentsData}
                                        getOptionLabel={(option) => option.label}
                                        value={selectedSegment}
                                        onChange={(_, newValue) => handleSegmentSelection(newValue)}
                                        renderInput={(params) => (
                                            <TextField
                                                {...params}
                                                label="Segments*"
                                                variant="outlined"
                                                error={!!taskErrors.segment}
                                                helperText={taskErrors.segment}
                                                slotProps={{
                                                    input: {
                                                        ...params.InputProps,
                                                        startAdornment: (
                                                            <>
                                                                <InputAdornment position="start">
                                                                    <CategoryOutlined />
                                                                </InputAdornment>
                                                                {params.InputProps.startAdornment}
                                                            </>
                                                        ),
                                                    },
                                                }}
                                                sx={{
                                                    "& .MuiInputBase-root": {
                                                        fontSize: { xs: "0.875rem", sm: "1rem", borderRadius: "8px" },
                                                    },
                                                }}
                                            />
                                        )}

                                    />

                                </Box>
                            }


                        </Grid>

                        {/* Right Side: Employee Name and Target Date */}
                        <Grid item xs={12} md={6}>
                            <Box mb={5}>
                                <LocalizationProvider dateAdapter={AdapterMoment}>
                                    <DatePicker
                                        label="Target Date*"
                                        value={task.targetDate ? moment(task.targetDate) : null}
                                        onChange={handleDateChange}
                                        open={dateOpen}
                                        onOpen={() => setDateOpen(true)}
                                        onClose={() => setDateOpen(false)}
                                        slotProps={{
                                            textField: {
                                                fullWidth: true,
                                                InputProps: {
                                                    startAdornment: (
                                                        <InputAdornment position="start">
                                                            <IconButton edge="start" onClick={() => setDateOpen(true)}>
                                                                <EventIcon color="action" />
                                                            </IconButton>
                                                        </InputAdornment>
                                                    ),
                                                    endAdornment: null,
                                                },
                                                sx: {
                                                    '& .MuiInputAdornment-root.MuiInputAdornment-positionEnd': {
                                                        display: 'none',
                                                    },
                                                    '& .MuiOutlinedInput-root': {
                                                        borderRadius: '8px',
                                                    },
                                                },
                                            },
                                        }}
                                    />
                                </LocalizationProvider>
                                {taskErrors.targetDate && (
                                    <Typography variant="caption" color="error">
                                        { }
                                    </Typography>
                                )}
                            </Box>

                            <Box mb={5}>
                                <Select
                                    isMulti
                                    options={employees}
                                    value={employees.filter((emp) => task.employeeIds.includes(emp.value))}
                                    onChange={handleEmployeeSelection}
                                    placeholder="Select Employee*"
                                    components={{ Control: CustomControl }}
                                    menuPortalTarget={document.body}
                                    styles={{
                                        control: (base) => ({
                                            ...base,
                                            borderRadius: '8px',
                                            border: '1px solid rgba(0, 0, 0, 0.23)',
                                            minHeight: '56px',
                                            maxHeight: '100px',
                                            overflowY: 'auto',
                                            padding: '0 8px',
                                        }),
                                        valueContainer: (base) => ({
                                            ...base,
                                            overflowY: 'auto',
                                            maxHeight: '90px',
                                            padding: '2px 8px',
                                        }),
                                        menuPortal: (base) => ({ ...base, zIndex: 9999 }),
                                    }}
                                />
                                {taskErrors.employeeIds && (
                                    <Typography variant="caption" color="error">
                                        {taskErrors.employeeIds}
                                    </Typography>
                                )}
                            </Box>


                            {!meetingId &&
                                <Box>

                                    <Autocomplete
                                        multiple
                                        options={departmentsData}
                                        getOptionLabel={(option) => option.label}
                                        value={selectedDepartment}
                                        onChange={(_, newValue) => handleDepartmentSelection(newValue)}
                                        renderInput={(params) => (
                                            <TextField
                                                {...params}
                                                label="Departments*"
                                                variant="outlined"
                                                error={!!taskErrors.department}
                                                helperText={taskErrors.department}
                                                slotProps={{
                                                    input: {
                                                        ...params.InputProps,
                                                        startAdornment: (
                                                            <>
                                                                <InputAdornment position="start">
                                                                    <ApartmentOutlined />
                                                                </InputAdornment>
                                                                {params.InputProps.startAdornment}
                                                            </>
                                                        ),
                                                    },
                                                }}
                                                sx={{
                                                    "& .MuiInputBase-root": {
                                                        fontSize: { xs: "0.875rem", sm: "1rem", borderRadius: "8px" },
                                                    },
                                                }}
                                            />
                                        )}
                                    />

                                </Box>}

                        </Grid>

                    </Grid>
                </Box>

            )}
            <ToastContainer />
        </CustomModal>
    );
};

export default EditGeneralTaskModal;