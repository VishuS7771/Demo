import React, { useEffect, useState } from "react";
import {
    Modal,
    Box,
    IconButton,
    Typography,
    Grid,
    CircularProgress,
    Alert,
    List,
    ListItem,
    ListItemText,
    Avatar,
    ListItemAvatar
} from "@mui/material";
import { Clear } from "@mui/icons-material";
import { getParticipantsByMeetingId } from "../../Requests/MeetingRequest";
import { Empty } from "antd";

interface AttendeesPopupProps {
    id: number;
    onClose: () => void;
}

const AttendeesPopup: React.FC<AttendeesPopupProps> = ({ id, onClose }) => {
    const [attendees, setAttendees] = useState<{ participantName: string, employeeImgUrl: string }[]>([]);
    const [loading, setLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const fetchAttendees = async () => {
            try {
                setLoading(true);
                const response = await getParticipantsByMeetingId(id);
                if (Array.isArray(response)) {
                    setAttendees(response.map((p: any) => ({ employeeImgUrl: p.employeeImgUrl, participantName: p.participantName })));
                }
                setError(null);
            } catch (err) {
                setError("Failed to fetch attendees. Please try again.");
            } finally {
                setLoading(false);
            }
        };

        if (id) fetchAttendees();
    }, [id]);

    return (
        <Modal
            open={true}
            onClose={onClose}
            aria-labelledby="attendees-modal-title"
            aria-describedby="attendees-modal-description"
        >
            <Box
                sx={{
                    position: "absolute",
                    top: "50%",
                    left: "50%",
                    transform: "translate(-50%, -50%)",
                    width: { xs: "90%", sm: "80%", md: "70%", lg: 600 },
                    maxWidth: "95vw",
                    bgcolor: "background.paper",
                    boxShadow: 24,
                    borderRadius: "10px",
                    maxHeight: "90vh",
                    overflow: "auto",
                }}
            >
                <Box
                    sx={{
                        display: "flex",
                        justifyContent: "end",
                        p: { xs: 1, sm: 1 },
                    }}
                >
                    <IconButton
                        onClick={onClose}
                        sx={{
                            color: "grey.500",
                            ":hover": { color: "red" },
                        }}
                    >
                        <Clear />
                    </IconButton>
                </Box>

                <Box
                    sx={{
                        p: { xs: 1, sm: 3 },
                        minWidth: { xs: 300, sm: 500 },
                        width: { xs: "100%", sm: 600 },
                        boxSizing: "border-box",
                        mb: 4,
                        mt: -5,
                    }}
                >
                    <Grid container spacing={2}>
                        <Grid item xs={12}>
                            <Typography
                                variant="subtitle1"
                                sx={{
                                    fontWeight: "bold",
                                    fontSize: { sm: "1.3rem" },
                                    color: "text.primary",
                                }}
                            >
                                Meeting Attendees
                            </Typography>

                            {loading ? (
                                <Box display="flex" justifyContent="center" mt={2}>
                                    <CircularProgress />
                                </Box>
                            ) : error ? (
                                <Alert severity="error" sx={{ mt: 2 }}>
                                    {error}
                                </Alert>
                            ) : (
                                <List sx={{ mt: 2 }}>
                                    {attendees.length > 0 ? (
                                        attendees.map((attendee, index) => (
                                            <ListItem key={index} divider>
                                                <ListItemAvatar>
                                                    <Avatar
                                                        src={attendee.employeeImgUrl}
                                                        alt={attendee.participantName}
                                                        sx={{ width: 40, height: 40 }}
                                                    />
                                                </ListItemAvatar>
                                                <ListItemText primary={attendee.participantName} />
                                            </ListItem>
                                        ))
                                    ) : (
                                         <Empty description="No any Attendees available" />
                                    )}
                                </List>
                            )}
                        </Grid>
                    </Grid>
                </Box>
            </Box>
        </Modal>
    );
};

export default AttendeesPopup;