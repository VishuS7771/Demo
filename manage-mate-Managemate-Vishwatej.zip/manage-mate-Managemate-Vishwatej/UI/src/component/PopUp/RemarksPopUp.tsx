import React, { useEffect, useState } from "react";
import {
    Box,
    IconButton,
    Modal,
    Typography,
    Grid,
    CircularProgress,
    Alert,
} from "@mui/material";
import { Clear } from "@mui/icons-material";
import { getMeetingById } from "../../Requests/MeetingRequest";

interface RemarksPopUp {
    meetingId: string;
    onClose: () => void;
}

const RemarksPopUp: React.FC<RemarksPopUp> = ({ meetingId, onClose }) => {
    const [description, setDescription] = useState<string | null>(null);
    const [loading, setLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);

    const fetchMeetingMomLink = async (id: string) => {
        try {
            setLoading(true);
            const response = await getMeetingById(id);
            setDescription(response.remarks || "");
            setError(null);
        } catch (err) {
            setError("Failed to fetch meeting details. Please try again.");
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchMeetingMomLink(meetingId);
    }, [meetingId]);

    return (
        <Modal
            open={true}
            onClose={onClose}
            aria-labelledby="remarks-modal-title"
            aria-describedby="remarks-modal-description"
        >
            <Box
                sx={{
                    position: "absolute",
                    top: "50%",
                    left: "50%",
                    transform: "translate(-50%, -50%)",
                    width: { xs: "90%", sm: "80%", md: "70%", lg: 800 },
                    maxWidth: "95vw",
                    bgcolor: "background.paper",
                    boxShadow: 24,
                    borderRadius: "10px",
                    maxHeight: "90vh",
                    overflow: "auto",
                }}
            >
                <Box
                    sx={{
                        display: "flex",
                        justifyContent: "end",
                        p: { xs: 1, sm: 1 },
                    }}
                >
                    <IconButton
                        onClick={onClose}
                        sx={{
                            color: "grey.500",
                            ":hover": { color: "red" },
                        }}
                    >
                        <Clear />
                    </IconButton>
                </Box>
                <Box
                    sx={{
                        p: { xs: 1, sm: 3 },
                        minWidth: { xs: 300, sm: 400 },
                        minHeight: { xs: 100, sm: 300 },
                        width: { xs: "100%", sm: 780 },
                        height: { xs: "auto", sm: 200 },
                        boxSizing: "border-box",
                        mb: 4,
                        mt: -5,
                    }}
                >
                    <Grid container spacing={2}>
                        <Grid item xs={12}>
                            <Typography
                                variant="subtitle1"
                                sx={{
                                    fontWeight: "bold",
                                    color: "text.primary",
                                    fontSize: { sm: "1.3rem" },
                                }}
                            >
                                Meeting Remarks :
                            </Typography>
                            {loading ? (
                                <Box sx={{ display: "flex", justifyContent: "center", mt: 2 }}>
                                    <CircularProgress />
                                </Box>
                            ) : error ? (
                                <Alert severity="error" sx={{ mt: 2 }}>
                                    {error}
                                </Alert>
                            ) : (
                                <Typography
                                    mt={1}
                                    ml={3}
                                    variant="body1"
                                    sx={{
                                        fontSize: { xs: "0.875rem", sm: "1rem" },
                                        color: "text.primary",
                                        whiteSpace: "pre-wrap",
                                        wordBreak: "break-word",
                                    }}
                                >
                                    {description || "N/A"}
                                </Typography>
                            )}
                        </Grid>
                    </Grid>
                </Box>
            </Box>
        </Modal>
    );
};

export default RemarksPopUp;