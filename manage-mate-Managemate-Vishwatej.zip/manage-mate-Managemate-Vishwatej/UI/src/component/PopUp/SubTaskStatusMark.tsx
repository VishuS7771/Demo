import React, { useState, useEffect } from "react";
import {
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    IconButton,
    Button,
    TextField,
    FormControl,
    MenuItem,
    SelectChangeEvent,
    InputAdornment,
    Grid,
    Typography,
} from "@mui/material";
import {
    SubTaskStatusMarkDto,
    Task,
} from "../../Interfaces/Task";
import { EmployeeData } from "../../Interfaces/Login";
import { markSubTaskStatus } from "../../Requests/TaskRequest";
import { toast } from "react-toastify";
import { DescriptionOutlined, LowPriorityOutlined, Save, Refresh, Clear } from "@mui/icons-material";

interface PopupProps {
    isVisible: boolean;
    onClose: (error: boolean) => void;
    task: Task | null;
    onSave: (task: Task) => void;
}

const SubTaskStatusMark: React.FC<PopupProps> = ({ isVisible, onClose, task, onSave }) => {
    const [status, setStatus] = useState<string>("");
    const [remark, setRemark] = useState<string>("");
    const [employee, setEmployee] = useState<EmployeeData | null>(null);
    const [errors, setErrors] = useState<{ [key: string]: string }>({});

    useEffect(() => {
        if (task) {
            const storedData = localStorage.getItem("employeedata");
            if (storedData) {
                const parsedData = JSON.parse(storedData);
                setEmployee(parsedData);
            }
        }
    }, [task]);

    const handleStatusChange = (e: React.ChangeEvent<{ value: unknown }> | SelectChangeEvent<string>) => {
        const selectedStatus = e.target.value as string;;
        setStatus(selectedStatus);
        setErrors((prevErrors) => ({ ...prevErrors, status: "" }));
    };

    const handleRemarkChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        setRemark(value);
        setErrors((prevErrors) => ({ ...prevErrors, remark: "" }));
    };

    const validateForm = (): boolean => {
        const newErrors: { [key: string]: string } = {};

        if (!status) {
            newErrors.status = "Status is required";
        }
        // if (!remark.trim()) {
        //     newErrors.remark = "Remark is required";
        // }
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleClose = () => {
        setStatus("");
        setRemark("");
        setErrors({});
        onClose(false);
    };

    const handleSave = async () => {
        if (!validateForm()) {
            return;
        }

        if (task && employee) {
            const subTaskStatusMark: SubTaskStatusMarkDto = {
                subTaskStatusMarkId: 1,
                markedStatus: status,
                statusMarkedBy: Number(employee.EmployeeNo),
                tasksDto: task,
                remark: remark,
                statusMarkedDate: new Date(),
            };
            try {
                await markSubTaskStatus(subTaskStatusMark);
                onSave(task);
                toast.success("Sub Task Status Marked successfully");
                handleClose();
            } catch (error) {
                toast.error(`Error marking status: ${error}`);
            }
        }
    };

    return (
        <Dialog
            open={isVisible}
            onClose={handleClose}
            aria-labelledby="subtask-status-dialog-title"
            aria-describedby="subtask-status-dialog-description"
            PaperProps={{
                sx: {
                    width: { xs: "90%", sm: "80%", md: "70%", lg: 600 },
                    maxWidth: "95vw",
                    borderRadius: "10px",
                    maxHeight: "90vh",
                },
            }}
        >
            <DialogTitle
                sx={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    p: { xs: 2, sm: 3 },
                    borderBottom: 1,
                    borderColor: "#4a4848",
                }}
            >
                <Typography
                    id="subtask-status-dialog-title"
                    variant="h5"
                    sx={{ fontWeight: "bold" }}
                >
                    Change Status for Task {task?.taskId}
                </Typography>
                <IconButton
                    onClick={handleClose}
                    sx={{
                        color: "grey.500",
                        ":hover": { color: "red" },
                    }}
                >
                    <Clear />
                </IconButton>
            </DialogTitle>
            <DialogContent
                sx={{ padding: { xs: "20px 30px", sm: "40px 110px" }, mb: 0 }}
            >
                <Grid container spacing={{ xs: 2, sm: 3, md: 4, lg: 5 }} >
                    <Grid item xs={12} sm={6} minWidth={"400px"} mt={5}>
                        <FormControl fullWidth variant="outlined" error={!!errors.status}>
                            <TextField
                                select
                                label="Status"
                                value={status}
                                onChange={handleStatusChange}
                                error={!!errors.status}
                                helperText={errors.status}
                                slotProps={{
                                    input: {
                                        startAdornment: (
                                            <InputAdornment position="start">
                                                <LowPriorityOutlined />
                                            </InputAdornment>
                                        ),
                                    }
                                }}
                                sx={{
                                    "& .MuiInputBase-root": {
                                        fontSize: { xs: "0.875rem", sm: "1rem" },
                                    },
                                }}
                            >
                                <MenuItem value="">
                                    <em>Select Status</em>
                                </MenuItem>
                                <MenuItem value="Not Started">Not Started</MenuItem>
                                <MenuItem value="In Progress">In Progress</MenuItem>
                                <MenuItem value="Completed">Completed</MenuItem>
                            </TextField>
                        </FormControl>
                    </Grid>
                    <Grid item xs={12} sm={6} minWidth={"400px"}>
                        <TextField
                            fullWidth
                            label="Remark"
                            value={remark}
                            onChange={handleRemarkChange}
                            placeholder="Enter remark"
                            multiline
                            maxRows={5}
                            error={!!errors.remark}
                            helperText={
                                errors.remark ||
                                `${remark.length} / 5000 characters used`
                            }
                            slotProps={{
                                input: {
                                    startAdornment: (
                                        <InputAdornment position="start">
                                            <DescriptionOutlined />
                                        </InputAdornment>
                                    ),
                                    inputProps: { maxLength: 5000 }
                                }
                            }}
                            sx={{
                                "& .MuiInputBase-root": {
                                    fontSize: { xs: "0.875rem", sm: "1rem" },
                                    resize: "vertical",
                                    minHeight: "56px",
                                },
                                "& .MuiInputBase-input": {
                                    overflow: "auto",
                                },
                            }}
                        />
                    </Grid>
                </Grid>
                <Grid container spacing={{ xs: 1, sm: 2, md: 4, lg: 5 }} >
                    <DialogActions
                        sx={{
                            padding: { sm: "10px 55px" },
                            gap: 2,
                            flexWrap: "wrap",
                            mt: 8
                        }}
                    >
                        <Button
                            type="submit"
                            variant="contained"
                            color="primary"
                            startIcon={<Save />}
                            onClick={handleSave}
                            sx={{
                                px: { xs: 2, sm: 3 },
                                py: 1,
                                fontSize: { xs: "0.75rem", sm: "0.875rem" },
                                textTransform: "none",
                                minWidth: { xs: "120px", sm: "140px" },
                            }}
                        >
                            Save Changes
                        </Button>
                        <Button
                            type="button"
                            variant="outlined"
                            color="secondary"
                            startIcon={<Refresh />}
                            onClick={handleClose}
                            sx={{
                                px: { xs: 2, sm: 3 },
                                py: 1,
                                fontSize: { xs: "0.75rem", sm: "0.875rem" },
                                textTransform: "none",
                                minWidth: { xs: "120px", sm: "140px" },
                            }}
                        >
                            Cancel
                        </Button>
                    </DialogActions>
                </Grid>
            </DialogContent>
        </Dialog>
    );
};

export default SubTaskStatusMark;
