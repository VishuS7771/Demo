import {
  Dialog,
  DialogTitle,
  DialogContent,
  IconButton,
  Typography,
  Avatar,
  Box,
  Card,
  CardContent,
} from "@mui/material";
import Grid from "@mui/material/Grid2";
import {
  BusinessOutlined,
  WorkOutline,
  EmailOutlined,
  PhoneOutlined,
  HomeOutlined,
  CalendarTodayOutlined,
  BadgeOutlined,
  CloseOutlined,
} from "@mui/icons-material";
import { EmployeeData } from "../../Interfaces/Login";
import { motion } from "framer-motion";

const ProfilePopup = ({ employee, isVisible, onClose }: {
  employee: EmployeeData | null;
  isVisible: boolean;
  onClose: () => void;
}) => {
  if (!employee) return null;

  const infoItems = [
    { label: "Date of Birth", value: employee.BirthDate, icon: <CalendarTodayOutlined fontSize="small" /> },
    { label: "Mobile Number", value: employee.MobileNo1, icon: <PhoneOutlined fontSize="small" /> },
    { label: "Employee ID", value: employee.EmployeeNo, icon: <BadgeOutlined fontSize="small" /> },
    { label: "Joining Date", value: employee.JoiningDate, icon: <CalendarTodayOutlined fontSize="small" /> },
    { label: "Email", value: employee.CompanyEmail, icon: <EmailOutlined fontSize="small" /> },
    { label: "Address", value: employee.CurrentAddress, icon: <HomeOutlined fontSize="small" /> },
  ];

  return (
    <Dialog
      open={isVisible}
      onClose={onClose}
      maxWidth="sm"
      fullWidth
      PaperProps={{
        component: motion.div,
        initial: { opacity: 0, y: 50 },
        animate: { opacity: 1, y: 0 },
        transition: { duration: 0.5, ease: "easeOut" },
        sx: { borderRadius: "10px", overflow: "hidden", backgroundColor: "#f1f5f9" },
      }}
    >
      <DialogTitle

        sx={{
          display: "flex",
          justifyContent: "flex-end",
          p: 1,
        }}
      >
        <IconButton
          onClick={onClose}
          sx={{
            color: "#1e293b",
            ":hover": { color: "red" },
          }}
        >
          <CloseOutlined fontSize="small" />
        </IconButton>
      </DialogTitle>

      <DialogContent sx={{ padding: "24px", backgroundColor: "#f1f5f9" }}>
        <Box
          display="flex"
          flexDirection="column"
          alignItems="center"
          sx={{ textAlign: "center", mb: 4 }}
        >
          <Avatar
            src={employee.ImageUrl || "/default-avatar.png"}
            sx={{
              width: 100,
              height: 100,
              mb: 2,
              boxShadow: "0 4px 12px rgba(0, 0, 0, 0.1)",
            }}
          />
          <Typography variant="h5" fontWeight={700} color="rgb(73, 102, 131)">
            {employee.EmployeeFullName || "N/A"}
          </Typography>
          <Typography
            variant="body1"
            color="#64748b"
            display="flex"
            alignItems="center"
            gap={1}
            mt={1}
          >
            <WorkOutline fontSize="small" /> {employee.Designation || "N/A"}
            <BusinessOutlined fontSize="small" sx={{ ml: 2 }} /> {employee.DepartmentName || "N/A"}
          </Typography>
        </Box>

        <Grid container spacing={2}>
          {infoItems.map((item, index) => (
            <Grid size={{ xs: 12, sm: 6 }} key={index}>
              <Card
                sx={{
                  backgroundColor: "white",
                  borderRadius: "12px",
                  boxShadow: "0 2px 8px rgba(0, 0, 0, 0.05)",
                  height: "100%",
                }}
              >
                <CardContent sx={{ padding: "12px 16px" }}>
                  <Typography
                    variant="body1"
                    fontWeight={600}
                    display="flex"
                    alignItems="center"
                    gap={1}
                    color="#1e293b"
                  >
                    {item.icon} {item.label}
                  </Typography>
                  <Typography variant="body2" color="#64748b" mt={0.5}>
                    {item.value || "N/A"}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      </DialogContent>
    </Dialog>
  );
};

export default ProfilePopup;