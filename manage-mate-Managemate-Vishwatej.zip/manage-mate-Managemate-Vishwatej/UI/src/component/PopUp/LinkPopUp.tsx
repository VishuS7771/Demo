import React, { useState, useEffect } from "react";
import { Box, IconButton, Modal, Typography, Grid } from "@mui/material";
import { Clear } from "@mui/icons-material";
import { getMeetingById } from "../../Requests/MeetingRequest";

interface LinkPopUpProps {
  meetingId: string;
  onClose: () => void;
}

const LinkPopUp: React.FC<LinkPopUpProps> = ({ meetingId, onClose }) => {
  const [link, setLink] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchMeetingLink = async (id: string) => {
    try {
      setLoading(true);
      const response = await getMeetingById(id);
      setLink(response.link || "");
      setError(null);
    } catch (err) {
      setError("Failed to fetch meeting details. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMeetingLink(meetingId);
  }, [meetingId]);

  return (
    <Modal
      open={true}
      onClose={onClose}
      aria-labelledby="link-modal-title"
      aria-describedby="link-modal-description"
    >
      <Box
        sx={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          width: { xs: "90%", sm: "80%", md: "70%", lg: 800 },
          maxWidth: "95vw",
          bgcolor: "background.paper",
          boxShadow: 24,
          borderRadius: "10px",
          maxHeight: "90vh",
          overflow: "auto",
        }}
      >
        <Box
          sx={{
            display: "flex",
            justifyContent: "end",
            p: { xs: 1, sm: 1 },
          }}
        >
          <IconButton
            onClick={onClose}
            sx={{
              color: "grey.500",
              ":hover": { color: "red" },
            }}
          >
            <Clear />
          </IconButton>
        </Box>
        <Box
          sx={{
            p: { xs: 1, sm: 2 },
            minWidth: { xs: 300, sm: 400 },
            minHeight: { xs: 100, sm: 100 },
            width: { xs: "100%", sm: 780 },
            height: { xs: "auto", sm: 200 },
            boxSizing: "border-box",
            mt: -5,
          }}
        >
          <Grid container spacing={3}>
            <Grid item xs={12} ml={2}>
              <Typography
                variant="subtitle1"
                sx={{
                  fontWeight: "bold",
                  color: "text.primary",
                  fontSize: { sm: "1.3rem" },
                }}
              >
                Meeting Link :
              </Typography>
              <Typography
                mt={1}
                ml={3}
                variant="body1"
                sx={{
                  fontSize: { xs: "0.875rem", sm: "1.1rem" },
                  color: "text.primary",
                  whiteSpace: "pre-wrap",
                  wordBreak: "break-word",
                }}
              >
                {loading ? (
                  "Loading..."
                ) : error ? (
                  <span style={{ color: "red" }}>{error}</span>
                ) : link ? (
                  <a href={link} target="_blank" rel="noopener noreferrer">
                    {link}
                  </a>
                ) : (
                  "No link available"
                )}
              </Typography>
            </Grid>
          </Grid>
        </Box>
      </Box>
    </Modal>
  );
};

export default LinkPopUp;