import React, { useEffect, useState, useRef } from "react";
import { GeneralMeetingTaskDto, TaskRespondDto } from "../../Interfaces/Generalmeeting";
import { FaEdit, FaReply, FaCheck, FaEllipsisH, FaClock, FaRegCalendarCheck, FaPlusCircle, FaSearch, FaEye } from "react-icons/fa";
import {
    MarkingMeetingTask,
    RespondMeetingTask,
    getRespondAndMarking,
    updateCompletionDate,
    getGeneralTasks
} from "../../Requests/GeneralMeetingRequest";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import dayjs from "dayjs";
import { DownloadOutlined, Close, Upload, Group, CancelOutlined } from "@mui/icons-material";
import AddTaskPopup from "../PopUp/GeneralMeeting/AddTaskPopup";
import EditGeneralTaskModal from "../PopUp/GeneralMeeting/EditGeneralTaskPopup";
import { Box, Button, Paper, Table as MuiTable, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography, Pagination, IconButton, Tooltip, Popover, Dialog, DialogTitle, DialogContent, DialogActions, TextField, Table as MuiTableComponent, TableHead as MuiTableHead, TableRow as MuiTableRow, TableCell as MuiTableCell, TableBody as MuiTableBody, CircularProgress, Select, MenuItem, FormControl, InputLabel, List, ListItem, ListItemAvatar, Avatar, ListItemText, TableSortLabel } from "@mui/material";
import { downLoadDocument } from "../../Requests/TaskRequest";
import MeetingsTraySlider from "../Slider/GeneralMeeting/MeetingsTraySlider";
import { DatePicker } from "@mui/x-date-pickers";
import moment from "moment";
import { Empty } from "antd";
import { getAllEmployees } from "../../Requests/MeetingRequest";
import { GridFilterListIcon } from "@mui/x-data-grid";
import { employeesType, SearchCriteria, searchGeneralTaskCriteriaProps } from "../../Interfaces/Task";
import TableSkeleton from "../Skeletons/Skeleton";
import { getIconButtonStyle } from "../../util/constants/commonStyles";
import CustomModal from "../Modal/CustomModal/CustomModal";
import { actionButtonStyle, employeeCellStyles, iconButtonStyles, Search, SearchIconWrapper, StyledInputBase, tooltipProps } from "../../util/constants/commonStyles";
import { StatusChip } from "../Chip/StatusChip";
import { usePageLoader } from "../../context/PageLoaderContext";

interface ActionButton {
    title: string;
    icon: React.ReactNode;
    color: string;
    handler: () => void;
    disabled?: boolean;
}

interface Employee {
    empId: number;
    employeeName: string;
    employeeImgUrl: string;
}
const MyTasks: React.FC = () => {

    const [tasks, setTasks] = useState<GeneralMeetingTaskDto[]>([]);
    const [showModal, setShowModal] = useState(false);
    const [selectedTask, setSelectedTask] = useState<GeneralMeetingTaskDto | null>(null);
    const [remarks, setRemarks] = useState("");
    const [file, setFile] = useState<File | null>(null);
    const [fileName, setFileName] = useState<string>("");
    const [taskDetails, setTaskDetails] = useState<TaskRespondDto[]>([]);
    const [loadingDetails, setLoadingDetails] = useState(false);

    const [showMarkingModal, setShowMarkingModal] = useState(false);
    const [markingRemarks, setMarkingRemarks] = useState("");
    const [selectedStatus, setSelectedStatus] = useState("");
    const [showAddTaskModal, setShowAddTaskModal] = useState(false);
    const [showEditTaskModal, setShowEditTaskModal] = useState(false);
    const [showUpdateCompletionDateModal, setShowUpdateCompletionDateModal] = useState(false);
    const [meetingStatus, setMeetingStatus] = useState("");

    const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null);
    const [selectedTaskForActions, setSelectedTaskForActions] = useState<GeneralMeetingTaskDto | null>(null);

    // State for the info modal
    const [showInfoModal, setShowInfoModal] = useState(false);
    const [infoContent, setInfoContent] = useState<string>("");
    const [infoTitle, setInfoTitle] = useState<string>("");
    const [showSegmentModal, setShowSegmentModal] = useState(false);
    const [infoEmployees, setInfoEmployees] = useState<Employee[]>([]);
    const [completionDate, setCompletionDate] = useState<Date | null>(null);

    const employeeData = JSON.parse(localStorage.getItem("employeedata") ?? "{}");
    const employeeNo = employeeData?.EmployeeNo;

    const [currentPage, setCurrentPage] = useState(1);
    const itemsPerPage = 10;

    const fileInputRef = useRef<HTMLInputElement>(null);
    const [currentSlider, setCurrentSlider] = useState<string>("");
    const [open, setOpen] = useState(false);
    const [allEmployees, setAllEmployees] = useState<employeesType[]>([]);
    const [showTableLoading, setShowTableLoading] = useState(false);
    const { showLoader, hideLoader } = usePageLoader();

    // completion date validations

    const [errors, setErrors] = useState({ date: '', remarks: '' });

    // search criterias

    // const [showSearchCriterias, setShowSearchCriterias] = useState(false);
    const [searchCriteria, setSearchCriteria] = useState<searchGeneralTaskCriteriaProps>({
        taskName: "",
        employeeName: "",
        employeeId: null,
        taskAssignee: "",
        taskAssigneeId: null,
        status: [],
    });

    // search filter criteria

    const [searchFilterCriteria, setSearchFilterCriteria] = useState<SearchCriteria>({
        meetingName: "",
        taskName: "",
        assignedDateFrom: "",
        assignedDateTo: "",
        targetDateFrom: "",
        targetDateTo: "",
        completionDateFrom: "",
        completionDateTo: "",
        statuses: [],
        employees: [],
        assignees: [],
        segments: [],
        departments: [],
        isOverdue: false,
    });

    const [filteredTasks, setFilteredTasks] = useState<GeneralMeetingTaskDto[]>([]);

    // column wise sorting
    const [orderDirection, setOrderDirection] = useState<'asc' | 'desc'>('asc');
    const [orderBy, setOrderBy] = useState<string>("");


    const handleSortRequest = (property: 'targetDate' | 'completionDate') => {
        const isAsc = orderBy === property && orderDirection === 'asc';
        const newOrderDirection = isAsc ? 'desc' : 'asc';
        setOrderDirection(newOrderDirection);
        setOrderBy(property);

        const sortedTasks = [...filteredTasks].sort((a, b) => {
            const dateA = a[property];
            const dateB = b[property];

            if (dateA === null && dateB === null) return 0;
            if (dateA === null) return 1;
            if (dateB === null) return -1;

            const timeA = new Date(dateA).getTime();
            const timeB = new Date(dateB).getTime();

            return newOrderDirection === 'asc' ? timeA - timeB : timeB - timeA;
        });

        setFilteredTasks(sortedTasks);
    };
    const toggleDrawer = (newOpen: boolean) => {
        setOpen(newOpen);
    }

    const toggleFilters = () => {
        // setShowFilters(prev => !prev);
        setCurrentSlider("searchTasks");
        toggleDrawer(true);
    };


    const clickTimelineHistory = (task: GeneralMeetingTaskDto) => {
        setSelectedTask(task);
        setCurrentSlider("timeline");
        toggleDrawer(true);
    };

    const fetchTasks = () => {
        setShowTableLoading(true);
        getGeneralTasks(Number(employeeNo), true)
            .then((data) => {
                const sortedData = data.slice().sort((a: { createdOn: string }, b: { createdOn: string }) => {
                    return new Date(b.createdOn).getTime() - new Date(a.createdOn).getTime();
                });
                setTasks(sortedData);
                setFilteredTasks(sortedData);
                handleSearchClear();
            })
            .catch((error) => console.error("Error fetching tasks:", error));
        getAllEmployees()
            .then((data) => {
                if (data) {
                    setAllEmployees(data);
                }
                setMeetingStatus(data.meetingStatus);
                setShowTableLoading(false);

            })
            .catch((error) => console.error("Error fetching meetings:", error));
    };

    const employeeMap = new Map(
        (allEmployees as { employeeId: number | string; employeeFullName: string }[]).map(emp => [
            emp.employeeId,
            emp.employeeFullName,
        ])
    );

    // Optimized lookup function
    const getEmployeeFullName = (employeeId: string) => {
        return employeeMap.get(employeeId) || null;
    };

    const checkIsAssignee = (task: GeneralMeetingTaskDto): boolean => {
        const parsedEmployee = Number(employeeNo);
        if (task?.meetingTaskAssigneeDtos?.length) {
            return task.meetingTaskAssigneeDtos.some(
                participant => participant.empId === parsedEmployee
            );
        }
        return false;
    };

    const getEmployeeCount = (task: GeneralMeetingTaskDto): number => {
        return task.meetingTaskAssigneeDtos === null ? 0 : task.meetingTaskAssigneeDtos.length;
    };

    const handleReplyClick = (task: GeneralMeetingTaskDto) => {
        setSelectedTask(task);
        setRemarks("");
        setFile(null);
        setFileName("");
        setShowModal(true);
        fetchTaskDetails(task.generalMeetingTaskId);
    };

    const fetchTaskDetails = async (taskId: number) => {
        try {
            setLoadingDetails(true);
            const res = await getRespondAndMarking(taskId);
            setTaskDetails(res || []);
            console.log('res: ', res);
        } catch (error) {
            console.error("Failed to fetch task details:", error);
        } finally {
            setLoadingDetails(false);
        }
    };

    const handleMarkingClick = (task: GeneralMeetingTaskDto) => {
        setSelectedTask(task);
        setMarkingRemarks("");
        setSelectedStatus("");
        setShowMarkingModal(true);
        fetchTaskDetails(task.generalMeetingTaskId);
    };

    const handleAddTaskModal = () => {
        setShowAddTaskModal(!showAddTaskModal);
        // if (showAddTaskModal) {
        //     fetchTasks();
        // }
    };

    const handleEditTaskModal = () => {
        setShowEditTaskModal(!showEditTaskModal);
    };

    const handleCompletiondateModal = (task: GeneralMeetingTaskDto) => {
        setErrors({ date: '', remarks: '' });
        setSelectedTask(task);
        setCompletionDate(task?.completionDate ? new Date(task?.completionDate) : null)
        setShowUpdateCompletionDateModal(!showUpdateCompletionDateModal);
    };

    const handleMarkingSubmit = () => {
        if (!selectedTask) {
            return;
        }
        if (selectedStatus === "") {
            toast.error("Select status");
            return;
        }
        if (markingRemarks === "") {
            toast.error("Enter remarks");
            return;
        }
        showLoader();
        const taskResponse: TaskRespondDto = {
            taskRespondId: 0,
            remark: markingRemarks,
            respondedBy: employeeNo?.toString() ?? "Unknown",
            respondedOn: new Date().toISOString(),
            filePath: "",
            Marking: false,
            Respond: true,
            meetingTaskId: selectedTask.generalMeetingTaskId,
            status: selectedStatus
        };
        MarkingMeetingTask(taskResponse)
            .then((res) => {
                if (res.httpStatus === "OK") {
                    toast.success("Task marked successfully!");
                }
                else {
                    toast.error(res?.message || "Failed to mark task.");
                }
                setShowMarkingModal(false);
                fetchTasks();
            })
            .catch(() => {
                toast.error("Failed to mark task.");
            }).finally(() => {
                hideLoader();
            });
        setShowMarkingModal(false);
        setSelectedStatus("");
        setMarkingRemarks("");
    };

    const handleSubmit = () => {
        if (!selectedTask || remarks === "") {
            toast.error("Remarks not added");
            return;
        }
        const taskResponse: TaskRespondDto = {
            taskRespondId: 0,
            remark: remarks,
            respondedBy: employeeNo?.toString() ?? "Unknown",
            respondedOn: new Date().toISOString(),
            filePath: "",
            Marking: false,
            Respond: true,
            meetingTaskId: selectedTask.generalMeetingTaskId,
            status: "Responded"
        };

        RespondMeetingTask(taskResponse, file)
            .then((res) => {
                if (res.httpStatus === "OK") {
                    toast.success("Task responded successfully!");
                    setShowModal(false);
                    fetchTasks();
                } else {
                    toast.error(res.message || "Failed to respond to task.");
                }
            })
            .catch(() => {
                toast.error("Failed to respond to task due to a network or server error.");
            });

    };

    const handleDownload = (filePath: string) => {
        if (filePath) {
            downLoadDocument(filePath);
        }
    };

    const getTaskDetailsColumns = () => [
        {
            title: "Sr. No.",
            render: (_: any, __: any, index: number) => index + 1,
            align: "center" as const,
            width: 70,
        },
        {
            title: "Remarks",
            dataIndex: "remark",
            align: "center" as const,
            width: 100,
        },
        {
            title: "Responded/Marked By",
            dataIndex: "respondedBy",
            align: "center" as const,
            width: 150,
        },
        {
            title: "Responded/Marked On",
            dataIndex: "respondedOn",
            render: (text: string) => dayjs(text).format("DD MMM YYYY hh:mm A"),
            align: "center" as const,
            width: 150,
        },
        {
            title: "Status",
            dataIndex: "status",
            align: "center" as const,
            width: 100,
        },
        {
            title: "Attachment",
            dataIndex: "filePath",
            render: (filePath: string) =>
                filePath ? (
                    <IconButton onClick={() => handleDownload(filePath)} title="Download File">
                        <DownloadOutlined sx={{ fontSize: 18, color: "#1890ff" }} />
                    </IconButton>
                ) : (
                    "No File"
                ),
            align: "center" as const,
            width: 100,
        },
    ];

    const handleClear = () => {
        setRemarks("");
        setFile(null);
        setFileName("");
        if (fileInputRef.current) {
            fileInputRef.current.value = "";
        }
    };

    const handleSearchClear = () => {
        setSearchCriteria({
            taskName: "",
            employeeName: "",
            employeeId: null,
            taskAssignee: "",
            taskAssigneeId: null,
            status: [],
        });
        setFilteredTasks(tasks);
    };

    const handleMarkingClear = () => {
        setMarkingRemarks("");
        setSelectedStatus("");
    };

    const handleCompletiondateClear = () => {
        setRemarks("");
        setErrors({ date: '', remarks: '' });
        setCompletionDate(null);
    }

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files.length > 0) {
            const selectedFile = e.target.files[0];
            setFile(selectedFile);
            setFileName(selectedFile.name);
        }
    };

    const handleInfoClick = (content: string, title: string, employees?: Employee[]) => {
        setInfoContent(content);
        setInfoTitle(title);
        setInfoEmployees(employees || []);
        setShowInfoModal(true);
    };

    const currentItems = filteredTasks.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

    const totalPages = Math.ceil(filteredTasks.length / itemsPerPage);

    const handlePageChange = (__: React.ChangeEvent<unknown>, pageNumber: number) => {
        setCurrentPage(pageNumber);
    };

    const handleOpenPopover = (event: React.MouseEvent<HTMLButtonElement>, task: GeneralMeetingTaskDto) => {
        setSelectedTaskForActions(task);
        setAnchorEl(event.currentTarget);
    };

    const handleClosePopover = () => {
        setAnchorEl(null);
        setSelectedTaskForActions(null);
    };

    const actionButtons = (task: GeneralMeetingTaskDto): ActionButton[] => [
        {
            title: "Edit",
            icon: <FaEdit />,
            color: "info",
            handler: () => {
                setSelectedTask(task);
                handleEditTaskModal();
            },
            disabled: !(employeeNo == task.createdBy) || task.status !== "Task Assigned"
        },
        {
            title: "Respond",
            icon: <FaReply />,
            color: "warning",
            handler: () => handleReplyClick(task),
            disabled: !checkIsAssignee(task)
        },
        {
            title: "Marking",
            icon: <FaCheck />,
            color: "success",
            handler: () => handleMarkingClick(task),
            disabled: !(employeeNo == task.createdBy) || task.status === "Task Assigned"
        },
        {
            title: "Timeline", icon: <FaClock />, color: "warning",
            handler: () => clickTimelineHistory(task)
        },
        {
            title: "Update Completion Date", icon: <FaRegCalendarCheck />, color: "primary",
            handler: () => handleCompletiondateModal(task),
            disabled: !checkIsAssignee(task)
        }
    ];

    const updateCompletiondate = async () => {
        const newErrors = { date: '', remarks: '' };
        const originalDate = selectedTask?.completionDate ? new Date(selectedTask.completionDate).toISOString() : null;

        // Validate completion date
        if (!completionDate) {
            newErrors.date = 'Completion date is required.';
        } else if (completionDate.toISOString() === originalDate) {
            newErrors.date = 'Please choose a different date.';
        }

        // Validate remarks
        if (!remarks.trim() && selectedTask?.completionDate) {
            newErrors.remarks = 'Remarks cannot be empty.';
        }

        setErrors(newErrors);

        const isValid = !newErrors.date && !newErrors.remarks;

        if (!isValid) return;


        try {
            const response = await updateCompletionDate({
                completionDate: completionDate || new Date(),
                generalMeetingTaskId: selectedTask?.generalMeetingTaskId!,
                markedBy: employeeData?.EmployeeFullName,
                remarks: remarks
            });
            if (response.httpStatus === "OK") {
                toast.success(response?.message || "Completion date updated successfully");
                console.log("emp data ", employeeData)
                setShowUpdateCompletionDateModal(false);
                fetchTasks();
            }
            else
                toast.error("Error updating completion date");
        } catch (error) {
            console.error('Error updating completion date:', error);
            toast.error("Error updating completion date");
            throw error;
        }
    };
    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setSearchCriteria((prev) => ({ ...prev, [name]: value }));
    };

    const handleSearch = () => {
        const filtered = tasks.filter((task) => {
            if (!searchCriteria.taskName) return true;

            return task.taskName
                ?.toLowerCase()
                .includes(searchCriteria.taskName.toLowerCase());
        });

        setFilteredTasks(filtered);
        setCurrentPage(1);
    };


    const respondToTaskModalContent = <>
        {taskDetails.length > 0 && (
            <Box sx={{ mb: 3, p: 2, backgroundColor: '#f9f9f9', borderRadius: '6px' }}>
                <Typography variant="subtitle1" fontWeight="bold" mb={1}>
                    Respond/Marking
                </Typography>
                {loadingDetails ? (
                    <Box display="flex" justifyContent="center" alignItems="center" minHeight="100px">
                        <CircularProgress />
                    </Box>
                ) : (
                    <TableContainer sx={{ overflowX: 'hidden' }}>
                        <MuiTableComponent sx={{ tableLayout: 'fixed', width: '100%' }}>
                            <MuiTableHead>
                                <MuiTableRow sx={{ backgroundColor: '#f0f0f0' }}>
                                    {getTaskDetailsColumns().map((column) => (
                                        <MuiTableCell
                                            key={column.title}
                                            align={column.align}
                                            sx={{
                                                fontWeight: 'bold',
                                                width: column.width,
                                                whiteSpace: 'nowrap',
                                                overflow: 'hidden',
                                                textOverflow: 'ellipsis',
                                                padding: '8px'
                                            }}
                                        >
                                            {column.title}
                                        </MuiTableCell>
                                    ))}
                                </MuiTableRow>
                            </MuiTableHead>
                            <MuiTableBody>
                                {taskDetails.map((record, idx) => (
                                    <MuiTableRow key={`${record.meetingTaskId}-${idx}`}>
                                        <MuiTableCell
                                            align="center"
                                            sx={{
                                                whiteSpace: 'normal',
                                                wordBreak: 'break-word',
                                                padding: '8px'
                                            }}
                                        >
                                            {idx + 1}
                                        </MuiTableCell>
                                        <MuiTableCell
                                            align="center"
                                            sx={{
                                                whiteSpace: 'normal',
                                                wordBreak: 'break-word',
                                                padding: '8px'
                                            }}
                                        >
                                            {record.remark}
                                        </MuiTableCell>
                                        <MuiTableCell
                                            align="center"
                                            sx={{
                                                whiteSpace: 'normal',
                                                wordBreak: 'break-word',
                                                padding: '8px'
                                            }}
                                        >
                                            {record.respondedBy}
                                        </MuiTableCell>
                                        <MuiTableCell
                                            align="center"
                                            sx={{
                                                whiteSpace: 'normal',
                                                wordBreak: 'break-word',
                                                padding: '8px'
                                            }}
                                        >
                                            {dayjs(record.respondedOn).format("DD MMM YYYY hh:mm A")}
                                        </MuiTableCell>
                                        <MuiTableCell
                                            align="center"
                                            sx={{
                                                whiteSpace: 'normal',
                                                wordBreak: 'break-word',
                                                padding: '8px'
                                            }}
                                        >
                                            {record.status}
                                        </MuiTableCell>
                                        <MuiTableCell
                                            align="center"
                                            sx={{
                                                whiteSpace: 'normal',
                                                wordBreak: 'break-word',
                                                padding: '8px'
                                            }}
                                        >
                                            {record.filePath ? (
                                                <IconButton onClick={() => handleDownload(record.filePath)} title="Download File">
                                                    <DownloadOutlined sx={{ fontSize: 18, color: "#1890ff" }} />
                                                </IconButton>
                                            ) : (
                                                "No File"
                                            )}
                                        </MuiTableCell>
                                    </MuiTableRow>
                                ))}
                            </MuiTableBody>
                        </MuiTableComponent>
                    </TableContainer>
                )}
            </Box>
        )}

        {selectedTask?.status !== "Completed" && taskDetails[taskDetails.length - 1]?.status !== "Responded" && (
            <>
                <Box sx={{ mb: 2 }}>
                    <Typography variant="body1" mb={1} fontWeight="medium">
                        Remarks*
                    </Typography>
                    <TextField
                        fullWidth
                        multiline
                        rows={3}
                        value={remarks}
                        onChange={(e) => setRemarks(e.target.value)}
                        variant="outlined"
                        placeholder="Enter your remarks here..."
                        sx={{
                            '& .MuiOutlinedInput-root': {
                                borderRadius: '8px',
                                backgroundColor: '#fff',
                            },
                        }}
                    />
                </Box>
                <Box>
                    <Typography variant="body1" mb={1} fontWeight="medium">
                        Upload File
                    </Typography>
                    <Box display="flex" alignItems="center" gap={2}>
                        <Button
                            variant="outlined"
                            color="primary"
                            startIcon={<Upload />}
                            onClick={() => fileInputRef.current?.click()}
                            sx={{ borderRadius: '8px', textTransform: 'none' }}
                        >
                            Choose File
                        </Button>
                        <Typography variant="body2" color={fileName ? "textPrimary" : "textSecondary"}>
                            {fileName || "No file chosen"}
                        </Typography>
                        <input
                            type="file"
                            ref={fileInputRef}
                            onChange={handleFileChange}
                            style={{ display: 'none' }}
                        />
                    </Box>
                </Box>
            </>
        )}
    </>

    useEffect(() => {
        handleSearch();
    }, [searchCriteria]);

    useEffect(() => {
        fetchTasks();
    }, []);

    return (
        <Paper
            elevation={3}
            sx={{
                pb: 2,
                borderRadius: 2,
                overflow: 'hidden',
                position: 'relative',
                boxShadow: '',
            }}
            onClick={() => {
                if (open) {
                    setOpen(false);
                }
            }}
        >
            <ToastContainer />

            <Box display="flex" justifyContent="space-between" flexWrap="wrap" gap={2} px={5} mt={4} mb={3}>
                <Typography variant="h5" sx={{ fontWeight: 600 }} >General Tasks </Typography>
                <Button
                    size="small"
                    variant="contained"
                    onClick={handleAddTaskModal}
                    disabled={meetingStatus === "Closed" || meetingStatus === "Cancelled"}
                    sx={actionButtonStyle}
                    startIcon={<FaPlusCircle />}
                >
                    Add Tasks
                </Button>
            </Box>

            <Box display="flex" flexDirection={"row"} justifyContent="space-between" gap={8} px={3} mb={2} mt={1}>
                <Box display="flex" flexDirection={"row"} justifyContent="start" gap={3} height={5} visibility={true ? "visible" : "hidden"}>

                </Box>

                <Box display="flex" flexDirection={"row"} justifyContent="end">
                    <Search>
                        <SearchIconWrapper>
                            <IconButton></IconButton>
                            <FaSearch color="#9d9d9d" />
                        </SearchIconWrapper>
                        <StyledInputBase
                            placeholder="Search"
                            name="taskName"
                            value={searchCriteria.taskName}
                            onChange={handleInputChange}
                            inputProps={{ 'aria-label': 'search' }}
                        />
                        <IconButton
                            sx={{
                                position: 'absolute',
                                right: 4,
                                top: '50%',
                                transform: 'translateY(-50%)',
                                padding: '4px',
                                color: "lightgray"
                            }}
                            onClick={handleSearchClear}
                        >
                            <CancelOutlined fontSize="medium" />
                        </IconButton>
                    </Search>
                    <Tooltip title="Filter" {...tooltipProps}>
                        <IconButton sx={{ height: 35 }}
                            // onClick={() => setShowSearchCriterias(!showSearchCriterias)}
                            onClick={toggleFilters}
                        >
                            <GridFilterListIcon fontSize="medium" color="action" />
                        </IconButton>
                    </Tooltip>

                    <Button onClick={handleSearchClear} variant="outlined" size="small">Reset Search</Button>
                </Box>
            </Box>

            <TableContainer sx={{ minHeight: "63vh", mt: 2 }}>
                {
                    showTableLoading ? (
                        <TableSkeleton column={10} />
                    )
                        :
                        currentItems.length > 0
                            ?
                            (
                                <MuiTable size="small" sx={{ overflow: "scroll", minWidth: 1500 }}>
                                    <TableHead>
                                        <TableRow sx={{ background: "rgb(246, 247, 251)", height: 60 }}>
                                            <TableCell sx={{ fontWeight: "bold", width: { xs: 50, md: 100 }, textAlign: "center", whiteSpace: "nowrap" }}>SR. NO</TableCell>
                                            <TableCell sx={{ fontWeight: "bold", width: { xs: 80, md: 100 }, textAlign: "left", whiteSpace: "nowrap" }}>TASK NAME</TableCell>
                                            <TableCell sx={{ fontWeight: "bold", width: { xs: 120, md: 150 }, textAlign: "left", whiteSpace: "nowrap" }}>MEETING NAME</TableCell>
                                            <TableCell sx={{ fontWeight: "bold", width: { xs: 120, md: 150 }, textAlign: "left", whiteSpace: "nowrap" }}>TASK DETAILS</TableCell>
                                            <TableCell sx={{ fontWeight: "bold", width: { xs: 120, md: 150 }, textAlign: "left", whiteSpace: "nowrap" }}>TASK ASSIGNED BY</TableCell>
                                            <TableCell sx={{ fontWeight: "bold", width: { xs: 150, md: 210 }, textAlign: "center", whiteSpace: "nowrap" }}>EMPLOYEE NAME</TableCell>
                                            <TableCell sx={{ fontWeight: "bold", width: { xs: 140, md: 190 }, textAlign: "left", whiteSpace: "nowrap" }}>ASSIGNED DATE</TableCell>
                                            <TableCell
                                                sx={{ fontWeight: "bold", width: { xs: 120, md: 160 }, textAlign: "left", whiteSpace: "nowrap" }}
                                                sortDirection={orderBy === "targetDate" ? orderDirection : undefined}
                                            >
                                                <TableSortLabel
                                                    active={orderBy === "targetDate"}
                                                    direction={orderBy === "targetDate" ? orderDirection : "asc"}
                                                    onClick={() => handleSortRequest("targetDate")}
                                                >
                                                    TARGET DATE
                                                </TableSortLabel>
                                            </TableCell>
                                            <TableCell
                                                sx={{ fontWeight: "bold", width: { xs: 140, md: 200 }, textAlign: "left", whiteSpace: "nowrap" }}
                                                sortDirection={orderBy === "completionDate" ? orderDirection : undefined}
                                            >
                                                <TableSortLabel
                                                    active={orderBy === "completionDate"}
                                                    direction={orderBy === "completionDate" ? orderDirection : "asc"}
                                                    onClick={() => handleSortRequest("completionDate")}
                                                >
                                                    USER EXPECTED DATE
                                                </TableSortLabel>
                                            </TableCell>
                                            <TableCell sx={{ fontWeight: "bold", width: { xs: 40, md: 50 }, textAlign: "left", whiteSpace: "nowrap" }}>SEG/DEP</TableCell>
                                            <TableCell sx={{ fontWeight: "bold", width: { xs: 100, md: 150 }, textAlign: "center", whiteSpace: "nowrap" }}>STATUS</TableCell>
                                            <TableCell sx={{ fontWeight: "bold", width: { xs: 80, md: 100 }, textAlign: "center", whiteSpace: "nowrap" }}>ACTION</TableCell>
                                        </TableRow>

                                    </TableHead>
                                    <TableBody>
                                        {

                                            currentItems.map((task, index) => {
                                                const employeeName = getEmployeeFullName(task.createdBy);
                                                // Use a fallback for display and tooltip
                                                const displayName = employeeName ?? '---';
                                                return (
                                                    <TableRow key={index}>
                                                        <TableCell sx={{ textAlign: "center" }}>
                                                            {(currentPage - 1) * itemsPerPage + index + 1}
                                                        </TableCell>
                                                        <TableCell sx={{ textAlign: "left" }}>
                                                            <Tooltip title={task.taskName} {...tooltipProps}>
                                                                <span
                                                                    style={{
                                                                        display: 'inline-block',
                                                                        whiteSpace: 'nowrap',
                                                                        overflow: 'hidden',
                                                                        textOverflow: 'ellipsis',
                                                                        maxWidth: 100,
                                                                    }}

                                                                >{task.taskName}</span>
                                                            </Tooltip>
                                                        </TableCell>

                                                        <TableCell sx={{ textAlign: "left" }}>
                                                            <Tooltip title={task.generalMeetingName} {...tooltipProps}>
                                                                <span style={{
                                                                    display: 'inline-block',
                                                                    whiteSpace: 'nowrap',
                                                                    overflow: 'hidden',
                                                                    textOverflow: 'ellipsis',
                                                                    maxWidth: 100,
                                                                }}>{task.generalMeetingName}</span>
                                                            </Tooltip>
                                                        </TableCell>
                                                        <TableCell sx={{ textAlign: "left", whiteSpace: "normal", wordBreak: "break-word", maxWidth: 150 }}>
                                                            {task.remark.length > 15 ? (
                                                                <Tooltip title="Click to see more" {...tooltipProps}>
                                                                    <Typography
                                                                        variant="body2"
                                                                        sx={{
                                                                            maxWidth: "120px",
                                                                            whiteSpace: "nowrap",
                                                                            overflow: "hidden",
                                                                            textOverflow: "ellipsis",
                                                                            color: "rgb(73, 102, 131)",
                                                                            cursor: "pointer",
                                                                            "&:hover": {
                                                                                fontWeight: "bold",
                                                                                color: "Highlight",
                                                                            },
                                                                        }}
                                                                        onClick={() => handleInfoClick(task.remark, "Task Details:")}
                                                                    >
                                                                        {`${task.remark.substring(0, 50)}...`}
                                                                    </Typography>
                                                                </Tooltip>
                                                            ) : (
                                                                <Typography
                                                                    variant="body2"
                                                                    sx={{
                                                                        maxWidth: "120px",
                                                                        whiteSpace: "nowrap",
                                                                        overflow: "hidden",
                                                                        textOverflow: "ellipsis",
                                                                        color: "rgb(73, 102, 131)",
                                                                    }}
                                                                >
                                                                    {task.remark}
                                                                </Typography>
                                                            )}
                                                        </TableCell>

                                                        <TableCell sx={{ textAlign: "left" }}>
                                                            <Tooltip title={displayName} {...tooltipProps}>
                                                                <span
                                                                    style={{
                                                                        display: 'inline-block',
                                                                        whiteSpace: 'nowrap',
                                                                        overflow: 'hidden',
                                                                        textOverflow: 'ellipsis',
                                                                        maxWidth: 150,
                                                                    }}
                                                                >
                                                                    {displayName}
                                                                </span>
                                                            </Tooltip>
                                                        </TableCell>
                                                        <TableCell sx={{ textAlign: "center", maxWidth: 50 }}>
                                                            <Tooltip title="View Employee Names" {...tooltipProps}>
                                                                <Box
                                                                    sx={employeeCellStyles}
                                                                    onClick={() => getEmployeeCount(task) > 0 && handleInfoClick("", "Employee Names", task.meetingTaskAssigneeDtos)}
                                                                >


                                                                    <Typography variant="body2" color="rgb(73, 102, 131)">
                                                                        {getEmployeeCount(task)}
                                                                    </Typography>

                                                                    <IconButton
                                                                        sx={{
                                                                            color: "rgb(73, 102, 131)",
                                                                            padding: 0,
                                                                            ...iconButtonStyles
                                                                        }}
                                                                    >
                                                                        <Group fontSize="small" />
                                                                    </IconButton>

                                                                </Box>
                                                            </Tooltip>
                                                        </TableCell>
                                                        <TableCell sx={{ textAlign: "left" }}>
                                                            {task.createdOn ? moment(task.createdOn).format("DD MMMM YYYY") : "---"}
                                                        </TableCell>
                                                        <TableCell sx={{ textAlign: "left" }}>
                                                            {task.targetDate ? (
                                                                <span
                                                                    style={{
                                                                        color:
                                                                            !task.completionDate && moment(task.targetDate).isBefore(moment(), 'day') &&
                                                                            task.status !== "Completed"
                                                                                ? "red"
                                                                                : "inherit",
                                                                    }}
                                                                >
                                                                    {moment(task.targetDate).format("DD MMMM YYYY")}
                                                                </span>
                                                            ) : (
                                                                "---"
                                                            )}
                                                        </TableCell>

                                                        <TableCell sx={{ textAlign: "left" }}>
                                                            {task.completionDate ? (
                                                                <span
                                                                    style={{
                                                                        color:
                                                                            moment(task.completionDate).isBefore(moment(), 'day') &&
                                                                                !moment(task.completionDate).isSame(moment(), 'day') &&
                                                                                task.status !== "Completed"
                                                                                ? "red"
                                                                                : "inherit",
                                                                    }}
                                                                >
                                                                    {moment(task.completionDate).format("DD MMMM YYYY")}
                                                                </span>
                                                            ) : (
                                                                "---"
                                                            )}
                                                        </TableCell>

                                                        <TableCell align="center">
                                                            <Tooltip title="View" {...tooltipProps}>
                                                                <IconButton
                                                                    color="info"
                                                                    onClick={() => {
                                                                        setShowSegmentModal(true);
                                                                        setSelectedTask(task);

                                                                    }}
                                                                    sx={getIconButtonStyle("info")}
                                                                >
                                                                    <FaEye />
                                                                </IconButton>
                                                            </Tooltip>
                                                        </TableCell>

                                                        <TableCell sx={{ whiteSpace: "nowrap" }} align="center">
                                                            <Tooltip title={task.status} {...tooltipProps} disableHoverListener={task.status.length <= 10} >
                                                                <span> <StatusChip status={task.status} /></span>
                                                            </Tooltip>
                                                        </TableCell>


                                                        <TableCell sx={{ textAlign: "center" }}>
                                                            <Box display="flex" gap={1} sx={{ justifyContent: "center" }}>
                                                                <Tooltip title="More Actions" {...tooltipProps}>
                                                                    <IconButton
                                                                        color="default"
                                                                        onClick={(e) => handleOpenPopover(e, task)}
                                                                        sx={getIconButtonStyle("#bbbbbb")}
                                                                    >
                                                                        <FaEllipsisH color="#bbbbbb" />
                                                                    </IconButton>
                                                                </Tooltip>
                                                                <Popover
                                                                    open={Boolean(anchorEl && selectedTaskForActions?.generalMeetingTaskId === task.generalMeetingTaskId)}
                                                                    anchorEl={anchorEl}
                                                                    onClose={handleClosePopover}
                                                                    anchorOrigin={{
                                                                        vertical: "bottom",
                                                                        horizontal: "left",
                                                                    }}
                                                                    transformOrigin={{
                                                                        vertical: "top",
                                                                        horizontal: "right",
                                                                    }}
                                                                >
                                                                    <Box display="grid" gridTemplateColumns="repeat(3, 1fr)" gap={1} p={2} width={180}>
                                                                        {actionButtons(task).map(({ title, icon, color, handler, disabled }, index) => (
                                                                            <Tooltip key={title} title={title} {...tooltipProps} placement={index < 3 ? "top" : "bottom"} >
                                                                                <span>
                                                                                    <IconButton
                                                                                        color={color as any}
                                                                                        sx={getIconButtonStyle(color || 'default')}
                                                                                        onClick={() => {
                                                                                            handler();
                                                                                            handleClosePopover();
                                                                                        }}
                                                                                        disabled={disabled}
                                                                                    >
                                                                                        {icon}
                                                                                    </IconButton>
                                                                                </span>
                                                                            </Tooltip>
                                                                        ))}
                                                                    </Box>
                                                                </Popover>
                                                            </Box>
                                                        </TableCell>
                                                    </TableRow>
                                                )
                                            }

                                            )}
                                    </TableBody>
                                </MuiTable>
                            ) : (
                                <Box
                                    display="flex"
                                    justifyContent="center"
                                    alignItems="center"
                                    minHeight="63vh"
                                >
                                    <Empty description="No Tasks found. Please add tasks or change search term." />
                                </Box>
                            )}
            </TableContainer>

            <Box display="flex" justifyContent="center" mt={1}>
                <Pagination
                    page={currentPage}
                    count={totalPages}
                    sx={{
                        '& .MuiPaginationItem-root': {
                            color: 'rgb(73, 102, 131) !important',
                            borderColor: 'rgb(73, 102, 131) !important',
                        },
                        '& .MuiPaginationItem-root.Mui-selected': {
                            backgroundColor: 'rgb(73, 102, 131) !important',
                            color: '#fff !important',
                        },
                    }}
                    onChange={handlePageChange}
                />
            </Box>

            <CustomModal
                open={showModal}
                onClose={() => setShowModal(false)}
                title={"Respond To Task"}
                actions={

                    selectedTask?.status !== "Completed" && taskDetails[taskDetails.length - 1]?.status !== "Responded" ? (

                        <>
                            <Button
                                variant="outlined"
                                color="error"
                                onClick={handleClear}
                                sx={{ borderRadius: '8px', textTransform: 'none', mr: 1 }}
                            >
                                Clear
                            </Button>
                            <Button
                                variant="contained"
                                color="primary"
                                onClick={handleSubmit}
                                sx={{ borderRadius: '8px', textTransform: 'none' }}
                            >
                                Submit
                            </Button>
                        </>) : <></>
                }
            >
                {respondToTaskModalContent}
            </CustomModal>

            {showMarkingModal && (
                <Dialog
                    open={showMarkingModal}
                    onClose={() => setShowMarkingModal(false)}
                    maxWidth="md"
                    fullWidth
                    sx={{
                        '& .MuiDialog-paper': {
                            borderRadius: '8px',
                            padding: '16px',
                            boxShadow: '0px 4px 20px rgba(0, 0, 0, 0.1)',
                        },
                    }}
                >
                    <DialogTitle sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', pb: 1 }}>
                        {selectedTask?.status !== "Completed" ? (
                            <Typography variant="h6" component="div" fontWeight="bold" color="rgb(73, 102, 131)">
                                Mark Task
                            </Typography>
                        ) : (
                            <Box />
                        )}
                        <IconButton
                            onClick={() => setShowMarkingModal(false)}
                            sx={{ color: 'grey.600', ":hover": { color: "red" }, }}
                            title="Close"
                        >
                            <Close />
                        </IconButton>
                    </DialogTitle>

                    <DialogContent dividers sx={{ py: 2 }}>
                        {taskDetails.length > 0 && (
                            <Box sx={{ mb: 3, p: 2, backgroundColor: '#f9f9f9', borderRadius: '6px' }}>
                                <Typography variant="subtitle1" fontWeight="bold" mb={1}>
                                    Respond/Marking
                                </Typography>
                                {loadingDetails ? (
                                    <Box display="flex" justifyContent="center" alignItems="center" minHeight="100px">
                                        <CircularProgress />
                                    </Box>
                                ) : (
                                    <TableContainer sx={{ overflowX: 'hidden' }}>
                                        <MuiTableComponent sx={{ tableLayout: 'fixed', width: '100%' }}>
                                            <MuiTableHead>
                                                <MuiTableRow sx={{ backgroundColor: '#f0f0f0' }}>
                                                    {getTaskDetailsColumns().map((column) => (
                                                        <MuiTableCell
                                                            key={column.title}
                                                            align={column.align}
                                                            sx={{
                                                                fontWeight: 'bold',
                                                                width: column.width,
                                                                whiteSpace: 'nowrap',
                                                                overflow: 'hidden',
                                                                textOverflow: 'ellipsis',
                                                                padding: '8px'
                                                            }}
                                                        >
                                                            {column.title}
                                                        </MuiTableCell>
                                                    ))}
                                                </MuiTableRow>
                                            </MuiTableHead>
                                            <MuiTableBody>
                                                {taskDetails.map((record, idx) => (
                                                    <MuiTableRow key={`${record.meetingTaskId}-${idx}`}>
                                                        <MuiTableCell
                                                            align="center"
                                                            sx={{
                                                                whiteSpace: 'normal',
                                                                wordBreak: 'break-word',
                                                                padding: '8px'
                                                            }}
                                                        >
                                                            {idx + 1}
                                                        </MuiTableCell>
                                                        <MuiTableCell
                                                            align="center"
                                                            sx={{
                                                                whiteSpace: 'normal',
                                                                wordBreak: 'break-word',
                                                                padding: '8px'
                                                            }}
                                                        >
                                                            {record.remark}
                                                        </MuiTableCell>
                                                        <MuiTableCell
                                                            align="center"
                                                            sx={{
                                                                whiteSpace: 'normal',
                                                                wordBreak: 'break-word',
                                                                padding: '8px'
                                                            }}
                                                        >
                                                            {record.respondedBy}
                                                        </MuiTableCell>
                                                        <MuiTableCell
                                                            align="center"
                                                            sx={{
                                                                whiteSpace: 'normal',
                                                                wordBreak: 'break-word',
                                                                padding: '8px'
                                                            }}
                                                        >
                                                            {dayjs(record.respondedOn).format("DD MMM YYYY hh:mm A")}
                                                        </MuiTableCell>
                                                        <MuiTableCell
                                                            align="center"
                                                            sx={{
                                                                whiteSpace: 'normal',
                                                                wordBreak: 'break-word',
                                                                padding: '8px'
                                                            }}
                                                        >
                                                            {record.status}
                                                        </MuiTableCell>
                                                        <MuiTableCell
                                                            align="center"
                                                            sx={{
                                                                whiteSpace: 'normal',
                                                                wordBreak: 'break-word',
                                                                padding: '8px'
                                                            }}
                                                        >
                                                            {record.filePath ? (
                                                                <IconButton onClick={() => handleDownload(record.filePath)} title="Download File">
                                                                    <DownloadOutlined sx={{ fontSize: 18, color: "#1890ff" }} />
                                                                </IconButton>
                                                            ) : (
                                                                "No File"
                                                            )}
                                                        </MuiTableCell>
                                                    </MuiTableRow>
                                                ))}
                                            </MuiTableBody>
                                        </MuiTableComponent>
                                    </TableContainer>
                                )}
                            </Box>
                        )}

                        {selectedTask?.status !== "Completed" && taskDetails[taskDetails.length - 1]?.status === "Responded" && (
                            <>
                                <Box sx={{ mb: 2 }}>
                                    <Typography variant="body1" mb={1} fontWeight="medium">
                                        Remarks*
                                    </Typography>
                                    <TextField
                                        fullWidth
                                        multiline
                                        rows={3}
                                        value={markingRemarks}
                                        onChange={(e) => setMarkingRemarks(e.target.value)}
                                        variant="outlined"
                                        placeholder="Enter your remarks here..."
                                        sx={{
                                            '& .MuiOutlinedInput-root': {
                                                borderRadius: '8px',
                                                backgroundColor: '#fff',
                                            },
                                        }}
                                    />
                                </Box>
                                <Box>
                                    <Typography variant="body1" mb={1} fontWeight="medium">
                                        Status
                                    </Typography>
                                    <FormControl fullWidth sx={{ mb: 2 }}>
                                        <InputLabel id="status-select-label">Select Status</InputLabel>
                                        <Select
                                            labelId="status-select-label"
                                            value={selectedStatus}
                                            onChange={(e) => setSelectedStatus(e.target.value)}
                                            variant="outlined"
                                            label="Select Status"
                                            sx={{
                                                borderRadius: '8px',
                                                backgroundColor: '#fff',
                                            }}
                                        >
                                            <MenuItem value="">Select Status</MenuItem>
                                            <MenuItem value="Justification Required">Justification Required</MenuItem>
                                            <MenuItem value="Completed">Completed</MenuItem>
                                        </Select>
                                    </FormControl>
                                </Box>
                            </>
                        )}
                    </DialogContent>

                    {selectedTask?.status !== "Completed" && taskDetails[taskDetails.length - 1]?.status === "Responded" && (
                        <DialogActions sx={{ p: 2, pt: 1 }}>
                            <Button
                                variant="outlined"
                                color="error"
                                onClick={handleMarkingClear}
                                sx={{ borderRadius: '8px', textTransform: 'none', mr: 1 }}
                            >
                                Clear
                            </Button>
                            <Button
                                variant="contained"
                                color="primary"
                                onClick={handleMarkingSubmit}
                                sx={{ borderRadius: '8px', textTransform: 'none' }}
                            >
                                Submit
                            </Button>
                        </DialogActions>
                    )}
                </Dialog>
            )}

            <CustomModal open={showInfoModal} onClose={() => setShowInfoModal(false)} title={infoTitle} maxWidth="sm">
                {infoTitle === "Employee Names" && infoEmployees.length > 0 ? (
                    <List sx={{
                        maxHeight: '250px',
                        overflowY: 'auto',
                        scrollbarWidth: 'thin',
                    }}>
                        {infoEmployees.map((employee, idx) => (
                            <ListItem key={`${employee.empId}-${idx}`} divider>
                                <ListItemAvatar>
                                    <Avatar
                                        src={employee.employeeImgUrl}
                                        alt={employee.employeeName}
                                        sx={{ width: 40, height: 40 }}
                                    />
                                </ListItemAvatar>
                                <ListItemText
                                    primary={employee.employeeName}
                                    primaryTypographyProps={{ fontWeight: 'medium' }}
                                    secondaryTypographyProps={{ color: 'text.secondary' }}
                                />
                            </ListItem>
                        ))}
                    </List>
                ) : (
                    <Typography
                        mt={1}
                        ml={3}
                        variant="body1"
                        sx={{
                            fontSize: { xs: "0.875rem", sm: "1rem" },
                            color: "text.primary",
                            whiteSpace: "pre-wrap",
                            wordBreak: "break-word",
                        }}
                    >
                        {infoContent || "N/A"}
                    </Typography>
                )}
            </CustomModal>

            <CustomModal open={showSegmentModal} onClose={() => setShowSegmentModal(false)} title={"Segments / Departments"} maxWidth="md">
                <Box display="flex" gap={2}>
                    {/* Segments List */}
                    <Box flex={1} p={0} sx={{ maxHeight: 500, display: 'flex', flexDirection: 'column', border: 1, borderColor: 'divider', borderRadius: 2 }}>
                        <Box
                            sx={{
                                position: 'sticky',
                                top: 0,
                                zIndex: 1,
                                borderBottom: 1,
                                borderColor: 'divider',
                                p: 2,
                            }}
                        >
                            <h3 style={{ margin: 0, textAlign: "center" }}>Segments</h3>
                        </Box>
                        <List sx={{ overflowY: 'auto', flex: 1, scrollbarWidth: 'thin' }}>
                            {selectedTask && selectedTask.segmentDtos?.length > 0 ? selectedTask?.segmentDtos?.map((item, idx) => (
                                <ListItem key={`segment-${item.id}-${idx}`} divider sx={{ '&:hover': { backgroundColor: 'action.hover' } }}>
                                    <ListItemText primary={item.name} />
                                </ListItem>
                            ))
                                :
                                <Typography
                                    mt={1}
                                    ml={3}
                                    variant="body1"
                                    sx={{
                                        fontSize: { xs: "0.875rem", sm: "1rem" },
                                        color: "text.disabled",
                                        whiteSpace: "pre-wrap",
                                        wordBreak: "break-word",
                                    }}
                                >
                                    No segments to show
                                </Typography>
                            }
                        </List>
                    </Box>

                    <Box flex={1} p={0} sx={{ maxHeight: 500, display: 'flex', flexDirection: 'column', border: 1, borderColor: 'divider', borderRadius: 2 }}>
                        <Box
                            sx={{
                                position: 'sticky',
                                top: 0,
                                zIndex: 1,
                                borderBottom: 1,
                                borderColor: 'divider',
                                p: 2,
                            }}
                        >
                            <h3 style={{ margin: 0, textAlign: "center" }}>Departments</h3>
                        </Box>
                        <List sx={{ overflowY: 'auto', flex: 1, scrollbarWidth: 'thin' }}>
                            {selectedTask && selectedTask?.departmentDtos.length > 0 ? selectedTask?.departmentDtos?.map((item, idx) => (
                                <ListItem key={`department-${item.id}-${idx}`} divider sx={{ '&:hover': { backgroundColor: 'action.hover' } }}>
                                    <ListItemText
                                        primary={item.name}
                                    />
                                </ListItem>
                            ))
                                :
                                <Typography
                                    mt={1}
                                    ml={3}
                                    variant="body1"
                                    sx={{
                                        fontSize: { xs: "0.875rem", sm: "1rem" },
                                        color: "text.disabled",
                                        whiteSpace: "pre-wrap",
                                        wordBreak: "break-word",
                                    }}
                                >
                                    No Departments to show
                                </Typography>
                            }
                        </List>
                    </Box>
                </Box>
            </CustomModal>

            <Dialog
                open={showUpdateCompletionDateModal}
                onClose={() => setShowUpdateCompletionDateModal(!showUpdateCompletionDateModal)}
                maxWidth="md"
                fullWidth
                sx={{
                    '& .MuiDialog-paper': {
                        borderRadius: '8px',
                        padding: '16px',
                        boxShadow: '0px 4px 20px rgba(0, 0, 0, 0.1)',
                    },
                }}
            >
                <DialogTitle sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', pb: 1 }}>
                    <Typography variant="h6" component="div" fontWeight="bold" color="rgb(73, 102, 131)">
                        Update Completion Date
                    </Typography>

                    <IconButton
                        onClick={() => { setShowUpdateCompletionDateModal(false) }}
                        sx={{ color: "grey.500", ":hover": { color: "red" } }}
                        title="Close"
                    >
                        <Close />
                    </IconButton>

                </DialogTitle>

                <DialogContent dividers sx={{ py: 2 }}>
                    <DatePicker
                        label="Completion Date*"
                        value={completionDate}
                        onChange={(newDate) => {
                            const isoString = newDate ? newDate.toISOString() : "";
                            setCompletionDate(new Date(isoString));
                        }}
                        slotProps={{
                            textField: {
                                error: !!errors.date,
                                helperText: errors.date,
                                fullWidth: true,
                                variant: 'outlined',
                                sx: {
                                    backgroundColor: '#fff',
                                    mb: 3,
                                    mt: 2,
                                    borderRadius: 2,
                                },
                            },
                        }}
                    />

                    {selectedTask?.completionDate && (
                        <Box sx={{ mb: 2 }}>
                            <Typography variant="body1" mb={1} fontWeight="medium">
                                Remarks*
                            </Typography>
                            <TextField
                                fullWidth
                                multiline
                                rows={3}
                                value={remarks}
                                onChange={(e) => setRemarks(e.target.value)}
                                variant="outlined"
                                placeholder="Enter your remarks here..."
                                sx={{
                                    '& .MuiOutlinedInput-root': {
                                        borderRadius: '8px',
                                        backgroundColor: '#fff',
                                        p: 1.5,
                                    },
                                    mb: 2,
                                }}
                                error={!!errors.remarks}
                                helperText={errors.remarks}
                            />
                        </Box>
                    )}
                </DialogContent>

                <DialogActions sx={{ p: 2, pt: 1 }}>
                    <Button
                        variant="outlined"
                        color="error"
                        onClick={handleCompletiondateClear}
                        sx={{ borderRadius: '8px', textTransform: 'none', mr: 1 }}
                    >
                        Clear
                    </Button>
                    <Button
                        variant="contained"
                        color="primary"
                        onClick={updateCompletiondate}
                        sx={{ borderRadius: '8px', textTransform: 'none' }}
                    >
                        Submit
                    </Button>
                </DialogActions>
            </Dialog>

            {showEditTaskModal && (
                <EditGeneralTaskModal
                    handleEditTaskModal={handleEditTaskModal}
                    selectedTask={selectedTask}
                    toast={toast}
                    refreshTasks={fetchTasks}
                />
            )}

            {showAddTaskModal && (
                <AddTaskPopup
                    handleAddTaskModal={handleAddTaskModal}
                    toast={toast}
                    refreshTasks={fetchTasks}
                />
            )}


            <MeetingsTraySlider
                open={open}
                setOpen={setOpen}
                currentSlider={currentSlider}
                generalMeetingTaskId={selectedTask?.generalMeetingTaskId}
                tasks={tasks} setFilteredTasks={setFilteredTasks}
                searchCriteria={searchFilterCriteria} setSearchCriteria={setSearchFilterCriteria}
            />

        </Paper>

    );
};

export default MyTasks;
