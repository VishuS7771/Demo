import React, { useState, useEffect } from "react";
import { toast } from "react-toastify";
import {
    Box, Button, Grid, Typography, TextField, Paper, InputAdornment,
    IconButton, Autocomplete
} from '@mui/material';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterMoment } from '@mui/x-date-pickers/AdapterMoment';
import {
    Save, Refresh, EventOutlined, PeopleOutline, ApartmentOutlined,
    CategoryOutlined, AssignmentIndOutlined
} from "@mui/icons-material";
import moment from 'moment';
import { getAllEmployees } from "../../Requests/MeetingRequest";
import { departmentsData, segmentsData } from "../../util/constants/generalMeeting";
import { GeneralMeetingReportDTO } from "../../Interfaces/Generalmeeting";
import { downloadGeneralMeetingReport } from "../../Requests/GeneralMeetingRequest";

interface SelectionOption {
    value: number;
    label: string;
}

const GeneralMeetingReport: React.FC = () => {
    const [reportDetails, setReportDetails] = useState<GeneralMeetingReportDTO>({
        reportType: "",
        segment: [],
        department: [],
        assignedBy: [],
        assignee: [],
        attendees: [],
        hosts: [],
        meetingDateFrom: null,
        meetingDateTo: null,
        taskAssignedDateFrom: null,
        taskAssignedDateTo: null,
        empId:JSON.parse(localStorage.getItem("employeeNo") ?? "{}")
    });
    const [employees, setEmployees] = useState<SelectionOption[]>([]);
    const [selectedAssignedBy, setSelectedAssignedBy] = useState<SelectionOption[]>([]);
    const [selectedAssignee, setSelectedAssignee] = useState<SelectionOption[]>([]);
    const [selectedAttendees, setSelectedAttendees] = useState<SelectionOption[]>([]);
    const [selectedHosts, setSelectedHosts] = useState<SelectionOption[]>([]);
    const [departmentOptions, setDepartmentOptions] = useState<SelectionOption[]>([]);
    const [selectedDepartment, setSelectedDepartment] = useState<SelectionOption[]>([]);
    const [segmentOptions, setSegmentOptions] = useState<SelectionOption[]>([]);
    const [selectedSegment, setSelectedSegment] = useState<SelectionOption[]>([]);
    const [errors, setErrors] = useState<{ [key: string]: string }>({});
    const [openMeetingFrom, setOpenMeetingFrom] = useState(false);
    const [openMeetingTo, setOpenMeetingTo] = useState(false);
    const [openTaskFrom, setOpenTaskFrom] = useState(false);
    const [openTaskTo, setOpenTaskTo] = useState(false);
    // Fetch employees for dropdowns
    const fetchEmployees = async () => {
        try {
            const fetchedEmployees = await getAllEmployees();
            const employeeOptions: SelectionOption[] = fetchedEmployees.map((employee: any) => ({
                value: Number(employee.employeeId),
                label: employee.employeeFullName,
            }));
            setEmployees(employeeOptions);
        } catch (error) {
            toast.error("Failed to load employees. Please try again later.");
        }
    };

    useEffect(() => {
        fetchEmployees();
        setDepartmentOptions(departmentsData);
        setSegmentOptions(segmentsData);
    }, []);

    // Handle multiple selection dropdowns
    const handleAssignedBySelection = (newValue: SelectionOption[]) => {
        setSelectedAssignedBy(newValue);
        const selectedIds = newValue.map((option) => option.value);
        setReportDetails((prevDetails) => ({ ...prevDetails, assignedBy: selectedIds }));
        setErrors((prevErrors) => ({ ...prevErrors, assignedBy: "" }));
    };

    const handleAssigneeSelection = (newValue: SelectionOption[]) => {
        setSelectedAssignee(newValue);
        const selectedIds = newValue.map((option) => option.value);
        setReportDetails((prevDetails) => ({ ...prevDetails, assignee: selectedIds }));
        setErrors((prevErrors) => ({ ...prevErrors, assignee: "" }));
    };

    const handleAttendeesSelection = (newValue: SelectionOption[]) => {
        setSelectedAttendees(newValue);
        const selectedIds = newValue.map((option) => option.value);
        setReportDetails((prevDetails) => ({ ...prevDetails, attendees: selectedIds }));
        setErrors((prevErrors) => ({ ...prevErrors, attendees: "" }));
    };

    const handleHostsSelection = (newValue: SelectionOption[]) => {
        setSelectedHosts(newValue);
        const selectedIds = newValue.map((option) => option.value);
        setReportDetails((prevDetails) => ({ ...prevDetails, hosts: selectedIds }));
        setErrors((prevErrors) => ({ ...prevErrors, hosts: "" }));
    };

    const handleDepartmentSelection = (newValue: SelectionOption[]) => {
        setSelectedDepartment(newValue);
        const selectedNames = newValue.map((option) => option.label);
        setReportDetails((prevDetails) => ({ ...prevDetails, department: selectedNames }));
        setErrors((prevErrors) => ({ ...prevErrors, department: "" }));
    };

    const handleSegmentSelection = (newValue: SelectionOption[]) => {
        setSelectedSegment(newValue);
        const selectedNames = newValue.map((option) => option.label);
        setReportDetails((prevDetails) => ({ ...prevDetails, segment: selectedNames }));
        setErrors((prevErrors) => ({ ...prevErrors, segment: "" }));
    };

    // Handle date changes
    const handleDateChange = (date: any, field: string) => {
        setReportDetails((prevDetails) => ({
            ...prevDetails,
            [field]: date ? date.format("YYYY-MM-DD") : null
        }));
        setErrors((prevErrors) => ({ ...prevErrors, [field]: "" }));
    };

    // Validation functions
    const validateReportType = () => {
        if (!reportDetails.reportType) {
            setErrors((prevErrors) => ({
                ...prevErrors,
                reportType: "Report Type is required."
            }));
            return false;
        }
        setErrors((prevErrors) => ({ ...prevErrors, reportType: "" }));
        return true;
    };

    const validateDates = () => {
        let isValid = true;
        if (reportDetails.meetingDateFrom && reportDetails.meetingDateTo) {
            const fromDate = moment(reportDetails.meetingDateFrom);
            const toDate = moment(reportDetails.meetingDateTo);
            if (fromDate.isAfter(toDate)) {
                setErrors((prevErrors) => ({
                    ...prevErrors,
                    meetingDateTo: "To date cannot be earlier than From date."
                }));
                isValid = false;
            }
        }
        if (reportDetails.taskAssignedDateFrom && reportDetails.taskAssignedDateTo) {
            const fromDate = moment(reportDetails.taskAssignedDateFrom);
            const toDate = moment(reportDetails.taskAssignedDateTo);
            if (fromDate.isAfter(toDate)) {
                setErrors((prevErrors) => ({
                    ...prevErrors,
                    taskAssignedDateTo: "To date cannot be earlier than From date."
                }));
                isValid = false;
            }
        }
        return isValid;
    };

    // Reset form
    const handleResetForm = () => {
        setReportDetails({
            reportType: "",
            segment: [],
            department: [],
            assignedBy: [],
            assignee: [],
            attendees: [],
            hosts: [],
            meetingDateFrom: null,
            meetingDateTo: null,
            taskAssignedDateFrom: null,
            taskAssignedDateTo: null,
            empId:JSON.parse(localStorage.getItem("employeeNo") ?? "{}")
        });
        setSelectedAssignedBy([]);
        setSelectedAssignee([]);
        setSelectedAttendees([]);
        setSelectedHosts([]);
        setSelectedDepartment([]);
        setSelectedSegment([]);
        setErrors({});
        setOpenMeetingFrom(false);
        setOpenMeetingTo(false);
        setOpenTaskFrom(false);
        setOpenTaskTo(false);
    };

    // Submit handler (placeholder - implement API call as needed)
    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        if (!validateReportType() || !validateDates()) {
            return;
        }

        try {
        
           await downloadGeneralMeetingReport(reportDetails);
            handleResetForm();
        } catch (error) {
            toast.error("Failed to download report. Please try again.");
        }
    };

      // Determine if fields should be disabled based on reportType
  const isTaskReport = reportDetails.reportType === "TaskReport";

    return (
        <Paper elevation={3} sx={{ borderRadius: 2, overflow: "hidden", position: "relative", boxShadow: "" }}>
             <Typography variant="h5" align="left" sx={{ ml: 14, mt: 7, fontWeight: "bold" }}>
                General Meeting Reports
            </Typography>
            <LocalizationProvider dateAdapter={AdapterMoment}>
                <Box sx={{ p: { xs: "20px", sm: "40px 50px" }, bgcolor: 'background.default', minHeight: '77vh' }}>
                    <form onSubmit={handleSubmit}>
                        <Grid container spacing={{ xs: 2, sm: 3, md: 4, lg: 5 }} sx={{ padding: "20px 60px 40px 60px" }}>
                            <Grid item xs={12} sm={12} lg={12} minWidth="400px">
                                <Autocomplete
                                    options={[
                                        { value: "GeneralMeetingReport", label: "General Meeting Report" },
                                        { value: "MeetingMOMReport", label: "Meeting MOM Report" },
                                        { value: "TaskReport", label: "Task Report" },
                                    ]}
                                    getOptionLabel={(option) => option.label}
                                    value={
                                        reportDetails.reportType
                                            ? { value: reportDetails.reportType, label: reportDetails.reportType === "GeneralMeetingReport" ? "General Meeting Report" : reportDetails.reportType === "MeetingMOMReport" ? "Meeting MOM Report" : "Task Report" }
                                            : null
                                    }
                                    onChange={(_, newValue) => {
                                        setReportDetails((prevDetails) => ({
                                            ...prevDetails,
                                            reportType: newValue ? newValue.value : "",
                                        }));
                                        setErrors((prevErrors) => ({ ...prevErrors, reportType: "" }));
                                    }}
                                    renderInput={(params) => (
                                        <TextField
                                            {...params}
                                            label="Report Type*"
                                            variant="outlined"
                                            error={!!errors.reportType}
                                            helperText={errors.reportType}
                                            slotProps={{
                                                input: {
                                                    ...params.InputProps,
                                                    startAdornment: (
                                                        <InputAdornment position="start">
                                                            <AssignmentIndOutlined />
                                                        </InputAdornment>
                                                    ),
                                                },
                                            }}
                                            sx={{
                                                "& .MuiInputBase-root": {
                                                    fontSize: { xs: "0.875rem", sm: "1rem" },
                                                },
                                            }}
                                        />
                                    )}
                                />
                            </Grid>
                            <Grid item xs={12} sm={12} lg={6} minWidth="400px">
                                <Autocomplete
                                    multiple
                                    options={segmentOptions}
                                    getOptionLabel={(option) => option.label}
                                    value={selectedSegment}
                                    onChange={(_, newValue) => handleSegmentSelection(newValue)}
                                    renderInput={(params) => (
                                        <TextField
                                            {...params}
                                            label="Segments"
                                            variant="outlined"
                                            error={!!errors.segment}
                                            helperText={errors.segment}
                                            slotProps={{
                                                input: {
                                                    ...params.InputProps,
                                                    startAdornment: (
                                                        <>
                                                            <InputAdornment position="start">
                                                                <CategoryOutlined />
                                                            </InputAdornment>
                                                            {params.InputProps.startAdornment}
                                                        </>
                                                    ),
                                                },
                                            }}
                                            sx={{
                                                "& .MuiInputBase-root": {
                                                    fontSize: { xs: "0.875rem", sm: "1rem" },
                                                },
                                            }}
                                        />
                                    )}
                                />
                            </Grid>
                            <Grid item xs={12} sm={12} lg={6} minWidth="400px">
                                <Autocomplete
                                    multiple
                                    options={departmentOptions}
                                    getOptionLabel={(option) => option.label}
                                    value={selectedDepartment}
                                    onChange={(_, newValue) => handleDepartmentSelection(newValue)}
                                    renderInput={(params) => (
                                        <TextField
                                            {...params}
                                            label="Departments"
                                            variant="outlined"
                                            error={!!errors.department}
                                            helperText={errors.department}
                                            slotProps={{
                                                input: {
                                                    ...params.InputProps,
                                                    startAdornment: (
                                                        <>
                                                            <InputAdornment position="start">
                                                                <ApartmentOutlined />
                                                            </InputAdornment>
                                                            {params.InputProps.startAdornment}
                                                        </>
                                                    ),
                                                },
                                            }}
                                            sx={{
                                                "& .MuiInputBase-root": {
                                                    fontSize: { xs: "0.875rem", sm: "1rem" },
                                                },
                                            }}
                                        />
                                    )}
                                />
                            </Grid>
                            <Grid item xs={12} sm={12} lg={6} minWidth="400px">
                                <Autocomplete
                                    multiple
                                    options={employees}
                                    getOptionLabel={(option) => option.label}
                                    value={selectedAssignedBy}
                                    onChange={(_, newValue) => handleAssignedBySelection(newValue)}
                                    renderInput={(params) => (
                                        <TextField
                                            {...params}
                                            label="Task Assigned By"
                                            variant="outlined"
                                            error={!!errors.assignedBy}
                                            helperText={errors.assignedBy}
                                            slotProps={{
                                                input: {
                                                    ...params.InputProps,
                                                    startAdornment: (
                                                        <>
                                                            <InputAdornment position="start">
                                                                <AssignmentIndOutlined />
                                                            </InputAdornment>
                                                            {params.InputProps.startAdornment}
                                                        </>
                                                    ),
                                                },
                                            }}
                                            sx={{
                                                "& .MuiInputBase-root": {
                                                    fontSize: { xs: "0.875rem", sm: "1rem" },
                                                },
                                            }}
                                        />
                                    )}
                                />
                            </Grid>
                            <Grid item xs={12} sm={12} lg={6} minWidth="400px">
                                <Autocomplete
                                    multiple
                                    options={employees}
                                    getOptionLabel={(option) => option.label}
                                    value={selectedAssignee}
                                    onChange={(_, newValue) => handleAssigneeSelection(newValue)}
                                    renderInput={(params) => (
                                        <TextField
                                            {...params}
                                            label="Task Assignees"
                                            variant="outlined"
                                            error={!!errors.assignee}
                                            helperText={errors.assignee}
                                            slotProps={{
                                                input: {
                                                    ...params.InputProps,
                                                    startAdornment: (
                                                        <>
                                                            <InputAdornment position="start">
                                                                <PeopleOutline />
                                                            </InputAdornment>
                                                            {params.InputProps.startAdornment}
                                                        </>
                                                    ),
                                                },
                                            }}
                                            sx={{
                                                "& .MuiInputBase-root": {
                                                    fontSize: { xs: "0.875rem", sm: "1rem" },
                                                },
                                            }}
                                        />
                                    )}
                                />
                            </Grid>
                            <Grid item xs={12} sm={12} lg={6} minWidth="400px">
                                <Autocomplete
                                    multiple
                                    options={employees}
                                    getOptionLabel={(option) => option.label}
                                    value={selectedAttendees}
                                    onChange={(_, newValue) => handleAttendeesSelection(newValue)}
                                    disabled={reportDetails.reportType === "TaskReport"}
                                    renderInput={(params) => (
                                        <TextField
                                            {...params}
                                            label="Attendees"
                                            disabled={isTaskReport}
                                            variant="outlined"
                                            error={!!errors.attendees}
                                            helperText={errors.attendees}
                                            slotProps={{
                                                input: {
                                                    ...params.InputProps,
                                                    startAdornment: (
                                                        <>
                                                            <InputAdornment position="start">
                                                                <PeopleOutline />
                                                            </InputAdornment>
                                                            {params.InputProps.startAdornment}
                                                        </>
                                                    ),
                                                },
                                            }}
                                            sx={{
                                                "& .MuiInputBase-root": {
                                                    fontSize: { xs: "0.875rem", sm: "1rem" },
                                                },
                                            }}
                                        />
                                    )}
                                />
                            </Grid>
                            <Grid item xs={12} sm={12} lg={6} minWidth="400px">
                                <Autocomplete
                                    multiple
                                    options={employees}
                                    getOptionLabel={(option) => option.label}
                                    value={selectedHosts}
                                    onChange={(_, newValue) => handleHostsSelection(newValue)}
                                    disabled={isTaskReport}
                                    renderInput={(params) => (
                                        <TextField
                                            {...params}
                                            label="Hosts"
                                            variant="outlined"
                                            error={!!errors.hosts}
                                            helperText={errors.hosts}
                                            slotProps={{
                                                input: {
                                                    ...params.InputProps,
                                                    startAdornment: (
                                                        <>
                                                            <InputAdornment position="start">
                                                                <AssignmentIndOutlined />
                                                            </InputAdornment>
                                                            {params.InputProps.startAdornment}
                                                        </>
                                                    ),
                                                },
                                            }}
                                            sx={{
                                                "& .MuiInputBase-root": {
                                                    fontSize: { xs: "0.875rem", sm: "1rem" },
                                                },
                                            }}
                                        />
                                    )}
                                />
                            </Grid>
                            <Grid item xs={12} sm={12} lg={6} minWidth="400px">
                                <DatePicker
                                    open={openMeetingFrom}
                                    onOpen={() => setOpenMeetingFrom(true)}
                                    onClose={() => setOpenMeetingFrom(false)}
                                    label="Meeting Date From"
                                    value={reportDetails.meetingDateFrom ? moment(reportDetails.meetingDateFrom) : null}
                                    onChange={(date) => handleDateChange(date, 'meetingDateFrom')}
                                    disabled={isTaskReport}
                                    format="DD/MM/YYYY"
                                    slotProps={{
                                        textField: {
                                            fullWidth: true,
                                            variant: "outlined",
                                            error: !!errors.meetingDateFrom,
                                            helperText: errors.meetingDateFrom,
                                            InputProps: {
                                                startAdornment: (
                                                    <InputAdornment position="start">
                                                        <IconButton onClick={() => setOpenMeetingFrom(true)} disabled={isTaskReport}>
                                                            <EventOutlined />
                                                        </IconButton>
                                                    </InputAdornment>
                                                ),
                                                endAdornment: <></>,
                                            },
                                            sx: {
                                                "& .MuiInputBase-root": {
                                                    fontSize: { xs: "0.875rem", sm: "1rem" },
                                                },
                                            },
                                        },
                                    }}
                                />
                            </Grid>
                            <Grid item xs={12} sm={12} lg={6} minWidth="400px">
                                <DatePicker
                                    open={openMeetingTo}
                                    onOpen={() => setOpenMeetingTo(true)}
                                    onClose={() => setOpenMeetingTo(false)}
                                    label="Meeting Date To"
                                    value={reportDetails.meetingDateTo ? moment(reportDetails.meetingDateTo) : null}
                                    onChange={(date) => handleDateChange(date, 'meetingDateTo')}
                                    disabled={isTaskReport}
                                    format="DD/MM/YYYY"
                                    slotProps={{
                                        textField: {
                                            fullWidth: true,
                                            variant: "outlined",
                                            error: !!errors.meetingDateTo,
                                            helperText: errors.meetingDateTo,
                                            InputProps: {
                                                startAdornment: (
                                                    <InputAdornment position="start">
                                                        <IconButton onClick={() => setOpenMeetingTo(true)} disabled={isTaskReport}>
                                                            <EventOutlined />
                                                        </IconButton>
                                                    </InputAdornment>
                                                ),
                                                endAdornment: <></>,
                                            },
                                            sx: {
                                                "& .MuiInputBase-root": {
                                                    fontSize: { xs: "0.875rem", sm: "1rem" },
                                                },
                                            },
                                        },
                                    }}
                                />
                            </Grid>
                            <Grid item xs={12} sm={12} lg={6} minWidth="400px">
                                <DatePicker
                                    open={openTaskFrom}
                                    onOpen={() => setOpenTaskFrom(true)}
                                    onClose={() => setOpenTaskFrom(false)}
                                    label="Task Assigned Date From"
                                    value={reportDetails.taskAssignedDateFrom ? moment(reportDetails.taskAssignedDateFrom) : null}
                                    onChange={(date) => handleDateChange(date, 'taskAssignedDateFrom')}
                                    format="DD/MM/YYYY"
                                    slotProps={{
                                        textField: {
                                            fullWidth: true,
                                            variant: "outlined",
                                            error: !!errors.taskAssignedDateFrom,
                                            helperText: errors.taskAssignedDateFrom,
                                            InputProps: {
                                                startAdornment: (
                                                    <InputAdornment position="start">
                                                        <IconButton onClick={() => setOpenTaskFrom(true)}>
                                                            <EventOutlined />
                                                        </IconButton>
                                                    </InputAdornment>
                                                ),
                                                endAdornment: <></>,
                                            },
                                            sx: {
                                                "& .MuiInputBase-root": {
                                                    fontSize: { xs: "0.875rem", sm: "1rem" },
                                                },
                                            },
                                        },
                                    }}
                                />
                            </Grid>
                            <Grid item xs={12} sm={12} lg={6} minWidth="400px">
                                <DatePicker
                                    open={openTaskTo}
                                    onOpen={() => setOpenTaskTo(true)}
                                    onClose={() => setOpenTaskTo(false)}
                                    label="Task Assigned Date To"
                                    value={reportDetails.taskAssignedDateTo ? moment(reportDetails.taskAssignedDateTo) : null}
                                    onChange={(date) => handleDateChange(date, 'taskAssignedDateTo')}
                                    format="DD/MM/YYYY"
                                    slotProps={{
                                        textField: {
                                            fullWidth: true,
                                            variant: "outlined",
                                            error: !!errors.taskAssignedDateTo,
                                            helperText: errors.taskAssignedDateTo,
                                            InputProps: {
                                                startAdornment: (
                                                    <InputAdornment position="start">
                                                        <IconButton onClick={() => setOpenTaskTo(true)}>
                                                            <EventOutlined />
                                                        </IconButton>
                                                    </InputAdornment>
                                                ),
                                                endAdornment: <></>,
                                            },
                                            sx: {
                                                "& .MuiInputBase-root": {
                                                    fontSize: { xs: "0.875rem", sm: "1rem" },
                                                },
                                            },
                                        },
                                    }}
                                />
                            </Grid>
                            <Grid item xs={12}>
                                <Box
                                    sx={{
                                        display: "flex",
                                        justifyContent: { xs: "center", sm: "flex-end" },
                                        gap: 2,
                                        flexWrap: "wrap",
                                        mt: 3
                                    }}
                                >
                                    <Button
                                        type="submit"
                                        variant="contained"
                                        color="primary"
                                        startIcon={<Save />}
                                        sx={{
                                            px: { xs: 2, sm: 3 },
                                            py: 1,
                                            fontSize: { xs: "0.75rem", sm: "0.875rem" },
                                            textTransform: "none",
                                            minWidth: { xs: "120px", sm: "140px" },
                                        }}
                                    >
                                        Download
                                    </Button>
                                    <Button
                                        type="button"
                                        variant="outlined"
                                        color="error"
                                        startIcon={<Refresh />}
                                        onClick={handleResetForm}
                                        sx={{
                                            px: { xs: 2, sm: 3 },
                                            py: 1,
                                            fontSize: { xs: "0.75rem", sm: "0.875rem" },
                                            textTransform: "none",
                                            minWidth: { xs: "120px", sm: "140px" },
                                        }}
                                    >
                                        Reset
                                    </Button>
                                </Box>
                            </Grid>
                        </Grid>
                    </form>
                </Box>
            </LocalizationProvider>
        </Paper>
    );
};

export default GeneralMeetingReport;