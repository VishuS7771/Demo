import React, { useEffect, useState, MouseEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import moment from 'moment';
import { downLoadStatusDocument, getAllMettings } from '../../Requests/GeneralMeetingRequest';
import GeneralMeetingStatusUI from '../PopUp/GeneralMeeting/GeneralMeetingStatusPopup';
import { GeneralMeetingsDto } from '../../Interfaces/Generalmeeting';
import { toast } from 'react-toastify';
import GeneralMeetingTaskStatusTimeline from '../PopUp/GeneralMeeting/GeneralMeetingTaskStatusTimeline';
import ScheduleGeneralMeeting from '../PopUp/GeneralMeeting/ScheduleGeneralMeetingPopup';
import GeneralMeetingLinkPopUp from '../PopUp/GeneralMeeting/GenearalMeetingLink';
import GeneralMeetingRemarksPopUp from '../PopUp/GeneralMeeting/GeneralMeetingRemarks';
import ViewMeeting from '../PopUp/GeneralMeeting/ViewMeeting';
import {
  Box,
  Button,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Pagination,
  IconButton,
  Popover,
  Tooltip,
} from '@mui/material';
import { Empty } from 'antd';
import { FaCalendarAlt, FaClock, FaCommentDots, FaEdit, FaEye, FaFileDownload, FaFlag, FaLink, FaPlusCircle, FaTasks, FaEllipsisH, FaSearch } from 'react-icons/fa';
import { IconButtonProps } from '@mui/material';
import { getIconButtonStyle } from '../../util/constants/commonStyles';
import TableSkeleton from '../Skeletons/Skeleton';
import { GridFilterListIcon } from '@mui/x-data-grid';
import { CancelOutlined } from '@mui/icons-material';
import {SearchCriteria } from '../../Interfaces/Task';
import MeetingsTraySlider from '../Slider/GeneralMeeting/MeetingsTraySlider';
import { actionButtonStyle, Search, SearchIconWrapper, StyledInputBase, tooltipProps } from '../../util/constants/commonStyles';
import { StatusChip } from '../Chip/StatusChip';
import { GeneralMeetingSearchCriteriaProps } from '../../Interfaces/Task';

interface ActionButton {
  title: string;
  icon: React.ReactNode;
  color: IconButtonProps['color'];
  handler: () => void;
  disabled?: boolean;
}

const GeneralMeeting: React.FC = () => {
  const itemsPerPage = 10;
  const [meetingsList, setMeetingsList] = useState<GeneralMeetingsDto[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [showLinkModal, setShowLinkModal] = useState(false);
  const [showRemarksModal, setShowRemarksModal] = useState(false);
  const [showMeetingStatusModal, setShowMeetingStatusModal] = useState(false);
  const [selectedMeetingData, setSelectedMeetingData] = useState<GeneralMeetingsDto | null>(null);
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [selectedMeeting, setSelectedMeeting] = useState<GeneralMeetingsDto | null>(null);
  const [selectedMeetingDetails, setSelectedMeetingDetails] = useState<GeneralMeetingsDto | null>(null);
  const [meetingMode, setMeetingMode] = useState<string>('');
  const [isTimeLineOpen, setIsTimeLineOpen] = useState(false);
  const [meetingId, setMeetingId] = useState<number | undefined>();
  const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null);
  const [showTableLoading, setShowTableLoading] = useState(true);
  const [filteredMeetings, setFilteredMeetings] = useState<GeneralMeetingsDto[]>([]);
  const [searchCriteria, setSearchCriteria] = useState<GeneralMeetingSearchCriteriaProps>({
    meetingId: "",
    meetingName: "",
    hostId: "",
    hostName: "",
    fromDate: "",
    toDate: "",
    status: [],
    segments: [],
    departments: [],
    host: [],
    assignees: [],
  })

  // search for filters 

       const [searchFilterCriteria, setSearchFilterCriteria] = useState<SearchCriteria>({
        meetingName: "",
        taskName: "",
        assignedDateFrom: "",
        assignedDateTo: "",
        targetDateFrom: "",
        targetDateTo: "",
        completionDateFrom: "",
        completionDateTo: "",
        statuses: [],
        employees: [],
        assignees: [],
        segments: [],
        departments: [],
        isOverdue: false,
    });

  const navigate = useNavigate();
  const employeeNo = localStorage.getItem('employeeNo');

  // search meetings states

  const [open, setOpen] = useState(false);
  const [currentSlider, setCurrentSlider] = useState<string>("");

  const toggleDrawer = (newOpen: boolean) => {
    setOpen(newOpen);
  }

  const toggleFilters = () => {
    // setShowFilters(prev => !prev);
    setCurrentSlider("searchMeetings");
    toggleDrawer(true);
  };

  const fetchMeetings = async () => {
    try {
      setShowTableLoading(true);
      const response = await getAllMettings(Number(employeeNo));
      // const sortedResponse = (response || []).sort((a: GeneralMeetingsDto, b: GeneralMeetingsDto) =>
      //   dayjs(b.createdOn, 'YYYY-DD-MM HH:mm:ss').valueOf() - dayjs(a.createdOn, 'YYYY-DD-MM HH:mm:ss').valueOf()
      // );

      setMeetingsList(response);
      setFilteredMeetings(response);
    } catch (error) {
      console.error('Error fetching meetings:', error);
    } finally {
      setShowTableLoading(false); // Set loading to false after fetching
    }
  };

  useEffect(() => {
    fetchMeetings();
  }, [showMeetingStatusModal]);

  const handlePageChange = (_event: React.ChangeEvent<unknown>, pageNumber: number) => {
    setCurrentPage(pageNumber);
  };

  const currentMeetings = filteredMeetings.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const totalPages = Math.ceil(filteredMeetings.length / itemsPerPage);
  const handleLinkClick = (meeting: GeneralMeetingsDto) => {
    setSelectedMeetingData(meeting);
    setShowLinkModal(true);
  };

  const handleRemarksClick = (meeting: GeneralMeetingsDto) => {
    setSelectedMeetingData(meeting);
    setShowRemarksModal(true);
  };

  const handleMeetingStatusClick = (meeting: GeneralMeetingsDto) => {
    setSelectedMeetingData(meeting);
    setShowMeetingStatusModal(true);
  };

  const handleScheduleMeetingPopup = () => {
    setShowScheduleModal(!showScheduleModal);
    if (!showScheduleModal) {
      setMeetingMode('New');
      setSelectedMeetingDetails(null);
    }
  };

  const handleCloseLinkModal = () => {
    setShowLinkModal(false);
    setSelectedMeetingData(null);
  };

  const handleCloseRemarksModal = () => {
    setShowRemarksModal(false);
    setSelectedMeetingData(null);
  };

  const handleCloseMeetingStatusModal = () => {
    setShowMeetingStatusModal(false);
    setSelectedMeetingData(null);
  };

  const handleclickTimelineHistory = (meeting: GeneralMeetingsDto) => {
    setMeetingId(meeting.id);
    setIsTimeLineOpen(true);
  };

  const handleCloseTimelineModal = () => {
    setIsTimeLineOpen(false);
    setSelectedMeeting(null);
  };

  const isCreatedByOrScheduledBy = (meeting: GeneralMeetingsDto) => {
    return meeting.createdBy == Number(employeeNo) || meeting.scheduledBy == Number(employeeNo);
  };

  const handleEditMeeting = (meeting: GeneralMeetingsDto) => {
    setSelectedMeetingDetails(meeting);
    setMeetingMode('Edit');
    setShowScheduleModal(true);
  };

  const handleRescheduleClick = (meeting: GeneralMeetingsDto) => {
    setSelectedMeetingDetails(meeting);
    setMeetingMode('Reschedule');
    setShowScheduleModal(true);
  };

  const handleTaskRedirect = (meetingId: string) => {
    navigate(`/ui/Meeting/Tasks/${meetingId}`);
  };

  const handleDownload = (filePath: string) => {
    downLoadStatusDocument(filePath);
  };

  const handleOpenPopover = (event: MouseEvent<HTMLButtonElement>, meeting: GeneralMeetingsDto) => {
    setAnchorEl(event.currentTarget);
    setSelectedMeetingData(meeting);
  };

  const handleClosePopover = () => {
    setAnchorEl(null);
  };

  const actionButtons = (meeting: GeneralMeetingsDto): ActionButton[] => [
    {
      title: "Edit", icon: <FaEdit />, color: "info", handler: () => handleEditMeeting(meeting), disabled: !isCreatedByOrScheduledBy(meeting) ||
        meeting.meetingStatus === 'Completed' ||
        meeting.meetingStatus === 'Cancelled' ||
        meeting.meetingStatus === 'Closed',
    },
    {
      title: "Status", icon: <FaFlag />, color: "warning", handler: () => handleMeetingStatusClick(meeting), disabled: !isCreatedByOrScheduledBy(meeting) ||
        meeting.meetingStatus === 'Closed',
    },
    {
      title: "Reschedule", icon: <FaCalendarAlt />, color: "secondary", handler: () => handleRescheduleClick(meeting), disabled: !isCreatedByOrScheduledBy(meeting) ||
        meeting.meetingStatus === 'Completed' ||
        meeting.meetingStatus === 'Cancelled' ||
        meeting.meetingStatus === 'Closed',
    },
    { title: "Timeline", icon: <FaClock />, color: "warning", handler: () => handleclickTimelineHistory(meeting), },
    { title: "Remarks", icon: <FaCommentDots />, color: "primary", handler: () => handleRemarksClick(meeting), },
    { title: "Meeting Link", icon: <FaLink />, color: "success", handler: () => handleLinkClick(meeting), },
    {
      title: "Task", icon: <FaTasks />, color: "primary", handler: () => handleTaskRedirect(String(meeting.id)),
    },
    { title: "Download Attachment", icon: <FaFileDownload />, color: "primary", handler: () => handleDownload(meeting.path), disabled: meeting.path === null, },
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setSearchCriteria((prev) => ({ ...prev, [name]: value }));
  };

  const handleSearch = () => {
    const meetings = meetingsList.filter((meeting) => {
      const query = searchCriteria.meetingName.toLowerCase();
      const meetingName = meeting.meetingName?.toLowerCase() || '';
      const meetingId = meeting.meetingId?.toLowerCase() || '';
      const hostInfo = meeting.hostIdName?.toLowerCase() || '';
      const designation = meeting.designation?.toLowerCase() || '';
      const departments = meeting.departmentDtos?.map((dept) => dept.name.toLowerCase()).join(' ') || '';
      return (
        meetingName.includes(query) ||
        meetingId.includes(query) ||
        hostInfo.includes(query) ||
        designation.includes(query) ||
        departments.includes(query)
      );
    });
    setFilteredMeetings(meetings)
    setCurrentPage(1);
  };

  const handleClear = () => {
    setSearchCriteria({
      meetingId: "",
      meetingName: "",
      hostId: "",
      hostName: "",
      fromDate: "",
      toDate: "",
      status: [],
      segments: [],
      departments: [],
      host: [],
      assignees: [],
    });
    setFilteredMeetings(meetingsList);
    setCurrentPage(1);

  };

  useEffect(() => {
    handleSearch();
  }, [searchCriteria]);

  return (
    <Paper
      elevation={3}
      sx={{
        pb: 2,
        borderRadius: 2,
        overflow: 'hidden',
        position: 'relative',
        boxShadow: '',
      }}
      onClick={() => {
        if (open) {
          setOpen(false);
        }
      }}
    >
      <Box display="flex" justifyContent="space-between" flexWrap="wrap" gap={2} px={5} mt={4} mb={3}>
        <Typography variant="h5" sx={{ fontWeight: 600 }} > General Meeting Details </Typography>
        <Button
          size="small"
          variant="contained"
          startIcon={<FaPlusCircle />}
          sx={actionButtonStyle}
          onClick={handleScheduleMeetingPopup}
        >
          Shedule New Meeting
        </Button>
      </Box>

      <Box display="flex" flexDirection={"row"} justifyContent="end" px={3} mb={2} mt={1}>
        <Search>
          <SearchIconWrapper>
            <IconButton></IconButton>
            <FaSearch color="#9d9d9d" />
          </SearchIconWrapper>
          <StyledInputBase
            placeholder="Search meeting name or id"
            name="meetingName"
            value={searchCriteria.meetingName}
            onChange={handleInputChange}
            inputProps={{ 'aria-label': 'search' }}
          />

          <IconButton
            sx={{
              position: 'absolute',
              right: 4,
              top: '50%',
              transform: 'translateY(-50%)',
              padding: '4px',
              color: "lightgray"
            }}
            onClick={handleClear}
          >
            <CancelOutlined fontSize="medium" />
          </IconButton>

        </Search>
        <Tooltip title="Filter list" {...tooltipProps}>
          <IconButton sx={{ height: 35 }}
            onClick={toggleFilters}
          >
            <GridFilterListIcon fontSize="medium" color="action" />
          </IconButton>
        </Tooltip>
      </Box>

      <TableContainer sx={{ minHeight: "63vh", mt: 2 }}>
        {showTableLoading ? (
          <TableSkeleton column={10} />
        ) : currentMeetings.length > 0 ? (
          <Table size="small">
            <TableHead>
              <TableRow sx={{ background: 'rgb(246, 247, 251)', height: 60 }}>
                <TableCell sx={{ fontWeight: 'bold', width: 50, textAlign: 'center' }}>
                  SR.NO
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', width: 200, whiteSpace: 'nowrap' }}>
                  MEETING ID & NAME
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', width: 200, whiteSpace: 'nowrap' }}>
                  HOST ID & NAME
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', width: 200, whiteSpace: 'nowrap' }}>
                  DESIGNATION & DEPARTMENT
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', width: 150, whiteSpace: 'nowrap' }}>
                  DATE & TIME
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', width: 100, whiteSpace: 'nowrap', textAlign: "center" }}>
                  STATUS
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', width: 50, textAlign: 'center' }}>
                  VIEW
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', width: 100, textAlign: 'center' }}>
                  ACTION
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {currentMeetings.map((meeting, index) => (
                <TableRow key={meeting.id} sx={{ height: 55 }}>
                  <TableCell align="center">
                    {(currentPage - 1) * itemsPerPage + index + 1}
                  </TableCell>
                  <TableCell
                    sx={{
                      maxWidth: 200,
                      whiteSpace: 'nowrap',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                    }}
                  >
                    <Tooltip title={`${meeting.meetingId} - ${meeting.meetingName}`} {...tooltipProps}>
                      <span>
                        {`${meeting.meetingId} - ${meeting.meetingName}`}
                      </span>
                    </Tooltip>

                  </TableCell>
                  <TableCell
                    sx={{
                      maxWidth: 200,
                      whiteSpace: 'nowrap',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                    }}
                  >
                    <Tooltip title={`${meeting.meetingId} - ${meeting.meetingName}`} {...tooltipProps}>
                      <span>
                        {meeting.hostIdName}
                      </span>
                    </Tooltip>
                  </TableCell>
                  <TableCell
                    sx={{
                      maxWidth: 200,
                      whiteSpace: 'nowrap',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                    }}
                  >
                    <Tooltip title={meeting.designation} {...tooltipProps}>
                      <span> {meeting.designation}</span>
                    </Tooltip>
                  </TableCell>
                  <TableCell
                    sx={{
                      maxWidth: 150,
                      whiteSpace: 'nowrap',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                    }}
                  >
                    <div>{moment(meeting.meetingDate).format('DD MMM YYYY')}</div>

                    <div>
                      {meeting.fromTime} - {meeting.toTime}
                    </div>
                  </TableCell>
                  <TableCell align='center' sx={{ maxWidth: 120 }}>
                    <Tooltip title={meeting.meetingStatus} {...tooltipProps}>
                      <span> <StatusChip status={meeting.meetingStatus} /></span>
                    </Tooltip>
                  </TableCell>
                  <TableCell align="center">
                    <Tooltip title="View" {...tooltipProps}>
                      <IconButton
                        color="info"
                        onClick={() => setSelectedMeeting(meeting)}
                        sx={getIconButtonStyle("info")}
                      >
                        <FaEye />
                      </IconButton>
                    </Tooltip>
                  </TableCell>
                  <TableCell align="center">
                    <Box display="flex" gap={1} justifyContent="center">
                      <Tooltip title="More Actions" {...tooltipProps}>
                        <IconButton
                          onClick={(e) => handleOpenPopover(e, meeting)}
                          sx={getIconButtonStyle("#bbbbbb")}
                        >
                          <FaEllipsisH color="#bbbbbb" />
                        </IconButton>
                      </Tooltip>
                      <Popover
                        open={Boolean(anchorEl && selectedMeetingData?.id === meeting.id)}
                        anchorEl={anchorEl}
                        onClose={handleClosePopover}
                        anchorOrigin={{
                          vertical: "bottom",
                          horizontal: "left",
                        }}
                        transformOrigin={{
                          vertical: "top",
                          horizontal: "right",
                        }}
                      >
                        <Box display="grid" gridTemplateColumns="repeat(4, 1fr)" gap={1} p={2} width={220}>
                          {actionButtons(meeting).map(({ title, icon, color, handler, disabled }, index) => (
                            <Tooltip key={title} title={title} {...tooltipProps} placement={index < 4 ? "top" : "bottom"}>
                              <span>
                                <IconButton
                                  color={color}
                                  sx={getIconButtonStyle(color || 'default')}
                                  onClick={() => { handler(); handleClosePopover(); }}
                                  disabled={disabled}
                                >
                                  {icon}
                                </IconButton>
                              </span>
                            </Tooltip>
                          ))}
                        </Box>
                      </Popover>
                    </Box>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        ) : (
          <Box
            display="flex"
            justifyContent="center"
            alignItems="center"
            minHeight="63vh"
          >
            <Empty description="No meetings found. Please schedule a meeting first." />
          </Box>
        )}
      </TableContainer>

      <Box display="flex" justifyContent="center" mt={1}>
        <Pagination
          count={totalPages}
          page={currentPage}
          sx={{
            '& .MuiPaginationItem-root': {
              color: 'rgb(73, 102, 131) !important',
              borderColor: 'rgb(73, 102, 131) !important',
            },
            '& .MuiPaginationItem-root.Mui-selected': {
              backgroundColor: 'rgb(73, 102, 131) !important',
              color: '#fff !important',
            },
          }}
          onChange={handlePageChange}
        />
      </Box>
      {showScheduleModal && (
        <ScheduleGeneralMeeting
          onClose={handleScheduleMeetingPopup}
          meetingMode={meetingMode}
          meetingDetail={selectedMeetingDetails}
          fetchMeetings={fetchMeetings}
        />
      )}
      {showMeetingStatusModal && selectedMeetingData && (
        <GeneralMeetingStatusUI
          onClose={handleCloseMeetingStatusModal}
          meetingData={selectedMeetingData}
          toast={toast}
        />
      )}
      {showLinkModal && selectedMeetingData && (
        <GeneralMeetingLinkPopUp meeting={selectedMeetingData} onClose={handleCloseLinkModal} />
      )}
      {showRemarksModal && selectedMeetingData && (
        <GeneralMeetingRemarksPopUp meeting={selectedMeetingData} onClose={handleCloseRemarksModal} />
      )}
      {selectedMeeting && (
        <ViewMeeting meeting={selectedMeeting} onClose={() => setSelectedMeeting(null)} />
      )}
      {isTimeLineOpen && (
        <GeneralMeetingTaskStatusTimeline
          open={isTimeLineOpen}
          setOpen={handleCloseTimelineModal}
          generalMeetingId={meetingId}
        />
      )}
      <MeetingsTraySlider 
      open={open} 
      setOpen={setOpen} 
      currentSlider={currentSlider} 
      meetings={meetingsList} 
      setFilteredMeetings={setFilteredMeetings} 
      searchCriteria={searchFilterCriteria} 
      setSearchCriteria={setSearchFilterCriteria}
      />

    </Paper>
  );
};

export default GeneralMeeting;