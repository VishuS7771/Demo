
import React, { useState, useEffect, MouseEvent } from "react";
import { EmployeeData } from "../../Interfaces/Login";
import { searchCriteriaProps, Task } from "../../Interfaces/Task";
import { downLoadDocument, getTaskByDesignation, getTaskSearchCriteria } from "../../Requests/TaskRequest";
import { FaUserPlus, FaHistory, FaClock, FaUsers, FaTasks, FaPlusSquare, FaPaperclip, FaEdit, FaEllipsisH, FaSearch } from "react-icons/fa";
import { useNavigate } from 'react-router-dom';
import dayjs from "dayjs";
import { Box, Card, Collapse, IconButton, IconButtonProps, Pagination, Paper, Popover, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Tooltip, Typography } from "@mui/material";
import { GridExpandMoreIcon, GridFilterListIcon } from '@mui/x-data-grid';
import { Empty } from "antd";
import BaTraySlider from "../Slider/BaTray/BaTraySlider";
import TableSkeleton from "../Skeletons/Skeleton";
import { CancelOutlined, ExpandLess } from "@mui/icons-material";
import { getIconButtonStyle } from "../../util/constants/commonStyles";
import { Search, SearchIconWrapper, StyledInputBase, tooltipProps } from "../../util/constants/commonStyles";
import { PriorityChip } from "../Chip/PriorityChip";

interface ActionButton {
    title: string;
    icon: React.ReactNode;
    color: IconButtonProps['color'];
    handler: () => void;
}

const BaTray = () => {

    const [showTableLoading, setShowTableLoading] = useState(false);
    const [tasks, setTasks] = useState<Task[]>([]);
    const [employee, setEmployee] = useState<EmployeeData | null>(null);
    const [searchCriteria, setSearchCriteria] = useState<searchCriteriaProps>({
        taskId: "",
        taskName: "",
        fromDate: "",
        toDate: "",
        status: [],
        subStatus: [],
        employeeId: null,
    })
    const [filteredTasks, setFilteredTasks] = useState<Task[]>([]);
    const [selectedTask, setSelectedTask] = useState<Task | null>(null);
    const [currentSlider, setCurrentSlider] = useState<string>("");
    const [currentPage, setCurrentPage] = useState(1);
    const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null);
    const [expandedRows, setExpandedRows] = useState<Record<string, boolean>>({});
    const navigate = useNavigate();
    const itemsPerPage = 10;
    const [open, setOpen] = useState(false);
    const toggleDrawer = (newOpen: boolean) => {
        setOpen(newOpen);
    }
    const toggleFilters = () => {
        setCurrentSlider("searchProjectDetails");
        toggleDrawer(true);
    };
    const handlePageChange = (pageNumber: number) => {
        setCurrentPage(pageNumber);
    };
    const currentTasks = filteredTasks.slice(
        (currentPage - 1) * itemsPerPage,
        currentPage * itemsPerPage
    );
    const totalPages = Math.ceil(filteredTasks.length / itemsPerPage);
    const fetchTasks = async (designationId: string) => {
        try {
            setShowTableLoading(true);
            const tasks: Task[] = await getTaskByDesignation(designationId, Number(employee?.EmployeeNo));
            const sortedResponse = (tasks || []).sort((a: Task, b: Task) =>
                dayjs(b.startDate).valueOf() - dayjs(a.startDate).valueOf()
            );

            setTasks(sortedResponse);
            setFilteredTasks(sortedResponse);
        } catch (error) {
            console.error("Error fetching tasks:", error);
        } finally {
            setShowTableLoading(false)
        }
    };

    const fetchSearchCriteria = async (empId: number) => {
        try {
            const response = await getTaskSearchCriteria(empId);
            setSearchCriteria({
                ...response.data,
                status: [],
                subStatus: [],
            });
            handleSearch();
        } catch (error) {
            console.error("Error fetching tray list:", error);
        } finally {
        }
    };

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setSearchCriteria((prev) => ({ ...prev, [name]: value }));
    };

    const handleSearch = () => {
        const filtered = tasks.filter((task) => {
            if (!searchCriteria.taskName) return true;

            return task.taskName
                ?.toLowerCase()
                .includes(searchCriteria.taskName.toLowerCase());
        });
        setFilteredTasks(filtered);
        setCurrentPage(1);
    };

    const handleClear = () => {
        setSearchCriteria({
            taskId: "",
            taskName: "",
            fromDate: "",
            toDate: "",
            status: [],
            subStatus: [],
            employeeId: Number(employee?.EmployeeNo) || null,
        });
        setFilteredTasks(tasks);
        setCurrentPage(1);

    };

    useEffect(() => {
        const storedData = localStorage.getItem('employeedata');
        if (storedData) {
            setEmployee(JSON.parse(storedData));
        }
    }, []);

    useEffect(() => {
        handleSearch();
    }, [searchCriteria]);

    useEffect(() => {
        if (employee?.DesignationId) {
            // showLoader();
            fetchTasks(employee.DesignationId);
            fetchSearchCriteria(Number(employee.EmployeeNo))
        }
        setSearchCriteria({
            taskId: "",
            taskName: "",
            fromDate: "",
            toDate: "",
            status: [],
            subStatus: [],
            employeeId: Number(employee?.EmployeeNo) || null,
        });
    }, [employee]);

    const clickAssigneChange = () => {
        setCurrentSlider("changeAssignee");
        toggleDrawer(true);
    };
    const clickAssigneHistory = () => {
        setCurrentSlider("assigneeHistory");
        toggleDrawer(true);
    };
    const clickTimelineHistory = () => {
        setCurrentSlider("timeline");
        toggleDrawer(true);
    };
    const clickedAdditonal = () => {
        setCurrentSlider("additional");
        toggleDrawer(true);
    };
    const clickSubTask = () => {
        if (selectedTask) {
            navigate(`/ui/sub-task/${selectedTask.id}`);
        }
    };
    const clickMeeting = () => {
        if (selectedTask) {
            navigate(`/ui/MeetingDetails/${selectedTask.id}`);
        }
    };
    const clickAttachment = () => {
        if (selectedTask && selectedTask.attachmentPath) {
            downLoadDocument(selectedTask.attachmentPath)
        }
    };
    const clickedEdit = () => {
        if (selectedTask) {
            navigate(`/ui/task/${selectedTask.id}`);
        }
    };
    const renderStatusAndSubStatus = (taskId: number) => {
        const task = tasks.find((t) => t.id === taskId);
        if (!task || !task.taskTimelineDto || task.taskTimelineDto.length === 0) {
            return null;
        }
        const latestTimeline = task.taskTimelineDto.reduce((latest, current) => {
            return new Date(current.dateAndTime) > new Date(latest.dateAndTime) ? current : latest;
        });
        const status = latestTimeline.statusDefinitionsDto?.status;
        const subStatus = latestTimeline.subStatusDefinitionsDto?.subStatus;

        return (
            <>
                <div style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', }}>{status}</div>
                <div style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', }}>{subStatus}</div>
            </>
        );
    };
    const renderPropriator = (taskId: number) => {
        const task = tasks.find((t) => t.id === taskId);
        if (!task || !task.taskTimelineDto || task.taskTimelineDto.length === 0) {
            return null;
        }
        const latestTimeline = task.taskTimelineDto.reduce((latest, current) => {
            return new Date(current.dateAndTime) > new Date(latest.dateAndTime) ? current : latest;
        });
        const proprietor = latestTimeline.proprietorAssignmentsDto.proprietorMasterDto.proprietorName;
        return `${proprietor || 'N/A'} `;
    };
    const renderDate = (taskId: number) => {
        const task = tasks.find((t) => t.id === taskId);
        if (!task || !task.taskTimelineDto || task.taskTimelineDto.length === 0) {
            return <td>N/A</td>;
        }
        const latestTimeline = task.taskTimelineDto.reduce((latest, current) => {
            return new Date(current.dateAndTime) > new Date(latest.dateAndTime) ? current : latest;
        });
        const statusDate = latestTimeline.dateAndTime
            ? dayjs(latestTimeline.dateAndTime).format('DD-MM-YYYY')
            : 'N/A';

        const enrollDate = task.dateAndTime;
        return (
            <>
                <div>Enroll Date: {enrollDate}</div>
                <div>Status Date: {statusDate}</div>
            </>
        );
    };
    const toggleRow = (taskId: string) => {
        setExpandedRows((prev) => ({
            ...prev,
            [taskId]: !prev[taskId],
        }));
    };
    const handleOpenPopover = (event: MouseEvent<HTMLButtonElement>, task: Task) => {
        setSelectedTask(task)
        setAnchorEl(event.currentTarget);
    };
    const handleClosePopover = () => {
        setAnchorEl(null);
    };
    const actionButtons: ActionButton[] = [
        { title: "Assign", icon: <FaUserPlus />, color: "success", handler: clickAssigneChange },
        { title: "Assign History", icon: <FaHistory />, color: "info", handler: clickAssigneHistory },
        { title: "Timeline", icon: <FaClock />, color: "warning", handler: clickTimelineHistory },
        { title: "Edit", icon: <FaEdit />, color: "primary", handler: clickedEdit },
        { title: "Meeting", icon: <FaUsers />, color: "secondary", handler: clickMeeting },
        { title: "Sub Task", icon: <FaTasks />, color: "primary", handler: clickSubTask },
        { title: "Additional Requirement", icon: <FaPlusSquare />, color: "error", handler: clickedAdditonal },
        { title: "Attachment", icon: <FaPaperclip />, color: "default", handler: clickAttachment },
    ];

    return (
        <Paper elevation={3} sx={{ pt: 2, pb: 2, borderRadius: 2, overflow: "hidden", position: "relative", boxShadow: "" }}
            onClick={() => {
                if (open) {
                    setOpen(false);
                }
            }}>

            <Box mt={2}>
                <Box display="flex" justifyContent="space-between" flexWrap="wrap" gap={2}>
                    <Typography variant="h5" sx={{ fontWeight: 600, px: 5 }} >Project Details </Typography>
                    <Box display="flex" justifyContent="end" px={3} mb={3}>
                        <Search>
                            <SearchIconWrapper>
                                <IconButton></IconButton>
                                <FaSearch color="#9d9d9d" />
                            </SearchIconWrapper>
                            <StyledInputBase
                                placeholder="Search project name"
                                name="taskName"
                                value={searchCriteria.taskName}
                                onChange={handleInputChange}
                                inputProps={{ 'aria-label': 'search' }}
                            />
                            {searchCriteria.taskName && <IconButton
                                sx={{
                                    position: 'absolute',
                                    right: 4,
                                    top: '50%',
                                    transform: 'translateY(-50%)',
                                    padding: '4px',
                                    color: "lightgray"
                                }}
                                onClick={handleClear}
                            >
                                <CancelOutlined fontSize="medium" />
                            </IconButton>}

                        </Search>
                        <Tooltip title="Filter list" {...tooltipProps}>
                            <IconButton sx={{ height: 35 }} onClick={toggleFilters}>
                                <GridFilterListIcon fontSize="medium" color="action" />
                            </IconButton>
                        </Tooltip>
                    </Box>
                </Box>
                <TableContainer style={{ minHeight: "68vh" }}>
                    {
                        showTableLoading ? (

                            <TableSkeleton column={10} />

                        )
                            : currentTasks.length > 0 ? (

                                <Table size="small">
                                    <TableHead>
                                        <TableRow sx={{ background: "rgb(246, 247, 251)", height: 60 }}>
                                            <TableCell sx={{ width: 50 }}></TableCell>
                                            <TableCell sx={{ fontWeight: "bold", width: 80, textAlign: "center" }}>SR.NO</TableCell>
                                            <TableCell sx={{ fontWeight: "bold", width: 120 }}>PROJECT ID</TableCell>
                                            <TableCell sx={{
                                                whiteSpace: "nowrap",
                                                overflow: "hidden",
                                                textOverflow: "ellipsis",
                                                fontWeight: "bold",
                                                width: 180,

                                            }}>PROJECT NAME</TableCell>
                                            <TableCell sx={{ fontWeight: "bold", width: 200 }}>DATE</TableCell>
                                            <TableCell sx={{ fontWeight: "bold", width: 150 }}>MODULE</TableCell>
                                            <TableCell sx={{ fontWeight: "bold", width: 150 }}>SUBJECT</TableCell>
                                            <TableCell sx={{ fontWeight: "bold", width: 120 }} align="center" >PRIORITY</TableCell>
                                            <TableCell sx={{
                                                width: 100,
                                                whiteSpace: "nowrap",
                                                overflow: "hidden",
                                                textOverflow: "ellipsis",
                                                fontWeight: "bold"
                                            }}>STATUS & SUB-STATUS</TableCell>
                                            <TableCell sx={{ fontWeight: "bold", width: 150 }}>PROPRIETOR</TableCell>
                                            <TableCell sx={{ fontWeight: "bold", width: 100 }} align="center" >ACTION</TableCell>
                                        </TableRow>
                                    </TableHead>


                                    <TableBody>
                                        {currentTasks.map((task, index) => (
                                            <React.Fragment key={task.id}>
                                                <TableRow sx={{ height: 55 }}>
                                                    <TableCell>
                                                        <IconButton size="small" onClick={() => toggleRow(task.taskId)}>
                                                            {expandedRows[task.taskId] ? <ExpandLess /> : <GridExpandMoreIcon />}
                                                        </IconButton>
                                                    </TableCell>
                                                    <TableCell align="center">{(currentPage - 1) * itemsPerPage + index + 1}</TableCell>
                                                    <TableCell>{task.taskId}</TableCell>
                                                    <TableCell
                                                        sx={{
                                                            maxWidth: 100,
                                                            whiteSpace: "nowrap",
                                                            overflow: "hidden",
                                                            textOverflow: "ellipsis",
                                                        }}
                                                    >

                                                        <Tooltip title={task.taskName} {...tooltipProps}>
                                                            <span>{task.taskName}</span>
                                                        </Tooltip>


                                                    </TableCell>
                                                    <TableCell
                                                        sx={{
                                                            minWidth: 100,
                                                            whiteSpace: "nowrap",
                                                            overflow: "hidden",
                                                            textOverflow: "ellipsis"

                                                        }}
                                                    >{renderDate(task.id)}</TableCell>
                                                    <TableCell
                                                        sx={{
                                                            maxWidth: 150,
                                                            whiteSpace: "nowrap",
                                                            overflow: "hidden",
                                                            textOverflow: "ellipsis"

                                                        }}

                                                    >


                                                        <Tooltip title={task.moduleName} {...tooltipProps}>
                                                            <span>{task.moduleName}</span>
                                                        </Tooltip>

                                                    </TableCell>
                                                    <TableCell
                                                        sx={{
                                                            maxWidth: 180,
                                                            whiteSpace: "nowrap",
                                                            overflow: "hidden",
                                                            textOverflow: "ellipsis"

                                                        }}
                                                    >
                                                        <Tooltip title={task.requirementSubject} {...tooltipProps}>
                                                            <span>{task.requirementSubject}</span>
                                                        </Tooltip>

                                                    </TableCell>
                                                    <TableCell>
                                                        <PriorityChip status={task.taskPriority} />
                                                    </TableCell>
                                                    <TableCell
                                                        sx={{
                                                            maxWidth: 150,

                                                        }}
                                                    >{renderStatusAndSubStatus(task.id)}</TableCell>
                                                    <TableCell>{renderPropriator(task.id)}</TableCell>
                                                    <TableCell>
                                                        <Box display="flex" gap={1} justifyContent="center">

                                                            <Tooltip title="More Actions" {...tooltipProps}>
                                                                <IconButton color="default" onClick={(e) => handleOpenPopover(e, task)} sx={getIconButtonStyle("#bbbbbb")}>
                                                                    <FaEllipsisH color="#bbbbbb" />                                                                    </IconButton>
                                                            </Tooltip>

                                                            <Popover open={Boolean(anchorEl)} anchorEl={anchorEl} onClose={handleClosePopover} anchorOrigin={{
                                                                vertical: "bottom",
                                                                horizontal: "left",
                                                            }}
                                                                transformOrigin={{
                                                                    vertical: "top",
                                                                    horizontal: "right",
                                                                }}
                                                            >
                                                                <Box display="grid" gridTemplateColumns="repeat(4, 1fr)" gap={1} p={2} width={220}>
                                                                    {actionButtons.map(({ title, icon, color, handler }, index) => (
                                                                        <Tooltip
                                                                            key={title}
                                                                            placement={index < 4 ? "top" : "bottom"}
                                                                            title={title}
                                                                            {...tooltipProps}
                                                                        >
                                                                            <IconButton
                                                                                sx={getIconButtonStyle(color || 'default')}
                                                                                onClick={() => {
                                                                                    handler();
                                                                                    handleClosePopover();
                                                                                }}
                                                                            >
                                                                                {icon}
                                                                            </IconButton>
                                                                        </Tooltip>
                                                                    ))}
                                                                </Box>

                                                            </Popover>

                                                        </Box>
                                                    </TableCell>
                                                </TableRow>
                                                <TableRow>
                                                    <TableCell colSpan={11} style={{ paddingBottom: 0, paddingTop: 0 }}>

                                                        <Collapse in={expandedRows[task.taskId]} timeout="auto" unmountOnExit>
                                                            <Card sx={{ width: "99%", p: 2, boxShadow: 3, m: 2 }}>
                                                                <TableContainer component={Paper} elevation={0}>
                                                                    <Table size="small">
                                                                        <TableHead>
                                                                            <TableRow>
                                                                                <TableCell>
                                                                                    <Typography variant="body1" fontWeight="bold">Raised By</Typography>
                                                                                </TableCell>
                                                                                <TableCell>
                                                                                    <Typography variant="body1" fontWeight="bold">Date</Typography>
                                                                                </TableCell>
                                                                                <TableCell>
                                                                                    <Typography variant="body1" fontWeight="bold">Status & Sub-Status</Typography>
                                                                                </TableCell>
                                                                                <TableCell>
                                                                                    <Typography variant="body1" fontWeight="bold">Requirement</Typography>
                                                                                </TableCell>
                                                                                <TableCell>
                                                                                    <Typography variant="body1" fontWeight="bold">Remarks</Typography>
                                                                                </TableCell>
                                                                            </TableRow>
                                                                        </TableHead>

                                                                        <TableBody>
                                                                            <TableRow>
                                                                                <TableCell sx={{ border: "none" }}>{task.raisedByName}</TableCell>
                                                                                <TableCell sx={{ border: "none" }}>{renderDate(task.id)}</TableCell>
                                                                                <TableCell sx={{ border: "none" }}>{renderStatusAndSubStatus(task.id)}</TableCell>
                                                                                <TableCell sx={{ border: "none" }}>{task.requirementInDetail}</TableCell>
                                                                                <TableCell sx={{ border: "none" }}>{task.remarks}</TableCell>
                                                                            </TableRow>
                                                                        </TableBody>
                                                                    </Table>
                                                                </TableContainer>
                                                            </Card>

                                                        </Collapse>
                                                    </TableCell>
                                                </TableRow>

                                            </React.Fragment>
                                        ))
                                        }
                                    </TableBody>
                                </Table>
                            )
                                :
                                (
                                    <Box
                                        display="flex"
                                        justifyContent="center"
                                        alignItems="center"
                                        minHeight="50vh"
                                    >
                                        <Empty description="No projects found. Please add projects first or change the search term." />
                                    </Box>
                                )}

                    <BaTraySlider open={open} setOpen={setOpen} task={selectedTask} currentSlider={currentSlider} setFilteredTasks={setFilteredTasks} tasks={tasks} />

                </TableContainer>

                <Box display="flex" justifyContent="center" mb={1}>

                    <Pagination 
                    count={totalPages}
                    page={currentPage}
                        sx={{
                            '& .MuiPaginationItem-root': {
                                color: 'rgb(73, 102, 131) !important',
                                borderColor: 'rgb(73, 102, 131) !important',
                            },
                            '& .MuiPaginationItem-root.Mui-selected': {
                                backgroundColor: 'rgb(73, 102, 131) !important',
                                color: '#fff !important',
                            }
                        }}
                        onChange={(_, newPage) => handlePageChange(newPage)} />
                </Box>
            </Box>
        </Paper>
    );
};

export default BaTray;
