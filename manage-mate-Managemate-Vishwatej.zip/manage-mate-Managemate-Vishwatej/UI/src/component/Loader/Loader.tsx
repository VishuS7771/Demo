import "./PageLoader.css"
interface LinearProgressBarProps {
  isLoading: boolean;
}

export default function LinearProgressBar({ isLoading }: LinearProgressBarProps) {
  if (!isLoading) return null;

  return (
    <div className="loader-overlay">
    <div className="loader">
      {Array.from({ length: 12 }, (_, i) => (
        <div key={i} className={`bar${i + 1}`} />
      ))}
    </div>
  </div>
  );
}
