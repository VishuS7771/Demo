import { Autorenew, MenuOpen, Person, SupervisedUserCircleSharp, ViewModule } from "@mui/icons-material";
import { AppBar, Paper, Tab, Tabs } from "@mui/material";
import { useEffect, useState } from "react";
import AddStatusMapping from "../StatusMapping/AddStatusMapping";
import SubStatusMapping from "../SubStatus/SubStatusForm";
import ProprietorMapping from "../Proprietor/Proprietor";
import UserMapping from "../StatusMapping/UserMapping";
import AddModuleMapping from "../StatusMapping/AddModuleMapping";
import { MenuPermission } from "../../Interfaces/MenuPermission";

const defaultMenuPermission: MenuPermission = {
    menuPermissionId: 0,
    employeeId: 0,
    isStatus: false,
    isSubStatus: false,
    isProprietor: false,
    isAssign: false,
    isUser: false,
    isDashboard: false,
    isTask: false,
    isProject: false,
    isReport: false,
    isModule: false,
    isGeneralMeeting: false,
};

const MappingMaster: React.FC = () => {
    const [value, setValue] = useState(0);
    const [menuPermission, setMenuPermission] = useState<MenuPermission | null>(null);

    const handleChange = (_event: React.SyntheticEvent, newValue: number) => {
        setValue(newValue);
    };

    const tabStyles = {
        color: "rgb(33 62 90)",
        '&:hover': { backgroundColor: 'rgb(73 102 131)', fontWeight: 600, color: "#ffffff" },
        '&.Mui-selected': { fontWeight: 600 },
    };

    const tabsHeaderStyle = { p: 2, boxShadow: 'unset', mb: 3, mt: 3, background: "#ffffff" };

    const allTabs = [
        { key: 'isStatus', label: "Status Mapping", icon: <Autorenew />, component: <AddStatusMapping /> },
        { key: 'isSubStatus', label: "Sub-Status Mapping", icon: <MenuOpen />, component: <SubStatusMapping /> },
        { key: 'isProprietor', label: "Proprietor Mapping", icon: <Person />, component: <ProprietorMapping /> },
        { key: 'isModule', label: "Module Mapping", icon: <ViewModule />, component: <AddModuleMapping /> },
        { key: 'isUser', label: "User Mapping", icon: <SupervisedUserCircleSharp />, component: <UserMapping /> },
    ];

    const visibleTabs = allTabs.filter(tab => menuPermission?.[tab.key as keyof MenuPermission]);

    useEffect(() => {

        const storedMenuPermission = localStorage.getItem("menuPermission");
        if (storedMenuPermission) {
            try {
                const menuPermissionObj: MenuPermission = JSON.parse(storedMenuPermission);
                setMenuPermission(menuPermissionObj);
            } catch (error) {
                console.error("Error parsing menuPermission from localStorage:", error);
                setMenuPermission(defaultMenuPermission);
            }
        }

    }, []);

    return (
        <>
            <AppBar position="static" sx={tabsHeaderStyle}>
                <Tabs
                    value={value}
                    onChange={handleChange}
                    variant="fullWidth"
                    textColor="inherit"
                    aria-label="mapping tabs"
                    slotProps={{
                        indicator: {
                            style: { backgroundColor: 'rgb(73, 102, 131)' },
                        },
                    }}
                >
                    {allTabs
                        .filter(tab => menuPermission?.[tab.key as keyof MenuPermission])
                        .map((tab, index) => (
                            <Tab
                                key={index}
                                icon={tab.icon}
                                label={tab.label}
                                iconPosition="top"
                                sx={tabStyles}
                            />
                        ))}
                </Tabs>
            </AppBar>

            <Paper
                elevation={3}
                sx={{
                    pb: 2,
                    borderRadius: 2,
                    overflow: "hidden",
                    position: "relative",
                    minHeight: "68vh",
                }}
            >

                {visibleTabs[value]?.component}
            </Paper>
        </>
    );
};

export default MappingMaster;