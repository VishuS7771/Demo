import React, { useEffect, useState } from "react";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { Box, Button, Pagination, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography } from "@mui/material";
import { FaPlusCircle } from "react-icons/fa";
import { usePageLoader } from "../../context/PageLoaderContext";
import { Modules, User } from "../../Interfaces/Task";
import { ModuleAssignmentDto } from "../../Interfaces/Module";
import MappingModal from "../Modal/Mapping/MappingModal";
import { getAllEmployees } from "../../Requests/MeetingRequest";
import { getAllModules, getmModuleList, updateModuleMapping } from "../../Requests/TaskRequest";
import ModuleMapping from "../Modal/Mapping/ModuleMapping";

const AddModuleMapping: React.FC = () => {
    const { showLoader, hideLoader } = usePageLoader();
    const [tableLoading, setTableLoading] = useState(false);
    const [modules, setModules] = useState<Modules[]>([]);
    const [employees, setEmployees] = useState<User[]>([]);
    const [empId, setEmpId] = useState<number | null>(null);
    const [moduleAssignments, setModuleAssignments] = useState<ModuleAssignmentDto[]>([]);
    const [selectedAssignment, setSelectedAssignment] = useState<ModuleAssignmentDto | null>(null);
    const [isEditing, setIsEditing] = useState(false);
    const [showModal, setShowModal] = useState(false);
    const [currentPage, setCurrentPage] = useState(1);
    const itemsPerPage = 8;


    const fetchEmployees = async () => {
        try {
            const data = await getAllEmployees();
            setEmployees(data);
        } catch (error) {
            console.error("Error fetching employees:", error);
        }
    };

    const fetchAllModuleMappings = async () => {
        setTableLoading(true);
        showLoader();
        try {
            const response = await getAllModules();
            const updatedModuleMappings = Array.isArray(response.data) ? response.data : [];
            setModuleAssignments(updatedModuleMappings);
        } catch (error) {
            console.error("Error fetching all module mappings:", error);
            setModuleAssignments([]);
        } finally {
            hideLoader();
            setTableLoading(false);
        }
    };

    const handleShowModal = () => {
        if (showModal) {
            setIsEditing(false);
            setSelectedAssignment(null);
        }
        setShowModal(!showModal);

    };

    const handleEdit = (moduleMappingId: number) => {
        const moduleToEdit = moduleAssignments.find((assignment) => assignment.moduleMappingId === moduleMappingId);
        if (moduleToEdit) {
            setSelectedAssignment(moduleToEdit);
            setIsEditing(true);
            setShowModal(true);
        }
    };

    const handleSave = async (updatedAssignment: ModuleAssignmentDto | null, isNew: boolean) => {
        if (updatedAssignment) {
            if (isNew) {
                setModuleAssignments([...moduleAssignments, updatedAssignment]);
                toast.success("Module mapping saved successfully!");
            } else {
                setModuleAssignments(prevAssignments =>
                    prevAssignments.map(assignment =>
                        assignment.moduleMappingId === updatedAssignment.moduleMappingId
                            ? updatedAssignment
                            : assignment
                    )
                );
                toast.success("Module mapping updated successfully!");
            }
            // Refresh assignments to ensure data consistency
            try {
                const response = await getAllModules();
                setModuleAssignments(Array.isArray(response.data) ? response.data : []);
            } catch (error) {
                console.error("Error refreshing module mappings:", error);
            }
        }
        setShowModal(false);
    };

    const handleInactive = async (moduleMappingId: number) => {
        showLoader();
        const moduleToUpdate = moduleAssignments.find((assignment) => assignment.moduleMappingId === moduleMappingId);
        if (moduleToUpdate) {
            const updatedModule = { ...moduleToUpdate, isActive: moduleToUpdate.isActive === 1 ? 0 : 1 };
            try {
                await updateModuleMapping(moduleMappingId, updatedModule);
                setModuleAssignments(moduleAssignments.map((assignment) =>
                    assignment.moduleMappingId === moduleMappingId ? updatedModule : assignment
                ));
                toast.success(`Module mapping marked as ${updatedModule.isActive === 1 ? "Active" : "De-Activate"}`);
            } catch (error) {
                console.error("Error updating module mapping:", error);
                toast.error("Failed to update module mapping.");
            } finally {
                hideLoader();
            }
        }
    };

    const currentItems = moduleAssignments.slice(
        (currentPage - 1) * itemsPerPage,
        currentPage * itemsPerPage
    );
    const totalPages = Math.ceil(moduleAssignments.length / itemsPerPage);

    const handlePageChange = (page: number) => {
        setCurrentPage(page);
    };


    useEffect(() => {
        if (empId) {
            getmModuleList(empId)
                .then((response) => setModules(response.data))
                .catch((error) => {
                    console.error("Error fetching module list:", error);
                    toast.error("Failed to fetch modules.");
                });
        }
    }, [empId]);

    useEffect(() => {
        const storedData = localStorage.getItem("employeedata");
        if (storedData) {
            try {
                const parsedData = JSON.parse(storedData);
                setEmpId(parsedData.EmployeeNo);
            } catch (error) {
                console.error("Error parsing employee data from localStorage:", error);
            }
        }

        fetchEmployees();
        fetchAllModuleMappings();
    }, []);

    return (
        <>
            <Box display="flex" justifyContent="end" mr={4}>
                <Button
                    size="small"
                    variant="contained"
                    startIcon={<FaPlusCircle fontSize="small" />}
                    onClick={handleShowModal}
                    sx={{
                        backgroundColor: 'rgba(73, 102, 131, 0.15)',
                        backdropFilter: 'blur(6px)',
                        color: 'rgb(73, 102, 131)',
                        border: '1px solid rgba(73, 102, 131, 0.3)',
                        textTransform: 'none',
                        fontWeight: 500,
                        fontSize: '0.75rem',
                        boxShadow: '0 1px 4px rgba(0,0,0,0.1)',
                        m: 3,
                        py: 1,
                        '&:hover': {
                            backgroundColor: 'rgba(73, 102, 131, 0.25)',
                            color: 'rgb(73, 102, 131)',
                        },
                    }}
                >
                    Add Module Mapping
                </Button>
            </Box>
            <TableContainer sx={{ minHeight: "50vh" }}>
                {!tableLoading ? (
                    currentItems.length > 0 ? (
                        <Table sx={{ tableLayout: "fixed", width: "100%" }} size="small">
                            <TableHead>
                                <TableRow sx={{ background: "rgb(246, 247, 251)", height: 60 }}>
                                    <TableCell sx={{ fontWeight: "bold", textAlign: "center", width: "10%" }}>SR. No.</TableCell>
                                    <TableCell sx={{ fontWeight: "bold", width: "30%" }}>MODULE NAME</TableCell>
                                    <TableCell sx={{ fontWeight: "bold", width: "30%" }}>EMPLOYEE NAME</TableCell>
                                    <TableCell sx={{ fontWeight: "bold", textAlign: "center", width: "30%" }}>ACTION</TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {currentItems.map((assignment, index) => (
                                    <TableRow key={assignment.moduleMappingId} sx={{ height: 50 }}>
                                        <TableCell align="center">
                                            {(currentPage - 1) * itemsPerPage + index + 1}
                                        </TableCell>
                                        <TableCell>
                                            <Typography variant="body2" noWrap>{assignment.module}</Typography>
                                        </TableCell>
                                        <TableCell>
                                            <Typography variant="body2" noWrap>{assignment.mappedEmployee}</Typography>
                                        </TableCell>
                                        <TableCell align="center">
                                            <Box display="flex" gap={1} justifyContent="center">
                                                <Button
                                                    size="small"
                                                    variant="contained"
                                                    onClick={() => handleEdit(assignment.moduleMappingId)}
                                                    sx={{
                                                        minWidth: "50px",
                                                        fontWeight: "600",
                                                        fontSize: "0.6rem",
                                                        padding: "2px 6px",
                                                        height: "25px",
                                                        lineHeight: "1",
                                                        backgroundColor: "#007bff",
                                                        '&:hover': {
                                                            backgroundColor: "#0056b3",
                                                        },
                                                    }}
                                                >
                                                    Edit
                                                </Button>
                                                <Button
                                                    size="small"
                                                    variant="contained"
                                                    color={assignment.isActive === 1 ? "error" : "success"}
                                                    onClick={() => handleInactive(assignment.moduleMappingId)}
                                                    sx={{
                                                        minWidth: "80px",
                                                        fontSize: "0.6rem",
                                                        fontWeight: "600",
                                                        padding: "2px 6px",
                                                        height: "25px",
                                                        lineHeight: "1",
                                                        backgroundColor: (theme) =>
                                                            assignment.isActive === 1 ? "#dc3545" : theme.palette.success.main,
                                                        '&:hover': {
                                                            backgroundColor: (theme) =>
                                                                assignment.isActive === 1 ? "#c82333" : theme.palette.success.dark,
                                                        },
                                                    }}
                                                >
                                                    {assignment.isActive === 1 ? "Deactivate" : "Activate"}
                                                </Button>
                                            </Box>
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    ) : (
                        <Box display="flex" justifyContent="center" alignItems="center" minHeight="50vh">
                            <Typography>No module assignments available.</Typography>
                        </Box>
                    )
                ) : (
                    <></>
                )}
            </TableContainer>
            {currentItems.length > 0 && (
                <Box display="flex" justifyContent="center" mt={2}>
                    <Pagination
                        count={totalPages}
                        page={currentPage}
                        onChange={(_, newPage) => handlePageChange(newPage)}
                        sx={{
                            '& .MuiPaginationItem-root': {
                                color: 'rgb(73, 102, 131) !important',
                                borderColor: 'rgb(73, 102, 131) !important',
                            },
                            '& .MuiPaginationItem-root.Mui-selected': {
                                backgroundColor: 'rgb(73, 102, 131) !important',
                                color: '#fff !important',
                            },
                        }}
                    />
                </Box>
            )}
            <MappingModal
                title={"Module Mapping"}
                isVisible={showModal}
                onClose={handleShowModal}
            >
                <ModuleMapping
                    editData={selectedAssignment}
                    mode={isEditing ? "edit" : "add"}
                    isOpen={showModal}
                    onClose={handleShowModal}
                    onSave={handleSave}
                    modules={modules}
                    employees={employees}
                    empId={empId}
                />
            </MappingModal>
        </>
    );
};

export default AddModuleMapping;
