import React, { useEffect, useState } from "react";
import { StatusDefinitionsDto } from "../../Interfaces/Task";
import { toast, ToastContainer } from "react-toastify";
import { getAllStatus, updateStatusMapping } from "../../Requests/StatusMappingRequest";
import { Box, Button, Pagination, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography } from "@mui/material";
import { FaPlusCircle } from "react-icons/fa";
import { usePageLoader } from "../../context/PageLoaderContext";
import { Empty } from "antd";
import MappingModal from "../Modal/Mapping/MappingModal";
import StatusMapping from "../Modal/Mapping/StatusMapping";

const AddStatusMapping: React.FC = () => {

    const { showLoader, hideLoader } = usePageLoader();
    const [filteredStatusMappings, setFilteredStatusMappings] = useState<StatusDefinitionsDto[]>([]);
    const [editMode, setEditMode] = useState<boolean>(false);
    const [status, setStatus] = useState<StatusDefinitionsDto>({
        statusId: 0,
        status: "",
        createdBy: 0,
        trayMasterDto: { trayId: 0, trayName: "", isActive: 1, createdBy: 0, createdOn: "" },
        createdOn: "",
        isActive: 1,
    });

    const [currentPage, setCurrentPage] = useState(1);
    const itemsPerPage = 8;

    useEffect(() => {
        const storedData = localStorage.getItem("employeedata");
        if (storedData) {
            try {
                const parsedData = JSON.parse(storedData);
                setStatus(prevTask => ({
                    ...prevTask,
                    createdBy: parsedData.EmployeeNo,
                    isActive: parsedData.isActive || 1,
                }));
                fetchAllStatusMappings();
            } catch (error) {
                console.error("Error parsing employee data from localStorage:", error);
            }
        } else {
            console.log("No employee data found in localStorage");
        }
    }, []);

    const fetchAllStatusMappings = async () => {
        showLoader();
        try {
            const response = await getAllStatus();
            const updatedMappings = Array.isArray(response.data) ? response.data : [];
            setFilteredStatusMappings(updatedMappings);
        } catch (error) {
            setFilteredStatusMappings([]);
        } finally {
            hideLoader();
        }
    };

    const handleEdit = (id: number) => {
        const statusToEdit = filteredStatusMappings.find((mapping) => mapping.statusId === id);
        if (statusToEdit) {
            setEditMode(true);
            setStatus(statusToEdit);
            setShowModal(!showModal);
        }
    };

    const handleInactive = async (id: number) => {
        const statusToUpdate = filteredStatusMappings.find((filteredStatusMapping) => filteredStatusMapping.statusId === id);
        showLoader();
        if (statusToUpdate) {
            const updatedStatus = { ...statusToUpdate, isActive: statusToUpdate.isActive === 1 ? 0 : 1 };
            try {
                await updateStatusMapping(id, updatedStatus);
                setFilteredStatusMappings(filteredStatusMappings.map((assignment) =>
                    assignment.statusId === id ? updatedStatus : assignment
                ));

                const statusMessage = updatedStatus.isActive === 1 ? 'Active' : 'De-Activate';
                toast.success(`Assignment marked as ${statusMessage}`);
            } catch (error) {
                toast.error("Failed to update status. Please try again.");
            } finally {
                hideLoader();
            }
        }
    };

    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentItems = filteredStatusMappings.slice(indexOfFirstItem, indexOfLastItem);
    const totalPages = Math.ceil(filteredStatusMappings.length / itemsPerPage);

    const handlePageChange = (page: number) => {
        if (page >= 1 && page <= totalPages) {
            setCurrentPage(page);
        }
    };

    const [showModal, setShowModal] = useState(false);
    const handleShowModal = () => {
        setShowModal(!showModal);
    }

    return (
        <>

            <Box display="flex" justifyContent="end" mr={4}>
                <Button
                    size="small"
                    variant="contained"
                    startIcon={<FaPlusCircle fontSize="small" />}
                    sx={{
                        backgroundColor: 'rgba(73, 102, 131, 0.15)',
                        backdropFilter: 'blur(6px)',
                        color: 'rgb(73, 102, 131)',
                        border: '1px solid rgba(73, 102, 131, 0.3)',
                        textTransform: 'none',
                        fontWeight: 500,
                        fontSize: '0.75rem',
                        boxShadow: '0 1px 4px rgba(0,0,0,0.1)',
                        m: 3,
                        py: 1,
                        '&:hover': {
                            backgroundColor: 'rgba(73, 102, 131, 0.25)',
                            color: 'rgb(73, 102, 131)',
                        },
                    }}
                    onClick={() => { handleShowModal(); setEditMode(false) }}
                >
                    Add Status Mapping
                </Button>
            </Box>

            <TableContainer sx={{ minHeight: "50vh", mt: 0 }}>

                {currentItems.length > 0 ? (
                    <Table sx={{ tableLayout: "fixed", width: "100%" }} size="small">
                        <TableHead>
                            <TableRow sx={{ background: "rgb(246, 247, 251)", height: 60 }}>
                                <TableCell sx={{ fontWeight: "bold", textAlign: "center", width: 150 }}>SR.NO</TableCell>
                                <TableCell sx={{ fontWeight: "bold", width: 200 }}>STATUS</TableCell>
                                <TableCell sx={{ fontWeight: "bold", width: 200 }}>TRAY</TableCell>
                                <TableCell sx={{ fontWeight: "bold", width: 150, textAlign: "center" }}>ACTION</TableCell>
                            </TableRow>
                        </TableHead>
                        {/* </Table> */}


                        <TableBody>
                            {
                                currentItems.map((mapping, index) => (
                                    <TableRow key={mapping.statusId} sx={{ height: 50 }}>
                                        <TableCell align="center">{index + 1 + indexOfFirstItem}</TableCell>

                                        {/* Avatar and Status properly aligned */}
                                        <TableCell>

                                            <Typography variant="body2" noWrap>
                                                {mapping.status}
                                            </Typography>
                                            {/* </Box> */}
                                        </TableCell>

                                        <TableCell>
                                            <Typography variant="body2" noWrap>
                                                {mapping.trayMasterDto?.trayName}
                                            </Typography>
                                        </TableCell>

                                        <TableCell align="center"> {/* Center align the TableCell */}
                                            <Box display="flex" gap={1} justifyContent="center"> {/* Center the buttons within the Box */}
                                                <Button
                                                    size="small"
                                                    variant="contained"
                                                    onClick={() => handleEdit(mapping.statusId)}
                                                    sx={{
                                                        minWidth: "50px",
                                                        fontWeight: "600",
                                                        fontSize: "0.6rem",
                                                        padding: "2px 6px",
                                                        height: "25px",
                                                        lineHeight: "1",
                                                    }}
                                                >
                                                    Edit
                                                </Button>

                                                <Button
                                                    size="small"
                                                    variant="contained"
                                                    color={mapping.isActive === 1 ? "error" : "success"}
                                                    onClick={() => handleInactive(mapping.statusId)}
                                                    sx={{
                                                        minWidth: "80px",
                                                        fontSize: "0.6rem",
                                                        fontWeight: "600",
                                                        padding: "2px 6px",
                                                        height: "25px",
                                                        lineHeight: "1",
                                                        backgroundColor: (theme) =>
                                                            mapping.isActive === 1 ? theme.palette.error.main : theme.palette.success.main,
                                                        '&:hover': {
                                                            backgroundColor: (theme) =>
                                                                mapping.isActive === 1
                                                                    ? theme.palette.error.dark
                                                                    : theme.palette.success.dark,
                                                        },
                                                    }}
                                                >
                                                    {mapping.isActive === 1 ? "Deactivate" : "Activate"}
                                                </Button>
                                            </Box>
                                        </TableCell>

                                    </TableRow>
                                )
                                )}
                        </TableBody>
                    </Table>
                )
                    : (
                        <Box
                            display="flex"
                            justifyContent="center"
                            alignItems="center"
                            minHeight="50vh"
                        >
                            <Empty description="No Status mappings. Please add Status first or change the search term." />
                        </Box>
                    )
                }
            </TableContainer>
            {
                currentItems.length > 0 &&
                <Box display="flex" justifyContent="center" mt={2}>
                    <Pagination count={totalPages}
                        page={currentPage}
                        sx={{
                            '& .MuiPaginationItem-root': {
                                color: 'rgb(73, 102, 131) !important',
                                borderColor: 'rgb(73, 102, 131) !important',
                            },
                            '& .MuiPaginationItem-root.Mui-selected': {
                                backgroundColor: 'rgb(73, 102, 131) !important',
                                color: '#fff !important',
                            }
                        }}
                        onChange={(_, newPage) => handlePageChange(newPage)} />
                </Box>
            }
            <ToastContainer />
            <MappingModal
                title={"Status Mapping"}
                isVisible={showModal}
                onClose={handleShowModal}
            >
                <StatusMapping
                    editData={status}           // status should be set via handleEdit
                    mode={editMode ? "edit" : "add"}
                    isOpen={showModal}
                    onClose={handleShowModal}
                />
            </MappingModal>
        </>
    );
};

export default AddStatusMapping;