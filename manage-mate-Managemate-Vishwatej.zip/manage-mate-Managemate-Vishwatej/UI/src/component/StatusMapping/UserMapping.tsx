import React, { useEffect, useState } from "react";
import { toast, ToastContainer } from "react-toastify";
import { StakeHolderManagementUser } from "../../Interfaces/Task";
import {
    deleteStakeholderManagementUser,
    getAllStakeholderManagementUser,
} from "../../Requests/MenuPermission";
import { Box, Button, Pagination, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography } from "@mui/material";
import { usePageLoader } from "../../context/PageLoaderContext";
import { FaPlusCircle } from "react-icons/fa";
import UserMappingModalForm from "../Modal/Mapping/UserMapping";
import MappingModal from "../Modal/Mapping/MappingModal";

const UserMapping: React.FC = () => {

    const { showLoader, hideLoader } = usePageLoader();
    const [tableLoading, setTableLoading] = useState(false);
    const [stakeholders, setStakeholders] = useState<StakeHolderManagementUser[]>([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [showModal, setShowModal] = useState(false);
    const itemsPerPage = 8;

    const handleDelete = async (id: number, userId: number, userType: string) => {
        if (!userId || !userType) {
            toast.error("Invalid user data");
            return;
        }

        const payload = { id, userId, userType, empName: "" };
        console.log("Deleting user with payload:", payload);

        try {
            const response = await deleteStakeholderManagementUser(payload);
            console.log("API Response:", response);

            if (response.httpStatus === "OK") {
                toast.success("User mapping deleted successfully.");
                setStakeholders((prevStakeholders) => prevStakeholders.filter(user => user.userId !== userId));
            } else {
                toast.error("Failed to delete user. Please try again.");
            }
        } catch (error) {
            console.error("Error deleting mapping:", error);
            toast.error("Failed to delete mapping.");
        }

        fetchAllStakeholders();
    };

    // Pagination logic
    const currentItems = stakeholders.slice(
        (currentPage - 1) * itemsPerPage,
        currentPage * itemsPerPage
    );
    const totalPages = Math.ceil(stakeholders.length / itemsPerPage);

    const handlePageChange = (page: number) => {
        setCurrentPage(page);
    };

    const handleShowModal = () => {
        setShowModal(!showModal);
    }

    const fetchAllStakeholders = async () => {
        setTableLoading(true);
        showLoader();
        try {
            const response = await getAllStakeholderManagementUser();
            setStakeholders(Array.isArray(response) ? response : []);
        } catch (error) {
            console.error("Error fetching stakeholders:", error);
            setStakeholders([]);
        } finally {
            hideLoader();
        }
        setTableLoading(false);
    };

    useEffect(() => {
        fetchAllStakeholders();
    }, []);

    return (
        <>
            <Box display="flex" justifyContent="end" mr={4}>
                <Button
                    size="small"
                    variant="contained"
                    startIcon={<FaPlusCircle fontSize="small" />}
                    sx={{
                        backgroundColor: 'rgba(73, 102, 131, 0.15)',
                        backdropFilter: 'blur(6px)',
                        color: 'rgb(73, 102, 131)',
                        border: '1px solid rgba(73, 102, 131, 0.3)',
                        textTransform: 'none',
                        fontWeight: 500,
                        fontSize: '0.75rem',
                        boxShadow: '0 1px 4px rgba(0,0,0,0.1)',
                        m: 3,
                        py: 1,
                        '&:hover': {
                            backgroundColor: 'rgba(73, 102, 131, 0.25)',
                            color: 'rgb(73, 102, 131)',
                        },
                    }}
                    onClick={handleShowModal}>
                    Add User Mapping
                </Button>
            </Box>
            <TableContainer sx={{ minHeight: "50vh" }}>
                {!tableLoading ? (
                    currentItems.length > 0 ? (
                        <Table sx={{ tableLayout: "fixed", width: "100%" }} size="small">
                            <TableHead>
                                <TableRow sx={{ background: "rgb(246, 247, 251)", height: 60 }}>
                                    <TableCell sx={{ fontWeight: "bold", textAlign: "center", width: 100 }}>SR. No.</TableCell>
                                    <TableCell sx={{ fontWeight: "bold", width: 150 }}>Employee Name</TableCell>
                                    <TableCell sx={{ fontWeight: "bold", width: 150 }}>User Type</TableCell>
                                    <TableCell sx={{ fontWeight: "bold", width: 100 }}>Actions</TableCell>
                                </TableRow>
                            </TableHead>

                            <TableBody>
                                {currentItems.map((stakeHolder, index) => (
                                    <TableRow key={stakeHolder.userId} sx={{ height: 50 }}>
                                        <TableCell align="center">
                                            {(currentPage - 1) * itemsPerPage + index + 1}
                                        </TableCell>
                                        <TableCell>
                                            <Typography variant="body2" noWrap>{stakeHolder.empName}</Typography>
                                        </TableCell>
                                        <TableCell>
                                            <Typography variant="body2" noWrap>{stakeHolder.userType}</Typography>
                                        </TableCell>
                                        <TableCell align="center">
                                            <Box display="flex">
                                                <Button
                                                    size="small"
                                                    variant="contained"
                                                    color="error"
                                                    onClick={() =>
                                                        handleDelete(stakeHolder.id, stakeHolder.userId, stakeHolder.userType)
                                                    }
                                                    sx={{
                                                        fontSize: "0.65rem",
                                                        fontWeight: "600",
                                                        padding: "2px 6px",
                                                        height: "25px",
                                                        lineHeight: 1,
                                                        backgroundColor: (theme) =>
                                                            theme.palette.error.main,
                                                        '&:hover': {
                                                            backgroundColor: (theme) =>
                                                                theme.palette.error.dark
                                                        },
                                                    }}
                                                >
                                                    Delete
                                                </Button>
                                            </Box>
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    ) : (
                        <Box display="flex" justifyContent="center" alignItems="center" minHeight="50vh">
                            <Typography>No stakeholder mappings available.</Typography>
                        </Box>
                    )
                ) : (
                    <></>
                )}
            </TableContainer>

            {currentItems.length > 0 && (
                <Box display="flex" justifyContent="center" mt={2}>
                    <Pagination
                        count={totalPages}
                        page={currentPage}
                        onChange={(_, newPage) => handlePageChange(newPage)}
                        sx={{
                            '& .MuiPaginationItem-root': {
                                color: 'rgb(73, 102, 131) !important',
                                borderColor: 'rgb(73, 102, 131) !important',
                            },
                            '& .MuiPaginationItem-root.Mui-selected': {
                                backgroundColor: 'rgb(73, 102, 131) !important',
                                color: '#fff !important',
                            },

                        }}
                    />
                </Box>
            )}

            <MappingModal
                title={"User Mapping"}
                isVisible={showModal}
                onClose={handleShowModal}
            >
                <UserMappingModalForm
                    isOpen={showModal}
                    onClose={handleShowModal}
                />
            </MappingModal>
            <ToastContainer />
        </>
    );
};

export default UserMapping;

