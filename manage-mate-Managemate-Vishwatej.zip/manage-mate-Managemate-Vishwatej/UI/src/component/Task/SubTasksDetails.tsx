import React, { useState, useEffect } from "react";
import { downLoadDocument, getTaskByParentTaskid, getTaskByTaskId, getUserListSubTask } from "../../Requests/TaskRequest";
import { Task, User } from "../../Interfaces/Task";
import { useParams } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import dayjs from "dayjs";
import SubTaskStatusMark from "../PopUp/SubTaskStatusMark";
import { EmployeeData } from "../../Interfaces/Login";
import {
    Box,
    Button,
    Typography,
    Paper,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Collapse,
    Card,
    Pagination,
    IconButton,
    Tooltip,
} from "@mui/material";
import { Empty } from "antd";
import { GridExpandMoreIcon } from "@mui/x-data-grid";
import { FaPlusCircle } from "react-icons/fa";
import SubTaskModal from "../Modal/ProjectModal/SubTaskModal";
import { StatusChip } from "../Chip/StatusChip";
import { tooltipProps } from "../../util/constants/commonStyles";
import { PriorityChip } from "../Chip/PriorityChip";

const SubTasksDetails: React.FC = () => {
    const [task, setTask] = useState<Partial<Task>>({});
    const [userList, setUserList] = useState<User[]>([]);
    const [parentTask, setParentTask] = useState<Partial<Task>>({});
    const [filteredTasks, setFilteredTasks] = useState<Task[]>([]);
    const { parentTaskId } = useParams<{ parentTaskId: string }>();
    const [currentPage, setCurrentPage] = useState(1);
    const itemsPerPage = 10;
    const [isSubTaskAllow, setIsSubTaskAllow] = useState(false);
    const [employee, setEmployee] = useState<EmployeeData | null>(null);
    const [showModal, setShowModal] = useState(false);

    useEffect(() => {
        const storedData = localStorage.getItem("employeedata");
        if (storedData) {
            try {
                const parsedData = JSON.parse(storedData);
                setTask((prevTask) => ({
                    ...prevTask,
                    employeeId: parsedData.EmployeeNo || "",
                    designationId: parsedData.DesignationId || "",
                    departmentId: parsedData.DepartmentId || "",
                    mobileNo: parsedData.MobileNo1 || "",
                    emailId: parsedData.PersonalEmail || "",
                    raisedBy: parsedData.EmployeeNo || "",
                }));
                setEmployee(parsedData);

                const department = parsedData?.Department;
                const departmentArray: string[] = department.split(" -> ") ?? [];

                if (
                    departmentArray.includes("Software Development") ||
                    departmentArray.includes("Project Management") ||
                    parsedData?.Designation === "CHIEF TECHNOLOGY OFFICER"
                ) {
                    setIsSubTaskAllow(true);
                }
            } catch (error) {
                console.error("Error parsing employee data from localStorage:", error);
            }
        } else {
            console.log("No employee data found in localStorage");
        }
    }, []);

    useEffect(() => {
        if (parentTaskId && parentTaskId !== "0") {
            fetchTasks();
            fetchParentTask();
        } else {
        }
    }, [parentTaskId]);

    const fetchParentTask = async () => {
        const parentTask: Task = await getTaskByTaskId(parentTaskId);
        setParentTask(parentTask);
    };

    const fetchTasks = async () => {
        try {
            const tasks: Task[] = await getTaskByParentTaskid(parentTaskId);
            setFilteredTasks(tasks);
        } catch (error) {
            console.error("Error fetching tasks:", error);
        }
    };

    useEffect(() => {
        if (parentTaskId) {
            getUserListSubTask(Number(parentTaskId))
                .then((response) => setUserList(response.data))
                .catch((error) => console.error("Error fetching user list:", error));
        }
    }, [parentTaskId]);

    const handlePageChange = (pageNumber: number) => {
        setCurrentPage(pageNumber);
    };

    const filterTasks = filteredTasks.slice(
        (currentPage - 1) * itemsPerPage,
        currentPage * itemsPerPage
    );
    const totalPages = Math.ceil(filteredTasks.length / itemsPerPage);

    const [isPopupVisible, setPopupVisible] = useState<boolean>(false);
    const [selectedTask, setSelectedTask] = useState<Task | null>(null);

    const clickStatusChange = (task: Task) => {
        setSelectedTask(task);
        setPopupVisible(true);
    };

    const clickedEdit = (task: Task) => {
        setTask(task);
        setSelectedTask(task);
        setShowModal(true);
    };

    const handleClosePopup = () => {
        setPopupVisible(false);
        setSelectedTask(null);
    };

    const handleSaveSubStatus = () => {
        fetchTasks();
    };

    const renderStatusAndSubStatus = (taskId: number) => {
        const task = filteredTasks.find((t) => t.id === taskId);
        if (!task || !task.subTaskStatusDtos || task.subTaskStatusDtos.length === 0) {
            return <div>N/A</div>;
        }
        const latestSubTaskStatus = task.subTaskStatusDtos.reduce((latest, current) => {
            return new Date(current.statusMarkedDate) > new Date(latest.statusMarkedDate)
                ? current
                : latest;
        });
        const status = latestSubTaskStatus.markedStatus;

        return (<Tooltip title={status} {...tooltipProps} disableHoverListener={status.length <= 10} >
            <span>
                <StatusChip status={status} />
            </span>
        </Tooltip>)
    };

    const renderDate = (taskId: number) => {
        const task = filteredTasks.find((t) => t.id === taskId);
        if (!task || !task.subTaskStatusDtos || task.subTaskStatusDtos.length === 0) {
            return <div>N/A</div>;
        }
        const latestSubTaskStatus = task.subTaskStatusDtos.reduce((latest, current) => {
            return new Date(current.statusMarkedDate) > new Date(latest.statusMarkedDate)
                ? current
                : latest;
        });
        const statusDate = latestSubTaskStatus.statusMarkedDate
            ? dayjs(latestSubTaskStatus.statusMarkedDate).format("DD-MM-YYYY")
            : "N/A";

        const enrollDate = task.dateAndTime;
        return (
            <>
                <div>Enroll Date: {enrollDate}</div>
                <div>Status Date: {statusDate}</div>
            </>
        );
    };

    const [expandedRows, setExpandedRows] = useState<Record<string, boolean>>({});

    const toggleRow = (taskId: string) => {
        setExpandedRows((prev) => ({
            ...prev,
            [taskId]: !prev[taskId],
        }));
    };

    const clickAttachment = (task: Task) => {
        if (task.attachmentPath) {
            downLoadDocument(task.attachmentPath);
        }
    };

    const handleShowModal = () => {
        setShowModal(!showModal);
        if (!showModal) {
            setTask({
                employeeId: employee?.EmployeeNo || "",
                designationId: employee?.DesignationId || "",
                departmentId: employee?.DepartmentId || "",
                mobileNo: employee?.MobileNo1 || "",
                emailId: employee?.PersonalEmail || "",
                raisedBy: employee?.EmployeeNo || "",
            });
        }
    };

    return (
        <div>
            <ToastContainer />
            <SubTaskStatusMark
                isVisible={isPopupVisible}
                onClose={handleClosePopup}
                task={selectedTask}
                onSave={handleSaveSubStatus}
            />
            <Paper
                elevation={3}
                sx={{
                    p: 2,
                    borderRadius: 2,
                    overflow: "hidden",
                    position: "relative",
                    boxShadow: filterTasks.length > 0 ? "" : "unset",
                    minHeight: "87vh",
                }}
            >
                {isSubTaskAllow && (
                    <Box display="flex" justifyContent="space-between" alignItems="center" px={3} mb={2} mt={2}>
                        <Typography variant="h5" sx={{ fontWeight: "bold" }}>
                            Sub-Task Details
                        </Typography>
                        <Button
                            size="small"
                            variant="contained"
                            startIcon={<FaPlusCircle fontSize="small" />}
                            sx={{
                                backgroundColor: 'rgba(73, 102, 131, 0.15)',
                                backdropFilter: 'blur(6px)',
                                color: 'rgb(73, 102, 131)',
                                border: '1px solid rgba(73, 102, 131, 0.3)',
                                textTransform: 'none',
                                fontWeight: 500,
                                fontSize: '0.75rem',
                                boxShadow: '0 1px 4px rgba(0,0,0,0.1)',
                                py: 1,
                                '&:hover': {
                                    backgroundColor: 'rgba(73, 102, 131, 0.25)',
                                    color: 'rgb(73, 102, 131)',
                                },
                            }}
                            onClick={handleShowModal}
                        >
                            ADD SUB-TASK
                        </Button>
                    </Box>
                )}
                <TableContainer sx={{ minHeight: "68vh", mt: 4 }}>
                    {filterTasks.length > 0 ? (
                        <Table size="small">
                            <TableHead>
                                <TableRow sx={{ background: "rgb(246, 247, 251)", height: 60 }}>
                                    <TableCell sx={{ width: 50 }}></TableCell>
                                    <TableCell sx={{ fontWeight: "bold", width: 100, textAlign: "center" }}>
                                        SR.NO
                                    </TableCell>
                                    <TableCell sx={{ fontWeight: "bold", width: 150, whiteSpace: "nowrap" }}>
                                        SUB-TASK ID
                                    </TableCell>
                                    <TableCell sx={{ fontWeight: "bold", width: 120, whiteSpace: "nowrap" }}>
                                        SUB-TASK
                                    </TableCell>
                                    <TableCell sx={{ fontWeight: "bold", width: 200, whiteSpace: "nowrap" }}>
                                        DATE
                                    </TableCell>
                                    <TableCell sx={{ fontWeight: "bold", width: 120, whiteSpace: "nowrap" }}>
                                        MODULE
                                    </TableCell>
                                    <TableCell sx={{ fontWeight: "bold", width: 100, whiteSpace: "nowrap" }}>
                                        SUBJECT
                                    </TableCell>
                                    <TableCell sx={{ fontWeight: "bold", width: 120, textAlign: "center" }}>
                                        PRIORITY
                                    </TableCell>
                                    <TableCell sx={{ fontWeight: "bold", width: 150, textAlign: "center" }}>
                                        STATUS
                                    </TableCell>
                                    <TableCell sx={{ fontWeight: "bold", width: 100, whiteSpace: "nowrap" }}>
                                        TENTATIVE DATE
                                    </TableCell>
                                    <TableCell sx={{ fontWeight: "bold", width: 100, textAlign: "center" }}>
                                        ACTION
                                    </TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {filterTasks.map((task, index) => (
                                    <React.Fragment key={task.id}>
                                        <TableRow sx={{ height: 55 }}>
                                            <TableCell>
                                                <IconButton size="small" onClick={() => toggleRow(task.taskId)}>
                                                    <GridExpandMoreIcon />
                                                </IconButton>
                                            </TableCell>
                                            <TableCell align="center">
                                                {(currentPage - 1) * itemsPerPage + index + 1}
                                            </TableCell>
                                            <TableCell
                                                sx={{
                                                    maxWidth: 150,
                                                    whiteSpace: "nowrap",
                                                    overflow: "hidden",
                                                    textOverflow: "ellipsis",
                                                }}
                                            >
                                                {task.taskId}
                                            </TableCell>
                                            <TableCell
                                                sx={{
                                                    maxWidth: 120,
                                                    whiteSpace: "nowrap",
                                                    overflow: "hidden",
                                                    textOverflow: "ellipsis",
                                                }}
                                            >
                                                {task.taskName}
                                            </TableCell>
                                            <TableCell
                                                sx={{
                                                    maxWidth: 150,
                                                    whiteSpace: "nowrap",
                                                    overflow: "hidden",
                                                    textOverflow: "ellipsis",
                                                }}
                                            >
                                                {renderDate(task.id)}
                                            </TableCell>
                                            <TableCell
                                                sx={{
                                                    maxWidth: 120,
                                                    whiteSpace: "nowrap",
                                                    overflow: "hidden",
                                                    textOverflow: "ellipsis",
                                                }}
                                            >
                                                {parentTask.moduleName}
                                            </TableCell>
                                            <TableCell
                                                sx={{
                                                    maxWidth: 300,
                                                    whiteSpace: "nowrap",
                                                    overflow: "hidden",
                                                    textOverflow: "ellipsis",
                                                }}
                                            >
                                                {parentTask.requirementSubject}
                                            </TableCell>
                                            <TableCell align="center">
                                                <PriorityChip status={task.taskPriority} />
                                            </TableCell>
                                            <TableCell
                                                sx={{
                                                    maxWidth: 120,
                                                    whiteSpace: "nowrap",
                                                    overflow: "hidden",
                                                    textOverflow: "ellipsis",
                                                }}
                                            >
                                                {renderStatusAndSubStatus(task.id)}
                                            </TableCell>
                                            <TableCell
                                                sx={{
                                                    maxWidth: 300,
                                                    whiteSpace: "nowrap",
                                                    overflow: "hidden",
                                                    textOverflow: "ellipsis",
                                                }}
                                            >
                                                {dayjs(task.tentativeEndDate).format("DD MMM YYYY")}
                                            </TableCell>
                                            <TableCell>
                                                <Box display="flex" gap={1} justifyContent="center">
                                                    {isSubTaskAllow && (
                                                        <IconButton
                                                            color="success"
                                                            onClick={() => clickStatusChange(task)}
                                                            title="Status Marking"
                                                        >
                                                            <i className="fas fa-check-circle" />
                                                        </IconButton>
                                                    )}
                                                    {isSubTaskAllow && (
                                                        <IconButton
                                                            color="primary"
                                                            onClick={() => clickedEdit(task)}
                                                            title="Edit Status"
                                                        >
                                                            <i className="fas fa-edit" />
                                                        </IconButton>
                                                    )}
                                                    <IconButton
                                                        color="default"
                                                        onClick={() => clickAttachment(task)}
                                                        title="Attachment"
                                                    >
                                                        <i className="fas fa-paperclip" />
                                                    </IconButton>
                                                </Box>
                                            </TableCell>
                                        </TableRow>
                                        <TableRow>
                                            <TableCell colSpan={11} style={{ paddingBottom: 0, paddingTop: 0 }}>
                                                <Collapse in={expandedRows[task.taskId]} timeout="auto" unmountOnExit>
                                                    <Card sx={{ width: "99%", p: 2, boxShadow: 3, m: 2 }}>
                                                        <TableContainer component={Paper} elevation={0}>
                                                            <Table size="small">
                                                                <TableHead>
                                                                    <TableRow>
                                                                        <TableCell>
                                                                            <Typography variant="body1" fontWeight="bold">
                                                                                Description
                                                                            </Typography>
                                                                        </TableCell>
                                                                    </TableRow>
                                                                </TableHead>
                                                                <TableBody>
                                                                    <TableRow>
                                                                        <TableCell sx={{ border: "none" }}>
                                                                            {task.description}
                                                                        </TableCell>
                                                                    </TableRow>
                                                                </TableBody>
                                                            </Table>
                                                        </TableContainer>
                                                    </Card>
                                                </Collapse>
                                            </TableCell>
                                        </TableRow>
                                    </React.Fragment>
                                ))}
                            </TableBody>
                        </Table>
                    ) : (
                        <Box
                            display="flex"
                            justifyContent="center"
                            alignItems="center"
                            minHeight="68vh"
                        >
                            <Empty description="No sub-tasks found. Please add sub-tasks first." />
                        </Box>
                    )}
                </TableContainer>
                {filterTasks.length > 0 && (
                    <Box display="flex" justifyContent="center" mb={1}>
                        <Pagination
                            count={totalPages}
                            page={currentPage}
                            sx={{
                                '& .MuiPaginationItem-root': {
                                    color: 'rgb(73, 102, 131) !important',
                                    borderColor: 'rgb(73, 102, 131) !important',
                                },
                                '& .MuiPaginationItem-root.Mui-selected': {
                                    backgroundColor: 'rgb(73, 102, 131) !important',
                                    color: '#fff !important',
                                },
                            }}
                            onChange={(_, newPage) => handlePageChange(newPage)}
                        />
                    </Box>
                )}
            </Paper>
            <SubTaskModal
                isVisible={showModal}
                onClose={handleShowModal}
                task={task}
                setTask={setTask}
                userList={userList}
                employee={employee}
                parentTaskId={parentTaskId}
                fetchTasks={fetchTasks}
            />
        </div>
    );
};

export default SubTasksDetails;
