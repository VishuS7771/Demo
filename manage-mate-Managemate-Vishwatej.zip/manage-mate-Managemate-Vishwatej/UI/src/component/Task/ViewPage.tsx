import React, { useEffect, useState } from "react";
import { Task } from "../../Interfaces/Task";
import { downLoadDocument, getTaskByParentTaskid, getTaskByTaskId } from "../../Requests/TaskRequest";
import { useParams } from "react-router-dom";
import dayjs from "dayjs";
import { ToastContainer } from "react-toastify";
import { MeetingsDto } from "../../Interfaces/Meeting";
import { getMeetingByTaskId } from "../../Requests/MeetingRequest";
import moment from "moment";
import MomLink from "../PopUp/MomPopUp";
import '@fortawesome/fontawesome-free/css/all.min.css';
import AttendeesPopup from "../PopUp/AttendeesPopUp";
import { Paper, Typography, Grid, Divider, Button, Box, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Collapse, Card, Chip, Pagination, IconButton, Tooltip } from "@mui/material";
import { AssignmentOutlined, EventOutlined, PeopleOutlined, BusinessOutlined, NotesOutlined, PhoneOutlined, Apps, Devices, LowPriorityOutlined, DescriptionOutlined, ListAlt, PeopleOutlineRounded, } from "@mui/icons-material";
import { GridExpandMoreIcon } from "@mui/x-data-grid";
import { getStatusChipStyles, tooltipProps } from "../../util/constants/commonStyles";
import { StatusChip } from "../Chip/StatusChip";
import { PriorityChip } from "../Chip/PriorityChip";

const ViewPage: React.FC = () => {
    const { taskId } = useParams<{ taskId: string }>();
    const [tasks, setTask] = useState<Task | null>(null);
    const [isSubTasks, setIsSubTasks] = useState(false);
    const [filteredTasks, setFilteredTasks] = useState<Task[]>([]);
    const [meetingsList, setMeetingsList] = useState<MeetingsDto[]>([]);
    const [showMomLinkModal, setShowMomLinkModal] = useState(false);
    const [selectedMeetingId, setSelectedMeetingId] = useState<string | null>(null);
    const [selectMeetingId, setSelectMeetingId] = useState<number | null>(null);
    const [subTasksPage, setSubTasksPage] = useState(1);
    const [meetingsPage, setMeetingsPage] = useState(1);
    const itemsPerPage = 5;
    const [showAttendeesModal, setShowAttendeesModal] = useState(false);
    const [expandedFields, setExpandedFields] = useState<{ [key: string]: boolean }>({});
    const [expandedRows, setExpandedRows] = useState<Record<string, boolean>>({});

    const toggleExpand = (field: string) => {
        setExpandedFields((prev) => ({
            ...prev,
            [field]: !prev[field],
        }));
    };

    const toggleRow = (taskId: string) => {
        setExpandedRows((prev) => ({
            ...prev,
            [taskId]: !prev[taskId],
        }));
    };

    const renderValue = (value: string, field: string) => {
        if (value.length > 50 && !expandedFields[field]) {
            return (
                <>
                    {value.substring(0, 50)}...
                    <Button
                        size="small"
                        onClick={() => toggleExpand(field)}
                        sx={{
                            textTransform: "none",
                            ml: 1,
                            '&:hover': {
                                backgroundColor: 'transparent',
                            }
                        }}
                    >
                        Show More
                    </Button>
                </>
            );
        }
        if (expandedFields[field]) {
            return (
                <>
                    {value}
                    <Button
                        size="small"
                        onClick={() => toggleExpand(field)}
                        sx={{
                            textTransform: "none",
                            ml: 1,
                            '&:hover': {
                                backgroundColor: 'transparent',
                            }
                        }}
                    >
                        Show Less
                    </Button>
                </>
            );
        }
        return value;
    };

    const fetchTask = async () => {
        try {
            const fetchedTask = await getTaskByTaskId(taskId);
            setTask(fetchedTask);
        } catch (err) {
            console.error("Failed to fetch task:", err);
        }
    };

    const fetchSubTasks = async () => {
        try {
            const tasks: Task[] = await getTaskByParentTaskid(taskId);
            setFilteredTasks(tasks);
            setIsSubTasks(tasks.length > 0);
        } catch (error) {
            console.error("Error fetching tasks:", error);
        }
    };

    const fetchMeetings = async () => {
        if (taskId && taskId !== "0") {
            const meetings = await getMeetingByTaskId(Number(taskId));
            setMeetingsList(meetings);
        }
    };

    useEffect(() => {
        fetchSubTasks();
        fetchMeetings();
        fetchTask();
    }, [taskId]);

    const handleSubTasksPageChange = (pageNumber: number) => {
        setSubTasksPage(pageNumber);
    };

    const handleMeetingsPageChange = (pageNumber: number) => {
        setMeetingsPage(pageNumber);
    };

    const paginatedSubTasks = filteredTasks.slice(
        (subTasksPage - 1) * itemsPerPage,
        subTasksPage * itemsPerPage
    );

    const paginatedMeetings = meetingsList.slice(
        (meetingsPage - 1) * itemsPerPage,
        meetingsPage * itemsPerPage
    );

    const totalSubTasksPages = Math.ceil(filteredTasks.length / itemsPerPage);
    const totalMeetingsPages = Math.ceil(meetingsList.length / itemsPerPage);

    const renderStatusAndSubStatus = (taskId: number) => {
        const task = filteredTasks.find((t) => t.id === taskId);
        if (!task || !task.subTaskStatusDtos || task.subTaskStatusDtos.length === 0) {
            return <Chip label="N/A" sx={getStatusChipStyles('default')} />;
        }
        const latestSubTaskStatus = task.subTaskStatusDtos.reduce((latest, current) => {
            return new Date(current.statusMarkedDate) > new Date(latest.statusMarkedDate) ? current : latest;
        });
        const status = latestSubTaskStatus.markedStatus;

        return (
            <Chip
                label={status}
                sx={{
                    height: '25px',
                    width: '100%',
                    textAlign: 'center',
                    borderRadius: '999px',
                    ...getStatusChipStyles(status),
                }}
            />
        );
    };

    const renderDate = (taskId: number) => {
        const task = filteredTasks.find((t) => t.id === taskId);
        if (!task || !task.subTaskStatusDtos || task.subTaskStatusDtos.length === 0) {
            return <div>N/A</div>;
        }
        const latestSubTaskStatus = task.subTaskStatusDtos.reduce((latest, current) => {
            return new Date(current.statusMarkedDate) > new Date(latest.statusMarkedDate) ? current : latest;
        });
        const statusDate = latestSubTaskStatus.statusMarkedDate
            ? dayjs(latestSubTaskStatus.statusMarkedDate).format('DD MMM YYYY')
            : 'N/A';

        const enrollDate = task.dateAndTime;
        return (
            <>
                <div>Enroll Date: {enrollDate}</div>
                <div>Status Date: {statusDate}</div>
            </>
        );
    };

    const clickAttachment = (task: Task) => {
        if (task.attachmentPath) {
            downLoadDocument(task.attachmentPath);
        }
    };

    const handleMomLinkClick = (meetingId: string) => {
        setSelectedMeetingId(meetingId);
        setShowMomLinkModal(true);
    };

    const handleCloseMomLinkModal = () => {
        setShowMomLinkModal(false);
        setSelectedMeetingId(null);
    };

    const handleAttendeesClick = (meetingId: number) => {
        setSelectMeetingId(meetingId);
        setShowAttendeesModal(true);
    };

    const handleCloseAttendeesModal = () => {
        setShowAttendeesModal(false);
        setSelectMeetingId(null);
    };

    return (
        <Paper
            elevation={2}
            sx={{
                p: 2,
                borderRadius: 2,
                minHeight: "84vh",
                boxShadow: "",
                overflow: "hidden",
            }}
        >
            <Box sx={{ p: { xs: 2, sm: 3, md: 4 }, }}>
                <ToastContainer />
                <Box sx={{ backgroundColor: '#e1e5eb', color: '#496683', borderRadius: 1, boxShadow: 1, mb: 4, px: 2, py: 1, }} >
                    <Typography variant="h5" sx={{ fontWeight: 'bold', textAlign: 'left', }} >
                        Project Details
                    </Typography>
                </Box>
                <Grid container spacing={2} justifyContent="center">
                    {[
                        {
                            label: "Project ID",
                            value: tasks?.taskId || "N/A",
                            icon: <AssignmentOutlined fontSize="small" />,
                        },
                        {
                            label: "Tentative Date & Time",
                            value: tasks?.tentativeEndDate
                                ? new Date(tasks.tentativeEndDate).toLocaleDateString()
                                : "N/A",
                            icon: <EventOutlined fontSize="small" />,
                        },
                        {
                            label: "Employee Name & ID",
                            value: tasks?.raisedByName || "N/A",
                            icon: <PeopleOutlined fontSize="small" />,
                        },
                        {
                            label: "Designation & Department",
                            value: tasks?.departmentAndDesignation || "N/A",
                            icon: <BusinessOutlined fontSize="small" />,
                        },
                        {
                            label: "Mobile Number and Email ID",
                            value: tasks?.mobileNo && tasks?.emailId
                                ? `${tasks.mobileNo}, ${tasks.emailId}`
                                : "N/A",
                            icon: <PhoneOutlined fontSize="small" />,
                        },
                        {
                            label: "Requirement Type",
                            value: tasks?.requirementType || "N/A",
                            icon: <ListAlt fontSize="small" />,
                        },
                        {
                            label: "Module",
                            value: tasks?.moduleName || "N/A",
                            icon: <Apps fontSize="small" />,
                        },
                        {
                            label: "Requirement Subject",
                            value: tasks?.requirementSubject || "N/A",
                            icon: <NotesOutlined fontSize="small" />,
                        },
                        {
                            label: "Platform",
                            value: tasks?.platform || "N/A",
                            icon: <Devices fontSize="small" />,
                        },
                        {
                            label: "Project Priority",
                            value: tasks?.taskPriority || "N/A",
                            icon: <LowPriorityOutlined fontSize="small" />,
                        },
                        {
                            label: "Requirement in Detail",
                            value: tasks?.requirementInDetail || "N/A",
                            icon: <DescriptionOutlined fontSize="small" />,
                        },
                        {
                            label: "Additional Requirements",
                            value: tasks?.additionalRequirementDtos && Array.isArray(tasks.additionalRequirementDtos) && tasks.additionalRequirementDtos.length > 0
                                ? tasks.additionalRequirementDtos
                                    .map((req) => req.requirement)
                                    .join(", ")
                                : "No additional requirements",
                            icon: <NotesOutlined fontSize="small" />,
                        },
                    ].map((item, index) => (
                        <Grid
                            item
                            xs={12}
                            sm={6}
                            md={4}
                            key={index}
                            sx={{ display: "flex", justifyContent: "center" }}
                        >
                            <Box
                                sx={{
                                    display: "flex",
                                    flexDirection: "column",
                                    gap: 1,
                                    width: "100%",
                                    overflow: "hidden",
                                    maxWidth: 350,
                                    textAlign: "left",
                                }}
                            >
                                <Typography
                                    variant="subtitle1"
                                    sx={{
                                        display: "flex",
                                        alignItems: "center",
                                        gap: 1,
                                        fontWeight: 500,
                                        color: "text.primary",
                                        whiteSpace: "nowrap",
                                        overflow: "hidden",
                                        textOverflow: "ellipsis",
                                    }}
                                >
                                    {item.icon}
                                    {item.label}
                                </Typography>
                                <Typography
                                    variant="body2"
                                    color="text.secondary"
                                    sx={{
                                        pl: 3,
                                        overflow: "hidden",
                                        textOverflow: "ellipsis",
                                        display: "-webkit-box",
                                        WebkitLineClamp: expandedFields[item.label]
                                            ? "unset"
                                            : 2,
                                        WebkitBoxOrient: "vertical",
                                    }}
                                >
                                    {renderValue(item.value, item.label)}
                                </Typography>
                                <Divider sx={{ mt: 1 }} />
                            </Box>
                        </Grid>
                    ))}
                </Grid>
            </Box>

            {isSubTasks && (
                <Box sx={{ p: { xs: 2, sm: 3, md: 4 } }}>
                    <Box sx={{ backgroundColor: '#e1e5eb', color: '#496683', borderRadius: 1, boxShadow: 1, mb: 4, px: 2, py: 1, }} >
                        <Typography variant="h5" sx={{ fontWeight: 'bold', textAlign: 'left', }} >
                            Sub-Task Details
                        </Typography>
                    </Box>
                    <TableContainer sx={{ minHeight: "30vh" }}>
                        <Table size="small">
                            <TableHead>
                                <TableRow sx={{ background: "rgb(246, 247, 251)", height: 60 }}>
                                    <TableCell sx={{ width: 50 }}></TableCell>
                                    <TableCell sx={{ fontWeight: "bold", width: 100, textAlign: "center" }}>
                                        SR.NO
                                    </TableCell>
                                    <TableCell sx={{ fontWeight: "bold", width: 150, whiteSpace: "nowrap" }}>
                                        PROJECT ID
                                    </TableCell>
                                    <TableCell sx={{ fontWeight: "bold", width: 120, whiteSpace: "nowrap" }}>
                                        PROJECT NAME
                                    </TableCell>
                                    <TableCell sx={{ fontWeight: "bold", width: 200, whiteSpace: "nowrap" }}>
                                        DATE
                                    </TableCell>
                                    <TableCell sx={{ fontWeight: "bold", width: 120, whiteSpace: "nowrap" }}>
                                        MODULE
                                    </TableCell>
                                    <TableCell sx={{ fontWeight: "bold", width: 100, whiteSpace: "nowrap" }}>
                                        SUBJECT
                                    </TableCell>
                                    <TableCell sx={{ fontWeight: "bold", width: 120, textAlign: "center" }}>
                                        PRIORITY
                                    </TableCell>
                                    <TableCell sx={{ fontWeight: "bold", width: 150, textAlign: "center" }}>
                                        STATUS
                                    </TableCell>
                                    <TableCell sx={{ fontWeight: "bold", width: 100, whiteSpace: "nowrap" }}>
                                        TENTATIVE DATE
                                    </TableCell>
                                    <TableCell sx={{ fontWeight: "bold", width: 100, textAlign: "center" }}>
                                        ACTION
                                    </TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {paginatedSubTasks.map((task, index) => (
                                    <React.Fragment key={task.id}>
                                        <TableRow sx={{ height: 55 }}>
                                            <TableCell>
                                                <IconButton size="small" onClick={() => toggleRow(task.taskId)}>
                                                    <GridExpandMoreIcon />
                                                </IconButton>
                                            </TableCell>
                                            <TableCell align="center">
                                                {(subTasksPage - 1) * itemsPerPage + index + 1}
                                            </TableCell>
                                            <TableCell
                                                sx={{
                                                    maxWidth: 150,
                                                    whiteSpace: "nowrap",
                                                    overflow: "hidden",
                                                    textOverflow: "ellipsis",
                                                }}
                                            >
                                                {task.taskId}
                                            </TableCell>
                                            <TableCell
                                                sx={{
                                                    maxWidth: 120,
                                                    whiteSpace: "nowrap",
                                                    overflow: "hidden",
                                                    textOverflow: "ellipsis",
                                                }}
                                            >
                                                {task.taskName}
                                            </TableCell>
                                            <TableCell
                                                sx={{
                                                    maxWidth: 150,
                                                    whiteSpace: "nowrap",
                                                    overflow: "hidden",
                                                    textOverflow: "ellipsis",
                                                }}
                                            >
                                                {renderDate(task.id)}
                                            </TableCell>
                                            <TableCell
                                                sx={{
                                                    maxWidth: 120,
                                                    whiteSpace: "nowrap",
                                                    overflow: "hidden",
                                                    textOverflow: "ellipsis",
                                                }}
                                            >
                                                {tasks?.moduleName}
                                            </TableCell>
                                            <TableCell
                                                sx={{
                                                    maxWidth: 300,
                                                    whiteSpace: "nowrap",
                                                    overflow: "hidden",
                                                    textOverflow: "ellipsis",
                                                }}
                                            >
                                                {tasks?.requirementSubject}
                                            </TableCell>
                                            <TableCell align="center">
                                                <PriorityChip status={task.taskPriority} />
                                            </TableCell>
                                            <TableCell
                                                sx={{
                                                    maxWidth: 120,
                                                    whiteSpace: "nowrap",
                                                    overflow: "hidden",
                                                    textOverflow: "ellipsis",
                                                }}
                                            >
                                                {renderStatusAndSubStatus(task.id)}
                                            </TableCell>
                                            <TableCell
                                                sx={{
                                                    maxWidth: 300,
                                                    whiteSpace: "nowrap",
                                                    overflow: "hidden",
                                                    textOverflow: "ellipsis",
                                                }}
                                            >
                                                {dayjs(task.tentativeEndDate).format("DD MMM YYYY")}
                                            </TableCell>
                                            <TableCell>
                                                <Box display="flex" gap={1} justifyContent="center">
                                                    <IconButton
                                                        color="default"
                                                        onClick={() => clickAttachment(task)}
                                                        title="Attachment"
                                                    >
                                                        <i className="fas fa-paperclip" />
                                                    </IconButton>
                                                </Box>
                                            </TableCell>
                                        </TableRow>
                                        <TableRow>
                                            <TableCell colSpan={11} style={{ paddingBottom: 0, paddingTop: 0 }}>
                                                <Collapse in={expandedRows[task.taskId]} timeout="auto" unmountOnExit>
                                                    <Card sx={{ width: "99%", p: 2, boxShadow: 3, m: 2 }}>
                                                        <TableContainer component={Paper} elevation={0}>
                                                            <Table size="small">
                                                                <TableHead>
                                                                    <TableRow>
                                                                        <TableCell>
                                                                            <Typography variant="body1" fontWeight="bold">
                                                                                Description
                                                                            </Typography>
                                                                        </TableCell>
                                                                    </TableRow>
                                                                </TableHead>
                                                                <TableBody>
                                                                    <TableRow>
                                                                        <TableCell sx={{ border: "none" }}>
                                                                            {task.description}
                                                                        </TableCell>
                                                                    </TableRow>
                                                                </TableBody>
                                                            </Table>
                                                        </TableContainer>
                                                    </Card>
                                                </Collapse>
                                            </TableCell>
                                        </TableRow>
                                    </React.Fragment>
                                ))}
                            </TableBody>
                        </Table>
                    </TableContainer>
                    <Box display="flex" justifyContent="center" mt={2} mb={1}>
                        <Pagination
                            count={totalSubTasksPages}
                            sx={{
                                '& .MuiPaginationItem-root': {
                                    color: 'rgb(73, 102, 131) !important',
                                    borderColor: 'rgb(73, 102, 131) !important',
                                },
                                '& .MuiPaginationItem-root.Mui-selected': {
                                    backgroundColor: 'rgb(73, 102, 131) !important',
                                    color: '#fff !important',
                                },
                            }}
                            onChange={(_, newPage) => handleSubTasksPageChange(newPage)}
                        />
                    </Box>
                </Box>
            )}

            {meetingsList.length > 0 && (
                <Box sx={{ p: { xs: 2, sm: 3, md: 4 } }}>
                    <Box sx={{ backgroundColor: '#e1e5eb', color: '#496683', borderRadius: 1, boxShadow: 1, mb: 4, px: 2, py: 1, }} >
                        <Typography variant="h5" sx={{ fontWeight: 'bold', textAlign: 'left', }} >
                            Meeting Details
                        </Typography>
                    </Box>
                    <TableContainer sx={{ minHeight: "30vh" }}>
                        <Table size="small">
                            <TableHead>
                                <TableRow sx={{ background: "rgb(246, 247, 251)", height: 60 }}>
                                    <TableCell sx={{ fontWeight: "bold", width: 100, textAlign: "center" }}>
                                        SR.NO
                                    </TableCell>
                                    <TableCell sx={{ fontWeight: "bold", width: 200, whiteSpace: "nowrap" }}>
                                        MEETING ID AND NAME
                                    </TableCell>
                                    <TableCell sx={{ fontWeight: "bold", width: 200, whiteSpace: "nowrap" }}>
                                        PROJECT ID AND NAME
                                    </TableCell>
                                    <TableCell sx={{ fontWeight: "bold", width: 150, whiteSpace: "nowrap" }}>
                                        HOST ID AND NAME
                                    </TableCell>
                                    <TableCell sx={{ fontWeight: "bold", width: 200, whiteSpace: "nowrap" }}>
                                        DESIGNATION & DEPARTMENT
                                    </TableCell>
                                    <TableCell sx={{ fontWeight: "bold", width: 200, whiteSpace: "nowrap" }}>
                                        DATE, FROM TIME - TO TIME
                                    </TableCell>
                                    <TableCell sx={{ fontWeight: "bold", width: 120, whiteSpace: "nowrap" }}>
                                        LOCATION
                                    </TableCell>
                                    <TableCell sx={{ fontWeight: "bold", width: 150, textAlign: "center" }}>
                                        STATUS
                                    </TableCell>
                                    <TableCell sx={{ fontWeight: "bold", width: 150, whiteSpace: "nowrap" }}>
                                        AGENDA
                                    </TableCell>
                                    <TableCell sx={{ fontWeight: "bold", width: 100, textAlign: "center" }}>
                                        ACTION
                                    </TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {paginatedMeetings.map((meeting, index) => (
                                    <TableRow key={meeting.id} sx={{ height: 55 }}>
                                        <TableCell align="center">
                                            {(meetingsPage - 1) * itemsPerPage + index + 1}
                                        </TableCell>
                                        <TableCell
                                            sx={{
                                                maxWidth: 200,
                                                whiteSpace: "nowrap",
                                                overflow: "hidden",
                                                textOverflow: "ellipsis",
                                            }}
                                        >
                                            {`${meeting.meetingId} - ${meeting.meetingName}`}
                                        </TableCell>
                                        <TableCell
                                            sx={{
                                                maxWidth: 200,
                                                whiteSpace: "nowrap",
                                                overflow: "hidden",
                                                textOverflow: "ellipsis",
                                            }}
                                        >
                                            {`${meeting.tasksDto?.taskId} - ${meeting.tasksDto?.taskName}`}
                                        </TableCell>
                                        <TableCell
                                            sx={{
                                                maxWidth: 150,
                                                whiteSpace: "nowrap",
                                                overflow: "hidden",
                                                textOverflow: "ellipsis",
                                            }}
                                        >
                                            {meeting.hostIdName}
                                        </TableCell>
                                        <TableCell
                                            sx={{
                                                maxWidth: 200,
                                                whiteSpace: "nowrap",
                                                overflow: "hidden",
                                                textOverflow: "ellipsis",
                                            }}
                                        >
                                            {`${meeting.designation} - ${meeting.departmentName}`}
                                        </TableCell>
                                        <TableCell
                                            sx={{
                                                maxWidth: 200,
                                                whiteSpace: "nowrap",
                                                overflow: "hidden",
                                                textOverflow: "ellipsis",
                                            }}
                                        >
                                            <div>{moment(meeting.date).format('DD MMM YYYY')}</div>
                                            <div>
                                                {moment(meeting.fromTime, 'HH:mm:ss').format('h:mm A')} -{' '}
                                                {moment(meeting.toTime, 'HH:mm:ss').format('h:mm A')}
                                            </div>
                                        </TableCell>
                                        <TableCell
                                            sx={{
                                                maxWidth: 120,
                                                whiteSpace: "nowrap",
                                                overflow: "hidden",
                                                textOverflow: "ellipsis",
                                            }}
                                        >
                                            {meeting.location}
                                        </TableCell>
                                        <TableCell align="center">
                                            <Tooltip title={meeting.meetingStatus} {...tooltipProps} disableHoverListener={meeting.meetingStatus.length <= 10} >
                                                <span>
                                                    <StatusChip status={meeting.meetingStatus} />
                                                </span>
                                            </Tooltip>

                                        </TableCell>

                                        <TableCell
                                            sx={{
                                                maxWidth: 150,
                                                whiteSpace: "nowrap",
                                                overflow: "hidden",
                                                textOverflow: "ellipsis",
                                            }}
                                        >
                                            {meeting.agenda}
                                        </TableCell>
                                        <TableCell>
                                            <Box display="flex" gap={1} justifyContent="center">
                                                <IconButton
                                                    color="default"
                                                    onClick={() => handleAttendeesClick(meeting.id)}
                                                    title="Attendees"
                                                >
                                                    <PeopleOutlineRounded fontSize="medium" color="info" />
                                                </IconButton>
                                                {meeting.meetingStatus === 'Completed' && (
                                                    <IconButton
                                                        color="default"
                                                        onClick={() => handleMomLinkClick(meeting.meetingId)}
                                                        title="MOM"
                                                    >
                                                        <AssignmentOutlined fontSize="medium" color="warning" />
                                                    </IconButton>
                                                )}
                                            </Box>
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </TableContainer>
                    <Box display="flex" justifyContent="center" mt={2} mb={1}>
                        <Pagination
                            count={totalMeetingsPages}
                            
                            sx={{
                                '& .MuiPaginationItem-root': {
                                    color: 'rgb(73, 102, 131) !important',
                                    borderColor: 'rgb(73, 102, 131) !important',
                                },
                                '& .MuiPaginationItem-root.Mui-selected': {
                                    backgroundColor: 'rgb(73, 102, 131) !important',
                                    color: '#fff !important',
                                },
                            }}
                            onChange={(_, newPage) => handleMeetingsPageChange(newPage)}
                        />
                    </Box>
                </Box>
            )}

            {showMomLinkModal && selectedMeetingId && (
                <MomLink meetingId={selectedMeetingId} onClose={handleCloseMomLinkModal} />
            )}
            {showAttendeesModal && selectMeetingId && (
                <AttendeesPopup id={selectMeetingId} onClose={handleCloseAttendeesModal} />
            )}
        </Paper>
    );
};

export default ViewPage;