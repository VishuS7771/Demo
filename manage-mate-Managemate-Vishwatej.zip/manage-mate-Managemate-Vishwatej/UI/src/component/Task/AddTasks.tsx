import React, { useState, useEffect, useRef } from "react";
import { createTask, Modules, Task } from "../../Interfaces/Task";
import { addTask, getmModuleList, getTaskByTaskId, updateTask } from "../../Requests/TaskRequest";
import { toast, ToastContainer } from "react-toastify";
import { EmployeeData } from "../../Interfaces/Login";
import { usePageLoader } from "../../context/PageLoaderContext";
import { useParams, useNavigate } from "react-router-dom";
import { Box, Typography, Grid, TextField, MenuItem, Button, Paper, InputAdornment } from "@mui/material";
import { ListAlt, Apps, UploadFile, Devices, Subject, LowPriorityOutlined, AssignmentIndOutlined, DescriptionOutlined, Save } from "@mui/icons-material";
import { DropZone } from "../../util/constants/commonStyles";

const AddTasks: React.FC = () => {
  const [task, setTask] = useState<Partial<Task>>({});
  const [module, setModules] = useState<Modules[]>([]);
  const [empId, setEmpId] = useState<number | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const [employee, setEmployee] = useState<EmployeeData | null>(null);
  const { TaskId } = useParams<{ TaskId: string }>();
  const { showLoader, hideLoader } = usePageLoader();
  const [isDragging, setIsDragging] = useState(false);
  const [errors, setErrors] = useState<Partial<Record<keyof Task, string>>>({});
  const navigate = useNavigate();

  useEffect(() => {
    const fetchTask = async () => {
      if (TaskId !== "0") {
        try {
          showLoader();
          const taskData = await getTaskByTaskId(TaskId);
          setTask({
            id: taskData.id,
            taskId: taskData.taskId,
            taskName: taskData.taskName,
            requirementType: taskData.requirementType,
            moduleId: taskData.moduleId,
            moduleName: taskData.moduleName,
            requirementSubject: taskData.requirementSubject,
            platform: taskData.platform,
            taskPriority: taskData.taskPriority,
            requirementInDetail: taskData.requirementInDetail,
            employeeId: taskData.employeeId,
            designationId: taskData.designationId,
            departmentId: taskData.departmentId,
            mobileNo: taskData.mobileNo,
            emailId: taskData.emailId,
            raisedBy: taskData.raisedBy,
          });
        } catch (error) {
          console.error("Error fetching task:", error);
          toast.error("Failed to load task details.");
        } finally {
          hideLoader();
        }
      }
    };
    fetchTask();
  }, [TaskId]);

  useEffect(() => {
    updateEmployee();
  }, []);

  useEffect(() => {
    if (empId) {
      getmModuleList(empId)
        .then((response) => setModules(response.data))
        .catch((error) => console.error("Error fetching module list:", error));
    }
  }, [empId]);

  const updateEmployee = () => {
    const storedData = localStorage.getItem("employeedata");
    if (storedData) {
      try {
        const parsedData = JSON.parse(storedData);
        setEmpId(parsedData.EmployeeNo || 0);
        setTask((prevTask) => ({
          ...prevTask,
          employeeId: parsedData.EmployeeNo || "",
          designationId: parsedData.DesignationId || "",
          departmentId: parsedData.DepartmentId || "",
          mobileNo: parsedData.MobileNo1 || "",
          emailId: parsedData.CompanyEmail || "",
          raisedBy: parsedData.EmployeeNo || "",
        }));
        setEmployee(parsedData);
      } catch (error) {
        console.error("Error parsing employee data from localStorage:", error);
      }
    } else {
      console.log("No employee data found in localStorage");
    }
  };

  const validateForm = (): boolean => {
    const newErrors: Partial<Record<keyof Task, string>> = {};

    if (!task.taskName?.trim()) {
      newErrors.taskName = "Project Name is required";
    }
    if (!task.requirementType) {
      newErrors.requirementType = "Requirement Type is required";
    }
    if (task.requirementType === "Enhancement and Observation (Error)" && !task.moduleId) {
      newErrors.moduleId = "Module is required";
    }
    if (task.requirementType === "New Requirement" && !task.moduleName?.trim()) {
      newErrors.moduleName = "Module Name is required";
    }
    if (!task.requirementSubject?.trim()) {
      newErrors.requirementSubject = "Requirement Subject is required";
    }
    if (!task.platform) {
      newErrors.platform = "Platform is required";
    }
    if (!task.taskPriority) {
      newErrors.taskPriority = "Project Priority is required";
    }
    if (!task.requirementInDetail?.trim()) {
      newErrors.requirementInDetail = "Requirement In Detail is required";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setTask((prevTask) => ({ ...prevTask, [name]: value }));
    setErrors((prevErrors) => ({ ...prevErrors, [name]: "" }));
  };

  const handleModuleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value } = e.target;
    if (task.requirementType === "Enhancement and Observation (Error)") {
      const selectedModule = module.find((mod) => mod.id === parseInt(value, 10));
      setTask((prevTask) => ({
        ...prevTask,
        moduleId: value,
        moduleName: selectedModule?.moduleName,
      }));
    } else {
      setTask((prevTask) => ({
        ...prevTask,
        moduleId: "0",
        moduleName: value,
      }));
    }
    setErrors((prevErrors) => ({ ...prevErrors, moduleId: "", moduleName: "" }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFile(file);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile) {
      setFile(droppedFile);
      if (fileInputRef.current) {
        const dataTransfer = new DataTransfer();
        dataTransfer.items.add(droppedFile);
        fileInputRef.current.files = dataTransfer.files;
      }
    }
  };

  const handleClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) {
      return;
    }
    showLoader();
    try {
      if (TaskId !== "0") {
        const response = await updateTask(task);
        if (response.data.httpStatus === "OK") {
          toast.success("Project updated successfully!");
          if (employee) setTask(createTask(employee));
          navigate("/ui/BaTray");
        } else {
          toast.error(`Error: ${response.data.message}`);
        }
      } else {
        const response = await addTask(task, file);
        if (response.data.httpStatus === "OK") {
          toast.success("Project added successfully!");
          if (employee) setTask(createTask(employee));
        } else {
          toast.error(`Error: ${response.data.message}`);
        }
      }
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
      setFile(null);
      setErrors({});
    } catch (error) {
      toast.error(`Error: ${error}`);
    } finally {
      hideLoader();
    }
  };

  const handleClear = () => {
    if (employee) setTask(createTask(employee));
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
    setFile(null);
    setErrors({});
  };

  return (
    <Paper
      elevation={3}
      sx={{
        pl: 14, pt: 5, pb: 3, pr: 14,

        borderRadius: 2,
        minHeight: "84vh",
        boxShadow: "",
        overflow: "hidden",
        overflowX:"auto"
      }}
    >
      <ToastContainer />
      <Box component="form" onSubmit={handleSubmit}>
        <Typography variant="h5" align="left" sx={{ fontWeight: "bold", pb: 3 }}>
          {TaskId !== "0" ? "Edit Project Detail" : "Add Project Detail"}
        </Typography>
        <Grid container spacing={{ xs: 2, sm: 3, md: 4, lg: 5 }}>
          <Grid item xs={12} lg={6} minWidth={"400px"}>
            <TextField
              fullWidth
              name="taskName"
              label="Project Name"
              placeholder="Project Name"
              value={task.taskName || ""}
              onChange={handleChange}
              variant="outlined"
              error={!!errors.taskName}
              helperText={errors.taskName || ""}
              slotProps={{
                input: {
                  startAdornment: (
                    <InputAdornment position="start">
                      <AssignmentIndOutlined />
                    </InputAdornment>
                  ),
                }
              }}
              sx={{
                "& .MuiInputBase-root": {
                  fontSize: { xs: "0.875rem", sm: "1rem" },
                },
              }}
            />
          </Grid>
          <Grid item xs={12} lg={6} minWidth={"400px"}>
            <TextField
              select
              fullWidth
              label="Requirement Type"
              name="requirementType"
              value={task.requirementType || ""}
              onChange={handleChange}
              variant="outlined"
              error={!!errors.requirementType}
              helperText={errors.requirementType || ""}
              slotProps={{
                input: {
                  startAdornment: (
                    <InputAdornment position="start">
                      <ListAlt />
                    </InputAdornment>

                  ),
                }
              }}
              sx={{
                "& .MuiInputBase-root": {
                  fontSize: { xs: "0.875rem", sm: "1rem" },
                },
              }}
            >
              <MenuItem value="">Select Requirement Type</MenuItem>
              <MenuItem value="New Requirement">New Requirement</MenuItem>
              <MenuItem value="Enhancement and Observation (Error)">
                Enhancement and Observation (Error)
              </MenuItem>
            </TextField>
          </Grid>
          {task.requirementType === "Enhancement and Observation (Error)" && (
            <Grid item xs={12} lg={6} minWidth={"400px"}>
              <TextField
                select
                fullWidth
                label="Module"
                name="moduleId"
                value={task.moduleId || ""}
                onChange={handleModuleChange}
                variant="outlined"
                error={!!errors.moduleId}
                helperText={errors.moduleId || ""}
                slotProps={{
                  input: {
                    startAdornment: (
                      <InputAdornment position="start">
                        <Apps />
                      </InputAdornment>
                    ),
                  }
                }}
                SelectProps={{
                  MenuProps: {
                    disablePortal: true,
                    PaperProps: {
                      sx: {
                        maxHeight: 300,
                        maxWidth: "90vw",
                      },
                    },
                  },
                }}
                sx={{
                  "& .MuiInputBase-root": {
                    fontSize: { xs: "0.875rem", sm: "1rem" },
                  },
                }}
              >
                <MenuItem value="">Select Module</MenuItem>
                {module.map((mod) => (
                  <MenuItem key={mod.id} value={mod.id}>
                    {mod.moduleName}
                  </MenuItem>
                ))}
              </TextField>
            </Grid>
          )}
          {task.requirementType === "New Requirement" && (
            <Grid item xs={12} lg={6} minWidth={"400px"}>
              <TextField
                fullWidth
                label="Module Name"
                name="moduleName"
                placeholder="Module Name"
                value={task.moduleName || ""}
                onChange={handleChange}
                variant="outlined"
                error={!!errors.moduleName}
                helperText={errors.moduleName || ""}
                slotProps={{
                  input: {
                    startAdornment: (
                      <InputAdornment position="start">
                        <Apps />
                      </InputAdornment>

                    ),
                  }
                }}
                sx={{
                  "& .MuiInputBase-root": {
                    fontSize: { xs: "0.875rem", sm: "1rem" },
                  },
                }}
              />
            </Grid>
          )}
          <Grid item xs={12} lg={6} minWidth={"400px"}>
            <TextField
              fullWidth
              label="Requirement Subject"
              name="requirementSubject"
              placeholder="Requirement Subject"
              value={task.requirementSubject || ""}
              onChange={handleChange}
              variant="outlined"

              error={!!errors.requirementSubject}
              helperText={
                errors.requirementSubject ||
                `${task.requirementSubject?.length || 0} / 100 characters used`
              }
              slotProps={{
                input: {
                  startAdornment: (
                    <InputAdornment position="start">
                      <Subject />
                    </InputAdornment>
                  ),
                  inputProps: { maxLength: 100 }
                }
              }}
              sx={{
                "& .MuiInputBase-root": {
                  fontSize: { xs: "0.875rem", sm: "1rem" },
                },
              }}
            />
          </Grid>
          <Grid item xs={12} lg={6} minWidth={"400px"}>
            <TextField
              select
              fullWidth
              label="Platform"
              name="platform"
              value={task.platform || ""}
              onChange={handleChange}
              variant="outlined"
              error={!!errors.platform}
              helperText={errors.platform || ""}
              slotProps={{
                input: {
                  startAdornment: (
                    <InputAdornment position="start">
                      <Devices />
                    </InputAdornment>
                  ),
                }
              }}
              sx={{
                "& .MuiInputBase-root": {
                  fontSize: { xs: "0.875rem", sm: "1rem" },
                },
              }}
            >
              <MenuItem value="">Select Platform</MenuItem>
              <MenuItem value="WEB">WEB</MenuItem>
              <MenuItem value="APP">APP</MenuItem>
              <MenuItem value="BOTH">BOTH</MenuItem>
            </TextField>
          </Grid>
          <Grid item xs={12} lg={6} minWidth={"400px"}>
            <TextField
              select
              fullWidth
              label="Project Priority"
              name="taskPriority"
              value={task.taskPriority || ""}
              onChange={handleChange}
              variant="outlined"
              error={!!errors.taskPriority}
              helperText={errors.taskPriority || ""}
              slotProps={{
                input: {
                  startAdornment: (
                    <InputAdornment position="start">
                      <LowPriorityOutlined />
                    </InputAdornment>
                  ),
                }
              }}
              sx={{
                "& .MuiInputBase-root": {
                  fontSize: { xs: "0.875rem", sm: "1rem" },
                },
              }}
            >
              <MenuItem value="">Select Project Priority</MenuItem>
              <MenuItem value="High">High</MenuItem>
              <MenuItem value="Medium">Medium</MenuItem>
              <MenuItem value="Low">Low</MenuItem>
              <MenuItem value="Critical">Critical</MenuItem>
            </TextField>
          </Grid>
          <Grid item xs={12} sm={12} lg={6} minWidth={"400px"}>
            <TextField
              fullWidth
              label="Requirement In Detail"
              name="requirementInDetail"
              placeholder="Requirement In Detail"
              value={task.requirementInDetail || ""}
              onChange={handleChange}
              variant="outlined"
              multiline
              maxRows={5}
              error={!!errors.requirementInDetail}
              helperText={
                errors.requirementInDetail ||
                `${task.requirementInDetail?.length || 0} / 10000 characters used`
              }
              slotProps={{
                input: {
                  startAdornment: (
                    <InputAdornment position="start">
                      <DescriptionOutlined />
                    </InputAdornment>
                  ),
                  inputProps: { maxLength: 10000 }
                }
              }}
              sx={{
                "& .MuiInputBase-root": {
                  fontSize: { xs: "0.875rem", sm: "1rem" },
                  resize: "vertical",
                  minHeight: "56px",
                },
                "& .MuiInputBase-input": {
                  overflow: "auto",
                },
              }}
            />
          </Grid>
          {TaskId === "0" && (
            <Grid item sm={12} lg={12} minWidth={"400px"} mt={-2}>
              <Typography
                variant="subtitle2"
                sx={{
                  color: "text.secondary",
                  fontSize: { xs: "0.75rem", sm: "0.875rem" },
                }}
              >
                Add Attachment
              </Typography>
              <DropZone
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                onClick={handleClick}
                className={isDragging ? "dragover" : ""}
                sx={{
                  py: { xs: 1.5, sm: 2 },
                  px: { xs: 1, sm: 2 },
                  fontSize: { xs: "0.875rem", sm: "1rem" },
                }}
              >
                <Typography
                  variant="body1"
                  sx={{ fontSize: { xs: "0.875rem", sm: "1rem" } }}
                >
                  <UploadFile sx={{ mr: 1, fontSize: { xs: "1rem", sm: "1.25rem" } }} />
                  {file ? file.name : "Drag & drop a file here or Click to select"}
                </Typography>
                <input
                  type="file"
                  name="attachmentPath"
                  onChange={handleFileChange}
                  ref={fileInputRef}
                  style={{ display: "none" }}
                />
              </DropZone>
            </Grid>
          )}
          <Grid item xs={12} minWidth={"400px"}>
            <Box
              sx={{
                display: "flex",
                justifyContent: { xs: "center", sm: "flex-end" },
                gap: 2,
                flexWrap: "wrap",
              }}
            >
              <Button
                type="submit"
                variant="contained"
                color="primary"
                startIcon={<Save />}
                sx={{
                  px: { xs: 2, sm: 3 },
                  py: 1,
                  fontSize: { xs: "0.75rem", sm: "0.875rem" },
                  textTransform: "none",
                  minWidth: { xs: "120px", sm: "140px" },
                }}
              >
                {TaskId !== "0" ? "Update Project" : "Save Project"}
              </Button>
              <Button
                variant="outlined"
                color="error"
                onClick={handleClear}
                sx={{
                  px: { xs: 2, sm: 3 },
                  py: 1,
                  fontSize: { xs: "0.75rem", sm: "0.875rem" },
                  textTransform: "none",
                  minWidth: { xs: "120px", sm: "140px" },
                }}
              >
                Clear
              </Button>
            </Box>
          </Grid>
        </Grid>
      </Box>
    </Paper>
  );
};

export default AddTasks;
