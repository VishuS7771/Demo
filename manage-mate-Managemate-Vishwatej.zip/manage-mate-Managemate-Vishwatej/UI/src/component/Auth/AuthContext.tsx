import { createContext, useState, useEffect, ReactNode } from 'react';
import { EmployeeData } from '../../Interfaces/Login';

interface AuthContextType {
  isAuthenticated: boolean;
  EmpId: string | null;
  employee: EmployeeData | null;
  setIsAuthenticated: (auth: boolean) => void;
  setEmployee: (employee: EmployeeData | null) => void;
}

export const AuthContext = createContext<AuthContextType>({
  isAuthenticated: false,
  EmpId: null,
  employee: null,
  setIsAuthenticated: () => {},
  setEmployee: () => {},
});

interface AuthProviderProps {
  children: ReactNode;
}

const AuthProvider = ({ children }: AuthProviderProps) => {
  const [isAuthenticated, setIsAuthenticatedState] = useState<boolean>(false);
  const [employee, setEmployeeState] = useState<EmployeeData | null>(null);

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      const storedData = localStorage.getItem('employeedata');
      const parsedData = storedData ? JSON.parse(storedData) : null;
      setEmployeeState(parsedData);
      setIsAuthenticatedState(true);
    }
  }, []);

  const setIsAuthenticated = (auth: boolean) => {
    setIsAuthenticatedState(auth);
  };

  const setEmployee = (employee: EmployeeData | null) => {
    setEmployeeState(employee);
    if (employee) {
      localStorage.setItem('employeedata', JSON.stringify(employee));
    } else {
      localStorage.removeItem('employeedata');
    }
  };

  return (
    <AuthContext.Provider value={{ isAuthenticated, EmpId: employee?.EmployeeNo ?? null, employee, setIsAuthenticated, setEmployee }}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthProvider;
