export interface MenuPermission{
    menuPermissionId:number;
    employeeId:number;
    isStatus:boolean;
    isSubStatus:boolean;
    isProprietor:boolean;
    isAssign:boolean;
    isUser:boolean;
    isDashboard:boolean;
    isTask:boolean;
    isProject:boolean;
    isReport:boolean;
    isModule:boolean;
    isGeneralMeeting:boolean;
    }
    export interface MenuPermissionAccess{
        id:number;
        employeeId:number;
    }
    