
import { MeetingParticipantsDto } from "./Meeting";

export interface SegmentOption {
  value: number;
  label: string;
}

export interface DepartmentOption {
  value: number;
  label: string;
}

export interface HostOption {
    label: string;
    value: string;
}
export interface AssigneeOption {
    label: string;
    value: string;
}
export interface GeneralMeetingsDto {
  hostId: any;
  id: number;
  meetingId: string;
  meetingName: string;
  agenda: string;
  employeeId: number[];
  date: string;
  meetingDate: string;
  fromTime: string;
  toTime: string;
  location: string;
  link: string;
  remarks: string;
  createdBy: number;
  reasonForCancellation: string;
  mom: string;
  meetingStatus: string;
  meetingParticipantsDtoList: MeetingParticipantsDto[];
  createdOn: string;
  hostIdName: string
  designation: string
  scheduledBy: number
  departmentDtos: MasterDto[]
  segmentDtos: MasterDto[]
  path: string
}

export interface MasterDto {
  id: number;
  name: string;
}

export interface MeetingStatusMarkDto {
  status: string
  generalMeetingId: number
  mom: string
  reasonForCancellation: string
  employeeIds: number[];
  markedBy: string
  generalMeetingTaskDto: GeneralMeetingTaskDto[]
}

export interface GeneralMeetingTaskDto {
  generalMeetingTaskId: number
  taskName: string
  generalMeetingName: string
  remark: string
  targetDate: string
  employeeIds: number[]
  createdOn: string
  status: string
  createdBy: string
  generalMeetingId: string
  meetingTaskAssigneeDtos: MeetingTaskAssigneeDtos[]
  completionDate: string
  departmentDtos: MasterDto[]
  segmentDtos: MasterDto[]
}
export interface EmployeeOption {
  value: number;
  label: string;
}

export interface ValidationError { status?: string; reasonForCancellation?: string; mom?: string; participants?: string }

export interface TaskValidationError {
  status?: string
  taskName?: string
  employeeIds?: string
  remark?: string
  targetDate?: string
  department?: string
  segment?: string
}
export interface TaskStatus {
  generalMeetingTaskId: number
  taskName: string
  remark: string
  targetDate: string
  employeeIds: EmployeeOption[]
  createdOn: string
  status: string
  createdBy: string
}

export interface MeetingTaskAssigneeDtos {
  meetingTaskAssigneeId: number
  empId: number
  employeeName: string
  employeeImgUrl: string
}

// meeting status interfaces 


export interface MeetingParticipant {
  meetingParticipantId: number;
  meetingsDto: any | null;
  employeeId: number;
  assignedBy: number;
  assignedDate: string;
  participantName: string | null;
  designation: string | null;
  departmentName: string | null;
  isActive: number;
}

export interface MeetingData {
  id: number;
  meetingId: string;
  meetingName: string;
  agenda: string;
  employeeId: number | null;
  date: string | null;
  fromTime: string;
  toTime: string;
  location: string;
  link: string;
  remarks: string;
  createdBy: number;
  scheduledBy: number
  meetingStatus: string | null;
  reasonForCancellation: string | null;
  mom: string | null;
  hostIdName: string | null;
  designation: string | null;
  departmentDtos: any | null;
  segmentDtos: any | null;
  meetingParticipantsDtoList: MeetingParticipant[];
  createdOn: string;
}

export interface TaskRespondDto {
  taskRespondId: number
  remark: string
  respondedBy: string
  respondedOn: string
  filePath: string
  Marking: boolean
  Respond: boolean
  meetingTaskId: number
  status: string
}

// Interface for meetingStatusMark items
export interface MeetingStatusMark {
  meetingName: string;
  status: string;
  markedOn: string;
  markedBy: string;
}

// Interface for meetingTaskStatus items
export interface MeetingTaskStatus {
  meetingTaskSubStatus?: string;
  taskStatus: string;
  markedOn: string;
  markedBy: string;
}

// Interface for generalMeetingTask items
export interface GeneralMeetingTask {
  meetingTaskStatus: MeetingTaskStatus[];
}

// Interface for the main data structure (inside "data")
export interface MeetingTimelineData {
  meetingStatusMark: MeetingStatusMark[];
  generalMeetingTask: GeneralMeetingTask[];
}

// Interface of task completion date obj
export interface CompletionDatePayload {
  completionDate: Date;
  generalMeetingTaskId: number;
  markedBy: string;
  remarks: string
}

export interface GeneralMeetingReportDTO {
    reportType: string;
    segment: string[];
    department: string[];
    assignedBy: number[];
    assignee: number[];
    attendees: number[];
    hosts: number[];
    meetingDateFrom: string | null;
    meetingDateTo: string | null;
    taskAssignedDateFrom: string | null;
    taskAssignedDateTo: string | null;
    empId:number
}