export interface LoginDto{
 username:string,
 password:string
}

export interface EmployeeData {
    EmployeeNo: string;
    EmployeeName: string;
    EmployeeFullName: string;
    DesignationId: string;
    Designation: string;
    Company: string;
    DepartmentId: string;
    DepartmentName: string;
    Department: string;
    JoiningDate: string; 
    BirthDate: string;
    MobileNo1: string;
    MobileNo2: string;
    Gender: string;
    CurrentAddress: string;
    PermentantAddress: string;
    CompanyEmail: string;
    PersonalEmail: string;
    State: string;
    Branch: string;
    Product: string;
    ReportingManager: string;
    Manager: string;
    HRManager: string;
    PayrollManager: string;
    ImageUrl: string;
  }