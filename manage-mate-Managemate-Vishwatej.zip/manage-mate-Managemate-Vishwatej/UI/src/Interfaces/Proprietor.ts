import { PropriotorDto, StatusDefinitionsDto, SubStatusDefinitionsDto, TrayMasterDto } from "./Task";

export interface ProprietorAssignmentsDto {
    proprietorMappingId: number;
    statusDefinitionsDto: StatusDefinitionsDto;
    subStatusDefinitionsDto: SubStatusDefinitionsDto;
    proprietorMasterDto: PropriotorDto;
    trayMasterDto: TrayMasterDto;
    isActive: number;
    createdBy: number;
    createdOn: string;
  }
