import { Task } from "./Task";

export interface MeetingsDto {
  id: number;
  meetingId: string;
  meetingName: string;
  agenda: string;
  employeeId: number[];
  date: string;
  fromTime: string;
  toTime: string;
  location: string;
  link: string;
  tasksDto: Task|null;
  remarks: string;
  createdBy: number;
  meetingStatus: string;
  reasonForCancellation: string;
  mom: string;
  meetingParticipantsDtoList: MeetingParticipantsDto[];
  createdOn: string;
  hostIdName:string
  designation:string
  departmentName:string
}
export interface MeetingParticipantsDto {
  meetingParticipantId: number;
  meetingsDto: MeetingsDto; 
  employeeId: number;
  assignedBy: number;
  isActive: number;
  assignedDate: string;
  participantName:string;
  designation:string;
  departmentName:string;
  employeeImgUrl:string;
}
