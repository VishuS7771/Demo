import { AssigneeOption, DepartmentOption, HostOption, SegmentOption } from "./Generalmeeting";
import { EmployeeData } from "./Login";

export interface Task {
  id: number,
  taskId: string;
  taskName: string;
  employeeId: string;
  designationId: string;
  departmentId: string;
  mobileNo: string;
  emailId: string;
  requirementType: string;
  moduleId: string;
  moduleName: string;
  requirementSubject: string;
  requirementInDetail: string;
  platform: string;
  taskPriority: string;
  attachmentPath: string | null;
  raisedBy: string;
  remarks: string;
  startDate: string;
  toDate: string;
  dateAndTime: string;
  tentativeEndDate: Date | null;
  description: string;
  assignedTo: number;
  additionalRequirementDtos: AdditonalRequirement[];
  taskTimelineDto: TaskTimelineDto[];
  taskAssignmentHistoryDto: TaskAssignmentHistoryDto[];
  subTaskStatusDtos: SubTaskStatusMarkDto[]
  onlySubTaskUser: boolean;
  raisedByName: string;
  departmentAndDesignation: string;
}

export interface searchCriteriaProps {
  taskId: string;
  taskName: string;
  fromDate: string;
  toDate: string;
  status: string[];
  subStatus: string[];
  employeeId: number | null;
}

export interface searchGeneralTaskCriteriaProps {
  taskName: string;
  employeeName: string;
  employeeId: number | null;
  taskAssignee: string,
  status: string[];
  taskAssigneeId: number | null;
}


export interface meetingSearchCriteriaProps {
  meetingId: string;
  meetingName: string;
  hostId: string;
  hostName: string;
  fromDate: string;
  toDate: string;
  status: string[];
}
export interface GeneralMeetingSearchCriteriaProps {
  meetingId: string;
  meetingName: string;
  hostId: string;
  hostName: string;
  fromDate: string;
  toDate: string;
  status: string[];
  segments: SegmentOption[];
  departments: DepartmentOption[];
  host: HostOption[];
  assignees: AssigneeOption[];
}
export interface TrayMasterDto {
  trayId: number;
  trayName: string;
  isActive: number;
  createdBy: number;
  createdOn: string;
}

export interface StatusDefinitionsDto {
  statusId: number;
  status: string;
  createdBy: number;
  trayMasterDto: TrayMasterDto;
  createdOn: string;
  isActive: number;
}

export interface SubStatusDefinitionsDto {
  subStatusId: number;
  subStatus: string;
  statusDefinitionsDto: StatusDefinitionsDto;
  createdBy: number;
  createdOn: string;
  isActive: number;
  trayMasterDto: TrayMasterDto;
}

export interface PropriotorAssignment {
  proprietorMappingId: number;
  statusDefinitionsDto: StatusDefinitionsDto;
  subStatusDefinitionsDto: SubStatusDefinitionsDto;
  proprietorMasterDto: PropriotorDto;
  trayMasterDto: TrayMasterDto;
  isActive: number;
  createdBy: number;
  createdOn: string;
}
export interface PropriotorDto {
  proprietorId: number;
  proprietorName: string;
  isActive: string;
  createdBy: string;
  createdOn: string
}

export interface User {
  employeeId: string;
  employeeName: string;
  employeeFullName: string
}

interface StatusOption {
    value: number;
    label: string;
}
export interface SearchCriteria {
    meetingName: string;
    taskName: string;
    assignedDateFrom: string;
    assignedDateTo: string;
    targetDateFrom: string;
    targetDateTo: string;
    completionDateFrom: string;
    completionDateTo: string;
    statuses: StatusOption[];
    employees: User[];
    assignees: User[];
    segments: SegmentOption[];
    departments: DepartmentOption[];
    isOverdue: boolean;
}


export interface employeesType {
  employeeId: string,
  employeeName: string,
  employeeFullName: string,
  designation: string,
  department: string,
  departmentName: string
}

export interface Tray {
  trayId: number;
  trayName: string;
}

export interface TaskAssignmentHistoryDto {
  assignTaskId: number;
  task: Task;
  employeeId: number;
  employeeNameAndId: string;
  assignDate: Date;
  remarks: string;
  assignedBy: number;
  assignedByNameAndId: string;
  isAssigned: number;
  attachmentPath: string
}

export interface TaskTimelineDto {
  taskTimeLineId: number;
  tasks: Task;
  dateAndTime: Date;
  statusDefinitionsDto: StatusDefinitionsDto;
  subStatusDefinitionsDto: SubStatusDefinitionsDto;
  proprietorAssignmentsDto: PropriotorAssignment;
  statusMarkedBy: string;
  proprietorUserId: number
}

export interface TaskTimeLineData {
  taskTimeLineId: number;
  status: string;
  subStatus: string;
  dateAndTime: string
  statusMarkedBy: string;
  proprietorName: string;
}

export interface AdditonalRequirement {
  additionalRequirementId: number
  tasksDto: Task
  requirement: string
  dateAndTime: string
  attachment: string
}

export interface Modules {
  id: number;
  moduleName: string
}

export interface StakeHolderManagementUser {
  id: number;
  userId: number;
  userType: string;
  empName: string;
}

export const createTask = (employee: EmployeeData): Task => ({
  id: 0,
  taskId: '',
  taskName: '',
  employeeId: employee.EmployeeNo,
  designationId: employee.DesignationId,
  departmentId: employee.DepartmentId,
  mobileNo: employee.MobileNo1,
  emailId: employee.CompanyEmail,
  requirementType: '',
  moduleId: '',
  moduleName: '',
  requirementSubject: '',
  requirementInDetail: '',
  platform: '',
  taskPriority: '',
  attachmentPath: '',
  raisedBy: employee.EmployeeNo,
  remarks: '',
  startDate: '',
  toDate: '',
  dateAndTime: '',
  tentativeEndDate: null,
  description: '',
  assignedTo: 0,
  additionalRequirementDtos: [],
  taskTimelineDto: [],
  taskAssignmentHistoryDto: [],
  subTaskStatusDtos: [],
  onlySubTaskUser: false,
  raisedByName: "",
  departmentAndDesignation: "",
});

export interface SubTaskStatusMarkDto {
  subTaskStatusMarkId: number;
  markedStatus: string;
  statusMarkedBy: number;
  tasksDto: Task;
  remark: string;
  statusMarkedDate: Date
}


export interface TaskList {
  taskId: string;
  taskName: string;
}



export interface ReportState {
  reportType: string;
  taskId: string;
  statusId: string[];
  subStatusId: string[];
  dateFrom: Date | null;
  dateTo: Date | null;
}
