export interface ModuleAssignmentDto {
    moduleMappingId: number;
    module: string;
    moduleId: number;
    employeeId: number;
    isActive: number;
    createdBy: number;
    createdOn: string;
    mappedEmployee: string; 
  }
  
